.class public abstract La/nw;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static w(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    return-void
.end method
