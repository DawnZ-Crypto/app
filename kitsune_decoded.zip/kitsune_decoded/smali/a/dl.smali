.class public abstract La/dl;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# static fields
.field public static final l:[I


# instance fields
.field public final K:Z

.field public final L:Landroid/graphics/Rect;

.field public final R:Z

.field public final d:Landroid/graphics/Rect;

.field public final f:La/dh;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const v0, 0x1010031

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, La/dl;->l:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    .line 1
    const v0, 0x7f04030a

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, p1, p2, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Landroid/graphics/Rect;

    .line 8
    .line 9
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v1, p0, La/dl;->L:Landroid/graphics/Rect;

    .line 13
    .line 14
    new-instance v2, Landroid/graphics/Rect;

    .line 15
    .line 16
    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v2, p0, La/dl;->d:Landroid/graphics/Rect;

    .line 20
    .line 21
    new-instance v2, La/dh;

    .line 22
    .line 23
    invoke-direct {v2, p0}, La/dh;-><init>(La/dl;)V

    .line 24
    .line 25
    .line 26
    iput-object v2, p0, La/dl;->f:La/dh;

    .line 27
    .line 28
    sget-object v3, La/YW;->w:[I

    .line 29
    .line 30
    const v4, 0x7f130137

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, p2, v3, v0, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const/4 p2, 0x2

    .line 38
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    const/4 v3, 0x3

    .line 43
    const/4 v4, 0x0

    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    goto :goto_2

    .line 51
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sget-object v5, La/dl;->l:[I

    .line 56
    .line 57
    invoke-virtual {v0, v5}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v0, v4, v4}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 66
    .line 67
    .line 68
    new-array v0, v3, [F

    .line 69
    .line 70
    invoke-static {v5, v0}, Landroid/graphics/Color;->colorToHSV(I[F)V

    .line 71
    .line 72
    .line 73
    aget p2, v0, p2

    .line 74
    .line 75
    const/high16 v0, 0x3f000000    # 0.5f

    .line 76
    .line 77
    cmpl-float p2, p2, v0

    .line 78
    .line 79
    if-lez p2, :cond_1

    .line 80
    .line 81
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 82
    .line 83
    .line 84
    move-result-object p2

    .line 85
    const v0, 0x7f06002d

    .line 86
    .line 87
    .line 88
    :goto_0
    invoke-virtual {p2, v0}, Landroid/content/res/Resources;->getColor(I)I

    .line 89
    .line 90
    .line 91
    move-result p2

    .line 92
    goto :goto_1

    .line 93
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 94
    .line 95
    .line 96
    move-result-object p2

    .line 97
    const v0, 0x7f06002c

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :goto_1
    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 102
    .line 103
    .line 104
    move-result-object p2

    .line 105
    :goto_2
    const/4 v0, 0x0

    .line 106
    invoke-virtual {p1, v3, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 107
    .line 108
    .line 109
    move-result v3

    .line 110
    const/4 v5, 0x4

    .line 111
    invoke-virtual {p1, v5, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    const/4 v6, 0x5

    .line 116
    invoke-virtual {p1, v6, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    const/4 v6, 0x7

    .line 121
    invoke-virtual {p1, v6, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 122
    .line 123
    .line 124
    move-result v6

    .line 125
    iput-boolean v6, p0, La/dl;->K:Z

    .line 126
    .line 127
    const/4 v6, 0x6

    .line 128
    const/4 v7, 0x1

    .line 129
    invoke-virtual {p1, v6, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 130
    .line 131
    .line 132
    move-result v6

    .line 133
    iput-boolean v6, p0, La/dl;->R:Z

    .line 134
    .line 135
    const/16 v6, 0x8

    .line 136
    .line 137
    invoke-virtual {p1, v6, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 138
    .line 139
    .line 140
    move-result v6

    .line 141
    const/16 v8, 0xa

    .line 142
    .line 143
    invoke-virtual {p1, v8, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 144
    .line 145
    .line 146
    move-result v8

    .line 147
    iput v8, v1, Landroid/graphics/Rect;->left:I

    .line 148
    .line 149
    const/16 v8, 0xc

    .line 150
    .line 151
    invoke-virtual {p1, v8, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 152
    .line 153
    .line 154
    move-result v8

    .line 155
    iput v8, v1, Landroid/graphics/Rect;->top:I

    .line 156
    .line 157
    const/16 v8, 0xb

    .line 158
    .line 159
    invoke-virtual {p1, v8, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 160
    .line 161
    .line 162
    move-result v8

    .line 163
    iput v8, v1, Landroid/graphics/Rect;->right:I

    .line 164
    .line 165
    const/16 v8, 0x9

    .line 166
    .line 167
    invoke-virtual {p1, v8, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 168
    .line 169
    .line 170
    move-result v6

    .line 171
    iput v6, v1, Landroid/graphics/Rect;->bottom:I

    .line 172
    .line 173
    cmpl-float v1, v5, v0

    .line 174
    .line 175
    if-lez v1, :cond_2

    .line 176
    .line 177
    move v0, v5

    .line 178
    :cond_2
    invoke-virtual {p1, v4, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 179
    .line 180
    .line 181
    invoke-virtual {p1, v7, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 182
    .line 183
    .line 184
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 185
    .line 186
    .line 187
    new-instance p1, La/pS;

    .line 188
    .line 189
    invoke-direct {p1, v3, p2}, La/pS;-><init>(FLandroid/content/res/ColorStateList;)V

    .line 190
    .line 191
    .line 192
    iput-object p1, v2, La/dh;->K:Ljava/lang/Object;

    .line 193
    .line 194
    iget-object p2, v2, La/dh;->R:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast p2, La/dl;

    .line 197
    .line 198
    invoke-virtual {p2, p1}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 199
    .line 200
    .line 201
    iget-object p1, v2, La/dh;->R:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast p1, La/dl;

    .line 204
    .line 205
    invoke-virtual {p1, v7}, Landroid/view/View;->setClipToOutline(Z)V

    .line 206
    .line 207
    .line 208
    invoke-virtual {p1, v5}, Landroid/view/View;->setElevation(F)V

    .line 209
    .line 210
    .line 211
    iget-object p1, v2, La/dh;->K:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast p1, Landroid/graphics/drawable/Drawable;

    .line 214
    .line 215
    check-cast p1, La/pS;

    .line 216
    .line 217
    iget-object p2, v2, La/dh;->R:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast p2, La/dl;

    .line 220
    .line 221
    iget-boolean p2, p2, La/dl;->K:Z

    .line 222
    .line 223
    invoke-virtual {v2}, La/dh;->F()Z

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    iget v3, p1, La/pS;->i:F

    .line 228
    .line 229
    cmpl-float v3, v0, v3

    .line 230
    .line 231
    if-nez v3, :cond_3

    .line 232
    .line 233
    iget-boolean v3, p1, La/pS;->Q:Z

    .line 234
    .line 235
    if-ne v3, p2, :cond_3

    .line 236
    .line 237
    iget-boolean v3, p1, La/pS;->X:Z

    .line 238
    .line 239
    if-ne v3, v1, :cond_3

    .line 240
    .line 241
    goto :goto_3

    .line 242
    :cond_3
    iput v0, p1, La/pS;->i:F

    .line 243
    .line 244
    iput-boolean p2, p1, La/pS;->Q:Z

    .line 245
    .line 246
    iput-boolean v1, p1, La/pS;->X:Z

    .line 247
    .line 248
    const/4 p2, 0x0

    .line 249
    invoke-virtual {p1, p2}, La/pS;->h(Landroid/graphics/Rect;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 253
    .line 254
    .line 255
    :goto_3
    iget-object p1, v2, La/dh;->R:Ljava/lang/Object;

    .line 256
    .line 257
    check-cast p1, La/dl;

    .line 258
    .line 259
    iget-boolean p1, p1, La/dl;->K:Z

    .line 260
    .line 261
    if-nez p1, :cond_4

    .line 262
    .line 263
    invoke-virtual {v2, v4, v4, v4, v4}, La/dh;->D(IIII)V

    .line 264
    .line 265
    .line 266
    goto :goto_4

    .line 267
    :cond_4
    iget-object p1, v2, La/dh;->K:Ljava/lang/Object;

    .line 268
    .line 269
    check-cast p1, Landroid/graphics/drawable/Drawable;

    .line 270
    .line 271
    check-cast p1, La/pS;

    .line 272
    .line 273
    iget p2, p1, La/pS;->i:F

    .line 274
    .line 275
    iget p1, p1, La/pS;->w:F

    .line 276
    .line 277
    invoke-virtual {v2}, La/dh;->F()Z

    .line 278
    .line 279
    .line 280
    move-result v0

    .line 281
    invoke-static {p2, p1, v0}, La/f4;->w(FFZ)F

    .line 282
    .line 283
    .line 284
    move-result v0

    .line 285
    float-to-double v0, v0

    .line 286
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    .line 287
    .line 288
    .line 289
    move-result-wide v0

    .line 290
    double-to-int v0, v0

    .line 291
    invoke-virtual {v2}, La/dh;->F()Z

    .line 292
    .line 293
    .line 294
    move-result v1

    .line 295
    invoke-static {p2, p1, v1}, La/f4;->h(FFZ)F

    .line 296
    .line 297
    .line 298
    move-result p1

    .line 299
    float-to-double p1, p1

    .line 300
    invoke-static {p1, p2}, Ljava/lang/Math;->ceil(D)D

    .line 301
    .line 302
    .line 303
    move-result-wide p1

    .line 304
    double-to-int p1, p1

    .line 305
    invoke-virtual {v2, v0, p1, v0, p1}, La/dh;->D(IIII)V

    .line 306
    .line 307
    .line 308
    :goto_4
    return-void
.end method

.method public static synthetic w(La/dl;IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    return-void
.end method


# virtual methods
.method public onMeasure(II)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    return-void
.end method

.method public final setMinimumHeight(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setMinimumHeight(I)V

    return-void
.end method

.method public final setMinimumWidth(I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setMinimumWidth(I)V

    return-void
.end method

.method public final setPadding(IIII)V
    .locals 0

    .line 1
    return-void
.end method

.method public final setPaddingRelative(IIII)V
    .locals 0

    .line 1
    return-void
.end method
