.class public abstract La/Jf;
.super Landroidx/activity/w;
.source "SourceFile"

# interfaces
.implements La/yV;


# static fields
.field public static final synthetic n:I


# instance fields
.field public j:Z

.field public final k:La/ze;

.field public s:Z

.field public t:Z

.field public final v:Landroidx/lifecycle/w;


# direct methods
.method public constructor <init>()V
    .locals 5

    .line 1
    invoke-direct {p0}, Landroidx/activity/w;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/Tz;

    .line 5
    .line 6
    move-object v1, p0

    .line 7
    check-cast v1, La/m1;

    .line 8
    .line 9
    invoke-direct {v0, v1}, La/Tz;-><init>(La/m1;)V

    .line 10
    .line 11
    .line 12
    new-instance v2, La/ze;

    .line 13
    .line 14
    const/16 v3, 0x11

    .line 15
    .line 16
    invoke-direct {v2, v3, v0}, La/ze;-><init>(ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iput-object v2, p0, La/Jf;->k:La/ze;

    .line 20
    .line 21
    new-instance v0, Landroidx/lifecycle/w;

    .line 22
    .line 23
    invoke-direct {v0, p0}, Landroidx/lifecycle/w;-><init>(La/RH;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    iput-boolean v0, p0, La/Jf;->t:Z

    .line 30
    .line 31
    iget-object v2, p0, Landroidx/activity/w;->d:La/fj;

    .line 32
    .line 33
    iget-object v2, v2, La/fj;->h:La/VV;

    .line 34
    .line 35
    new-instance v3, La/V0;

    .line 36
    .line 37
    invoke-direct {v3, v0, p0}, La/V0;-><init>(ILjava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    const-string v4, "android:support:lifecycle"

    .line 41
    .line 42
    invoke-virtual {v2, v4, v3}, La/VV;->p(Ljava/lang/String;La/KO;)V

    .line 43
    .line 44
    .line 45
    new-instance v2, La/pk;

    .line 46
    .line 47
    const/4 v3, 0x0

    .line 48
    invoke-direct {v2, v1, v3}, La/pk;-><init>(La/m1;I)V

    .line 49
    .line 50
    .line 51
    iget-object v3, p0, Landroidx/activity/w;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 52
    .line 53
    invoke-virtual {v3, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    new-instance v2, La/pk;

    .line 57
    .line 58
    invoke-direct {v2, v1, v0}, La/pk;-><init>(La/m1;I)V

    .line 59
    .line 60
    .line 61
    iget-object v1, p0, Landroidx/activity/w;->P:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 62
    .line 63
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    new-instance v1, La/PT;

    .line 67
    .line 68
    invoke-direct {v1, p0, v0}, La/PT;-><init>(La/Jf;I)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0, v1}, Landroidx/activity/w;->m(La/oh;)V

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method public static R(La/ef;)Z
    .locals 6

    .line 1
    sget-object v0, La/m2;->R:La/m2;

    .line 2
    .line 3
    iget-object p0, p0, La/ef;->p:La/kQ;

    .line 4
    .line 5
    invoke-virtual {p0}, La/kQ;->y()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    const/4 v1, 0x0

    .line 14
    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-eqz v2, :cond_5

    .line 19
    .line 20
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, La/zr;

    .line 25
    .line 26
    if-nez v2, :cond_1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    iget-object v3, v2, La/zr;->k:La/Tz;

    .line 30
    .line 31
    if-nez v3, :cond_2

    .line 32
    .line 33
    const/4 v3, 0x0

    .line 34
    goto :goto_1

    .line 35
    :cond_2
    iget-object v3, v3, La/Tz;->f:La/Jf;

    .line 36
    .line 37
    :goto_1
    if-eqz v3, :cond_3

    .line 38
    .line 39
    invoke-virtual {v2}, La/zr;->K()La/ef;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    invoke-static {v3}, La/Jf;->R(La/ef;)Z

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    or-int/2addr v1, v3

    .line 48
    :cond_3
    iget-object v3, v2, La/zr;->rC:La/NT;

    .line 49
    .line 50
    sget-object v4, La/m2;->L:La/m2;

    .line 51
    .line 52
    const/4 v5, 0x1

    .line 53
    if-eqz v3, :cond_4

    .line 54
    .line 55
    invoke-virtual {v3}, La/NT;->e()V

    .line 56
    .line 57
    .line 58
    iget-object v3, v3, La/NT;->d:Landroidx/lifecycle/w;

    .line 59
    .line 60
    iget-object v3, v3, Landroidx/lifecycle/w;->e:La/m2;

    .line 61
    .line 62
    invoke-virtual {v3, v4}, La/m2;->w(La/m2;)Z

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    if-eqz v3, :cond_4

    .line 67
    .line 68
    iget-object v1, v2, La/zr;->rC:La/NT;

    .line 69
    .line 70
    iget-object v1, v1, La/NT;->d:Landroidx/lifecycle/w;

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Landroidx/lifecycle/w;->X(La/m2;)V

    .line 73
    .line 74
    .line 75
    move v1, v5

    .line 76
    :cond_4
    iget-object v3, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 77
    .line 78
    iget-object v3, v3, Landroidx/lifecycle/w;->e:La/m2;

    .line 79
    .line 80
    invoke-virtual {v3, v4}, La/m2;->w(La/m2;)Z

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    if-eqz v3, :cond_0

    .line 85
    .line 86
    iget-object v1, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 87
    .line 88
    invoke-virtual {v1, v0}, Landroidx/lifecycle/w;->X(La/m2;)V

    .line 89
    .line 90
    .line 91
    move v1, v5

    .line 92
    goto :goto_0

    .line 93
    :cond_5
    return v1
.end method


# virtual methods
.method public final dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz p4, :cond_5

    .line 7
    .line 8
    array-length v2, p4

    .line 9
    if-lez v2, :cond_5

    .line 10
    .line 11
    aget-object v2, p4, v1

    .line 12
    .line 13
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    const/4 v4, -0x1

    .line 21
    sparse-switch v3, :sswitch_data_0

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :sswitch_0
    const-string v3, "--autofill"

    .line 26
    .line 27
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_0

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 v4, 0x4

    .line 35
    goto :goto_0

    .line 36
    :sswitch_1
    const-string v3, "--contentcapture"

    .line 37
    .line 38
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-nez v2, :cond_1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    const/4 v4, 0x3

    .line 46
    goto :goto_0

    .line 47
    :sswitch_2
    const-string v3, "--list-dumpables"

    .line 48
    .line 49
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-nez v2, :cond_2

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    const/4 v4, 0x2

    .line 57
    goto :goto_0

    .line 58
    :sswitch_3
    const-string v3, "--dump-dumpable"

    .line 59
    .line 60
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-nez v2, :cond_3

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_3
    move v4, v0

    .line 68
    goto :goto_0

    .line 69
    :sswitch_4
    const-string v3, "--translation"

    .line 70
    .line 71
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-nez v2, :cond_4

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_4
    move v4, v1

    .line 79
    :goto_0
    packed-switch v4, :pswitch_data_0

    .line 80
    .line 81
    .line 82
    goto :goto_2

    .line 83
    :pswitch_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 84
    .line 85
    const/16 v3, 0x1a

    .line 86
    .line 87
    if-lt v2, v3, :cond_5

    .line 88
    .line 89
    :goto_1
    move v2, v0

    .line 90
    goto :goto_3

    .line 91
    :pswitch_1
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 92
    .line 93
    const/16 v3, 0x1d

    .line 94
    .line 95
    if-lt v2, v3, :cond_5

    .line 96
    .line 97
    goto :goto_1

    .line 98
    :pswitch_2
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 99
    .line 100
    const/16 v3, 0x21

    .line 101
    .line 102
    if-lt v2, v3, :cond_5

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :pswitch_3
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 106
    .line 107
    const/16 v3, 0x1f

    .line 108
    .line 109
    if-lt v2, v3, :cond_5

    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_5
    :goto_2
    move v2, v1

    .line 113
    :goto_3
    xor-int/2addr v0, v2

    .line 114
    if-nez v0, :cond_6

    .line 115
    .line 116
    return-void

    .line 117
    :cond_6
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    const-string v0, "Local FragmentActivity "

    .line 121
    .line 122
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    const-string v0, " State:"

    .line 137
    .line 138
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    new-instance v0, Ljava/lang/StringBuilder;

    .line 142
    .line 143
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 147
    .line 148
    .line 149
    const-string v2, "  "

    .line 150
    .line 151
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    const-string v2, "mCreated="

    .line 162
    .line 163
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    iget-boolean v2, p0, La/Jf;->s:Z

    .line 167
    .line 168
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Z)V

    .line 169
    .line 170
    .line 171
    const-string v2, " mResumed="

    .line 172
    .line 173
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    iget-boolean v2, p0, La/Jf;->j:Z

    .line 177
    .line 178
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Z)V

    .line 179
    .line 180
    .line 181
    const-string v2, " mStopped="

    .line 182
    .line 183
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    iget-boolean v2, p0, La/Jf;->t:Z

    .line 187
    .line 188
    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->print(Z)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 192
    .line 193
    .line 194
    move-result-object v2

    .line 195
    if-eqz v2, :cond_8

    .line 196
    .line 197
    invoke-interface {p0}, La/CG;->i()La/Sx;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    new-instance v3, La/yW;

    .line 202
    .line 203
    sget-object v4, La/WM;->d:La/oK;

    .line 204
    .line 205
    invoke-direct {v3, v2, v4}, La/yW;-><init>(La/Sx;La/o7;)V

    .line 206
    .line 207
    .line 208
    const-class v2, La/WM;

    .line 209
    .line 210
    invoke-virtual {v3, v2}, La/yW;->m(Ljava/lang/Class;)La/AZ;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    check-cast v2, La/WM;

    .line 215
    .line 216
    iget-object v2, v2, La/WM;->L:La/a1;

    .line 217
    .line 218
    invoke-virtual {v2}, La/a1;->O()I

    .line 219
    .line 220
    .line 221
    move-result v3

    .line 222
    if-lez v3, :cond_8

    .line 223
    .line 224
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    const-string v3, "Loaders:"

    .line 228
    .line 229
    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v2}, La/a1;->O()I

    .line 233
    .line 234
    .line 235
    move-result v3

    .line 236
    if-gtz v3, :cond_7

    .line 237
    .line 238
    goto :goto_4

    .line 239
    :cond_7
    invoke-virtual {v2, v1}, La/a1;->V(I)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object p1

    .line 243
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    const-string p1, "  #"

    .line 250
    .line 251
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v2, v1}, La/a1;->Q(I)I

    .line 255
    .line 256
    .line 257
    move-result p1

    .line 258
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(I)V

    .line 259
    .line 260
    .line 261
    const-string p1, ": "

    .line 262
    .line 263
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    const/4 p1, 0x0

    .line 267
    throw p1

    .line 268
    :cond_8
    :goto_4
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 269
    .line 270
    invoke-virtual {v0}, La/ze;->W()La/ef;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    invoke-virtual {v0, p1, p2, p3, p4}, La/ef;->W(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    return-void

    .line 278
    nop

    .line 279
    :sswitch_data_0
    .sparse-switch
        -0x2673d6ef -> :sswitch_4
        0x5fd0f67 -> :sswitch_3
        0x1c2b8816 -> :sswitch_2
        0x4519f64d -> :sswitch_1
        0x56b9c952 -> :sswitch_0
    .end sparse-switch

    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Jf;->k:La/ze;

    invoke-virtual {v0}, La/ze;->q()V

    invoke-super {p0, p1, p2, p3}, Landroidx/activity/w;->onActivityResult(IILandroid/content/Intent;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroidx/activity/w;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 5
    .line 6
    sget-object v0, La/cw;->ON_CREATE:La/cw;

    .line 7
    .line 8
    invoke-virtual {p1, v0}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, La/Jf;->k:La/ze;

    .line 12
    .line 13
    iget-object p1, p1, La/ze;->K:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, La/Tz;

    .line 16
    .line 17
    iget-object p1, p1, La/Tz;->d:La/ef;

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    iput-boolean v0, p1, La/ef;->U:Z

    .line 21
    .line 22
    iput-boolean v0, p1, La/ef;->k:Z

    .line 23
    .line 24
    iget-object v1, p1, La/ef;->C:La/d5;

    .line 25
    .line 26
    iput-boolean v0, v1, La/d5;->q:Z

    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    invoke-virtual {p1, v0}, La/ef;->l(I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 1
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Tz;

    .line 2
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 3
    iget-object v0, v0, La/ef;->Q:La/BH;

    .line 4
    invoke-virtual {v0, p1, p2, p3, p4}, La/BH;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_0
    return-object v0
.end method

.method public final onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 2

    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 6
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Tz;

    .line 7
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 8
    iget-object v0, v0, La/ef;->Q:La/BH;

    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1, p1, p2, p3}, La/BH;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    .line 10
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_0
    return-object v0
.end method

.method public onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 5
    .line 6
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La/Tz;

    .line 9
    .line 10
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 11
    .line 12
    invoke-virtual {v0}, La/ef;->M()V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 16
    .line 17
    sget-object v1, La/cw;->ON_DESTROY:La/cw;

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/activity/w;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    if-eqz p2, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    return p1

    .line 9
    :cond_0
    const/4 p2, 0x6

    .line 10
    if-ne p1, p2, :cond_1

    .line 11
    .line 12
    iget-object p1, p0, La/Jf;->k:La/ze;

    .line 13
    .line 14
    iget-object p1, p1, La/ze;->K:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p1, La/Tz;

    .line 17
    .line 18
    iget-object p1, p1, La/Tz;->d:La/ef;

    .line 19
    .line 20
    invoke-virtual {p1}, La/ef;->V()Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    return p1

    .line 25
    :cond_1
    const/4 p1, 0x0

    .line 26
    return p1
.end method

.method public final onPause()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La/Jf;->j:Z

    .line 6
    .line 7
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 8
    .line 9
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, La/Tz;

    .line 12
    .line 13
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 14
    .line 15
    const/4 v1, 0x5

    .line 16
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 20
    .line 21
    sget-object v1, La/cw;->ON_PAUSE:La/cw;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public onPostResume()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onPostResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 5
    .line 6
    sget-object v1, La/cw;->ON_RESUME:La/cw;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 12
    .line 13
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, La/Tz;

    .line 16
    .line 17
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    iput-boolean v1, v0, La/ef;->U:Z

    .line 21
    .line 22
    iput-boolean v1, v0, La/ef;->k:Z

    .line 23
    .line 24
    iget-object v2, v0, La/ef;->C:La/d5;

    .line 25
    .line 26
    iput-boolean v1, v2, La/d5;->q:Z

    .line 27
    .line 28
    const/4 v1, 0x7

    .line 29
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Jf;->k:La/ze;

    invoke-virtual {v0}, La/ze;->q()V

    invoke-super {p0, p1, p2, p3}, Landroidx/activity/w;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    return-void
.end method

.method public onResume()V
    .locals 2

    .line 1
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 2
    .line 3
    invoke-virtual {v0}, La/ze;->q()V

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    iput-boolean v1, p0, La/Jf;->j:Z

    .line 11
    .line 12
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, La/Tz;

    .line 15
    .line 16
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 17
    .line 18
    invoke-virtual {v0, v1}, La/ef;->E(Z)Z

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public onStart()V
    .locals 5

    .line 1
    iget-object v0, p0, La/Jf;->k:La/ze;

    .line 2
    .line 3
    invoke-virtual {v0}, La/ze;->q()V

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    iput-boolean v1, p0, La/Jf;->t:Z

    .line 11
    .line 12
    iget-boolean v2, p0, La/Jf;->s:Z

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    iput-boolean v3, p0, La/Jf;->s:Z

    .line 18
    .line 19
    iget-object v2, v0, La/ze;->K:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, La/Tz;

    .line 22
    .line 23
    iget-object v2, v2, La/Tz;->d:La/ef;

    .line 24
    .line 25
    iput-boolean v1, v2, La/ef;->U:Z

    .line 26
    .line 27
    iput-boolean v1, v2, La/ef;->k:Z

    .line 28
    .line 29
    iget-object v4, v2, La/ef;->C:La/d5;

    .line 30
    .line 31
    iput-boolean v1, v4, La/d5;->q:Z

    .line 32
    .line 33
    const/4 v4, 0x4

    .line 34
    invoke-virtual {v2, v4}, La/ef;->l(I)V

    .line 35
    .line 36
    .line 37
    :cond_0
    iget-object v2, v0, La/ze;->K:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v2, La/Tz;

    .line 40
    .line 41
    iget-object v2, v2, La/Tz;->d:La/ef;

    .line 42
    .line 43
    invoke-virtual {v2, v3}, La/ef;->E(Z)Z

    .line 44
    .line 45
    .line 46
    iget-object v2, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 47
    .line 48
    sget-object v3, La/cw;->ON_START:La/cw;

    .line 49
    .line 50
    invoke-virtual {v2, v3}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, La/Tz;

    .line 56
    .line 57
    iget-object v0, v0, La/Tz;->d:La/ef;

    .line 58
    .line 59
    iput-boolean v1, v0, La/ef;->U:Z

    .line 60
    .line 61
    iput-boolean v1, v0, La/ef;->k:Z

    .line 62
    .line 63
    iget-object v2, v0, La/ef;->C:La/d5;

    .line 64
    .line 65
    iput-boolean v1, v2, La/d5;->q:Z

    .line 66
    .line 67
    const/4 v1, 0x5

    .line 68
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public final onStateNotSaved()V
    .locals 1

    .line 1
    iget-object v0, p0, La/Jf;->k:La/ze;

    invoke-virtual {v0}, La/ze;->q()V

    return-void
.end method

.method public onStop()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, La/Jf;->t:Z

    .line 6
    .line 7
    :cond_0
    iget-object v1, p0, La/Jf;->k:La/ze;

    .line 8
    .line 9
    invoke-virtual {v1}, La/ze;->W()La/ef;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-static {v2}, La/Jf;->R(La/ef;)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-nez v2, :cond_0

    .line 18
    .line 19
    iget-object v1, v1, La/ze;->K:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v1, La/Tz;

    .line 22
    .line 23
    iget-object v1, v1, La/Tz;->d:La/ef;

    .line 24
    .line 25
    iput-boolean v0, v1, La/ef;->k:Z

    .line 26
    .line 27
    iget-object v2, v1, La/ef;->C:La/d5;

    .line 28
    .line 29
    iput-boolean v0, v2, La/d5;->q:Z

    .line 30
    .line 31
    const/4 v0, 0x4

    .line 32
    invoke-virtual {v1, v0}, La/ef;->l(I)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, La/Jf;->v:Landroidx/lifecycle/w;

    .line 36
    .line 37
    sget-object v1, La/cw;->ON_STOP:La/cw;

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method
