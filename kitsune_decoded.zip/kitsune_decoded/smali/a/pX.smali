.class public interface abstract La/pX;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/fb;
