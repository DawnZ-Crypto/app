.class public Lcom/google/android/material/theme/MaterialComponentsViewInflater;
.super La/lK;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La/lK;-><init>()V

    return-void
.end method


# virtual methods
.method public final e(Landroid/content/Context;Landroid/util/AttributeSet;)La/qD;
    .locals 8

    .line 1
    new-instance v0, La/Xp;

    .line 2
    .line 3
    const v4, 0x7f0403b6

    .line 4
    .line 5
    .line 6
    const v1, 0x7f130448

    .line 7
    .line 8
    .line 9
    invoke-static {p1, p2, v4, v1}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-direct {v0, p1, p2}, La/qD;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    sget-object v3, La/tS;->F:[I

    .line 21
    .line 22
    const v5, 0x7f130448

    .line 23
    .line 24
    .line 25
    const/4 v7, 0x0

    .line 26
    new-array v6, v7, [I

    .line 27
    .line 28
    move-object v1, p1

    .line 29
    move-object v2, p2

    .line 30
    invoke-static/range {v1 .. v6}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 31
    .line 32
    .line 33
    move-result-object p2

    .line 34
    invoke-virtual {p2, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_0

    .line 39
    .line 40
    invoke-static {p1, p2, v7}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-static {v0, p1}, La/vb;->p(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    const/4 p1, 0x1

    .line 48
    invoke-virtual {p2, p1, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    iput-boolean p1, v0, La/Xp;->l:Z

    .line 53
    .line 54
    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method

.method public final h(Landroid/content/Context;Landroid/util/AttributeSet;)La/Bz;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/button/MaterialButton;

    invoke-direct {v0, p1, p2}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final i(Landroid/content/Context;Landroid/util/AttributeSet;)La/c8;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/android/material/textview/MaterialTextView;

    invoke-direct {v0, p1, p2}, Lcom/google/android/material/textview/MaterialTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final p(Landroid/content/Context;Landroid/util/AttributeSet;)La/q8;
    .locals 1

    .line 1
    new-instance v0, La/E3;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, La/E3;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final w(Landroid/content/Context;Landroid/util/AttributeSet;)La/rp;
    .locals 1

    .line 1
    new-instance v0, La/UH;

    invoke-direct {v0, p1, p2}, La/UH;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method
