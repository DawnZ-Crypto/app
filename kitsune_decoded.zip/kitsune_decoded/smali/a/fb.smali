.class public interface abstract La/fb;
.super Ljava/lang/Object;
.source "SourceFile"
