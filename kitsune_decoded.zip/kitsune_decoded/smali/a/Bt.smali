.class public final La/Bt;
.super La/wl;
.source "SourceFile"


# instance fields
.field public final synthetic h:La/Hb;


# direct methods
.method public constructor <init>(La/Hb;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/Bt;->h:La/Hb;

    return-void
.end method


# virtual methods
.method public final w(Landroid/content/res/Resources;)Ljava/lang/CharSequence;
    .locals 2

    .line 1
    iget-object v0, p0, La/Bt;->h:La/Hb;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La/Hb;->q(Landroid/content/res/Resources;)[Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {v0}, La/oW;->l()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Number;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-ltz v0, :cond_0

    .line 18
    .line 19
    array-length v1, p1

    .line 20
    add-int/lit8 v1, v1, -0x1

    .line 21
    .line 22
    if-gt v0, v1, :cond_0

    .line 23
    .line 24
    aget-object p1, p1, v0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const-string p1, ""

    .line 28
    .line 29
    :goto_0
    return-object p1
.end method
