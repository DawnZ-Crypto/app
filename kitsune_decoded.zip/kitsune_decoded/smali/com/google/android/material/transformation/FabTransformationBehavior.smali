.class public abstract Lcom/google/android/material/transformation/FabTransformationBehavior;
.super Lcom/google/android/material/transformation/ExpandableTransformationBehavior;
.source "SourceFile"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field public O:F

.field public final Q:[I

.field public X:F

.field public final e:Landroid/graphics/RectF;

.field public final i:Landroid/graphics/RectF;

.field public final p:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lcom/google/android/material/transformation/ExpandableTransformationBehavior;-><init>()V

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->p:Landroid/graphics/Rect;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->e:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->i:Landroid/graphics/RectF;

    const/4 v0, 0x2

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->Q:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1, p2}, Lcom/google/android/material/transformation/ExpandableTransformationBehavior;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->p:Landroid/graphics/Rect;

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->e:Landroid/graphics/RectF;

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->i:Landroid/graphics/RectF;

    const/4 p1, 0x2

    new-array p1, p1, [I

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->Q:[I

    return-void
.end method

.method public static E(La/dh;La/fa;F)F
    .locals 6

    .line 1
    iget-wide v0, p1, La/fa;->w:J

    .line 2
    .line 3
    iget-object p0, p0, La/dh;->K:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, La/tX;

    .line 6
    .line 7
    const-string v2, "expansion"

    .line 8
    .line 9
    invoke-virtual {p0, v2}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    iget-wide v2, p0, La/fa;->w:J

    .line 14
    .line 15
    iget-wide v4, p0, La/fa;->h:J

    .line 16
    .line 17
    add-long/2addr v2, v4

    .line 18
    const-wide/16 v4, 0x11

    .line 19
    .line 20
    add-long/2addr v2, v4

    .line 21
    sub-long/2addr v2, v0

    .line 22
    long-to-float p0, v2

    .line 23
    iget-wide v0, p1, La/fa;->h:J

    .line 24
    .line 25
    long-to-float v0, v0

    .line 26
    div-float/2addr p0, v0

    .line 27
    invoke-virtual {p1}, La/fa;->h()Landroid/animation/TimeInterpolator;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-interface {p1, p0}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    const/4 p1, 0x0

    .line 36
    invoke-static {p2, p1, p0}, La/FP;->w(FFF)F

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    return p0
.end method

.method public static W(FFZLa/dh;)Landroid/util/Pair;
    .locals 1

    .line 1
    const/4 v0, 0x0

    cmpl-float p0, p0, v0

    if-eqz p0, :cond_4

    cmpl-float p0, p1, v0

    if-nez p0, :cond_0

    goto :goto_1

    :cond_0
    if-eqz p2, :cond_1

    cmpg-float p1, p1, v0

    if-ltz p1, :cond_2

    :cond_1
    if-nez p2, :cond_3

    if-lez p0, :cond_3

    :cond_2
    iget-object p0, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p0, La/tX;

    const-string p1, "translationXCurveUpwards"

    invoke-virtual {p0, p1}, La/tX;->Q(Ljava/lang/String;)La/fa;

    move-result-object p0

    iget-object p1, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p1, La/tX;

    const-string p2, "translationYCurveUpwards"

    :goto_0
    invoke-virtual {p1, p2}, La/tX;->Q(Ljava/lang/String;)La/fa;

    move-result-object p1

    goto :goto_2

    :cond_3
    iget-object p0, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p0, La/tX;

    const-string p1, "translationXCurveDownwards"

    invoke-virtual {p0, p1}, La/tX;->Q(Ljava/lang/String;)La/fa;

    move-result-object p0

    iget-object p1, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p1, La/tX;

    const-string p2, "translationYCurveDownwards"

    goto :goto_0

    :cond_4
    :goto_1
    iget-object p0, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p0, La/tX;

    const-string p1, "translationXLinear"

    invoke-virtual {p0, p1}, La/tX;->Q(Ljava/lang/String;)La/fa;

    move-result-object p0

    iget-object p1, p3, La/dh;->K:Ljava/lang/Object;

    check-cast p1, La/tX;

    const-string p2, "translationYLinear"

    goto :goto_0

    :goto_2
    new-instance p2, Landroid/util/Pair;

    invoke-direct {p2, p0, p1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p2
.end method


# virtual methods
.method public final F(Landroid/view/View;Landroid/view/View;La/Qr;)F
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->e:Landroid/graphics/RectF;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->i:Landroid/graphics/RectF;

    .line 4
    .line 5
    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 6
    .line 7
    .line 8
    iget p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 9
    .line 10
    iget v2, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 11
    .line 12
    invoke-virtual {v0, p1, v2}, Landroid/graphics/RectF;->offset(FF)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p2, v1}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    sub-float/2addr p1, p2

    .line 30
    const/4 p2, 0x0

    .line 31
    add-float/2addr p1, p2

    .line 32
    return p1
.end method

.method public abstract H(Landroid/content/Context;Z)La/dh;
.end method

.method public final S(Landroid/view/View;Landroid/graphics/RectF;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    const/4 v2, 0x0

    invoke-virtual {p2, v2, v2, v0, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->Q:[I

    invoke-virtual {p1, v0}, Landroid/view/View;->getLocationInWindow([I)V

    const/4 v1, 0x0

    aget v1, v0, v1

    int-to-float v1, v1

    const/4 v2, 0x1

    aget v0, v0, v2

    int-to-float v0, v0

    invoke-virtual {p2, v1, v0}, Landroid/graphics/RectF;->offsetTo(FF)V

    invoke-virtual {p1}, Landroid/view/View;->getTranslationX()F

    move-result v0

    neg-float v0, v0

    float-to-int v0, v0

    int-to-float v0, v0

    invoke-virtual {p1}, Landroid/view/View;->getTranslationY()F

    move-result p1

    neg-float p1, p1

    float-to-int p1, p1

    int-to-float p1, p1

    invoke-virtual {p2, v0, p1}, Landroid/graphics/RectF;->offset(FF)V

    return-void
.end method

.method public final h(Landroid/view/View;Landroid/view/View;)Z
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x8

    .line 6
    .line 7
    if-eq v0, v1, :cond_2

    .line 8
    .line 9
    instance-of v0, p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    check-cast p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 15
    .line 16
    iget-object p2, p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->H:La/og;

    .line 17
    .line 18
    iget p2, p2, La/og;->h:I

    .line 19
    .line 20
    if-eqz p2, :cond_0

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    if-ne p2, p1, :cond_1

    .line 27
    .line 28
    :cond_0
    const/4 v1, 0x1

    .line 29
    :cond_1
    return v1

    .line 30
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 31
    .line 32
    const-string p2, "This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead."

    .line 33
    .line 34
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    throw p1
.end method

.method public final l(Landroid/view/View;Landroid/view/View;ZZ)Landroid/animation/AnimatorSet;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    invoke-virtual/range {p2 .. p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    invoke-virtual {v0, v4, v3}, Lcom/google/android/material/transformation/FabTransformationBehavior;->H(Landroid/content/Context;Z)La/dh;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getTranslationX()F

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    iput v5, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 24
    .line 25
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getTranslationY()F

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    iput v5, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 30
    .line 31
    :cond_0
    new-instance v5, Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 34
    .line 35
    .line 36
    new-instance v6, Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 39
    .line 40
    .line 41
    sget-object v7, La/sI;->w:Ljava/util/WeakHashMap;

    .line 42
    .line 43
    invoke-static/range {p2 .. p2}, La/Sg;->V(Landroid/view/View;)F

    .line 44
    .line 45
    .line 46
    move-result v7

    .line 47
    invoke-static/range {p1 .. p1}, La/Sg;->V(Landroid/view/View;)F

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    sub-float/2addr v7, v8

    .line 52
    const/4 v8, 0x1

    .line 53
    const/4 v9, 0x0

    .line 54
    const/4 v10, 0x0

    .line 55
    if-eqz v3, :cond_2

    .line 56
    .line 57
    if-nez p4, :cond_1

    .line 58
    .line 59
    neg-float v7, v7

    .line 60
    invoke-virtual {v2, v7}, Landroid/view/View;->setTranslationZ(F)V

    .line 61
    .line 62
    .line 63
    :cond_1
    sget-object v7, Landroid/view/View;->TRANSLATION_Z:Landroid/util/Property;

    .line 64
    .line 65
    new-array v11, v8, [F

    .line 66
    .line 67
    aput v9, v11, v10

    .line 68
    .line 69
    invoke-static {v2, v7, v11}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    goto :goto_0

    .line 74
    :cond_2
    sget-object v11, Landroid/view/View;->TRANSLATION_Z:Landroid/util/Property;

    .line 75
    .line 76
    new-array v12, v8, [F

    .line 77
    .line 78
    neg-float v7, v7

    .line 79
    aput v7, v12, v10

    .line 80
    .line 81
    invoke-static {v2, v11, v12}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 82
    .line 83
    .line 84
    move-result-object v7

    .line 85
    :goto_0
    iget-object v11, v4, La/dh;->K:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v11, La/tX;

    .line 88
    .line 89
    const-string v12, "elevation"

    .line 90
    .line 91
    invoke-virtual {v11, v12}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 92
    .line 93
    .line 94
    move-result-object v11

    .line 95
    invoke-virtual {v11, v7}, La/fa;->w(Landroid/animation/Animator;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    iget-object v7, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->e:Landroid/graphics/RectF;

    .line 102
    .line 103
    iget-object v11, v4, La/dh;->R:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v11, La/Qr;

    .line 106
    .line 107
    invoke-virtual {v0, v1, v2, v11}, Lcom/google/android/material/transformation/FabTransformationBehavior;->q(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 108
    .line 109
    .line 110
    move-result v11

    .line 111
    iget-object v12, v4, La/dh;->R:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v12, La/Qr;

    .line 114
    .line 115
    invoke-virtual {v0, v1, v2, v12}, Lcom/google/android/material/transformation/FabTransformationBehavior;->F(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    invoke-static {v11, v12, v3, v4}, Lcom/google/android/material/transformation/FabTransformationBehavior;->W(FFZLa/dh;)Landroid/util/Pair;

    .line 120
    .line 121
    .line 122
    move-result-object v13

    .line 123
    iget-object v14, v13, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 124
    .line 125
    check-cast v14, La/fa;

    .line 126
    .line 127
    iget-object v13, v13, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast v13, La/fa;

    .line 130
    .line 131
    iget-object v15, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->i:Landroid/graphics/RectF;

    .line 132
    .line 133
    iget-object v9, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->p:Landroid/graphics/Rect;

    .line 134
    .line 135
    if-eqz v3, :cond_4

    .line 136
    .line 137
    if-nez p4, :cond_3

    .line 138
    .line 139
    neg-float v10, v11

    .line 140
    invoke-virtual {v2, v10}, Landroid/view/View;->setTranslationX(F)V

    .line 141
    .line 142
    .line 143
    neg-float v10, v12

    .line 144
    invoke-virtual {v2, v10}, Landroid/view/View;->setTranslationY(F)V

    .line 145
    .line 146
    .line 147
    :cond_3
    sget-object v10, Landroid/view/View;->TRANSLATION_X:Landroid/util/Property;

    .line 148
    .line 149
    move-object/from16 v18, v6

    .line 150
    .line 151
    new-array v6, v8, [F

    .line 152
    .line 153
    const/16 v16, 0x0

    .line 154
    .line 155
    const/16 v17, 0x0

    .line 156
    .line 157
    aput v16, v6, v17

    .line 158
    .line 159
    invoke-static {v2, v10, v6}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 160
    .line 161
    .line 162
    move-result-object v6

    .line 163
    sget-object v10, Landroid/view/View;->TRANSLATION_Y:Landroid/util/Property;

    .line 164
    .line 165
    move-object/from16 v19, v6

    .line 166
    .line 167
    new-array v6, v8, [F

    .line 168
    .line 169
    aput v16, v6, v17

    .line 170
    .line 171
    invoke-static {v2, v10, v6}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 172
    .line 173
    .line 174
    move-result-object v6

    .line 175
    neg-float v10, v11

    .line 176
    neg-float v11, v12

    .line 177
    invoke-static {v4, v14, v10}, Lcom/google/android/material/transformation/FabTransformationBehavior;->E(La/dh;La/fa;F)F

    .line 178
    .line 179
    .line 180
    move-result v10

    .line 181
    invoke-static {v4, v13, v11}, Lcom/google/android/material/transformation/FabTransformationBehavior;->E(La/dh;La/fa;F)F

    .line 182
    .line 183
    .line 184
    move-result v11

    .line 185
    invoke-virtual {v2, v9}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v7, v9}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0, v2, v15}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v15, v10, v11}, Landroid/graphics/RectF;->offset(FF)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v15, v7}, Landroid/graphics/RectF;->intersect(Landroid/graphics/RectF;)Z

    .line 198
    .line 199
    .line 200
    invoke-virtual {v7, v15}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    .line 201
    .line 202
    .line 203
    move-object v10, v6

    .line 204
    move-object/from16 v6, v19

    .line 205
    .line 206
    goto :goto_1

    .line 207
    :cond_4
    move-object/from16 v18, v6

    .line 208
    .line 209
    sget-object v6, Landroid/view/View;->TRANSLATION_X:Landroid/util/Property;

    .line 210
    .line 211
    new-array v10, v8, [F

    .line 212
    .line 213
    neg-float v11, v11

    .line 214
    const/16 v17, 0x0

    .line 215
    .line 216
    aput v11, v10, v17

    .line 217
    .line 218
    invoke-static {v2, v6, v10}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 219
    .line 220
    .line 221
    move-result-object v6

    .line 222
    sget-object v10, Landroid/view/View;->TRANSLATION_Y:Landroid/util/Property;

    .line 223
    .line 224
    new-array v11, v8, [F

    .line 225
    .line 226
    neg-float v12, v12

    .line 227
    aput v12, v11, v17

    .line 228
    .line 229
    invoke-static {v2, v10, v11}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 230
    .line 231
    .line 232
    move-result-object v10

    .line 233
    :goto_1
    invoke-virtual {v14, v6}, La/fa;->w(Landroid/animation/Animator;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v13, v10}, La/fa;->w(Landroid/animation/Animator;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    invoke-virtual {v7}, Landroid/graphics/RectF;->width()F

    .line 246
    .line 247
    .line 248
    move-result v6

    .line 249
    invoke-virtual {v7}, Landroid/graphics/RectF;->height()F

    .line 250
    .line 251
    .line 252
    move-result v10

    .line 253
    iget-object v11, v4, La/dh;->R:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v11, La/Qr;

    .line 256
    .line 257
    invoke-virtual {v0, v1, v2, v11}, Lcom/google/android/material/transformation/FabTransformationBehavior;->q(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 258
    .line 259
    .line 260
    move-result v11

    .line 261
    iget-object v12, v4, La/dh;->R:Ljava/lang/Object;

    .line 262
    .line 263
    check-cast v12, La/Qr;

    .line 264
    .line 265
    invoke-virtual {v0, v1, v2, v12}, Lcom/google/android/material/transformation/FabTransformationBehavior;->F(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 266
    .line 267
    .line 268
    move-result v12

    .line 269
    invoke-static {v11, v12, v3, v4}, Lcom/google/android/material/transformation/FabTransformationBehavior;->W(FFZLa/dh;)Landroid/util/Pair;

    .line 270
    .line 271
    .line 272
    move-result-object v13

    .line 273
    iget-object v14, v13, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 274
    .line 275
    check-cast v14, La/fa;

    .line 276
    .line 277
    iget-object v13, v13, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 278
    .line 279
    check-cast v13, La/fa;

    .line 280
    .line 281
    move/from16 v19, v11

    .line 282
    .line 283
    sget-object v11, Landroid/view/View;->TRANSLATION_X:Landroid/util/Property;

    .line 284
    .line 285
    move/from16 v20, v12

    .line 286
    .line 287
    new-array v12, v8, [F

    .line 288
    .line 289
    if-eqz v3, :cond_5

    .line 290
    .line 291
    move/from16 v8, v19

    .line 292
    .line 293
    :goto_2
    const/16 v17, 0x0

    .line 294
    .line 295
    goto :goto_3

    .line 296
    :cond_5
    iget v8, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 297
    .line 298
    goto :goto_2

    .line 299
    :goto_3
    aput v8, v12, v17

    .line 300
    .line 301
    invoke-static {v1, v11, v12}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 302
    .line 303
    .line 304
    move-result-object v8

    .line 305
    sget-object v11, Landroid/view/View;->TRANSLATION_Y:Landroid/util/Property;

    .line 306
    .line 307
    move/from16 v21, v6

    .line 308
    .line 309
    const/4 v12, 0x1

    .line 310
    new-array v6, v12, [F

    .line 311
    .line 312
    if-eqz v3, :cond_6

    .line 313
    .line 314
    move/from16 v12, v20

    .line 315
    .line 316
    goto :goto_4

    .line 317
    :cond_6
    iget v12, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 318
    .line 319
    :goto_4
    aput v12, v6, v17

    .line 320
    .line 321
    invoke-static {v1, v11, v6}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 322
    .line 323
    .line 324
    move-result-object v6

    .line 325
    invoke-virtual {v14, v8}, La/fa;->w(Landroid/animation/Animator;)V

    .line 326
    .line 327
    .line 328
    invoke-virtual {v13, v6}, La/fa;->w(Landroid/animation/Animator;)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 335
    .line 336
    .line 337
    instance-of v6, v2, La/De;

    .line 338
    .line 339
    if-eqz v6, :cond_8

    .line 340
    .line 341
    instance-of v8, v1, Landroid/widget/ImageView;

    .line 342
    .line 343
    if-nez v8, :cond_7

    .line 344
    .line 345
    goto :goto_5

    .line 346
    :cond_7
    move-object v8, v2

    .line 347
    check-cast v8, La/De;

    .line 348
    .line 349
    move-object v11, v1

    .line 350
    check-cast v11, Landroid/widget/ImageView;

    .line 351
    .line 352
    invoke-virtual {v11}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 353
    .line 354
    .line 355
    move-result-object v11

    .line 356
    if-nez v11, :cond_9

    .line 357
    .line 358
    :cond_8
    :goto_5
    move-object/from16 v8, v18

    .line 359
    .line 360
    goto :goto_7

    .line 361
    :cond_9
    invoke-virtual {v11}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 362
    .line 363
    .line 364
    const/16 v12, 0xff

    .line 365
    .line 366
    if-eqz v3, :cond_b

    .line 367
    .line 368
    if-nez p4, :cond_a

    .line 369
    .line 370
    invoke-virtual {v11, v12}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 371
    .line 372
    .line 373
    :cond_a
    sget-object v12, La/mF;->w:La/mF;

    .line 374
    .line 375
    const/4 v13, 0x0

    .line 376
    filled-new-array {v13}, [I

    .line 377
    .line 378
    .line 379
    move-result-object v14

    .line 380
    invoke-static {v11, v12, v14}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Landroid/util/Property;[I)Landroid/animation/ObjectAnimator;

    .line 381
    .line 382
    .line 383
    move-result-object v12

    .line 384
    goto :goto_6

    .line 385
    :cond_b
    sget-object v13, La/mF;->w:La/mF;

    .line 386
    .line 387
    filled-new-array {v12}, [I

    .line 388
    .line 389
    .line 390
    move-result-object v12

    .line 391
    invoke-static {v11, v13, v12}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Landroid/util/Property;[I)Landroid/animation/ObjectAnimator;

    .line 392
    .line 393
    .line 394
    move-result-object v12

    .line 395
    :goto_6
    new-instance v13, La/es;

    .line 396
    .line 397
    const/4 v14, 0x1

    .line 398
    invoke-direct {v13, v14, v2, v0}, La/es;-><init>(ILandroid/view/View;Ljava/lang/Object;)V

    .line 399
    .line 400
    .line 401
    invoke-virtual {v12, v13}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 402
    .line 403
    .line 404
    iget-object v13, v4, La/dh;->K:Ljava/lang/Object;

    .line 405
    .line 406
    check-cast v13, La/tX;

    .line 407
    .line 408
    const-string v14, "iconFade"

    .line 409
    .line 410
    invoke-virtual {v13, v14}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 411
    .line 412
    .line 413
    move-result-object v13

    .line 414
    invoke-virtual {v13, v12}, La/fa;->w(Landroid/animation/Animator;)V

    .line 415
    .line 416
    .line 417
    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    new-instance v12, La/Gt;

    .line 421
    .line 422
    const/4 v13, 0x2

    .line 423
    invoke-direct {v12, v13, v0, v8, v11}, La/Gt;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    move-object/from16 v8, v18

    .line 427
    .line 428
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 429
    .line 430
    .line 431
    :goto_7
    if-nez v6, :cond_c

    .line 432
    .line 433
    move-object/from16 v23, v4

    .line 434
    .line 435
    move/from16 v18, v6

    .line 436
    .line 437
    goto/16 :goto_a

    .line 438
    .line 439
    :cond_c
    move-object v11, v2

    .line 440
    check-cast v11, La/De;

    .line 441
    .line 442
    iget-object v12, v4, La/dh;->R:Ljava/lang/Object;

    .line 443
    .line 444
    check-cast v12, La/Qr;

    .line 445
    .line 446
    invoke-virtual {v0, v1, v7}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 447
    .line 448
    .line 449
    iget v13, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 450
    .line 451
    iget v14, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 452
    .line 453
    invoke-virtual {v7, v13, v14}, Landroid/graphics/RectF;->offset(FF)V

    .line 454
    .line 455
    .line 456
    invoke-virtual {v0, v2, v15}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v0, v1, v2, v12}, Lcom/google/android/material/transformation/FabTransformationBehavior;->q(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 460
    .line 461
    .line 462
    move-result v12

    .line 463
    neg-float v12, v12

    .line 464
    const/4 v13, 0x0

    .line 465
    invoke-virtual {v15, v12, v13}, Landroid/graphics/RectF;->offset(FF)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {v7}, Landroid/graphics/RectF;->centerX()F

    .line 469
    .line 470
    .line 471
    move-result v12

    .line 472
    iget v13, v15, Landroid/graphics/RectF;->left:F

    .line 473
    .line 474
    sub-float/2addr v12, v13

    .line 475
    iget-object v13, v4, La/dh;->R:Ljava/lang/Object;

    .line 476
    .line 477
    check-cast v13, La/Qr;

    .line 478
    .line 479
    invoke-virtual {v0, v1, v7}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 480
    .line 481
    .line 482
    iget v14, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 483
    .line 484
    move/from16 v18, v6

    .line 485
    .line 486
    iget v6, v0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 487
    .line 488
    invoke-virtual {v7, v14, v6}, Landroid/graphics/RectF;->offset(FF)V

    .line 489
    .line 490
    .line 491
    invoke-virtual {v0, v2, v15}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 492
    .line 493
    .line 494
    invoke-virtual {v0, v1, v2, v13}, Lcom/google/android/material/transformation/FabTransformationBehavior;->F(Landroid/view/View;Landroid/view/View;La/Qr;)F

    .line 495
    .line 496
    .line 497
    move-result v6

    .line 498
    neg-float v6, v6

    .line 499
    const/4 v13, 0x0

    .line 500
    invoke-virtual {v15, v13, v6}, Landroid/graphics/RectF;->offset(FF)V

    .line 501
    .line 502
    .line 503
    invoke-virtual {v7}, Landroid/graphics/RectF;->centerY()F

    .line 504
    .line 505
    .line 506
    move-result v6

    .line 507
    iget v7, v15, Landroid/graphics/RectF;->top:F

    .line 508
    .line 509
    sub-float/2addr v6, v7

    .line 510
    move-object v7, v1

    .line 511
    check-cast v7, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 512
    .line 513
    invoke-static {v7}, La/AM;->p(Landroid/view/View;)Z

    .line 514
    .line 515
    .line 516
    move-result v13

    .line 517
    if-eqz v13, :cond_d

    .line 518
    .line 519
    invoke-virtual {v7}, Landroid/view/View;->getWidth()I

    .line 520
    .line 521
    .line 522
    move-result v13

    .line 523
    invoke-virtual {v7}, Landroid/view/View;->getHeight()I

    .line 524
    .line 525
    .line 526
    move-result v14

    .line 527
    const/4 v15, 0x0

    .line 528
    invoke-virtual {v9, v15, v15, v13, v14}, Landroid/graphics/Rect;->set(IIII)V

    .line 529
    .line 530
    .line 531
    invoke-virtual {v7, v9}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->O(Landroid/graphics/Rect;)V

    .line 532
    .line 533
    .line 534
    :cond_d
    invoke-virtual {v9}, Landroid/graphics/Rect;->width()I

    .line 535
    .line 536
    .line 537
    move-result v7

    .line 538
    int-to-float v7, v7

    .line 539
    const/high16 v9, 0x40000000    # 2.0f

    .line 540
    .line 541
    div-float/2addr v7, v9

    .line 542
    iget-object v9, v4, La/dh;->K:Ljava/lang/Object;

    .line 543
    .line 544
    check-cast v9, La/tX;

    .line 545
    .line 546
    const-string v13, "expansion"

    .line 547
    .line 548
    invoke-virtual {v9, v13}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 549
    .line 550
    .line 551
    move-result-object v9

    .line 552
    if-eqz v3, :cond_11

    .line 553
    .line 554
    if-nez p4, :cond_e

    .line 555
    .line 556
    new-instance v15, La/xb;

    .line 557
    .line 558
    invoke-direct {v15, v12, v6, v7}, La/xb;-><init>(FFF)V

    .line 559
    .line 560
    .line 561
    move-object v13, v11

    .line 562
    check-cast v13, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 563
    .line 564
    invoke-virtual {v13, v15}, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->e(La/xb;)V

    .line 565
    .line 566
    .line 567
    :cond_e
    if-eqz p4, :cond_f

    .line 568
    .line 569
    move-object v7, v11

    .line 570
    check-cast v7, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 571
    .line 572
    invoke-virtual {v7}, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->p()La/xb;

    .line 573
    .line 574
    .line 575
    move-result-object v7

    .line 576
    iget v7, v7, La/xb;->p:F

    .line 577
    .line 578
    :cond_f
    move/from16 v13, v21

    .line 579
    .line 580
    invoke-static {v12, v6, v13, v10}, La/rE;->u(FFFF)F

    .line 581
    .line 582
    .line 583
    move-result v10

    .line 584
    invoke-static {v11, v12, v6, v10}, La/rE;->z(La/De;FFF)Landroid/animation/AnimatorSet;

    .line 585
    .line 586
    .line 587
    move-result-object v10

    .line 588
    new-instance v13, La/m6;

    .line 589
    .line 590
    const/4 v14, 0x1

    .line 591
    invoke-direct {v13, v0, v14, v11}, La/m6;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 592
    .line 593
    .line 594
    invoke-virtual {v10, v13}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 595
    .line 596
    .line 597
    iget-wide v13, v9, La/fa;->w:J

    .line 598
    .line 599
    float-to-int v12, v12

    .line 600
    float-to-int v6, v6

    .line 601
    const-wide/16 v0, 0x0

    .line 602
    .line 603
    cmp-long v15, v13, v0

    .line 604
    .line 605
    if-lez v15, :cond_10

    .line 606
    .line 607
    invoke-static {v2, v12, v6, v7, v7}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    .line 608
    .line 609
    .line 610
    move-result-object v6

    .line 611
    invoke-virtual {v6, v0, v1}, Landroid/animation/Animator;->setStartDelay(J)V

    .line 612
    .line 613
    .line 614
    invoke-virtual {v6, v13, v14}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 615
    .line 616
    .line 617
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 618
    .line 619
    .line 620
    :cond_10
    move-object/from16 v23, v4

    .line 621
    .line 622
    move-object/from16 v20, v11

    .line 623
    .line 624
    goto/16 :goto_9

    .line 625
    .line 626
    :cond_11
    move-object v0, v11

    .line 627
    check-cast v0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 628
    .line 629
    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->p()La/xb;

    .line 630
    .line 631
    .line 632
    move-result-object v1

    .line 633
    iget v1, v1, La/xb;->p:F

    .line 634
    .line 635
    invoke-static {v0, v12, v6, v7}, La/rE;->z(La/De;FFF)Landroid/animation/AnimatorSet;

    .line 636
    .line 637
    .line 638
    move-result-object v10

    .line 639
    iget-wide v13, v9, La/fa;->w:J

    .line 640
    .line 641
    float-to-int v0, v12

    .line 642
    float-to-int v6, v6

    .line 643
    move-object v15, v10

    .line 644
    move-object v12, v11

    .line 645
    const-wide/16 v10, 0x0

    .line 646
    .line 647
    cmp-long v20, v13, v10

    .line 648
    .line 649
    if-lez v20, :cond_12

    .line 650
    .line 651
    invoke-static {v2, v0, v6, v1, v1}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    .line 652
    .line 653
    .line 654
    move-result-object v1

    .line 655
    invoke-virtual {v1, v10, v11}, Landroid/animation/Animator;->setStartDelay(J)V

    .line 656
    .line 657
    .line 658
    invoke-virtual {v1, v13, v14}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 659
    .line 660
    .line 661
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 662
    .line 663
    .line 664
    :cond_12
    iget-object v1, v4, La/dh;->K:Ljava/lang/Object;

    .line 665
    .line 666
    check-cast v1, La/tX;

    .line 667
    .line 668
    iget-object v1, v1, La/tX;->w:La/LC;

    .line 669
    .line 670
    iget v13, v1, La/LC;->R:I

    .line 671
    .line 672
    const/4 v14, 0x0

    .line 673
    :goto_8
    if-ge v14, v13, :cond_13

    .line 674
    .line 675
    invoke-virtual {v1, v14}, La/LC;->I(I)Ljava/lang/Object;

    .line 676
    .line 677
    .line 678
    move-result-object v20

    .line 679
    move-object/from16 v21, v1

    .line 680
    .line 681
    move-object/from16 v1, v20

    .line 682
    .line 683
    check-cast v1, La/fa;

    .line 684
    .line 685
    move-object/from16 v20, v12

    .line 686
    .line 687
    move/from16 v22, v13

    .line 688
    .line 689
    iget-wide v12, v1, La/fa;->w:J

    .line 690
    .line 691
    move-object/from16 v23, v4

    .line 692
    .line 693
    iget-wide v3, v1, La/fa;->h:J

    .line 694
    .line 695
    add-long/2addr v12, v3

    .line 696
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->max(JJ)J

    .line 697
    .line 698
    .line 699
    move-result-wide v10

    .line 700
    add-int/lit8 v14, v14, 0x1

    .line 701
    .line 702
    move/from16 v3, p3

    .line 703
    .line 704
    move-object/from16 v12, v20

    .line 705
    .line 706
    move-object/from16 v1, v21

    .line 707
    .line 708
    move/from16 v13, v22

    .line 709
    .line 710
    move-object/from16 v4, v23

    .line 711
    .line 712
    goto :goto_8

    .line 713
    :cond_13
    move-object/from16 v23, v4

    .line 714
    .line 715
    move-object/from16 v20, v12

    .line 716
    .line 717
    iget-wide v3, v9, La/fa;->w:J

    .line 718
    .line 719
    iget-wide v12, v9, La/fa;->h:J

    .line 720
    .line 721
    add-long/2addr v3, v12

    .line 722
    cmp-long v1, v3, v10

    .line 723
    .line 724
    if-gez v1, :cond_14

    .line 725
    .line 726
    invoke-static {v2, v0, v6, v7, v7}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    .line 727
    .line 728
    .line 729
    move-result-object v0

    .line 730
    invoke-virtual {v0, v3, v4}, Landroid/animation/Animator;->setStartDelay(J)V

    .line 731
    .line 732
    .line 733
    sub-long/2addr v10, v3

    .line 734
    invoke-virtual {v0, v10, v11}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 735
    .line 736
    .line 737
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 738
    .line 739
    .line 740
    :cond_14
    move-object v10, v15

    .line 741
    :goto_9
    invoke-virtual {v9, v10}, La/fa;->w(Landroid/animation/Animator;)V

    .line 742
    .line 743
    .line 744
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 745
    .line 746
    .line 747
    new-instance v0, La/AR;

    .line 748
    .line 749
    const/4 v1, 0x5

    .line 750
    move-object/from16 v3, v20

    .line 751
    .line 752
    invoke-direct {v0, v1, v3}, La/AR;-><init>(ILjava/lang/Object;)V

    .line 753
    .line 754
    .line 755
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 756
    .line 757
    .line 758
    :goto_a
    if-nez v18, :cond_15

    .line 759
    .line 760
    move/from16 v4, p3

    .line 761
    .line 762
    move-object/from16 v1, v23

    .line 763
    .line 764
    goto :goto_d

    .line 765
    :cond_15
    move-object v0, v2

    .line 766
    check-cast v0, La/De;

    .line 767
    .line 768
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 769
    .line 770
    invoke-static/range {p1 .. p1}, La/Sg;->X(Landroid/view/View;)Landroid/content/res/ColorStateList;

    .line 771
    .line 772
    .line 773
    move-result-object v1

    .line 774
    if-eqz v1, :cond_16

    .line 775
    .line 776
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getDrawableState()[I

    .line 777
    .line 778
    .line 779
    move-result-object v3

    .line 780
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 781
    .line 782
    .line 783
    move-result v4

    .line 784
    invoke-virtual {v1, v3, v4}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 785
    .line 786
    .line 787
    move-result v1

    .line 788
    goto :goto_b

    .line 789
    :cond_16
    const/4 v1, 0x0

    .line 790
    :goto_b
    const v3, 0xffffff

    .line 791
    .line 792
    .line 793
    and-int/2addr v3, v1

    .line 794
    move/from16 v4, p3

    .line 795
    .line 796
    if-eqz v4, :cond_18

    .line 797
    .line 798
    if-nez p4, :cond_17

    .line 799
    .line 800
    move-object v6, v0

    .line 801
    check-cast v6, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 802
    .line 803
    iget-object v6, v6, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    .line 804
    .line 805
    iget-object v7, v6, La/kS;->p:Landroid/graphics/Paint;

    .line 806
    .line 807
    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 808
    .line 809
    .line 810
    iget-object v1, v6, La/kS;->h:Landroid/view/View;

    .line 811
    .line 812
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 813
    .line 814
    .line 815
    :cond_17
    sget-object v1, La/A9;->w:La/A9;

    .line 816
    .line 817
    filled-new-array {v3}, [I

    .line 818
    .line 819
    .line 820
    move-result-object v3

    .line 821
    invoke-static {v0, v1, v3}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Landroid/util/Property;[I)Landroid/animation/ObjectAnimator;

    .line 822
    .line 823
    .line 824
    move-result-object v0

    .line 825
    goto :goto_c

    .line 826
    :cond_18
    sget-object v3, La/A9;->w:La/A9;

    .line 827
    .line 828
    filled-new-array {v1}, [I

    .line 829
    .line 830
    .line 831
    move-result-object v1

    .line 832
    invoke-static {v0, v3, v1}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Landroid/util/Property;[I)Landroid/animation/ObjectAnimator;

    .line 833
    .line 834
    .line 835
    move-result-object v0

    .line 836
    :goto_c
    sget-object v1, La/Fb;->w:La/Fb;

    .line 837
    .line 838
    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setEvaluator(Landroid/animation/TypeEvaluator;)V

    .line 839
    .line 840
    .line 841
    move-object/from16 v1, v23

    .line 842
    .line 843
    iget-object v3, v1, La/dh;->K:Ljava/lang/Object;

    .line 844
    .line 845
    check-cast v3, La/tX;

    .line 846
    .line 847
    const-string v6, "color"

    .line 848
    .line 849
    invoke-virtual {v3, v6}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 850
    .line 851
    .line 852
    move-result-object v3

    .line 853
    invoke-virtual {v3, v0}, La/fa;->w(Landroid/animation/Animator;)V

    .line 854
    .line 855
    .line 856
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 857
    .line 858
    .line 859
    :goto_d
    instance-of v0, v2, Landroid/view/ViewGroup;

    .line 860
    .line 861
    if-nez v0, :cond_19

    .line 862
    .line 863
    :goto_e
    const/4 v9, 0x0

    .line 864
    goto :goto_11

    .line 865
    :cond_19
    const v3, 0x7f090195

    .line 866
    .line 867
    .line 868
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 869
    .line 870
    .line 871
    move-result-object v3

    .line 872
    const/4 v6, 0x0

    .line 873
    if-eqz v3, :cond_1a

    .line 874
    .line 875
    instance-of v0, v3, Landroid/view/ViewGroup;

    .line 876
    .line 877
    if-eqz v0, :cond_1b

    .line 878
    .line 879
    move-object v6, v3

    .line 880
    check-cast v6, Landroid/view/ViewGroup;

    .line 881
    .line 882
    goto :goto_f

    .line 883
    :cond_1a
    if-eqz v0, :cond_1b

    .line 884
    .line 885
    move-object v6, v2

    .line 886
    check-cast v6, Landroid/view/ViewGroup;

    .line 887
    .line 888
    :cond_1b
    :goto_f
    if-nez v6, :cond_1c

    .line 889
    .line 890
    goto :goto_e

    .line 891
    :cond_1c
    if-eqz v4, :cond_1e

    .line 892
    .line 893
    if-nez p4, :cond_1d

    .line 894
    .line 895
    sget-object v0, La/Z2;->w:La/Z2;

    .line 896
    .line 897
    const/4 v3, 0x0

    .line 898
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 899
    .line 900
    .line 901
    move-result-object v3

    .line 902
    invoke-virtual {v0, v6, v3}, La/Z2;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 903
    .line 904
    .line 905
    :cond_1d
    sget-object v0, La/Z2;->w:La/Z2;

    .line 906
    .line 907
    const/4 v3, 0x1

    .line 908
    new-array v3, v3, [F

    .line 909
    .line 910
    const/high16 v7, 0x3f800000    # 1.0f

    .line 911
    .line 912
    const/4 v9, 0x0

    .line 913
    aput v7, v3, v9

    .line 914
    .line 915
    invoke-static {v6, v0, v3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 916
    .line 917
    .line 918
    move-result-object v0

    .line 919
    goto :goto_10

    .line 920
    :cond_1e
    const/4 v3, 0x1

    .line 921
    const/4 v9, 0x0

    .line 922
    sget-object v0, La/Z2;->w:La/Z2;

    .line 923
    .line 924
    new-array v3, v3, [F

    .line 925
    .line 926
    const/4 v7, 0x0

    .line 927
    aput v7, v3, v9

    .line 928
    .line 929
    invoke-static {v6, v0, v3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 930
    .line 931
    .line 932
    move-result-object v0

    .line 933
    :goto_10
    iget-object v1, v1, La/dh;->K:Ljava/lang/Object;

    .line 934
    .line 935
    check-cast v1, La/tX;

    .line 936
    .line 937
    const-string v3, "contentFade"

    .line 938
    .line 939
    invoke-virtual {v1, v3}, La/tX;->Q(Ljava/lang/String;)La/fa;

    .line 940
    .line 941
    .line 942
    move-result-object v1

    .line 943
    invoke-virtual {v1, v0}, La/fa;->w(Landroid/animation/Animator;)V

    .line 944
    .line 945
    .line 946
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 947
    .line 948
    .line 949
    :goto_11
    new-instance v0, Landroid/animation/AnimatorSet;

    .line 950
    .line 951
    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    .line 952
    .line 953
    .line 954
    invoke-static {v0, v5}, La/rx;->p7(Landroid/animation/AnimatorSet;Ljava/util/ArrayList;)V

    .line 955
    .line 956
    .line 957
    new-instance v1, La/XZ;

    .line 958
    .line 959
    move-object/from16 v3, p1

    .line 960
    .line 961
    invoke-direct {v1, v4, v2, v3}, La/XZ;-><init>(ZLandroid/view/View;Landroid/view/View;)V

    .line 962
    .line 963
    .line 964
    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 965
    .line 966
    .line 967
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 968
    .line 969
    .line 970
    move-result v1

    .line 971
    move v10, v9

    .line 972
    :goto_12
    if-ge v10, v1, :cond_1f

    .line 973
    .line 974
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 975
    .line 976
    .line 977
    move-result-object v2

    .line 978
    check-cast v2, Landroid/animation/Animator$AnimatorListener;

    .line 979
    .line 980
    invoke-virtual {v0, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 981
    .line 982
    .line 983
    add-int/lit8 v10, v10, 0x1

    .line 984
    .line 985
    goto :goto_12

    .line 986
    :cond_1f
    return-object v0
.end method

.method public final p(La/y9;)V
    .locals 1

    .line 1
    iget v0, p1, La/y9;->O:I

    if-nez v0, :cond_0

    const/16 v0, 0x50

    iput v0, p1, La/y9;->O:I

    :cond_0
    return-void
.end method

.method public final q(Landroid/view/View;Landroid/view/View;La/Qr;)F
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->e:Landroid/graphics/RectF;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->i:Landroid/graphics/RectF;

    .line 4
    .line 5
    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 6
    .line 7
    .line 8
    iget p1, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->X:F

    .line 9
    .line 10
    iget v2, p0, Lcom/google/android/material/transformation/FabTransformationBehavior;->O:F

    .line 11
    .line 12
    invoke-virtual {v0, p1, v2}, Landroid/graphics/RectF;->offset(FF)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p2, v1}, Lcom/google/android/material/transformation/FabTransformationBehavior;->S(Landroid/view/View;Landroid/graphics/RectF;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    sub-float/2addr p1, p2

    .line 30
    const/4 p2, 0x0

    .line 31
    add-float/2addr p1, p2

    .line 32
    return p1
.end method
