.class public interface abstract La/Xg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# virtual methods
.method public abstract M(La/WI;J)J
.end method

.method public abstract e()La/WU;
.end method
