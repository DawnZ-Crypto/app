.class public final La/H0;
.super La/yl;
.source "SourceFile"


# instance fields
.field public w:La/Uw;


# virtual methods
.method public final e(La/SB;)V
    .locals 2

    .line 1
    iget-object v0, p0, La/H0;->w:La/Uw;

    iget v1, v0, La/Uw;->x:I

    add-int/lit8 v1, v1, -0x1

    iput v1, v0, La/Uw;->x:I

    if-nez v1, :cond_0

    const/4 v1, 0x0

    iput-boolean v1, v0, La/Uw;->g:Z

    invoke-virtual {v0}, La/SB;->R()V

    :cond_0
    invoke-virtual {p1, p0}, La/SB;->z(La/XI;)V

    return-void
.end method

.method public final h(La/SB;)V
    .locals 1

    .line 1
    iget-object p1, p0, La/H0;->w:La/Uw;

    iget-boolean v0, p1, La/Uw;->g:Z

    if-nez v0, :cond_0

    invoke-virtual {p1}, La/SB;->t()V

    const/4 v0, 0x1

    iput-boolean v0, p1, La/Uw;->g:Z

    :cond_0
    return-void
.end method
