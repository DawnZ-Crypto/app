.class public abstract Landroidx/lifecycle/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final M:Ljava/lang/Object;


# instance fields
.field public final I:La/oE;

.field public O:Z

.field public volatile Q:Ljava/lang/Object;

.field public V:Z

.field public X:I

.field public e:Z

.field public final h:La/U6;

.field public volatile i:Ljava/lang/Object;

.field public p:I

.field public final w:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/lifecycle/h;->M:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/h;->w:Ljava/lang/Object;

    new-instance v0, La/U6;

    invoke-direct {v0}, La/U6;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/h;->h:La/U6;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/lifecycle/h;->p:I

    sget-object v0, Landroidx/lifecycle/h;->M:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/lifecycle/h;->Q:Ljava/lang/Object;

    new-instance v1, La/oE;

    const/16 v2, 0x9

    invoke-direct {v1, v2, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Landroidx/lifecycle/h;->I:La/oE;

    iput-object v0, p0, Landroidx/lifecycle/h;->i:Ljava/lang/Object;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/lifecycle/h;->X:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/h;->w:Ljava/lang/Object;

    new-instance v0, La/U6;

    invoke-direct {v0}, La/U6;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/h;->h:La/U6;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/lifecycle/h;->p:I

    sget-object v1, Landroidx/lifecycle/h;->M:Ljava/lang/Object;

    iput-object v1, p0, Landroidx/lifecycle/h;->Q:Ljava/lang/Object;

    new-instance v1, La/oE;

    const/16 v2, 0x9

    invoke-direct {v1, v2, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Landroidx/lifecycle/h;->I:La/oE;

    iput-object p1, p0, Landroidx/lifecycle/h;->i:Ljava/lang/Object;

    iput v0, p0, Landroidx/lifecycle/h;->X:I

    return-void
.end method

.method public static w(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-static {}, La/t5;->Pb()La/t5;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, La/t5;->K:La/RM;

    .line 6
    .line 7
    invoke-virtual {v0}, La/RM;->lI()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v1, "Cannot invoke "

    .line 17
    .line 18
    const-string v2, " on a background thread"

    .line 19
    .line 20
    invoke-static {v1, p0, v2}, La/zq;->I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw v0
.end method


# virtual methods
.method public abstract I(Ljava/lang/Object;)V
.end method

.method public O()V
    .locals 0

    .line 1
    return-void
.end method

.method public final Q(La/yb;)V
    .locals 2

    .line 1
    const-string v0, "observeForever"

    .line 2
    .line 3
    invoke-static {v0}, Landroidx/lifecycle/h;->w(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, La/Jz;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, La/nT;-><init>(Landroidx/lifecycle/h;La/yb;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Landroidx/lifecycle/h;->h:La/U6;

    .line 12
    .line 13
    invoke-virtual {v1, p1, v0}, La/U6;->p(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    check-cast p1, La/nT;

    .line 18
    .line 19
    instance-of v1, p1, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;

    .line 20
    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    if-eqz p1, :cond_0

    .line 24
    .line 25
    return-void

    .line 26
    :cond_0
    const/4 p1, 0x1

    .line 27
    invoke-virtual {v0, p1}, La/nT;->O(Z)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 32
    .line 33
    const-string v0, "Cannot add the same observer with different lifecycles"

    .line 34
    .line 35
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw p1
.end method

.method public final V(La/yb;)V
    .locals 1

    .line 1
    const-string v0, "removeObserver"

    invoke-static {v0}, Landroidx/lifecycle/h;->w(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/lifecycle/h;->h:La/U6;

    invoke-virtual {v0, p1}, La/U6;->e(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/nT;

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, La/nT;->V()V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, La/nT;->O(Z)V

    return-void
.end method

.method public X()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/h;->i:Ljava/lang/Object;

    sget-object v1, Landroidx/lifecycle/h;->M:Ljava/lang/Object;

    if-eq v0, v1, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final h(La/nT;)V
    .locals 2

    .line 1
    iget-boolean v0, p1, La/nT;->K:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, La/nT;->M()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, La/nT;->O(Z)V

    return-void

    :cond_1
    iget v0, p1, La/nT;->R:I

    iget v1, p0, Landroidx/lifecycle/h;->X:I

    if-lt v0, v1, :cond_2

    return-void

    :cond_2
    iput v1, p1, La/nT;->R:I

    iget-object p1, p1, La/nT;->X:La/yb;

    iget-object v0, p0, Landroidx/lifecycle/h;->i:Ljava/lang/Object;

    invoke-interface {p1, v0}, La/yb;->w(Ljava/lang/Object;)V

    return-void
.end method

.method public final i(La/RH;La/yb;)V
    .locals 2

    .line 1
    const-string v0, "observe"

    .line 2
    .line 3
    invoke-static {v0}, Landroidx/lifecycle/h;->w(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object v0, v0, Landroidx/lifecycle/w;->e:La/m2;

    .line 11
    .line 12
    sget-object v1, La/m2;->X:La/m2;

    .line 13
    .line 14
    if-ne v0, v1, :cond_0

    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    new-instance v0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;

    .line 18
    .line 19
    invoke-direct {v0, p0, p1, p2}, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;-><init>(Landroidx/lifecycle/h;La/RH;La/yb;)V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Landroidx/lifecycle/h;->h:La/U6;

    .line 23
    .line 24
    invoke-virtual {v1, p2, v0}, La/U6;->p(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    check-cast p2, La/nT;

    .line 29
    .line 30
    if-eqz p2, :cond_2

    .line 31
    .line 32
    invoke-virtual {p2, p1}, La/nT;->I(La/RH;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 40
    .line 41
    const-string p2, "Cannot add the same observer with different lifecycles"

    .line 42
    .line 43
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw p1

    .line 47
    :cond_2
    :goto_0
    if-eqz p2, :cond_3

    .line 48
    .line 49
    return-void

    .line 50
    :cond_3
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-virtual {p1, v0}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final p(La/nT;)V
    .locals 4

    .line 1
    iget-boolean v0, p0, Landroidx/lifecycle/h;->O:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iput-boolean v1, p0, Landroidx/lifecycle/h;->V:Z

    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    iput-boolean v1, p0, Landroidx/lifecycle/h;->O:Z

    .line 10
    .line 11
    :cond_1
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Landroidx/lifecycle/h;->V:Z

    .line 13
    .line 14
    if-eqz p1, :cond_2

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Landroidx/lifecycle/h;->h(La/nT;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    goto :goto_0

    .line 21
    :cond_2
    iget-object v1, p0, Landroidx/lifecycle/h;->h:La/U6;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    new-instance v2, La/Mo;

    .line 27
    .line 28
    invoke-direct {v2, v1}, La/Mo;-><init>(La/U6;)V

    .line 29
    .line 30
    .line 31
    iget-object v1, v1, La/U6;->R:Ljava/util/WeakHashMap;

    .line 32
    .line 33
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 34
    .line 35
    invoke-virtual {v1, v2, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    :cond_3
    invoke-virtual {v2}, La/Mo;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_4

    .line 43
    .line 44
    invoke-virtual {v2}, La/Mo;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, Ljava/util/Map$Entry;

    .line 49
    .line 50
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    check-cast v1, La/nT;

    .line 55
    .line 56
    invoke-virtual {p0, v1}, Landroidx/lifecycle/h;->h(La/nT;)V

    .line 57
    .line 58
    .line 59
    iget-boolean v1, p0, Landroidx/lifecycle/h;->V:Z

    .line 60
    .line 61
    if-eqz v1, :cond_3

    .line 62
    .line 63
    :cond_4
    :goto_0
    iget-boolean v1, p0, Landroidx/lifecycle/h;->V:Z

    .line 64
    .line 65
    if-nez v1, :cond_1

    .line 66
    .line 67
    iput-boolean v0, p0, Landroidx/lifecycle/h;->O:Z

    .line 68
    .line 69
    return-void
.end method
