.class public final La/UY;
.super La/yG;
.source "SourceFile"

# interfaces
.implements La/Wb;


# instance fields
.field public d:I

.field public final synthetic f:La/Un;


# direct methods
.method public constructor <init>(La/Un;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/UY;->f:La/Un;

    invoke-direct {p0, p2}, La/yG;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final I(Ljava/lang/Object;La/hu;)La/hu;
    .locals 1

    .line 1
    new-instance p1, La/UY;

    iget-object v0, p0, La/UY;->f:La/Un;

    invoke-direct {p1, v0, p2}, La/UY;-><init>(La/Un;La/hu;)V

    return-object p1
.end method

.method public final O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La/wE;

    .line 2
    .line 3
    check-cast p2, La/hu;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La/UY;->I(Ljava/lang/Object;La/hu;)La/hu;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La/UY;

    .line 10
    .line 11
    sget-object p2, La/rr;->w:La/rr;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La/UY;->T(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, La/cj;->X:La/cj;

    iget v1, p0, La/UY;->d:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    iput v2, p0, La/UY;->d:I

    iget-object p1, p0, La/UY;->f:La/Un;

    invoke-virtual {p1}, La/Un;->O()Ljava/lang/Boolean;

    move-result-object p1

    if-ne p1, v0, :cond_2

    return-object v0

    :cond_2
    :goto_0
    return-object p1
.end method
