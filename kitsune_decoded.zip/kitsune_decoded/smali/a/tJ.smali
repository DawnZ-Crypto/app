.class public final La/tJ;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public Q:[I

.field public final synthetic X:Landroidx/recyclerview/widget/StaggeredGridLayoutManager;

.field public e:Z

.field public h:I

.field public i:Z

.field public p:Z

.field public w:I


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/StaggeredGridLayoutManager;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/tJ;->X:Landroidx/recyclerview/widget/StaggeredGridLayoutManager;

    invoke-virtual {p0}, La/tJ;->w()V

    return-void
.end method


# virtual methods
.method public final w()V
    .locals 2

    .line 1
    const/4 v0, -0x1

    iput v0, p0, La/tJ;->w:I

    const/high16 v1, -0x80000000

    iput v1, p0, La/tJ;->h:I

    const/4 v1, 0x0

    iput-boolean v1, p0, La/tJ;->p:Z

    iput-boolean v1, p0, La/tJ;->e:Z

    iput-boolean v1, p0, La/tJ;->i:Z

    iget-object v1, p0, La/tJ;->Q:[I

    if-eqz v1, :cond_0

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([II)V

    :cond_0
    return-void
.end method
