.class public interface abstract La/eC;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract Q(La/HN;)Z
.end method
