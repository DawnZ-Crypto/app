.class public interface abstract La/Y0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getValue()Ljava/lang/Object;
.end method
