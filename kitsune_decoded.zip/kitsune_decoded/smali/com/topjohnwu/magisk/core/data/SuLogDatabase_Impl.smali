.class public final Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;
.super Lcom/topjohnwu/magisk/core/data/SuLogDatabase;
.source "SourceFile"


# instance fields
.field public volatile y:La/dg;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;-><init>()V

    return-void
.end method


# virtual methods
.method public final O()Ljava/util/Map;
    .locals 3

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-class v2, La/GN;

    .line 11
    .line 12
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final T()La/GN;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;->y:La/dg;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;->y:La/dg;

    return-object v0

    :cond_0
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;->y:La/dg;

    if-nez v0, :cond_1

    new-instance v0, La/dg;

    invoke-direct {v0, p0}, La/dg;-><init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V

    iput-object v0, p0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;->y:La/dg;

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;->y:La/dg;

    monitor-exit p0

    return-object v0

    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public final X()Ljava/util/Set;
    .locals 1

    .line 1
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    return-object v0
.end method

.method public final e(La/qE;)La/Af;
    .locals 3

    .line 1
    new-instance v0, La/n1;

    .line 2
    .line 3
    new-instance v1, La/k0;

    .line 4
    .line 5
    invoke-direct {v1, p0}, La/k0;-><init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, p1, v1}, La/n1;-><init>(La/qE;La/k0;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p1, La/qE;->p:La/YB;

    .line 12
    .line 13
    check-cast v1, La/Qr;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    new-instance v1, La/YQ;

    .line 19
    .line 20
    iget-object v2, p1, La/qE;->w:Landroid/content/Context;

    .line 21
    .line 22
    iget-object p1, p1, La/qE;->h:Ljava/lang/String;

    .line 23
    .line 24
    invoke-direct {v1, v2, p1, v0}, La/YQ;-><init>(Landroid/content/Context;Ljava/lang/String;La/di;)V

    .line 25
    .line 26
    .line 27
    return-object v1
.end method

.method public final h()V
    .locals 5

    .line 1
    const-string v0, "VACUUM"

    .line 2
    .line 3
    const-string v1, "PRAGMA wal_checkpoint(FULL)"

    .line 4
    .line 5
    invoke-virtual {p0}, La/cO;->w()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, La/cO;->Q()La/Af;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-interface {v2}, La/Af;->N()La/V1;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :try_start_0
    invoke-virtual {p0}, La/cO;->w()V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, La/cO;->w()V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, La/cO;->Q()La/Af;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-interface {v3}, La/Af;->N()La/V1;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    iget-object v4, p0, La/cO;->i:La/u3;

    .line 31
    .line 32
    invoke-virtual {v4, v3}, La/u3;->p(La/V1;)V

    .line 33
    .line 34
    .line 35
    invoke-interface {v3}, La/V1;->L()Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_0

    .line 40
    .line 41
    invoke-interface {v3}, La/V1;->t()V

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-interface {v3}, La/V1;->V()V

    .line 46
    .line 47
    .line 48
    :goto_0
    const-string v3, "DELETE FROM `logs`"

    .line 49
    .line 50
    invoke-interface {v2, v3}, La/V1;->l(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0}, La/cO;->Q()La/Af;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-interface {v3}, La/Af;->N()La/V1;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    invoke-interface {v3}, La/V1;->P()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0}, La/cO;->V()V

    .line 65
    .line 66
    .line 67
    invoke-interface {v2, v1}, La/V1;->FL(Ljava/lang/String;)Landroid/database/Cursor;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 72
    .line 73
    .line 74
    invoke-interface {v2}, La/V1;->rC()Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-nez v1, :cond_1

    .line 79
    .line 80
    invoke-interface {v2, v0}, La/V1;->l(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    :cond_1
    return-void

    .line 84
    :catchall_0
    move-exception v3

    .line 85
    invoke-virtual {p0}, La/cO;->V()V

    .line 86
    .line 87
    .line 88
    invoke-interface {v2, v1}, La/V1;->FL(Ljava/lang/String;)Landroid/database/Cursor;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 93
    .line 94
    .line 95
    invoke-interface {v2}, La/V1;->rC()Z

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    if-nez v1, :cond_2

    .line 100
    .line 101
    invoke-interface {v2, v0}, La/V1;->l(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    :cond_2
    throw v3
.end method

.method public final i()Ljava/util/List;
    .locals 1

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

.method public final p()La/u3;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/HashMap;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2, v1}, Ljava/util/HashMap;-><init>(I)V

    new-instance v1, La/u3;

    const-string v3, "logs"

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, p0, v0, v2, v3}, La/u3;-><init>(La/cO;Ljava/util/HashMap;Ljava/util/HashMap;[Ljava/lang/String;)V

    return-object v1
.end method
