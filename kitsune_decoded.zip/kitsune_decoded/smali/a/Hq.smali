.class public final La/Hq;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/yb;


# instance fields
.field public final synthetic K:La/hK;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(La/hK;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, La/Hq;->X:I

    .line 5
    .line 6
    iput-object p1, p0, La/Hq;->K:La/hK;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Boolean;)V
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iget v1, p0, La/Hq;->X:I

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, La/Hq;->K:La/hK;

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    invoke-virtual {v3, v0}, La/hK;->G(I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v3}, La/hK;->FL()V

    .line 20
    .line 21
    .line 22
    iget-object p1, v3, La/hK;->y6:La/TO;

    .line 23
    .line 24
    iget-object v0, p1, La/TO;->t:La/bc;

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    new-instance v0, La/bc;

    .line 29
    .line 30
    invoke-direct {v0}, Landroidx/lifecycle/h;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v0, p1, La/TO;->t:La/bc;

    .line 34
    .line 35
    :cond_0
    iget-object p1, p1, La/TO;->t:La/bc;

    .line 36
    .line 37
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-static {p1, v0}, La/TO;->R(La/bc;Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    return-void

    .line 43
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-eqz p1, :cond_4

    .line 48
    .line 49
    invoke-virtual {v3}, La/hK;->rC()Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-eqz p1, :cond_2

    .line 54
    .line 55
    invoke-virtual {v3}, La/hK;->F9()V

    .line 56
    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_2
    iget-object p1, v3, La/hK;->y6:La/TO;

    .line 60
    .line 61
    invoke-virtual {p1}, La/TO;->M()Ljava/lang/CharSequence;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    if-eqz p1, :cond_3

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_3
    const p1, 0x7f120038

    .line 69
    .line 70
    .line 71
    invoke-virtual {v3, p1}, La/zr;->l(I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    :goto_0
    const/16 v0, 0xd

    .line 76
    .line 77
    invoke-virtual {v3, v0, p1}, La/hK;->eH(ILjava/lang/CharSequence;)V

    .line 78
    .line 79
    .line 80
    const/4 p1, 0x2

    .line 81
    invoke-virtual {v3, p1}, La/hK;->G(I)V

    .line 82
    .line 83
    .line 84
    :goto_1
    iget-object p1, v3, La/hK;->y6:La/TO;

    .line 85
    .line 86
    invoke-virtual {p1, v2}, La/TO;->K(Z)V

    .line 87
    .line 88
    .line 89
    :cond_4
    return-void

    .line 90
    :pswitch_1
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    if-eqz p1, :cond_9

    .line 95
    .line 96
    invoke-virtual {v3}, La/hK;->p7()Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-eqz p1, :cond_5

    .line 101
    .line 102
    const p1, 0x7f120054

    .line 103
    .line 104
    .line 105
    invoke-virtual {v3, p1}, La/zr;->l(I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    invoke-virtual {v3, p1}, La/hK;->rZ(Ljava/lang/CharSequence;)V

    .line 110
    .line 111
    .line 112
    :cond_5
    iget-object p1, v3, La/hK;->y6:La/TO;

    .line 113
    .line 114
    iget-boolean v1, p1, La/TO;->z:Z

    .line 115
    .line 116
    if-nez v1, :cond_6

    .line 117
    .line 118
    const-string p1, "BiometricFragment"

    .line 119
    .line 120
    const-string v0, "Failure not sent to client. Client is not awaiting a result."

    .line 121
    .line 122
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 123
    .line 124
    .line 125
    goto :goto_3

    .line 126
    :cond_6
    iget-object p1, p1, La/TO;->L:Ljava/util/concurrent/Executor;

    .line 127
    .line 128
    if-eqz p1, :cond_7

    .line 129
    .line 130
    goto :goto_2

    .line 131
    :cond_7
    new-instance p1, La/MD;

    .line 132
    .line 133
    invoke-direct {p1, v0}, La/MD;-><init>(I)V

    .line 134
    .line 135
    .line 136
    :goto_2
    new-instance v0, La/l5;

    .line 137
    .line 138
    invoke-direct {v0, v3, v2}, La/l5;-><init>(La/hK;I)V

    .line 139
    .line 140
    .line 141
    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 142
    .line 143
    .line 144
    :goto_3
    iget-object p1, v3, La/hK;->y6:La/TO;

    .line 145
    .line 146
    iget-object v0, p1, La/TO;->v:La/bc;

    .line 147
    .line 148
    if-nez v0, :cond_8

    .line 149
    .line 150
    new-instance v0, La/bc;

    .line 151
    .line 152
    invoke-direct {v0}, Landroidx/lifecycle/h;-><init>()V

    .line 153
    .line 154
    .line 155
    iput-object v0, p1, La/TO;->v:La/bc;

    .line 156
    .line 157
    :cond_8
    iget-object p1, p1, La/TO;->v:La/bc;

    .line 158
    .line 159
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 160
    .line 161
    invoke-static {p1, v0}, La/TO;->R(La/bc;Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    :cond_9
    return-void

    .line 165
    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/Object;)V
    .locals 10

    .line 1
    iget v0, p0, La/Hq;->X:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, La/Hq;->K:La/hK;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p1, Ljava/lang/Boolean;

    .line 10
    .line 11
    invoke-virtual {p0, p1}, La/Hq;->h(Ljava/lang/Boolean;)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-virtual {p0, p1}, La/Hq;->h(Ljava/lang/Boolean;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-virtual {p0, p1}, La/Hq;->h(Ljava/lang/Boolean;)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_2
    check-cast p1, Ljava/lang/CharSequence;

    .line 28
    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    invoke-virtual {v2}, La/hK;->p7()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_0

    .line 36
    .line 37
    invoke-virtual {v2, p1}, La/hK;->rZ(Ljava/lang/CharSequence;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    iget-object p1, v2, La/hK;->y6:La/TO;

    .line 41
    .line 42
    invoke-virtual {p1, v1}, La/TO;->T(La/rk;)V

    .line 43
    .line 44
    .line 45
    :cond_1
    return-void

    .line 46
    :pswitch_3
    check-cast p1, La/rk;

    .line 47
    .line 48
    if-eqz p1, :cond_10

    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    iget v0, p1, La/rk;->w:I

    .line 54
    .line 55
    packed-switch v0, :pswitch_data_1

    .line 56
    .line 57
    .line 58
    :pswitch_4
    const/16 v0, 0x8

    .line 59
    .line 60
    :pswitch_5
    invoke-virtual {v2}, La/zr;->R()Landroid/content/Context;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 65
    .line 66
    const/16 v5, 0x1d

    .line 67
    .line 68
    if-ge v4, v5, :cond_4

    .line 69
    .line 70
    const/4 v5, 0x7

    .line 71
    if-eq v0, v5, :cond_2

    .line 72
    .line 73
    const/16 v5, 0x9

    .line 74
    .line 75
    if-ne v0, v5, :cond_4

    .line 76
    .line 77
    :cond_2
    if-eqz v3, :cond_4

    .line 78
    .line 79
    invoke-static {v3}, La/Wk;->w(Landroid/content/Context;)Landroid/app/KeyguardManager;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    if-nez v3, :cond_3

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_3
    invoke-static {v3}, La/Wk;->h(Landroid/app/KeyguardManager;)Z

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    if-eqz v3, :cond_4

    .line 91
    .line 92
    iget-object v3, v2, La/hK;->y6:La/TO;

    .line 93
    .line 94
    invoke-virtual {v3}, La/TO;->V()I

    .line 95
    .line 96
    .line 97
    move-result v3

    .line 98
    invoke-static {v3}, La/fe;->Y(I)Z

    .line 99
    .line 100
    .line 101
    move-result v3

    .line 102
    if-eqz v3, :cond_4

    .line 103
    .line 104
    invoke-virtual {v2}, La/hK;->F9()V

    .line 105
    .line 106
    .line 107
    goto/16 :goto_7

    .line 108
    .line 109
    :cond_4
    :goto_0
    invoke-virtual {v2}, La/hK;->p7()Z

    .line 110
    .line 111
    .line 112
    move-result v3

    .line 113
    iget-object p1, p1, La/rk;->h:Ljava/lang/CharSequence;

    .line 114
    .line 115
    if-eqz v3, :cond_e

    .line 116
    .line 117
    if-eqz p1, :cond_5

    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_5
    invoke-virtual {v2}, La/zr;->R()Landroid/content/Context;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    invoke-static {p1, v0}, La/cH;->I(Landroid/content/Context;I)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    :goto_1
    const/4 v3, 0x5

    .line 129
    if-ne v0, v3, :cond_8

    .line 130
    .line 131
    iget-object v3, v2, La/hK;->y6:La/TO;

    .line 132
    .line 133
    iget v3, v3, La/TO;->S:I

    .line 134
    .line 135
    if-eqz v3, :cond_6

    .line 136
    .line 137
    const/4 v4, 0x3

    .line 138
    if-ne v3, v4, :cond_7

    .line 139
    .line 140
    :cond_6
    invoke-virtual {v2, v0, p1}, La/hK;->mh(ILjava/lang/CharSequence;)V

    .line 141
    .line 142
    .line 143
    :cond_7
    invoke-virtual {v2}, La/hK;->FL()V

    .line 144
    .line 145
    .line 146
    goto/16 :goto_7

    .line 147
    .line 148
    :cond_8
    iget-object v3, v2, La/hK;->y6:La/TO;

    .line 149
    .line 150
    iget-boolean v3, v3, La/TO;->j:Z

    .line 151
    .line 152
    const/4 v5, 0x1

    .line 153
    if-eqz v3, :cond_9

    .line 154
    .line 155
    invoke-virtual {v2, v0, p1}, La/hK;->eH(ILjava/lang/CharSequence;)V

    .line 156
    .line 157
    .line 158
    goto :goto_5

    .line 159
    :cond_9
    invoke-virtual {v2, p1}, La/hK;->rZ(Ljava/lang/CharSequence;)V

    .line 160
    .line 161
    .line 162
    iget-object v3, v2, La/hK;->B1:Landroid/os/Handler;

    .line 163
    .line 164
    new-instance v6, La/l3;

    .line 165
    .line 166
    invoke-direct {v6, v2, v0, p1, v5}, La/l3;-><init>(La/hK;ILjava/lang/CharSequence;I)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v2}, La/zr;->R()Landroid/content/Context;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    if-eqz p1, :cond_d

    .line 174
    .line 175
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 176
    .line 177
    const/16 v7, 0x1c

    .line 178
    .line 179
    if-eq v4, v7, :cond_a

    .line 180
    .line 181
    goto :goto_3

    .line 182
    :cond_a
    if-nez v0, :cond_b

    .line 183
    .line 184
    goto :goto_3

    .line 185
    :cond_b
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    const v4, 0x7f030006

    .line 190
    .line 191
    .line 192
    invoke-virtual {p1, v4}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    array-length v4, p1

    .line 197
    const/4 v7, 0x0

    .line 198
    move v8, v7

    .line 199
    :goto_2
    if-ge v8, v4, :cond_d

    .line 200
    .line 201
    aget-object v9, p1, v8

    .line 202
    .line 203
    invoke-virtual {v0, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 204
    .line 205
    .line 206
    move-result v9

    .line 207
    if-eqz v9, :cond_c

    .line 208
    .line 209
    goto :goto_4

    .line 210
    :cond_c
    add-int/lit8 v8, v8, 0x1

    .line 211
    .line 212
    goto :goto_2

    .line 213
    :cond_d
    :goto_3
    const/16 v7, 0x7d0

    .line 214
    .line 215
    :goto_4
    int-to-long v7, v7

    .line 216
    invoke-virtual {v3, v6, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 217
    .line 218
    .line 219
    :goto_5
    iget-object p1, v2, La/hK;->y6:La/TO;

    .line 220
    .line 221
    iput-boolean v5, p1, La/TO;->j:Z

    .line 222
    .line 223
    goto :goto_7

    .line 224
    :cond_e
    if-eqz p1, :cond_f

    .line 225
    .line 226
    goto :goto_6

    .line 227
    :cond_f
    new-instance p1, Ljava/lang/StringBuilder;

    .line 228
    .line 229
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 230
    .line 231
    .line 232
    const v3, 0x7f120038

    .line 233
    .line 234
    .line 235
    invoke-virtual {v2, v3}, La/zr;->l(I)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 240
    .line 241
    .line 242
    const-string v3, " "

    .line 243
    .line 244
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 245
    .line 246
    .line 247
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object p1

    .line 254
    :goto_6
    invoke-virtual {v2, v0, p1}, La/hK;->eH(ILjava/lang/CharSequence;)V

    .line 255
    .line 256
    .line 257
    :goto_7
    iget-object p1, v2, La/hK;->y6:La/TO;

    .line 258
    .line 259
    invoke-virtual {p1, v1}, La/TO;->T(La/rk;)V

    .line 260
    .line 261
    .line 262
    :cond_10
    return-void

    .line 263
    :pswitch_6
    check-cast p1, La/Z1;

    .line 264
    .line 265
    if-eqz p1, :cond_12

    .line 266
    .line 267
    invoke-virtual {v2, p1}, La/hK;->ZU(La/Z1;)V

    .line 268
    .line 269
    .line 270
    iget-object p1, v2, La/hK;->y6:La/TO;

    .line 271
    .line 272
    iget-object v0, p1, La/TO;->u:La/bc;

    .line 273
    .line 274
    if-nez v0, :cond_11

    .line 275
    .line 276
    new-instance v0, La/bc;

    .line 277
    .line 278
    invoke-direct {v0}, Landroidx/lifecycle/h;-><init>()V

    .line 279
    .line 280
    .line 281
    iput-object v0, p1, La/TO;->u:La/bc;

    .line 282
    .line 283
    :cond_11
    iget-object p1, p1, La/TO;->u:La/bc;

    .line 284
    .line 285
    invoke-static {p1, v1}, La/TO;->R(La/bc;Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    :cond_12
    return-void

    .line 289
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
    .end packed-switch
.end method
