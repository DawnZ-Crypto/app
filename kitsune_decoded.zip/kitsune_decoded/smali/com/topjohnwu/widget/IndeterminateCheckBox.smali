.class public Lcom/topjohnwu/widget/IndeterminateCheckBox;
.super La/E3;
.source "SourceFile"


# static fields
.field public static final N:[I


# instance fields
.field public transient B:La/Mq;

.field public transient c:Z

.field public r:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const v0, 0x7f040421

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->N:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1, p2}, La/E3;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    const v0, 0x7f0800ce

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->setButtonDrawable(I)V

    .line 8
    .line 9
    .line 10
    sget-object v0, La/TH;->w:[I

    .line 11
    .line 12
    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const/4 p2, 0x0

    .line 17
    const/4 v0, 0x1

    .line 18
    :try_start_0
    invoke-virtual {p1, v0, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    if-eqz p2, :cond_0

    .line 23
    .line 24
    invoke-virtual {p0, v0, v0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->V(ZZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    .line 26
    .line 27
    :cond_0
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :catchall_0
    move-exception p2

    .line 32
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 33
    .line 34
    .line 35
    throw p2
.end method


# virtual methods
.method public final O()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->c:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->c:Z

    .line 8
    .line 9
    iget-object v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->B:La/Mq;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->X()Ljava/lang/Boolean;

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, La/Mq;->K:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, La/pi;

    .line 19
    .line 20
    invoke-interface {v0}, La/pi;->w()V

    .line 21
    .line 22
    .line 23
    :cond_1
    const/4 v0, 0x0

    .line 24
    iput-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->c:Z

    .line 25
    .line 26
    return-void
.end method

.method public final V(ZZ)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    if-eq v0, p1, :cond_0

    iput-boolean p1, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    if-eqz p2, :cond_0

    invoke-virtual {p0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->O()V

    :cond_0
    return-void
.end method

.method public final X()Ljava/lang/Boolean;
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/E3;->isChecked()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public final getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 1

    const-class v0, Lcom/topjohnwu/widget/IndeterminateCheckBox;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final onCreateDrawableState(I)[I
    .locals 1

    add-int/lit8 p1, p1, 0x1

    invoke-super {p0, p1}, La/E3;->onCreateDrawableState(I)[I

    move-result-object p1

    invoke-virtual {p0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->X()Ljava/lang/Boolean;

    move-result-object v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->N:[I

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    return-object p1
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    check-cast p1, La/CO;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->c:Z

    invoke-virtual {p1}, Landroid/view/AbsSavedState;->getSuperState()Landroid/os/Parcelable;

    move-result-object v0

    invoke-super {p0, v0}, La/E3;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->c:Z

    iget-boolean p1, p1, La/CO;->X:Z

    iput-boolean p1, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    if-nez p1, :cond_0

    invoke-virtual {p0}, La/E3;->isChecked()Z

    move-result p1

    if-eqz p1, :cond_1

    :cond_0
    invoke-virtual {p0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->O()V

    :cond_1
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    invoke-super {p0}, La/E3;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, La/CO;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    iget-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    .line 11
    .line 12
    iput-boolean v0, v1, La/CO;->X:Z

    .line 13
    .line 14
    return-object v1
.end method

.method public final setButtonDrawable(I)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, La/E3;->setButtonDrawable(I)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x4

    .line 5
    new-array p1, p1, [[I

    .line 6
    .line 7
    const v0, -0x101009e

    .line 8
    .line 9
    .line 10
    filled-new-array {v0}, [I

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const/4 v1, 0x0

    .line 15
    aput-object v0, p1, v1

    .line 16
    .line 17
    const v0, 0x7f040421

    .line 18
    .line 19
    .line 20
    filled-new-array {v0}, [I

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const/4 v1, 0x1

    .line 25
    aput-object v0, p1, v1

    .line 26
    .line 27
    const v0, 0x10100a0

    .line 28
    .line 29
    .line 30
    filled-new-array {v0}, [I

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v1, 0x2

    .line 35
    aput-object v0, p1, v1

    .line 36
    .line 37
    const/4 v0, 0x3

    .line 38
    sget-object v1, Landroid/util/StateSet;->WILD_CARD:[I

    .line 39
    .line 40
    aput-object v1, p1, v0

    .line 41
    .line 42
    const v0, 0x7f040100

    .line 43
    .line 44
    .line 45
    invoke-static {p0, v0}, La/rE;->o(Landroid/view/View;I)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    const v2, 0x7f040102

    .line 54
    .line 55
    .line 56
    invoke-static {v1, v2, v0}, La/rE;->g(Landroid/content/Context;II)I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const v2, 0x7f04012d

    .line 61
    .line 62
    .line 63
    invoke-static {p0, v2}, La/rE;->o(Landroid/view/View;I)I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    const v3, 0x7f040117

    .line 68
    .line 69
    .line 70
    invoke-static {p0, v3}, La/rE;->o(Landroid/view/View;I)I

    .line 71
    .line 72
    .line 73
    move-result v3

    .line 74
    const/high16 v4, 0x3f800000    # 1.0f

    .line 75
    .line 76
    invoke-static {v2, v0, v4}, La/rE;->Gy(IIF)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    invoke-static {v2, v1, v4}, La/rE;->Gy(IIF)I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    const v4, 0x3f0a3d71    # 0.54f

    .line 85
    .line 86
    .line 87
    invoke-static {v2, v3, v4}, La/rE;->Gy(IIF)I

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    const v5, 0x3ec28f5c    # 0.38f

    .line 92
    .line 93
    .line 94
    invoke-static {v2, v3, v5}, La/rE;->Gy(IIF)I

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    filled-new-array {v2, v1, v0, v4}, [I

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    new-instance v1, Landroid/content/res/ColorStateList;

    .line 103
    .line 104
    invoke-direct {v1, p1, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 105
    .line 106
    .line 107
    invoke-static {p0, v1}, La/vb;->p(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    .line 108
    .line 109
    .line 110
    return-void
.end method

.method public final setChecked(Z)V
    .locals 2

    .line 1
    invoke-virtual {p0}, La/E3;->isChecked()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eq v0, p1, :cond_0

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move v0, v1

    .line 11
    :goto_0
    invoke-virtual {p0, p1}, La/E3;->p(I)V

    .line 12
    .line 13
    .line 14
    iget-boolean p1, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    .line 15
    .line 16
    invoke-virtual {p0, v1, v1}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->V(ZZ)V

    .line 17
    .line 18
    .line 19
    if-nez p1, :cond_1

    .line 20
    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    :cond_1
    invoke-virtual {p0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->O()V

    .line 24
    .line 25
    .line 26
    :cond_2
    return-void
.end method

.method public final toggle()V
    .locals 1

    iget-boolean v0, p0, Lcom/topjohnwu/widget/IndeterminateCheckBox;->r:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->setChecked(Z)V

    goto :goto_0

    :cond_0
    invoke-super {p0}, La/E3;->toggle()V

    :goto_0
    return-void
.end method
