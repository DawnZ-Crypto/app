.class public final Landroidx/lifecycle/SavedStateHandleController;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final K:La/RZ;

.field public R:Z

.field public final X:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;La/RZ;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/SavedStateHandleController;->X:Ljava/lang/String;

    iput-object p2, p0, Landroidx/lifecycle/SavedStateHandleController;->K:La/RZ;

    return-void
.end method


# virtual methods
.method public final O(La/GK;La/VV;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/lifecycle/SavedStateHandleController;->R:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    xor-int/2addr v0, v1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iput-boolean v1, p0, Landroidx/lifecycle/SavedStateHandleController;->R:Z

    .line 8
    .line 9
    invoke-virtual {p1, p0}, La/GK;->w(La/IQ;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Landroidx/lifecycle/SavedStateHandleController;->K:La/RZ;

    .line 13
    .line 14
    iget-object p1, p1, La/RZ;->i:La/p2;

    .line 15
    .line 16
    iget-object v0, p0, Landroidx/lifecycle/SavedStateHandleController;->X:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {p2, v0, p1}, La/VV;->p(Ljava/lang/String;La/KO;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    const-string p2, "Already attached to lifecycleOwner"

    .line 25
    .line 26
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    throw p1
.end method

.method public final Q(La/RH;La/cw;)V
    .locals 1

    .line 1
    sget-object v0, La/cw;->ON_DESTROY:La/cw;

    if-ne p2, v0, :cond_0

    const/4 p2, 0x0

    iput-boolean p2, p0, Landroidx/lifecycle/SavedStateHandleController;->R:Z

    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/w;->h(La/IQ;)V

    :cond_0
    return-void
.end method
