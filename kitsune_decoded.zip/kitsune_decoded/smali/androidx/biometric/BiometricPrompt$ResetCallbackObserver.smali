.class Landroidx/biometric/BiometricPrompt$ResetCallbackObserver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/IQ;


# virtual methods
.method public resetCallback()V
    .locals 1
    .annotation runtime La/tu;
        value = .enum La/cw;->ON_DESTROY:La/cw;
    .end annotation

    const/4 v0, 0x0

    throw v0
.end method
