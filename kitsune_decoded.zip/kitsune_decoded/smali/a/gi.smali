.class public La/gi;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/mt;


# instance fields
.field public final synthetic K:Landroid/view/View;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, La/gi;->X:I

    .line 5
    .line 6
    iput-object p1, p0, La/gi;->K:Landroid/view/View;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final I(La/pY;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/gi;->K:Landroid/view/View;

    check-cast v0, Landroidx/appcompat/widget/ActionMenuView;

    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->t:La/mt;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, La/mt;->I(La/pY;)V

    :cond_0
    return-void
.end method

.method public h(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final i(La/pY;Landroid/view/MenuItem;)Z
    .locals 3

    .line 1
    iget-object p1, p0, La/gi;->K:Landroid/view/View;

    .line 2
    .line 3
    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    .line 4
    .line 5
    iget-object p1, p1, Landroidx/appcompat/widget/ActionMenuView;->o:La/Lg;

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    if-eqz p1, :cond_2

    .line 9
    .line 10
    iget-object p1, p1, La/Lg;->X:Landroidx/appcompat/widget/Toolbar;

    .line 11
    .line 12
    iget-object v1, p1, Landroidx/appcompat/widget/Toolbar;->J:La/yW;

    .line 13
    .line 14
    iget-object v1, v1, La/yW;->R:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, La/We;

    .line 33
    .line 34
    invoke-interface {v2, p2}, La/We;->X(Landroid/view/MenuItem;)Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_0

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->Pc:La/Ej;

    .line 42
    .line 43
    if-eqz p1, :cond_2

    .line 44
    .line 45
    iget-object p1, p1, La/Ej;->X:La/ug;

    .line 46
    .line 47
    iget-object p1, p1, La/ug;->R:Landroid/view/Window$Callback;

    .line 48
    .line 49
    invoke-interface {p1, v0, p2}, Landroid/view/Window$Callback;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-eqz p1, :cond_2

    .line 54
    .line 55
    :goto_0
    const/4 v0, 0x1

    .line 56
    :cond_2
    return v0
.end method

.method public w(I)V
    .locals 0

    .line 1
    return-void
.end method
