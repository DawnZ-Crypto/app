.class public final Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;
.super La/eh;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/eh;"
    }
.end annotation


# instance fields
.field public volatile e:Ljava/lang/reflect/Constructor;

.field public final h:La/eh;

.field public final p:La/eh;

.field public final w:La/dh;


# direct methods
.method public constructor <init>(La/Nm;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "link"

    const-string v1, "note"

    const-string v2, "version"

    const-string v3, "versionCode"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/dh;->S([Ljava/lang/String;)La/dh;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->w:La/dh;

    sget-object v0, La/UK;->X:La/UK;

    const-class v1, Ljava/lang/String;

    invoke-virtual {p1, v1, v0, v2}, La/Nm;->h(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)La/eh;

    move-result-object v1

    iput-object v1, p0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->h:La/eh;

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-virtual {p1, v1, v0, v3}, La/Nm;->h(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)La/eh;

    move-result-object p1

    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->p:La/eh;

    return-void
.end method


# virtual methods
.method public final p(La/At;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p2, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 2
    .line 3
    if-eqz p2, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, La/At;->h()La/AN;

    .line 6
    .line 7
    .line 8
    const-string v0, "version"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->h:La/eh;

    .line 14
    .line 15
    iget-object v1, p2, Lcom/topjohnwu/magisk/core/model/MagiskJson;->X:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v0, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const-string v1, "versionCode"

    .line 21
    .line 22
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 23
    .line 24
    .line 25
    iget v1, p2, Lcom/topjohnwu/magisk/core/model/MagiskJson;->K:I

    .line 26
    .line 27
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iget-object v2, p0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->p:La/eh;

    .line 32
    .line 33
    invoke-virtual {v2, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    const-string v1, "link"

    .line 37
    .line 38
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 39
    .line 40
    .line 41
    iget-object v1, p2, Lcom/topjohnwu/magisk/core/model/MagiskJson;->R:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v0, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    const-string v1, "note"

    .line 47
    .line 48
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 49
    .line 50
    .line 51
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/MagiskJson;->L:Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v0, p1, p2}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1}, La/At;->I()La/AN;

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 61
    .line 62
    const-string p2, "value_ was null! Wrap in .nullSafe() to write nullable values."

    .line 63
    .line 64
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "GeneratedJsonAdapter(MagiskJson)"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w(La/SN;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v3

    .line 10
    invoke-virtual/range {p1 .. p1}, La/SN;->h()V

    .line 11
    .line 12
    .line 13
    const/4 v4, 0x0

    .line 14
    const/4 v5, -0x1

    .line 15
    move-object v7, v4

    .line 16
    move-object v8, v7

    .line 17
    move-object v9, v8

    .line 18
    move v6, v5

    .line 19
    :goto_0
    invoke-virtual/range {p1 .. p1}, La/SN;->U()Z

    .line 20
    .line 21
    .line 22
    move-result v10

    .line 23
    const/4 v11, 0x3

    .line 24
    const/4 v12, 0x2

    .line 25
    const/4 v13, 0x1

    .line 26
    if-eqz v10, :cond_9

    .line 27
    .line 28
    iget-object v10, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->w:La/dh;

    .line 29
    .line 30
    invoke-virtual {v1, v10}, La/SN;->xF(La/dh;)I

    .line 31
    .line 32
    .line 33
    move-result v10

    .line 34
    if-eq v10, v5, :cond_8

    .line 35
    .line 36
    if-eqz v10, :cond_6

    .line 37
    .line 38
    if-eq v10, v13, :cond_4

    .line 39
    .line 40
    if-eq v10, v12, :cond_2

    .line 41
    .line 42
    if-eq v10, v11, :cond_0

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    iget-object v9, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->h:La/eh;

    .line 46
    .line 47
    invoke-virtual {v9, v1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v9

    .line 51
    check-cast v9, Ljava/lang/String;

    .line 52
    .line 53
    if-eqz v9, :cond_1

    .line 54
    .line 55
    and-int/lit8 v6, v6, -0x9

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    const-string v2, "note"

    .line 59
    .line 60
    invoke-static {v2, v2, v1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    throw v1

    .line 65
    :cond_2
    iget-object v8, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->h:La/eh;

    .line 66
    .line 67
    invoke-virtual {v8, v1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    check-cast v8, Ljava/lang/String;

    .line 72
    .line 73
    if-eqz v8, :cond_3

    .line 74
    .line 75
    and-int/lit8 v6, v6, -0x5

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_3
    const-string v2, "link"

    .line 79
    .line 80
    invoke-static {v2, v2, v1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    throw v1

    .line 85
    :cond_4
    iget-object v3, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->p:La/eh;

    .line 86
    .line 87
    invoke-virtual {v3, v1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    check-cast v3, Ljava/lang/Integer;

    .line 92
    .line 93
    if-eqz v3, :cond_5

    .line 94
    .line 95
    and-int/lit8 v6, v6, -0x3

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_5
    const-string v2, "versionCode"

    .line 99
    .line 100
    invoke-static {v2, v2, v1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    throw v1

    .line 105
    :cond_6
    iget-object v7, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->h:La/eh;

    .line 106
    .line 107
    invoke-virtual {v7, v1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v7

    .line 111
    check-cast v7, Ljava/lang/String;

    .line 112
    .line 113
    if-eqz v7, :cond_7

    .line 114
    .line 115
    and-int/lit8 v6, v6, -0x2

    .line 116
    .line 117
    goto :goto_0

    .line 118
    :cond_7
    const-string v2, "version"

    .line 119
    .line 120
    invoke-static {v2, v2, v1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    throw v1

    .line 125
    :cond_8
    invoke-virtual/range {p1 .. p1}, La/SN;->Pb()V

    .line 126
    .line 127
    .line 128
    invoke-virtual/range {p1 .. p1}, La/SN;->lI()V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_9
    invoke-virtual/range {p1 .. p1}, La/SN;->T()V

    .line 133
    .line 134
    .line 135
    const/16 v1, -0x10

    .line 136
    .line 137
    if-ne v6, v1, :cond_a

    .line 138
    .line 139
    new-instance v1, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 140
    .line 141
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    invoke-direct {v1, v7, v2, v8, v9}, Lcom/topjohnwu/magisk/core/model/MagiskJson;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_a
    iget-object v1, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->e:Ljava/lang/reflect/Constructor;

    .line 150
    .line 151
    const/4 v5, 0x5

    .line 152
    const/4 v10, 0x4

    .line 153
    const/4 v14, 0x6

    .line 154
    if-nez v1, :cond_b

    .line 155
    .line 156
    new-array v1, v14, [Ljava/lang/Class;

    .line 157
    .line 158
    const-class v15, Ljava/lang/String;

    .line 159
    .line 160
    aput-object v15, v1, v2

    .line 161
    .line 162
    sget-object v16, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 163
    .line 164
    aput-object v16, v1, v13

    .line 165
    .line 166
    aput-object v15, v1, v12

    .line 167
    .line 168
    aput-object v15, v1, v11

    .line 169
    .line 170
    aput-object v16, v1, v10

    .line 171
    .line 172
    sget-object v15, La/Gh;->p:Ljava/lang/Class;

    .line 173
    .line 174
    aput-object v15, v1, v5

    .line 175
    .line 176
    const-class v15, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 177
    .line 178
    invoke-virtual {v15, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    iput-object v1, v0, Lcom/topjohnwu/magisk/core/model/MagiskJsonJsonAdapter;->e:Ljava/lang/reflect/Constructor;

    .line 183
    .line 184
    :cond_b
    new-array v14, v14, [Ljava/lang/Object;

    .line 185
    .line 186
    aput-object v7, v14, v2

    .line 187
    .line 188
    aput-object v3, v14, v13

    .line 189
    .line 190
    aput-object v8, v14, v12

    .line 191
    .line 192
    aput-object v9, v14, v11

    .line 193
    .line 194
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 195
    .line 196
    .line 197
    move-result-object v2

    .line 198
    aput-object v2, v14, v10

    .line 199
    .line 200
    aput-object v4, v14, v5

    .line 201
    .line 202
    invoke-virtual {v1, v14}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    check-cast v1, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 207
    .line 208
    :goto_1
    return-object v1
.end method
