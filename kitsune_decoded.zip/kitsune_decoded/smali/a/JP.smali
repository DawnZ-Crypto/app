.class public La/JP;
.super Landroid/graphics/drawable/Drawable$ConstantState;
.source "SourceFile"


# instance fields
.field public I:F

.field public final K:F

.field public L:I

.field public M:F

.field public O:Landroid/graphics/Rect;

.field public Q:Landroid/content/res/ColorStateList;

.field public final R:I

.field public T:I

.field public final V:F

.field public final W:Landroid/graphics/Paint$Style;

.field public X:Landroid/graphics/PorterDuff$Mode;

.field public d:I

.field public e:Landroid/content/res/ColorStateList;

.field public final f:I

.field public h:La/WC;

.field public final i:Landroid/content/res/ColorStateList;

.field public l:Z

.field public m:F

.field public p:Landroid/content/res/ColorStateList;

.field public w:La/c9;

.field public y:F


# direct methods
.method public constructor <init>(La/JP;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/JP;->p:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->e:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->i:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->Q:Landroid/content/res/ColorStateList;

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    iput-object v1, p0, La/JP;->X:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La/JP;->O:Landroid/graphics/Rect;

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, La/JP;->V:F

    iput v0, p0, La/JP;->I:F

    const/16 v0, 0xff

    iput v0, p0, La/JP;->T:I

    const/4 v0, 0x0

    iput v0, p0, La/JP;->m:F

    iput v0, p0, La/JP;->y:F

    iput v0, p0, La/JP;->K:F

    const/4 v0, 0x0

    iput v0, p0, La/JP;->R:I

    iput v0, p0, La/JP;->L:I

    iput v0, p0, La/JP;->d:I

    iput v0, p0, La/JP;->f:I

    iput-boolean v0, p0, La/JP;->l:Z

    sget-object v0, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    iput-object v0, p0, La/JP;->W:Landroid/graphics/Paint$Style;

    iget-object v0, p1, La/JP;->w:La/c9;

    iput-object v0, p0, La/JP;->w:La/c9;

    iget-object v0, p1, La/JP;->h:La/WC;

    iput-object v0, p0, La/JP;->h:La/WC;

    iget v0, p1, La/JP;->M:F

    iput v0, p0, La/JP;->M:F

    iget-object v0, p1, La/JP;->p:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->p:Landroid/content/res/ColorStateList;

    iget-object v0, p1, La/JP;->e:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->e:Landroid/content/res/ColorStateList;

    iget-object v0, p1, La/JP;->X:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La/JP;->X:Landroid/graphics/PorterDuff$Mode;

    iget-object v0, p1, La/JP;->Q:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->Q:Landroid/content/res/ColorStateList;

    iget v0, p1, La/JP;->T:I

    iput v0, p0, La/JP;->T:I

    iget v0, p1, La/JP;->V:F

    iput v0, p0, La/JP;->V:F

    iget v0, p1, La/JP;->d:I

    iput v0, p0, La/JP;->d:I

    iget v0, p1, La/JP;->R:I

    iput v0, p0, La/JP;->R:I

    iget-boolean v0, p1, La/JP;->l:Z

    iput-boolean v0, p0, La/JP;->l:Z

    iget v0, p1, La/JP;->I:F

    iput v0, p0, La/JP;->I:F

    iget v0, p1, La/JP;->m:F

    iput v0, p0, La/JP;->m:F

    iget v0, p1, La/JP;->y:F

    iput v0, p0, La/JP;->y:F

    iget v0, p1, La/JP;->K:F

    iput v0, p0, La/JP;->K:F

    iget v0, p1, La/JP;->L:I

    iput v0, p0, La/JP;->L:I

    iget v0, p1, La/JP;->f:I

    iput v0, p0, La/JP;->f:I

    iget-object v0, p1, La/JP;->i:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->i:Landroid/content/res/ColorStateList;

    iget-object v0, p1, La/JP;->W:Landroid/graphics/Paint$Style;

    iput-object v0, p0, La/JP;->W:Landroid/graphics/Paint$Style;

    iget-object v0, p1, La/JP;->O:Landroid/graphics/Rect;

    if-eqz v0, :cond_0

    new-instance v0, Landroid/graphics/Rect;

    iget-object p1, p1, La/JP;->O:Landroid/graphics/Rect;

    invoke-direct {v0, p1}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    iput-object v0, p0, La/JP;->O:Landroid/graphics/Rect;

    :cond_0
    return-void
.end method

.method public constructor <init>(La/c9;)V
    .locals 2

    .line 2
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, La/JP;->p:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->e:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->i:Landroid/content/res/ColorStateList;

    iput-object v0, p0, La/JP;->Q:Landroid/content/res/ColorStateList;

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    iput-object v1, p0, La/JP;->X:Landroid/graphics/PorterDuff$Mode;

    iput-object v0, p0, La/JP;->O:Landroid/graphics/Rect;

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, La/JP;->V:F

    iput v1, p0, La/JP;->I:F

    const/16 v1, 0xff

    iput v1, p0, La/JP;->T:I

    const/4 v1, 0x0

    iput v1, p0, La/JP;->m:F

    iput v1, p0, La/JP;->y:F

    iput v1, p0, La/JP;->K:F

    const/4 v1, 0x0

    iput v1, p0, La/JP;->R:I

    iput v1, p0, La/JP;->L:I

    iput v1, p0, La/JP;->d:I

    iput v1, p0, La/JP;->f:I

    iput-boolean v1, p0, La/JP;->l:Z

    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    iput-object v1, p0, La/JP;->W:Landroid/graphics/Paint$Style;

    iput-object p1, p0, La/JP;->w:La/c9;

    iput-object v0, p0, La/JP;->h:La/WC;

    return-void
.end method


# virtual methods
.method public final getChangingConfigurations()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    new-instance v0, La/ex;

    invoke-direct {v0, p0}, La/ex;-><init>(La/JP;)V

    const/4 v1, 0x1

    iput-boolean v1, v0, La/ex;->d:Z

    return-object v0
.end method
