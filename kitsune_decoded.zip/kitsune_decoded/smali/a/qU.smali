.class public final La/qU;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;
.implements La/zg;


# static fields
.field public static final B:Ljava/util/List;

.field public static final c:Ljava/util/List;


# instance fields
.field public final C:I

.field public final D:Ljavax/net/SocketFactory;

.field public final E:La/RN;

.field public final F:La/ah;

.field public final H:Ljava/net/Proxy;

.field public final K:La/sR;

.field public final L:Ljava/util/List;

.field public final P:La/va;

.field public final R:Ljava/util/List;

.field public final S:La/pw;

.field public final U:Ljava/util/List;

.field public final W:Z

.field public final X:La/DG;

.field public final Y:Ljavax/net/ssl/SSLSocketFactory;

.field public final d:La/Mq;

.field public final f:Z

.field public final g:I

.field public final j:La/A8;

.field public final k:Ljava/util/List;

.field public final l:La/va;

.field public final n:I

.field public final o:J

.field public final q:Z

.field public final r:La/sR;

.field public final s:La/y0;

.field public final t:I

.field public final u:Ljavax/net/ssl/X509TrustManager;

.field public final v:Ljavax/net/ssl/HostnameVerifier;

.field public final x:I

.field public final z:Ljava/net/ProxySelector;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    const/4 v0, 0x2

    new-array v1, v0, [La/Li;

    sget-object v2, La/Li;->d:La/Li;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    sget-object v2, La/Li;->R:La/Li;

    const/4 v4, 0x1

    aput-object v2, v1, v4

    invoke-static {v1}, La/kD;->I([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sput-object v1, La/qU;->c:Ljava/util/List;

    new-array v0, v0, [La/dP;

    sget-object v1, La/dP;->i:La/dP;

    aput-object v1, v0, v3

    sget-object v1, La/dP;->Q:La/dP;

    aput-object v1, v0, v4

    invoke-static {v0}, La/kD;->I([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, La/qU;->B:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(La/ML;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, La/ML;->w:La/DG;

    .line 5
    .line 6
    iput-object v0, p0, La/qU;->X:La/DG;

    .line 7
    .line 8
    iget-object v0, p1, La/ML;->h:La/sR;

    .line 9
    .line 10
    iput-object v0, p0, La/qU;->K:La/sR;

    .line 11
    .line 12
    iget-object v0, p1, La/ML;->p:Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-static {v0}, La/kD;->q(Ljava/util/List;)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, La/qU;->R:Ljava/util/List;

    .line 19
    .line 20
    iget-object v0, p1, La/ML;->e:Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-static {v0}, La/kD;->q(Ljava/util/List;)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iput-object v0, p0, La/qU;->L:Ljava/util/List;

    .line 27
    .line 28
    iget-object v0, p1, La/ML;->i:La/Mq;

    .line 29
    .line 30
    iput-object v0, p0, La/qU;->d:La/Mq;

    .line 31
    .line 32
    iget-boolean v0, p1, La/ML;->Q:Z

    .line 33
    .line 34
    iput-boolean v0, p0, La/qU;->f:Z

    .line 35
    .line 36
    iget-object v0, p1, La/ML;->X:La/va;

    .line 37
    .line 38
    iput-object v0, p0, La/qU;->l:La/va;

    .line 39
    .line 40
    iget-boolean v0, p1, La/ML;->O:Z

    .line 41
    .line 42
    iput-boolean v0, p0, La/qU;->W:Z

    .line 43
    .line 44
    iget-boolean v0, p1, La/ML;->V:Z

    .line 45
    .line 46
    iput-boolean v0, p0, La/qU;->q:Z

    .line 47
    .line 48
    iget-object v0, p1, La/ML;->I:La/ah;

    .line 49
    .line 50
    iput-object v0, p0, La/qU;->F:La/ah;

    .line 51
    .line 52
    iget-object v0, p1, La/ML;->M:La/RN;

    .line 53
    .line 54
    iput-object v0, p0, La/qU;->E:La/RN;

    .line 55
    .line 56
    iget-object v0, p1, La/ML;->T:La/pw;

    .line 57
    .line 58
    iput-object v0, p0, La/qU;->S:La/pw;

    .line 59
    .line 60
    iget-object v0, p1, La/ML;->m:Ljava/net/Proxy;

    .line 61
    .line 62
    iput-object v0, p0, La/qU;->H:Ljava/net/Proxy;

    .line 63
    .line 64
    if-eqz v0, :cond_0

    .line 65
    .line 66
    :goto_0
    sget-object v0, La/bB;->w:La/bB;

    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_0
    iget-object v0, p1, La/ML;->y:Ljava/net/ProxySelector;

    .line 70
    .line 71
    if-nez v0, :cond_1

    .line 72
    .line 73
    invoke-static {}, Ljava/net/ProxySelector;->getDefault()Ljava/net/ProxySelector;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    :cond_1
    if-nez v0, :cond_2

    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_2
    :goto_1
    iput-object v0, p0, La/qU;->z:Ljava/net/ProxySelector;

    .line 81
    .line 82
    iget-object v0, p1, La/ML;->K:La/va;

    .line 83
    .line 84
    iput-object v0, p0, La/qU;->P:La/va;

    .line 85
    .line 86
    iget-object v0, p1, La/ML;->R:Ljavax/net/SocketFactory;

    .line 87
    .line 88
    iput-object v0, p0, La/qU;->D:Ljavax/net/SocketFactory;

    .line 89
    .line 90
    iget-object v0, p1, La/ML;->f:Ljava/util/List;

    .line 91
    .line 92
    iput-object v0, p0, La/qU;->U:Ljava/util/List;

    .line 93
    .line 94
    iget-object v1, p1, La/ML;->l:Ljava/util/List;

    .line 95
    .line 96
    iput-object v1, p0, La/qU;->k:Ljava/util/List;

    .line 97
    .line 98
    iget-object v1, p1, La/ML;->W:Ljavax/net/ssl/HostnameVerifier;

    .line 99
    .line 100
    iput-object v1, p0, La/qU;->v:Ljavax/net/ssl/HostnameVerifier;

    .line 101
    .line 102
    iget v1, p1, La/ML;->E:I

    .line 103
    .line 104
    iput v1, p0, La/qU;->t:I

    .line 105
    .line 106
    iget v1, p1, La/ML;->S:I

    .line 107
    .line 108
    iput v1, p0, La/qU;->n:I

    .line 109
    .line 110
    iget v1, p1, La/ML;->H:I

    .line 111
    .line 112
    iput v1, p0, La/qU;->C:I

    .line 113
    .line 114
    iget v1, p1, La/ML;->z:I

    .line 115
    .line 116
    iput v1, p0, La/qU;->x:I

    .line 117
    .line 118
    iget v1, p1, La/ML;->P:I

    .line 119
    .line 120
    iput v1, p0, La/qU;->g:I

    .line 121
    .line 122
    iget-wide v1, p1, La/ML;->D:J

    .line 123
    .line 124
    iput-wide v1, p0, La/qU;->o:J

    .line 125
    .line 126
    iget-object v1, p1, La/ML;->Y:La/sR;

    .line 127
    .line 128
    if-nez v1, :cond_3

    .line 129
    .line 130
    new-instance v1, La/sR;

    .line 131
    .line 132
    const/4 v2, 0x7

    .line 133
    invoke-direct {v1, v2}, La/sR;-><init>(I)V

    .line 134
    .line 135
    .line 136
    :cond_3
    iput-object v1, p0, La/qU;->r:La/sR;

    .line 137
    .line 138
    instance-of v1, v0, Ljava/util/Collection;

    .line 139
    .line 140
    const/4 v2, 0x0

    .line 141
    if-eqz v1, :cond_4

    .line 142
    .line 143
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    if-eqz v1, :cond_4

    .line 148
    .line 149
    goto :goto_4

    .line 150
    :cond_4
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    :cond_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    if-eqz v1, :cond_9

    .line 159
    .line 160
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    check-cast v1, La/dP;

    .line 165
    .line 166
    iget-boolean v1, v1, La/dP;->w:Z

    .line 167
    .line 168
    if-eqz v1, :cond_5

    .line 169
    .line 170
    iget-object v0, p1, La/ML;->L:Ljavax/net/ssl/SSLSocketFactory;

    .line 171
    .line 172
    if-eqz v0, :cond_7

    .line 173
    .line 174
    iput-object v0, p0, La/qU;->Y:Ljavax/net/ssl/SSLSocketFactory;

    .line 175
    .line 176
    iget-object v0, p1, La/ML;->F:La/A8;

    .line 177
    .line 178
    iput-object v0, p0, La/qU;->j:La/A8;

    .line 179
    .line 180
    iget-object v1, p1, La/ML;->d:Ljavax/net/ssl/X509TrustManager;

    .line 181
    .line 182
    iput-object v1, p0, La/qU;->u:Ljavax/net/ssl/X509TrustManager;

    .line 183
    .line 184
    iget-object p1, p1, La/ML;->q:La/y0;

    .line 185
    .line 186
    iget-object v1, p1, La/y0;->h:La/A8;

    .line 187
    .line 188
    invoke-static {v1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    move-result v1

    .line 192
    if-eqz v1, :cond_6

    .line 193
    .line 194
    goto :goto_3

    .line 195
    :cond_6
    new-instance v1, La/y0;

    .line 196
    .line 197
    iget-object p1, p1, La/y0;->w:Ljava/util/Set;

    .line 198
    .line 199
    invoke-direct {v1, p1, v0}, La/y0;-><init>(Ljava/util/Set;La/A8;)V

    .line 200
    .line 201
    .line 202
    :goto_2
    move-object p1, v1

    .line 203
    :goto_3
    iput-object p1, p0, La/qU;->s:La/y0;

    .line 204
    .line 205
    goto :goto_5

    .line 206
    :cond_7
    sget-object v0, La/wd;->w:La/wd;

    .line 207
    .line 208
    sget-object v0, La/wd;->w:La/wd;

    .line 209
    .line 210
    invoke-virtual {v0}, La/wd;->y()Ljavax/net/ssl/X509TrustManager;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    iput-object v0, p0, La/qU;->u:Ljavax/net/ssl/X509TrustManager;

    .line 215
    .line 216
    sget-object v1, La/wd;->w:La/wd;

    .line 217
    .line 218
    invoke-virtual {v1, v0}, La/wd;->m(Ljavax/net/ssl/X509TrustManager;)Ljavax/net/ssl/SSLSocketFactory;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    iput-object v1, p0, La/qU;->Y:Ljavax/net/ssl/SSLSocketFactory;

    .line 223
    .line 224
    sget-object v1, La/wd;->w:La/wd;

    .line 225
    .line 226
    invoke-virtual {v1, v0}, La/wd;->h(Ljavax/net/ssl/X509TrustManager;)La/A8;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    iput-object v0, p0, La/qU;->j:La/A8;

    .line 231
    .line 232
    iget-object p1, p1, La/ML;->q:La/y0;

    .line 233
    .line 234
    iget-object v1, p1, La/y0;->h:La/A8;

    .line 235
    .line 236
    invoke-static {v1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 237
    .line 238
    .line 239
    move-result v1

    .line 240
    if-eqz v1, :cond_8

    .line 241
    .line 242
    goto :goto_3

    .line 243
    :cond_8
    new-instance v1, La/y0;

    .line 244
    .line 245
    iget-object p1, p1, La/y0;->w:Ljava/util/Set;

    .line 246
    .line 247
    invoke-direct {v1, p1, v0}, La/y0;-><init>(Ljava/util/Set;La/A8;)V

    .line 248
    .line 249
    .line 250
    goto :goto_2

    .line 251
    :cond_9
    :goto_4
    iput-object v2, p0, La/qU;->Y:Ljavax/net/ssl/SSLSocketFactory;

    .line 252
    .line 253
    iput-object v2, p0, La/qU;->j:La/A8;

    .line 254
    .line 255
    iput-object v2, p0, La/qU;->u:Ljavax/net/ssl/X509TrustManager;

    .line 256
    .line 257
    sget-object p1, La/y0;->p:La/y0;

    .line 258
    .line 259
    goto :goto_3

    .line 260
    :goto_5
    iget-object p1, p0, La/qU;->R:Ljava/util/List;

    .line 261
    .line 262
    invoke-interface {p1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result v0

    .line 266
    xor-int/lit8 v0, v0, 0x1

    .line 267
    .line 268
    if-eqz v0, :cond_15

    .line 269
    .line 270
    iget-object p1, p0, La/qU;->L:Ljava/util/List;

    .line 271
    .line 272
    invoke-interface {p1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-result v0

    .line 276
    xor-int/lit8 v0, v0, 0x1

    .line 277
    .line 278
    if-eqz v0, :cond_14

    .line 279
    .line 280
    iget-object p1, p0, La/qU;->U:Ljava/util/List;

    .line 281
    .line 282
    instance-of v0, p1, Ljava/util/Collection;

    .line 283
    .line 284
    iget-object v1, p0, La/qU;->u:Ljavax/net/ssl/X509TrustManager;

    .line 285
    .line 286
    iget-object v2, p0, La/qU;->j:La/A8;

    .line 287
    .line 288
    iget-object v3, p0, La/qU;->Y:Ljavax/net/ssl/SSLSocketFactory;

    .line 289
    .line 290
    if-eqz v0, :cond_a

    .line 291
    .line 292
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 293
    .line 294
    .line 295
    move-result v0

    .line 296
    if-eqz v0, :cond_a

    .line 297
    .line 298
    goto :goto_6

    .line 299
    :cond_a
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 300
    .line 301
    .line 302
    move-result-object p1

    .line 303
    :cond_b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 304
    .line 305
    .line 306
    move-result v0

    .line 307
    if-eqz v0, :cond_f

    .line 308
    .line 309
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    check-cast v0, La/dP;

    .line 314
    .line 315
    iget-boolean v0, v0, La/dP;->w:Z

    .line 316
    .line 317
    if-eqz v0, :cond_b

    .line 318
    .line 319
    if-eqz v3, :cond_e

    .line 320
    .line 321
    if-eqz v2, :cond_d

    .line 322
    .line 323
    if-eqz v1, :cond_c

    .line 324
    .line 325
    goto :goto_7

    .line 326
    :cond_c
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 327
    .line 328
    const-string v0, "x509TrustManager == null"

    .line 329
    .line 330
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v0

    .line 334
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    throw p1

    .line 338
    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 339
    .line 340
    const-string v0, "certificateChainCleaner == null"

    .line 341
    .line 342
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 343
    .line 344
    .line 345
    move-result-object v0

    .line 346
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    throw p1

    .line 350
    :cond_e
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 351
    .line 352
    const-string v0, "sslSocketFactory == null"

    .line 353
    .line 354
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v0

    .line 358
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    throw p1

    .line 362
    :cond_f
    :goto_6
    const-string p1, "Check failed."

    .line 363
    .line 364
    if-nez v3, :cond_13

    .line 365
    .line 366
    if-nez v2, :cond_12

    .line 367
    .line 368
    if-nez v1, :cond_11

    .line 369
    .line 370
    iget-object v0, p0, La/qU;->s:La/y0;

    .line 371
    .line 372
    sget-object v1, La/y0;->p:La/y0;

    .line 373
    .line 374
    invoke-static {v0, v1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    move-result v0

    .line 378
    if-eqz v0, :cond_10

    .line 379
    .line 380
    :goto_7
    return-void

    .line 381
    :cond_10
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 382
    .line 383
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object p1

    .line 387
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 388
    .line 389
    .line 390
    throw v0

    .line 391
    :cond_11
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 392
    .line 393
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 394
    .line 395
    .line 396
    move-result-object p1

    .line 397
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 398
    .line 399
    .line 400
    throw v0

    .line 401
    :cond_12
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 402
    .line 403
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 404
    .line 405
    .line 406
    move-result-object p1

    .line 407
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 408
    .line 409
    .line 410
    throw v0

    .line 411
    :cond_13
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 412
    .line 413
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 414
    .line 415
    .line 416
    move-result-object p1

    .line 417
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 418
    .line 419
    .line 420
    throw v0

    .line 421
    :cond_14
    new-instance v0, Ljava/lang/StringBuilder;

    .line 422
    .line 423
    const-string v1, "Null network interceptor: "

    .line 424
    .line 425
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 426
    .line 427
    .line 428
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 429
    .line 430
    .line 431
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object p1

    .line 435
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 436
    .line 437
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 438
    .line 439
    .line 440
    move-result-object p1

    .line 441
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 442
    .line 443
    .line 444
    throw v0

    .line 445
    :cond_15
    new-instance v0, Ljava/lang/StringBuilder;

    .line 446
    .line 447
    const-string v1, "Null interceptor: "

    .line 448
    .line 449
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 450
    .line 451
    .line 452
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 453
    .line 454
    .line 455
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object p1

    .line 459
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 460
    .line 461
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object p1

    .line 465
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 466
    .line 467
    .line 468
    throw v0
.end method


# virtual methods
.method public final clone()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
