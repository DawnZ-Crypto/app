.class public Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;
.super La/Vo;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/Vo;"
    }
.end annotation


# instance fields
.field public final FL:La/Y0;

.field public final Pc:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/Vo;-><init>()V

    const v0, 0x7f0c001d

    iput v0, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->Pc:I

    new-instance v0, La/Vn;

    const/16 v1, 0x9

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->FL:La/Y0;

    return-void
.end method


# virtual methods
.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->FL:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/J8;

    .line 8
    .line 9
    return-object v0
.end method

.method public final W()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->Pc:I

    return v0
.end method

.method public final finish()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->finishAndRemoveTask()V

    return-void
.end method

.method public final getTheme()Landroid/content/res/Resources$Theme;
    .locals 3

    invoke-super {p0}, Landroid/app/Activity;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v0

    const v1, 0x7f13013d

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/Resources$Theme;->applyStyle(IZ)V

    return-object v0
.end method

.method public final onBackPressed()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->FL:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/J8;

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    invoke-virtual {v0, v1}, La/J8;->R(I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, La/m1;->L()La/Js;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1}, La/Js;->V(I)Z

    .line 7
    .line 8
    .line 9
    const/16 v0, 0xe

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const/16 v2, 0x80

    .line 19
    .line 20
    invoke-virtual {v0, v2}, Landroid/view/Window;->addFlags(I)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v2, 0x3

    .line 28
    invoke-virtual {v0, v2}, Landroid/view/Window;->addFlags(I)V

    .line 29
    .line 30
    .line 31
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 32
    .line 33
    const/16 v3, 0x1f

    .line 34
    .line 35
    if-lt v0, v3, :cond_0

    .line 36
    .line 37
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-static {v0}, La/e;->R(Landroid/view/Window;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    sget-object v0, La/B4;->L:[La/B4;

    .line 45
    .line 46
    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, [La/B4;

    .line 51
    .line 52
    sget-object v3, La/Dp;->w:La/Dp;

    .line 53
    .line 54
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    sget-object v4, La/Dp;->h:[La/KG;

    .line 58
    .line 59
    const/16 v5, 0xa

    .line 60
    .line 61
    aget-object v4, v4, v5

    .line 62
    .line 63
    sget-object v5, La/Dp;->R:La/bT;

    .line 64
    .line 65
    invoke-virtual {v5, v3, v4}, La/bT;->r(La/dN;La/KG;)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    const/4 v4, 0x0

    .line 74
    if-ltz v3, :cond_1

    .line 75
    .line 76
    array-length v5, v0

    .line 77
    sub-int/2addr v5, v1

    .line 78
    if-gt v3, v5, :cond_1

    .line 79
    .line 80
    aget-object v0, v0, v3

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_1
    move-object v0, v4

    .line 84
    :goto_0
    if-nez v0, :cond_2

    .line 85
    .line 86
    sget-object v0, La/B4;->R:La/B4;

    .line 87
    .line 88
    :cond_2
    iget v0, v0, La/B4;->K:I

    .line 89
    .line 90
    invoke-virtual {p0, v0}, La/m1;->setTheme(I)V

    .line 91
    .line 92
    .line 93
    invoke-super {p0, p1}, La/Vo;->onCreate(Landroid/os/Bundle;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    const-string v0, "android.intent.action.VIEW"

    .line 105
    .line 106
    invoke-static {p1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_4

    .line 111
    .line 112
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    const-string v0, "action"

    .line 117
    .line 118
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    const-string v0, "request"

    .line 123
    .line 124
    invoke-static {p1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-eqz v0, :cond_3

    .line 129
    .line 130
    iget-object p1, p0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->FL:La/Y0;

    .line 131
    .line 132
    invoke-interface {p1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    check-cast p1, La/J8;

    .line 137
    .line 138
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    .line 144
    .line 145
    invoke-static {p1}, La/rE;->mh(La/AZ;)La/wE;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    sget-object v2, La/Th;->w:La/Fu;

    .line 150
    .line 151
    new-instance v3, La/IT;

    .line 152
    .line 153
    invoke-direct {v3, p1, v0, v4}, La/IT;-><init>(La/J8;Landroid/content/Intent;La/hu;)V

    .line 154
    .line 155
    .line 156
    const/4 p1, 0x2

    .line 157
    invoke-static {v1, v2, v3, p1}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 158
    .line 159
    .line 160
    goto :goto_1

    .line 161
    :cond_3
    invoke-static {p0}, La/rE;->J(La/RH;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    new-instance v1, La/dK;

    .line 166
    .line 167
    invoke-direct {v1, p0, p1, v4}, La/dK;-><init>(Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;Ljava/lang/String;La/hu;)V

    .line 168
    .line 169
    .line 170
    invoke-static {v0, v4, v1, v2}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 171
    .line 172
    .line 173
    goto :goto_1

    .line 174
    :cond_4
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;->finish()V

    .line 175
    .line 176
    .line 177
    :goto_1
    return-void
.end method
