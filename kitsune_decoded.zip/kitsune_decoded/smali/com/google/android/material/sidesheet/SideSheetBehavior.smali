.class public Lcom/google/android/material/sidesheet/SideSheetBehavior;
.super La/AC;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Landroid/view/View;",
        ">",
        "La/AC;"
    }
.end annotation


# instance fields
.field public I:Z

.field public K:I

.field public L:Ljava/lang/ref/WeakReference;

.field public final M:F

.field public O:I

.field public final Q:F

.field public R:Ljava/lang/ref/WeakReference;

.field public T:I

.field public V:La/w1;

.field public final W:Ljava/util/LinkedHashSet;

.field public final X:Z

.field public final d:I

.field public final e:La/c9;

.field public f:Landroid/view/VelocityTracker;

.field public final h:La/ex;

.field public final i:La/Dt;

.field public l:I

.field public m:I

.field public final p:Landroid/content/res/ColorStateList;

.field public final q:La/pU;

.field public w:La/B5;

.field public y:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, La/Dt;

    invoke-direct {v0, p0}, La/Dt;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;)V

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:La/Dt;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->X:Z

    const/4 v0, 0x5

    iput v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    const v0, 0x3dcccccd    # 0.1f

    iput v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->M:F

    const/4 v0, -0x1

    iput v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->d:I

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->W:Ljava/util/LinkedHashSet;

    new-instance v0, La/pU;

    invoke-direct {v0, p0}, La/pU;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;)V

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->q:La/pU;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 7

    const/4 v0, 0x0

    invoke-direct {p0, v0}, La/AC;-><init>(I)V

    new-instance v1, La/Dt;

    invoke-direct {v1, p0}, La/Dt;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;)V

    iput-object v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:La/Dt;

    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->X:Z

    const/4 v2, 0x5

    iput v2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    const v3, 0x3dcccccd    # 0.1f

    iput v3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->M:F

    const/4 v3, -0x1

    iput v3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->d:I

    new-instance v4, Ljava/util/LinkedHashSet;

    invoke-direct {v4}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v4, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->W:Ljava/util/LinkedHashSet;

    new-instance v4, La/pU;

    invoke-direct {v4, p0}, La/pU;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;)V

    iput-object v4, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->q:La/pU;

    sget-object v4, La/tS;->k:[I

    invoke-virtual {p1, p2, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v4

    const/4 v5, 0x3

    invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-static {p1, v4, v5}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v5

    iput-object v5, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->p:Landroid/content/res/ColorStateList;

    :cond_0
    const/4 v5, 0x6

    invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v5

    if-eqz v5, :cond_1

    const v5, 0x7f1303fe

    invoke-static {p1, p2, v0, v5}, La/c9;->h(Landroid/content/Context;Landroid/util/AttributeSet;II)La/as;

    move-result-object p2

    invoke-virtual {p2}, La/as;->w()La/c9;

    move-result-object p2

    iput-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->e:La/c9;

    :cond_1
    invoke-virtual {v4, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p2

    if-eqz p2, :cond_3

    invoke-virtual {v4, v2, v3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p2

    iput p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->d:I

    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->L:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    .line 2
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->clear()V

    :cond_2
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->L:Ljava/lang/ref/WeakReference;

    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eq p2, v3, :cond_3

    sget-object p2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 4
    invoke-static {v0}, La/AM;->p(Landroid/view/View;)Z

    move-result p2

    if-eqz p2, :cond_3

    .line 5
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_3
    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->e:La/c9;

    if-nez p2, :cond_4

    goto :goto_0

    .line 6
    :cond_4
    new-instance v0, La/ex;

    invoke-direct {v0, p2}, La/ex;-><init>(La/c9;)V

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    invoke-virtual {v0, p1}, La/ex;->T(Landroid/content/Context;)V

    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->p:Landroid/content/res/ColorStateList;

    if-eqz p2, :cond_5

    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    invoke-virtual {v0, p2}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    goto :goto_0

    :cond_5
    new-instance p2, Landroid/util/TypedValue;

    invoke-direct {p2}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v0

    const v2, 0x1010031

    invoke-virtual {v0, v2, p2, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    iget p2, p2, Landroid/util/TypedValue;->data:I

    invoke-virtual {v0, p2}, La/ex;->setTint(I)V

    :goto_0
    const/4 p2, 0x2

    const/high16 v0, -0x40800000    # -1.0f

    .line 7
    invoke-virtual {v4, p2, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p2

    iput p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->Q:F

    const/4 p2, 0x4

    invoke-virtual {v4, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    iput-boolean p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->X:Z

    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    return-void
.end method


# virtual methods
.method public final K(Landroid/view/View;)Landroid/os/Parcelable;
    .locals 1

    .line 1
    new-instance p1, La/lk;

    .line 2
    .line 3
    sget-object v0, Landroid/view/View$BaseSavedState;->EMPTY_STATE:Landroid/view/AbsSavedState;

    .line 4
    .line 5
    invoke-direct {p1, v0, p0}, La/lk;-><init>(Landroid/view/AbsSavedState;Lcom/google/android/material/sidesheet/SideSheetBehavior;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final O(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 9

    .line 1
    sget-object v0, La/sI;->w:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    invoke-static {p1}, La/Tl;->h(Landroid/view/View;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x1

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p2}, La/Tl;->h(Landroid/view/View;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p2, v1}, Landroid/view/View;->setFitsSystemWindows(Z)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 20
    .line 21
    const/4 v2, 0x5

    .line 22
    const/4 v3, 0x0

    .line 23
    const/4 v4, 0x0

    .line 24
    if-nez v0, :cond_7

    .line 25
    .line 26
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 27
    .line 28
    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 32
    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    const/high16 v5, 0x3f800000    # 1.0f

    .line 38
    .line 39
    invoke-static {v4, v4, v4, v5}, La/UR;->h(FFFF)Landroid/view/animation/Interpolator;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    const v6, 0x7f040354

    .line 44
    .line 45
    .line 46
    invoke-static {v0, v6, v5}, La/rx;->cS(Landroid/content/Context;ILandroid/view/animation/Interpolator;)Landroid/animation/TimeInterpolator;

    .line 47
    .line 48
    .line 49
    const v5, 0x7f040343

    .line 50
    .line 51
    .line 52
    const/16 v6, 0x12c

    .line 53
    .line 54
    invoke-static {v0, v5, v6}, La/rx;->MX(Landroid/content/Context;II)I

    .line 55
    .line 56
    .line 57
    const v5, 0x7f040348

    .line 58
    .line 59
    .line 60
    const/16 v6, 0x96

    .line 61
    .line 62
    invoke-static {v0, v5, v6}, La/rx;->MX(Landroid/content/Context;II)I

    .line 63
    .line 64
    .line 65
    const v5, 0x7f040347

    .line 66
    .line 67
    .line 68
    const/16 v6, 0x64

    .line 69
    .line 70
    invoke-static {v0, v5, v6}, La/rx;->MX(Landroid/content/Context;II)I

    .line 71
    .line 72
    .line 73
    invoke-virtual {p2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const v5, 0x7f0700c5

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDimension(I)F

    .line 81
    .line 82
    .line 83
    const v5, 0x7f0700c4

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDimension(I)F

    .line 87
    .line 88
    .line 89
    const v5, 0x7f0700c6

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDimension(I)F

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    .line 96
    .line 97
    if-eqz v0, :cond_2

    .line 98
    .line 99
    invoke-static {p2, v0}, La/Tl;->L(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 100
    .line 101
    .line 102
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    .line 103
    .line 104
    iget v5, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->Q:F

    .line 105
    .line 106
    const/high16 v6, -0x40800000    # -1.0f

    .line 107
    .line 108
    cmpl-float v6, v5, v6

    .line 109
    .line 110
    if-nez v6, :cond_1

    .line 111
    .line 112
    invoke-static {p2}, La/Sg;->V(Landroid/view/View;)F

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    :cond_1
    invoke-virtual {v0, v5}, La/ex;->y(F)V

    .line 117
    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->p:Landroid/content/res/ColorStateList;

    .line 121
    .line 122
    if-eqz v0, :cond_3

    .line 123
    .line 124
    invoke-static {p2, v0}, La/Sg;->L(Landroid/view/View;Landroid/content/res/ColorStateList;)V

    .line 125
    .line 126
    .line 127
    :cond_3
    :goto_0
    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 128
    .line 129
    if-ne v0, v2, :cond_4

    .line 130
    .line 131
    const/4 v0, 0x4

    .line 132
    goto :goto_1

    .line 133
    :cond_4
    move v0, v3

    .line 134
    :goto_1
    invoke-virtual {p2}, Landroid/view/View;->getVisibility()I

    .line 135
    .line 136
    .line 137
    move-result v5

    .line 138
    if-eq v5, v0, :cond_5

    .line 139
    .line 140
    invoke-virtual {p2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 141
    .line 142
    .line 143
    :cond_5
    invoke-virtual {p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->q()V

    .line 144
    .line 145
    .line 146
    invoke-static {p2}, La/Tl;->p(Landroid/view/View;)I

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    if-nez v0, :cond_6

    .line 151
    .line 152
    invoke-static {p2, v1}, La/Tl;->f(Landroid/view/View;I)V

    .line 153
    .line 154
    .line 155
    :cond_6
    invoke-static {p2}, La/sI;->e(Landroid/view/View;)Ljava/lang/CharSequence;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    if-nez v0, :cond_7

    .line 160
    .line 161
    invoke-virtual {p2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    const v5, 0x7f120171

    .line 166
    .line 167
    .line 168
    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-static {p2, v0}, La/sI;->m(Landroid/view/View;Ljava/lang/CharSequence;)V

    .line 173
    .line 174
    .line 175
    :cond_7
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    check-cast v0, La/y9;

    .line 180
    .line 181
    iget v0, v0, La/y9;->p:I

    .line 182
    .line 183
    invoke-static {v0, p3}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    const/4 v5, 0x3

    .line 188
    if-ne v0, v5, :cond_8

    .line 189
    .line 190
    move v0, v1

    .line 191
    goto :goto_2

    .line 192
    :cond_8
    move v0, v3

    .line 193
    :goto_2
    iget-object v6, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 194
    .line 195
    if-eqz v6, :cond_9

    .line 196
    .line 197
    iget v6, v6, La/B5;->K:I

    .line 198
    .line 199
    packed-switch v6, :pswitch_data_0

    .line 200
    .line 201
    .line 202
    move v6, v3

    .line 203
    goto :goto_3

    .line 204
    :pswitch_0
    move v6, v1

    .line 205
    :goto_3
    if-eq v6, v0, :cond_f

    .line 206
    .line 207
    :cond_9
    iget-object v6, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->e:La/c9;

    .line 208
    .line 209
    const/4 v7, 0x0

    .line 210
    if-nez v0, :cond_c

    .line 211
    .line 212
    new-instance v0, La/B5;

    .line 213
    .line 214
    invoke-direct {v0, p0, v1}, La/B5;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;I)V

    .line 215
    .line 216
    .line 217
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 218
    .line 219
    if-eqz v6, :cond_f

    .line 220
    .line 221
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 222
    .line 223
    if-eqz v0, :cond_a

    .line 224
    .line 225
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    check-cast v0, Landroid/view/View;

    .line 230
    .line 231
    if-eqz v0, :cond_a

    .line 232
    .line 233
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 234
    .line 235
    .line 236
    move-result-object v8

    .line 237
    instance-of v8, v8, La/y9;

    .line 238
    .line 239
    if-eqz v8, :cond_a

    .line 240
    .line 241
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    move-object v7, v0

    .line 246
    check-cast v7, La/y9;

    .line 247
    .line 248
    :cond_a
    if-eqz v7, :cond_b

    .line 249
    .line 250
    iget v0, v7, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 251
    .line 252
    if-lez v0, :cond_b

    .line 253
    .line 254
    goto :goto_5

    .line 255
    :cond_b
    invoke-virtual {v6}, La/c9;->Q()La/as;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    new-instance v6, La/r;

    .line 260
    .line 261
    invoke-direct {v6, v4}, La/r;-><init>(F)V

    .line 262
    .line 263
    .line 264
    iput-object v6, v0, La/as;->Q:La/cv;

    .line 265
    .line 266
    new-instance v6, La/r;

    .line 267
    .line 268
    invoke-direct {v6, v4}, La/r;-><init>(F)V

    .line 269
    .line 270
    .line 271
    iput-object v6, v0, La/as;->X:La/cv;

    .line 272
    .line 273
    invoke-virtual {v0}, La/as;->w()La/c9;

    .line 274
    .line 275
    .line 276
    move-result-object v0

    .line 277
    iget-object v4, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    .line 278
    .line 279
    if-eqz v4, :cond_f

    .line 280
    .line 281
    :goto_4
    invoke-virtual {v4, v0}, La/ex;->h(La/c9;)V

    .line 282
    .line 283
    .line 284
    goto :goto_5

    .line 285
    :cond_c
    if-ne v0, v1, :cond_17

    .line 286
    .line 287
    new-instance v0, La/B5;

    .line 288
    .line 289
    invoke-direct {v0, p0, v3}, La/B5;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;I)V

    .line 290
    .line 291
    .line 292
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 293
    .line 294
    if-eqz v6, :cond_f

    .line 295
    .line 296
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 297
    .line 298
    if-eqz v0, :cond_d

    .line 299
    .line 300
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    check-cast v0, Landroid/view/View;

    .line 305
    .line 306
    if-eqz v0, :cond_d

    .line 307
    .line 308
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 309
    .line 310
    .line 311
    move-result-object v8

    .line 312
    instance-of v8, v8, La/y9;

    .line 313
    .line 314
    if-eqz v8, :cond_d

    .line 315
    .line 316
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 317
    .line 318
    .line 319
    move-result-object v0

    .line 320
    move-object v7, v0

    .line 321
    check-cast v7, La/y9;

    .line 322
    .line 323
    :cond_d
    if-eqz v7, :cond_e

    .line 324
    .line 325
    iget v0, v7, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 326
    .line 327
    if-lez v0, :cond_e

    .line 328
    .line 329
    goto :goto_5

    .line 330
    :cond_e
    invoke-virtual {v6}, La/c9;->Q()La/as;

    .line 331
    .line 332
    .line 333
    move-result-object v0

    .line 334
    new-instance v6, La/r;

    .line 335
    .line 336
    invoke-direct {v6, v4}, La/r;-><init>(F)V

    .line 337
    .line 338
    .line 339
    iput-object v6, v0, La/as;->i:La/cv;

    .line 340
    .line 341
    new-instance v6, La/r;

    .line 342
    .line 343
    invoke-direct {v6, v4}, La/r;-><init>(F)V

    .line 344
    .line 345
    .line 346
    iput-object v6, v0, La/as;->O:La/cv;

    .line 347
    .line 348
    invoke-virtual {v0}, La/as;->w()La/c9;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    iget-object v4, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:La/ex;

    .line 353
    .line 354
    if-eqz v4, :cond_f

    .line 355
    .line 356
    goto :goto_4

    .line 357
    :cond_f
    :goto_5
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 358
    .line 359
    if-nez v0, :cond_10

    .line 360
    .line 361
    new-instance v0, La/w1;

    .line 362
    .line 363
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 364
    .line 365
    .line 366
    move-result-object v4

    .line 367
    iget-object v6, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->q:La/pU;

    .line 368
    .line 369
    invoke-direct {v0, v4, p1, v6}, La/w1;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;La/A8;)V

    .line 370
    .line 371
    .line 372
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 373
    .line 374
    :cond_10
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 375
    .line 376
    iget v4, v0, La/B5;->K:I

    .line 377
    .line 378
    iget-object v0, v0, La/B5;->R:Lcom/google/android/material/sidesheet/SideSheetBehavior;

    .line 379
    .line 380
    packed-switch v4, :pswitch_data_1

    .line 381
    .line 382
    .line 383
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 384
    .line 385
    .line 386
    move-result v4

    .line 387
    iget v0, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->K:I

    .line 388
    .line 389
    sub-int/2addr v4, v0

    .line 390
    goto :goto_6

    .line 391
    :pswitch_1
    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 392
    .line 393
    .line 394
    move-result v4

    .line 395
    iget v0, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->K:I

    .line 396
    .line 397
    add-int/2addr v4, v0

    .line 398
    :goto_6
    invoke-virtual {p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->d(Landroid/view/View;I)V

    .line 399
    .line 400
    .line 401
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 402
    .line 403
    .line 404
    move-result p3

    .line 405
    iput p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->m:I

    .line 406
    .line 407
    iget-object p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 408
    .line 409
    iget p3, p3, La/B5;->K:I

    .line 410
    .line 411
    packed-switch p3, :pswitch_data_2

    .line 412
    .line 413
    .line 414
    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    .line 415
    .line 416
    .line 417
    move-result p3

    .line 418
    goto :goto_7

    .line 419
    :pswitch_2
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    .line 420
    .line 421
    .line 422
    move-result p3

    .line 423
    :goto_7
    iput p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->y:I

    .line 424
    .line 425
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 426
    .line 427
    .line 428
    move-result p3

    .line 429
    iput p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->T:I

    .line 430
    .line 431
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 432
    .line 433
    .line 434
    move-result-object p3

    .line 435
    check-cast p3, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 436
    .line 437
    if-eqz p3, :cond_11

    .line 438
    .line 439
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 440
    .line 441
    iget v0, v0, La/B5;->K:I

    .line 442
    .line 443
    packed-switch v0, :pswitch_data_3

    .line 444
    .line 445
    .line 446
    iget p3, p3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 447
    .line 448
    goto :goto_8

    .line 449
    :pswitch_3
    iget p3, p3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 450
    .line 451
    goto :goto_8

    .line 452
    :cond_11
    move p3, v3

    .line 453
    :goto_8
    iput p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->K:I

    .line 454
    .line 455
    iget p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 456
    .line 457
    if-eq p3, v1, :cond_13

    .line 458
    .line 459
    const/4 v0, 0x2

    .line 460
    if-eq p3, v0, :cond_13

    .line 461
    .line 462
    if-eq p3, v5, :cond_14

    .line 463
    .line 464
    if-ne p3, v2, :cond_12

    .line 465
    .line 466
    iget-object p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 467
    .line 468
    invoke-virtual {p3}, La/B5;->B()I

    .line 469
    .line 470
    .line 471
    move-result v3

    .line 472
    goto :goto_a

    .line 473
    :cond_12
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 474
    .line 475
    new-instance p2, Ljava/lang/StringBuilder;

    .line 476
    .line 477
    const-string p3, "Unexpected value: "

    .line 478
    .line 479
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 480
    .line 481
    .line 482
    iget p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 483
    .line 484
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 485
    .line 486
    .line 487
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 488
    .line 489
    .line 490
    move-result-object p2

    .line 491
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 492
    .line 493
    .line 494
    throw p1

    .line 495
    :cond_13
    iget-object p3, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 496
    .line 497
    iget v0, p3, La/B5;->K:I

    .line 498
    .line 499
    iget-object p3, p3, La/B5;->R:Lcom/google/android/material/sidesheet/SideSheetBehavior;

    .line 500
    .line 501
    packed-switch v0, :pswitch_data_4

    .line 502
    .line 503
    .line 504
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 505
    .line 506
    .line 507
    move-result v0

    .line 508
    iget p3, p3, Lcom/google/android/material/sidesheet/SideSheetBehavior;->K:I

    .line 509
    .line 510
    sub-int/2addr v0, p3

    .line 511
    goto :goto_9

    .line 512
    :pswitch_4
    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 513
    .line 514
    .line 515
    move-result v0

    .line 516
    iget p3, p3, Lcom/google/android/material/sidesheet/SideSheetBehavior;->K:I

    .line 517
    .line 518
    add-int/2addr v0, p3

    .line 519
    :goto_9
    sub-int v3, v4, v0

    .line 520
    .line 521
    :cond_14
    :goto_a
    invoke-virtual {p2, v3}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 522
    .line 523
    .line 524
    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->L:Ljava/lang/ref/WeakReference;

    .line 525
    .line 526
    if-nez p2, :cond_15

    .line 527
    .line 528
    iget p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->d:I

    .line 529
    .line 530
    const/4 p3, -0x1

    .line 531
    if-eq p2, p3, :cond_15

    .line 532
    .line 533
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    if-eqz p1, :cond_15

    .line 538
    .line 539
    new-instance p2, Ljava/lang/ref/WeakReference;

    .line 540
    .line 541
    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 542
    .line 543
    .line 544
    iput-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->L:Ljava/lang/ref/WeakReference;

    .line 545
    .line 546
    :cond_15
    iget-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->W:Ljava/util/LinkedHashSet;

    .line 547
    .line 548
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 549
    .line 550
    .line 551
    move-result-object p1

    .line 552
    :goto_b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 553
    .line 554
    .line 555
    move-result p2

    .line 556
    if-eqz p2, :cond_16

    .line 557
    .line 558
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 559
    .line 560
    .line 561
    move-result-object p2

    .line 562
    invoke-static {p2}, La/zq;->R(Ljava/lang/Object;)V

    .line 563
    .line 564
    .line 565
    goto :goto_b

    .line 566
    :cond_16
    return v1

    .line 567
    :cond_17
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 568
    .line 569
    const-string p2, "Invalid sheet edge position value: "

    .line 570
    .line 571
    const-string p3, ". Must be 0 or 1."

    .line 572
    .line 573
    invoke-static {p2, v0, p3}, La/zq;->Q(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 574
    .line 575
    .line 576
    move-result-object p2

    .line 577
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 578
    .line 579
    .line 580
    throw p1

    .line 581
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch

    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_3
    .end packed-switch

    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_4
    .end packed-switch
.end method

.method public final Q()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    return-void
.end method

.method public final V(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)Z
    .locals 3

    .line 1
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    add-int/2addr v2, v1

    .line 16
    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 17
    .line 18
    add-int/2addr v2, v1

    .line 19
    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 20
    .line 21
    add-int/2addr v2, v1

    .line 22
    add-int/2addr v2, p4

    .line 23
    iget p4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 24
    .line 25
    invoke-static {p3, v2, p4}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 26
    .line 27
    .line 28
    move-result p3

    .line 29
    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    .line 30
    .line 31
    .line 32
    move-result p4

    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    add-int/2addr p1, p4

    .line 38
    iget p4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 39
    .line 40
    add-int/2addr p1, p4

    .line 41
    iget p4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 42
    .line 43
    add-int/2addr p1, p4

    .line 44
    iget p4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 45
    .line 46
    invoke-static {p5, p1, p4}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    invoke-virtual {p2, p3, p1}, Landroid/view/View;->measure(II)V

    .line 51
    .line 52
    .line 53
    const/4 p1, 0x1

    .line 54
    return p1
.end method

.method public final W(Landroid/view/View;IZ)V
    .locals 2

    .line 1
    const/4 v0, 0x3

    .line 2
    if-eq p2, v0, :cond_1

    .line 3
    .line 4
    const/4 v0, 0x5

    .line 5
    if-ne p2, v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 8
    .line 9
    invoke-virtual {v0}, La/B5;->B()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 15
    .line 16
    const-string p3, "Invalid state to get outer edge offset: "

    .line 17
    .line 18
    invoke-static {p3, p2}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->w:La/B5;

    .line 27
    .line 28
    invoke-virtual {v0}, La/B5;->c()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    :goto_0
    iget-object v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 33
    .line 34
    if-eqz v1, :cond_4

    .line 35
    .line 36
    if-eqz p3, :cond_2

    .line 37
    .line 38
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    invoke-virtual {v1, v0, p1}, La/w1;->K(II)Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_4

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    iput-object p1, v1, La/w1;->d:Landroid/view/View;

    .line 54
    .line 55
    const/4 p1, -0x1

    .line 56
    iput p1, v1, La/w1;->p:I

    .line 57
    .line 58
    const/4 p1, 0x0

    .line 59
    invoke-virtual {v1, v0, p3, p1, p1}, La/w1;->O(IIII)Z

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    if-nez p1, :cond_3

    .line 64
    .line 65
    iget p3, v1, La/w1;->w:I

    .line 66
    .line 67
    if-nez p3, :cond_3

    .line 68
    .line 69
    iget-object p3, v1, La/w1;->d:Landroid/view/View;

    .line 70
    .line 71
    if-eqz p3, :cond_3

    .line 72
    .line 73
    const/4 p3, 0x0

    .line 74
    iput-object p3, v1, La/w1;->d:Landroid/view/View;

    .line 75
    .line 76
    :cond_3
    if-eqz p1, :cond_4

    .line 77
    .line 78
    :goto_1
    const/4 p1, 0x2

    .line 79
    invoke-virtual {p0, p1}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f(I)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:La/Dt;

    .line 83
    .line 84
    invoke-virtual {p1, p2}, La/Dt;->w(I)V

    .line 85
    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_4
    invoke-virtual {p0, p2}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f(I)V

    .line 89
    .line 90
    .line 91
    :goto_2
    return-void
.end method

.method public final X(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2

    .line 1
    invoke-virtual {p2}, Landroid/view/View;->isShown()Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x1

    .line 6
    const/4 v1, 0x0

    .line 7
    if-nez p1, :cond_0

    .line 8
    .line 9
    invoke-static {p2}, La/sI;->e(Landroid/view/View;)Ljava/lang/CharSequence;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    if-eqz p1, :cond_7

    .line 14
    .line 15
    :cond_0
    iget-boolean p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->X:Z

    .line 16
    .line 17
    if-eqz p1, :cond_7

    .line 18
    .line 19
    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    if-nez p1, :cond_1

    .line 24
    .line 25
    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 26
    .line 27
    if-eqz p2, :cond_1

    .line 28
    .line 29
    invoke-virtual {p2}, Landroid/view/VelocityTracker;->recycle()V

    .line 30
    .line 31
    .line 32
    const/4 p2, 0x0

    .line 33
    iput-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 34
    .line 35
    :cond_1
    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 36
    .line 37
    if-nez p2, :cond_2

    .line 38
    .line 39
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    iput-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 44
    .line 45
    :cond_2
    iget-object p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 46
    .line 47
    invoke-virtual {p2, p3}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 48
    .line 49
    .line 50
    if-eqz p1, :cond_4

    .line 51
    .line 52
    if-eq p1, v0, :cond_3

    .line 53
    .line 54
    const/4 p2, 0x3

    .line 55
    if-eq p1, p2, :cond_3

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_3
    iget-boolean p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 59
    .line 60
    if-eqz p1, :cond_5

    .line 61
    .line 62
    iput-boolean v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 63
    .line 64
    return v1

    .line 65
    :cond_4
    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    float-to-int p1, p1

    .line 70
    iput p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->l:I

    .line 71
    .line 72
    :cond_5
    :goto_0
    iget-boolean p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 73
    .line 74
    if-nez p1, :cond_6

    .line 75
    .line 76
    iget-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 77
    .line 78
    if-eqz p1, :cond_6

    .line 79
    .line 80
    invoke-virtual {p1, p3}, La/w1;->R(Landroid/view/MotionEvent;)Z

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    if-eqz p1, :cond_6

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_6
    move v0, v1

    .line 88
    :goto_1
    return v0

    .line 89
    :cond_7
    iput-boolean v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 90
    .line 91
    return v1
.end method

.method public final d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3

    .line 1
    invoke-virtual {p2}, Landroid/view/View;->isShown()Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    return p1

    .line 9
    :cond_0
    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 14
    .line 15
    const/4 v1, 0x1

    .line 16
    if-ne v0, v1, :cond_1

    .line 17
    .line 18
    if-nez p1, :cond_1

    .line 19
    .line 20
    return v1

    .line 21
    :cond_1
    invoke-virtual {p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->l()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 28
    .line 29
    invoke-virtual {v0, p3}, La/w1;->I(Landroid/view/MotionEvent;)V

    .line 30
    .line 31
    .line 32
    :cond_2
    if-nez p1, :cond_3

    .line 33
    .line 34
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 35
    .line 36
    if-eqz v0, :cond_3

    .line 37
    .line 38
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 39
    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 43
    .line 44
    :cond_3
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 45
    .line 46
    if-nez v0, :cond_4

    .line 47
    .line 48
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 53
    .line 54
    :cond_4
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->f:Landroid/view/VelocityTracker;

    .line 55
    .line 56
    invoke-virtual {v0, p3}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->l()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_6

    .line 64
    .line 65
    const/4 v0, 0x2

    .line 66
    if-ne p1, v0, :cond_6

    .line 67
    .line 68
    iget-boolean p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 69
    .line 70
    if-nez p1, :cond_6

    .line 71
    .line 72
    invoke-virtual {p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->l()Z

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    if-nez p1, :cond_5

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_5
    iget p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->l:I

    .line 80
    .line 81
    int-to-float p1, p1

    .line 82
    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    sub-float/2addr p1, v0

    .line 87
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    .line 92
    .line 93
    iget v2, v0, La/w1;->h:I

    .line 94
    .line 95
    int-to-float v2, v2

    .line 96
    cmpl-float p1, p1, v2

    .line 97
    .line 98
    if-lez p1, :cond_6

    .line 99
    .line 100
    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    invoke-virtual {p3, p1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 105
    .line 106
    .line 107
    move-result p1

    .line 108
    invoke-virtual {v0, p2, p1}, La/w1;->h(Landroid/view/View;I)V

    .line 109
    .line 110
    .line 111
    :cond_6
    :goto_0
    iget-boolean p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->I:Z

    .line 112
    .line 113
    xor-int/2addr p1, v1

    .line 114
    return p1
.end method

.method public final f(I)V
    .locals 2

    .line 1
    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iput p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    const/4 v1, 0x5

    .line 10
    iget-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 11
    .line 12
    if-nez p1, :cond_1

    .line 13
    .line 14
    return-void

    .line 15
    :cond_1
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Landroid/view/View;

    .line 20
    .line 21
    if-nez p1, :cond_2

    .line 22
    .line 23
    return-void

    .line 24
    :cond_2
    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 25
    .line 26
    if-ne v0, v1, :cond_3

    .line 27
    .line 28
    const/4 v0, 0x4

    .line 29
    goto :goto_0

    .line 30
    :cond_3
    const/4 v0, 0x0

    .line 31
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eq v1, v0, :cond_4

    .line 36
    .line 37
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 38
    .line 39
    .line 40
    :cond_4
    iget-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->W:Ljava/util/LinkedHashSet;

    .line 41
    .line 42
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_5

    .line 51
    .line 52
    invoke-virtual {p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->q()V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_5
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    const/4 p1, 0x0

    .line 64
    throw p1
.end method

.method public final l()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->X:Z

    const/4 v1, 0x1

    if-nez v0, :cond_1

    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :cond_1
    :goto_0
    return v1
.end method

.method public final p(La/y9;)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    iput-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    iput-object p1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->V:La/w1;

    return-void
.end method

.method public final q()V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->R:Ljava/lang/ref/WeakReference;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Landroid/view/View;

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    return-void

    .line 15
    :cond_1
    const/high16 v1, 0x40000

    .line 16
    .line 17
    invoke-static {v0, v1}, La/sI;->V(Landroid/view/View;I)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-static {v0, v1}, La/sI;->X(Landroid/view/View;I)V

    .line 22
    .line 23
    .line 24
    const/high16 v2, 0x100000

    .line 25
    .line 26
    invoke-static {v0, v2}, La/sI;->V(Landroid/view/View;I)V

    .line 27
    .line 28
    .line 29
    invoke-static {v0, v1}, La/sI;->X(Landroid/view/View;I)V

    .line 30
    .line 31
    .line 32
    iget v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 33
    .line 34
    const/4 v2, 0x5

    .line 35
    if-eq v1, v2, :cond_2

    .line 36
    .line 37
    sget-object v1, La/Hs;->I:La/Hs;

    .line 38
    .line 39
    new-instance v3, La/Rz;

    .line 40
    .line 41
    invoke-direct {v3, p0, v2}, La/Rz;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;I)V

    .line 42
    .line 43
    .line 44
    invoke-static {v0, v1, v3}, La/sI;->I(Landroid/view/View;La/Hs;La/Fl;)V

    .line 45
    .line 46
    .line 47
    :cond_2
    iget v1, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    .line 48
    .line 49
    const/4 v2, 0x3

    .line 50
    if-eq v1, v2, :cond_3

    .line 51
    .line 52
    sget-object v1, La/Hs;->O:La/Hs;

    .line 53
    .line 54
    new-instance v3, La/Rz;

    .line 55
    .line 56
    invoke-direct {v3, p0, v2}, La/Rz;-><init>(Lcom/google/android/material/sidesheet/SideSheetBehavior;I)V

    .line 57
    .line 58
    .line 59
    invoke-static {v0, v1, v3}, La/sI;->I(Landroid/view/View;La/Hs;La/Fl;)V

    .line 60
    .line 61
    .line 62
    :cond_3
    return-void
.end method

.method public final y(Landroid/view/View;Landroid/os/Parcelable;)V
    .locals 0

    .line 1
    check-cast p2, La/lk;

    const/4 p1, 0x1

    iget p2, p2, La/lk;->R:I

    if-eq p2, p1, :cond_0

    const/4 p1, 0x2

    if-ne p2, p1, :cond_1

    :cond_0
    const/4 p2, 0x5

    :cond_1
    iput p2, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->O:I

    return-void
.end method
