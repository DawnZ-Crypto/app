.class public final La/gH;
.super La/Yo;
.source "SourceFile"


# instance fields
.field public final synthetic K:Landroid/content/Context;

.field public final synthetic L:La/Yo;

.field public final synthetic R:Landroid/text/TextPaint;

.field public final synthetic d:La/fy;


# direct methods
.method public constructor <init>(La/fy;Landroid/content/Context;Landroid/text/TextPaint;La/Yo;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/gH;->d:La/fy;

    iput-object p2, p0, La/gH;->K:Landroid/content/Context;

    iput-object p3, p0, La/gH;->R:Landroid/text/TextPaint;

    iput-object p4, p0, La/gH;->L:La/Yo;

    const/4 p1, 0x5

    invoke-direct {p0, p1}, La/Yo;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final H(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La/gH;->L:La/Yo;

    invoke-virtual {v0, p1}, La/Yo;->H(I)V

    return-void
.end method

.method public final z(Landroid/graphics/Typeface;Z)V
    .locals 3

    .line 1
    iget-object v0, p0, La/gH;->R:Landroid/text/TextPaint;

    iget-object v1, p0, La/gH;->d:La/fy;

    iget-object v2, p0, La/gH;->K:Landroid/content/Context;

    invoke-virtual {v1, v2, v0, p1}, La/fy;->X(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    iget-object v0, p0, La/gH;->L:La/Yo;

    invoke-virtual {v0, p1, p2}, La/Yo;->z(Landroid/graphics/Typeface;Z)V

    return-void
.end method
