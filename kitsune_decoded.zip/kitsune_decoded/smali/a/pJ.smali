.class public abstract La/pJ;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:[Ljava/lang/String;

.field public static final h:[Ljava/lang/String;

.field public static final p:[Ljava/lang/String;

.field public static final w:La/xi;


# direct methods
.method static constructor <clinit>()V
    .locals 13

    .line 1
    sget-object v0, La/xi;->L:La/xi;

    .line 2
    .line 3
    const-string v0, "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"

    .line 4
    .line 5
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, La/pJ;->w:La/xi;

    .line 10
    .line 11
    const-string v1, "DATA"

    .line 12
    .line 13
    const-string v2, "HEADERS"

    .line 14
    .line 15
    const-string v3, "PRIORITY"

    .line 16
    .line 17
    const-string v4, "RST_STREAM"

    .line 18
    .line 19
    const-string v5, "SETTINGS"

    .line 20
    .line 21
    const-string v6, "PUSH_PROMISE"

    .line 22
    .line 23
    const-string v7, "PING"

    .line 24
    .line 25
    const-string v8, "GOAWAY"

    .line 26
    .line 27
    const-string v9, "WINDOW_UPDATE"

    .line 28
    .line 29
    const-string v10, "CONTINUATION"

    .line 30
    .line 31
    filled-new-array/range {v1 .. v10}, [Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    sput-object v0, La/pJ;->h:[Ljava/lang/String;

    .line 36
    .line 37
    const/16 v0, 0x40

    .line 38
    .line 39
    new-array v0, v0, [Ljava/lang/String;

    .line 40
    .line 41
    sput-object v0, La/pJ;->p:[Ljava/lang/String;

    .line 42
    .line 43
    const/16 v0, 0x100

    .line 44
    .line 45
    new-array v1, v0, [Ljava/lang/String;

    .line 46
    .line 47
    const/4 v2, 0x0

    .line 48
    move v3, v2

    .line 49
    :goto_0
    const/16 v4, 0x20

    .line 50
    .line 51
    const/4 v5, 0x1

    .line 52
    if-ge v3, v0, :cond_0

    .line 53
    .line 54
    new-array v5, v5, [Ljava/lang/Object;

    .line 55
    .line 56
    invoke-static {v3}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    aput-object v6, v5, v2

    .line 61
    .line 62
    const-string v6, "%8s"

    .line 63
    .line 64
    invoke-static {v6, v5}, La/kD;->X(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v5

    .line 68
    const/16 v6, 0x30

    .line 69
    .line 70
    invoke-virtual {v5, v4, v6}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    aput-object v4, v1, v3

    .line 75
    .line 76
    add-int/lit8 v3, v3, 0x1

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_0
    sput-object v1, La/pJ;->e:[Ljava/lang/String;

    .line 80
    .line 81
    sget-object v0, La/pJ;->p:[Ljava/lang/String;

    .line 82
    .line 83
    const-string v1, ""

    .line 84
    .line 85
    aput-object v1, v0, v2

    .line 86
    .line 87
    const-string v1, "END_STREAM"

    .line 88
    .line 89
    aput-object v1, v0, v5

    .line 90
    .line 91
    filled-new-array {v5}, [I

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    const-string v3, "PADDED"

    .line 96
    .line 97
    const/16 v5, 0x8

    .line 98
    .line 99
    aput-object v3, v0, v5

    .line 100
    .line 101
    aget v3, v1, v2

    .line 102
    .line 103
    or-int/lit8 v6, v3, 0x8

    .line 104
    .line 105
    new-instance v7, Ljava/lang/StringBuilder;

    .line 106
    .line 107
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 108
    .line 109
    .line 110
    aget-object v3, v0, v3

    .line 111
    .line 112
    const-string v8, "|PADDED"

    .line 113
    .line 114
    invoke-static {v7, v3, v8}, La/zq;->M(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    aput-object v3, v0, v6

    .line 119
    .line 120
    const/4 v3, 0x4

    .line 121
    const-string v6, "END_HEADERS"

    .line 122
    .line 123
    aput-object v6, v0, v3

    .line 124
    .line 125
    const-string v6, "PRIORITY"

    .line 126
    .line 127
    aput-object v6, v0, v4

    .line 128
    .line 129
    const/16 v6, 0x24

    .line 130
    .line 131
    const-string v7, "END_HEADERS|PRIORITY"

    .line 132
    .line 133
    aput-object v7, v0, v6

    .line 134
    .line 135
    filled-new-array {v3, v4, v6}, [I

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    move v3, v2

    .line 140
    :goto_1
    const/4 v4, 0x3

    .line 141
    if-ge v3, v4, :cond_1

    .line 142
    .line 143
    aget v4, v0, v3

    .line 144
    .line 145
    aget v6, v1, v2

    .line 146
    .line 147
    sget-object v7, La/pJ;->p:[Ljava/lang/String;

    .line 148
    .line 149
    or-int v9, v6, v4

    .line 150
    .line 151
    new-instance v10, Ljava/lang/StringBuilder;

    .line 152
    .line 153
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 154
    .line 155
    .line 156
    aget-object v11, v7, v6

    .line 157
    .line 158
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 159
    .line 160
    .line 161
    const/16 v11, 0x7c

    .line 162
    .line 163
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 164
    .line 165
    .line 166
    aget-object v12, v7, v4

    .line 167
    .line 168
    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v10

    .line 175
    aput-object v10, v7, v9

    .line 176
    .line 177
    or-int/2addr v9, v5

    .line 178
    new-instance v10, Ljava/lang/StringBuilder;

    .line 179
    .line 180
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 181
    .line 182
    .line 183
    aget-object v6, v7, v6

    .line 184
    .line 185
    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    aget-object v4, v7, v4

    .line 192
    .line 193
    invoke-static {v10, v4, v8}, La/zq;->M(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v4

    .line 197
    aput-object v4, v7, v9

    .line 198
    .line 199
    add-int/lit8 v3, v3, 0x1

    .line 200
    .line 201
    goto :goto_1

    .line 202
    :cond_1
    sget-object v0, La/pJ;->p:[Ljava/lang/String;

    .line 203
    .line 204
    array-length v0, v0

    .line 205
    :goto_2
    if-ge v2, v0, :cond_3

    .line 206
    .line 207
    sget-object v1, La/pJ;->p:[Ljava/lang/String;

    .line 208
    .line 209
    aget-object v3, v1, v2

    .line 210
    .line 211
    if-nez v3, :cond_2

    .line 212
    .line 213
    sget-object v3, La/pJ;->e:[Ljava/lang/String;

    .line 214
    .line 215
    aget-object v3, v3, v2

    .line 216
    .line 217
    aput-object v3, v1, v2

    .line 218
    .line 219
    :cond_2
    add-int/lit8 v2, v2, 0x1

    .line 220
    .line 221
    goto :goto_2

    .line 222
    :cond_3
    return-void
.end method

.method public static w(IIIIZ)Ljava/lang/String;
    .locals 10

    .line 1
    sget-object v0, La/pJ;->h:[Ljava/lang/String;

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    if-ge p2, v1, :cond_0

    .line 7
    .line 8
    aget-object v0, v0, p2

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    new-array v0, v3, [Ljava/lang/Object;

    .line 12
    .line 13
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    aput-object v1, v0, v2

    .line 18
    .line 19
    const-string v1, "0x%02x"

    .line 20
    .line 21
    invoke-static {v1, v0}, La/kD;->X(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    :goto_0
    const/4 v1, 0x4

    .line 26
    const/4 v4, 0x5

    .line 27
    const/4 v5, 0x3

    .line 28
    const/4 v6, 0x2

    .line 29
    if-nez p3, :cond_1

    .line 30
    .line 31
    const-string p2, ""

    .line 32
    .line 33
    goto :goto_3

    .line 34
    :cond_1
    sget-object v7, La/pJ;->e:[Ljava/lang/String;

    .line 35
    .line 36
    if-eq p2, v6, :cond_7

    .line 37
    .line 38
    if-eq p2, v5, :cond_7

    .line 39
    .line 40
    if-eq p2, v1, :cond_5

    .line 41
    .line 42
    const/4 v8, 0x6

    .line 43
    if-eq p2, v8, :cond_5

    .line 44
    .line 45
    const/4 v8, 0x7

    .line 46
    if-eq p2, v8, :cond_7

    .line 47
    .line 48
    const/16 v8, 0x8

    .line 49
    .line 50
    if-eq p2, v8, :cond_7

    .line 51
    .line 52
    sget-object v8, La/pJ;->p:[Ljava/lang/String;

    .line 53
    .line 54
    array-length v9, v8

    .line 55
    if-ge p3, v9, :cond_2

    .line 56
    .line 57
    aget-object v7, v8, p3

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_2
    aget-object v7, v7, p3

    .line 61
    .line 62
    :goto_1
    if-ne p2, v4, :cond_3

    .line 63
    .line 64
    and-int/lit8 v8, p3, 0x4

    .line 65
    .line 66
    if-eqz v8, :cond_3

    .line 67
    .line 68
    const-string p2, "HEADERS"

    .line 69
    .line 70
    const-string p3, "PUSH_PROMISE"

    .line 71
    .line 72
    :goto_2
    invoke-static {v7, p2, p3}, La/ge;->ID(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object p2

    .line 76
    goto :goto_3

    .line 77
    :cond_3
    if-nez p2, :cond_4

    .line 78
    .line 79
    and-int/lit8 p2, p3, 0x20

    .line 80
    .line 81
    if-eqz p2, :cond_4

    .line 82
    .line 83
    const-string p2, "PRIORITY"

    .line 84
    .line 85
    const-string p3, "COMPRESSED"

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_4
    move-object p2, v7

    .line 89
    goto :goto_3

    .line 90
    :cond_5
    if-ne p3, v3, :cond_6

    .line 91
    .line 92
    const-string p2, "ACK"

    .line 93
    .line 94
    goto :goto_3

    .line 95
    :cond_6
    aget-object p2, v7, p3

    .line 96
    .line 97
    goto :goto_3

    .line 98
    :cond_7
    aget-object p2, v7, p3

    .line 99
    .line 100
    :goto_3
    if-eqz p4, :cond_8

    .line 101
    .line 102
    const-string p3, "<<"

    .line 103
    .line 104
    goto :goto_4

    .line 105
    :cond_8
    const-string p3, ">>"

    .line 106
    .line 107
    :goto_4
    new-array p4, v4, [Ljava/lang/Object;

    .line 108
    .line 109
    aput-object p3, p4, v2

    .line 110
    .line 111
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    aput-object p0, p4, v3

    .line 116
    .line 117
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    aput-object p0, p4, v6

    .line 122
    .line 123
    aput-object v0, p4, v5

    .line 124
    .line 125
    aput-object p2, p4, v1

    .line 126
    .line 127
    const-string p0, "%s 0x%08x %5d %-13s %s"

    .line 128
    .line 129
    invoke-static {p0, p4}, La/kD;->X(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    return-object p0
.end method
