.class public La/xJ;
.super La/P4;
.source "SourceFile"


# instance fields
.field public m:La/f0;


# direct methods
.method public constructor <init>(La/VB;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La/P4;-><init>(La/VB;Landroid/view/WindowInsets;)V

    const/4 p1, 0x0

    iput-object p1, p0, La/xJ;->m:La/f0;

    return-void
.end method


# virtual methods
.method public L(La/f0;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/xJ;->m:La/f0;

    return-void
.end method

.method public final O()La/f0;
    .locals 4

    .line 1
    iget-object v0, p0, La/xJ;->m:La/f0;

    if-nez v0, :cond_0

    iget-object v0, p0, La/P4;->p:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetLeft()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetTop()I

    move-result v2

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetRight()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetBottom()I

    move-result v0

    invoke-static {v1, v2, v3, v0}, La/f0;->h(IIII)La/f0;

    move-result-object v0

    iput-object v0, p0, La/xJ;->m:La/f0;

    :cond_0
    iget-object v0, p0, La/xJ;->m:La/f0;

    return-object v0
.end method

.method public h()La/VB;
    .locals 2

    .line 1
    iget-object v0, p0, La/P4;->p:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeStableInsets()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v1, v0}, La/VB;->X(Landroid/view/View;Landroid/view/WindowInsets;)La/VB;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method

.method public m()Z
    .locals 1

    .line 1
    iget-object v0, p0, La/P4;->p:Landroid/view/WindowInsets;

    invoke-virtual {v0}, Landroid/view/WindowInsets;->isConsumed()Z

    move-result v0

    return v0
.end method

.method public p()La/VB;
    .locals 2

    .line 1
    iget-object v0, p0, La/P4;->p:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/WindowInsets;->consumeSystemWindowInsets()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {v1, v0}, La/VB;->X(Landroid/view/View;Landroid/view/WindowInsets;)La/VB;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0
.end method
