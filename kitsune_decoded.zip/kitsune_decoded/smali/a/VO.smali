.class public abstract La/VO;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public h:I

.field public final p:Landroid/graphics/Rect;

.field public final w:La/XG;


# direct methods
.method public constructor <init>(La/XG;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, -0x80000000

    .line 5
    .line 6
    iput v0, p0, La/VO;->h:I

    .line 7
    .line 8
    new-instance v0, Landroid/graphics/Rect;

    .line 9
    .line 10
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, La/VO;->p:Landroid/graphics/Rect;

    .line 14
    .line 15
    iput-object p1, p0, La/VO;->w:La/XG;

    .line 16
    .line 17
    return-void
.end method

.method public static w(La/XG;I)La/Tt;
    .locals 1

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne p1, v0, :cond_0

    .line 5
    .line 6
    new-instance p1, La/Tt;

    .line 7
    .line 8
    invoke-direct {p1, p0, v0}, La/Tt;-><init>(La/XG;I)V

    .line 9
    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 13
    .line 14
    const-string p1, "invalid orientation"

    .line 15
    .line 16
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p0

    .line 20
    :cond_1
    new-instance p1, La/Tt;

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-direct {p1, p0, v0}, La/Tt;-><init>(La/XG;I)V

    .line 24
    .line 25
    .line 26
    return-object p1
.end method


# virtual methods
.method public abstract I(Landroid/view/View;)I
.end method

.method public abstract M(I)V
.end method

.method public final O()I
    .locals 2

    .line 1
    const/high16 v0, -0x80000000

    iget v1, p0, La/VO;->h:I

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/VO;->X()I

    move-result v0

    iget v1, p0, La/VO;->h:I

    sub-int/2addr v0, v1

    :goto_0
    return v0
.end method

.method public abstract Q()I
.end method

.method public abstract V(Landroid/view/View;)I
.end method

.method public abstract X()I
.end method

.method public abstract e(Landroid/view/View;)I
.end method

.method public abstract h(Landroid/view/View;)I
.end method

.method public abstract i()I
.end method

.method public abstract p(Landroid/view/View;)I
.end method
