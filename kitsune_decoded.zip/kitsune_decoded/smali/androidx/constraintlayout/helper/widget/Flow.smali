.class public Landroidx/constraintlayout/helper/widget/Flow;
.super La/Sc;
.source "SourceFile"


# instance fields
.field public E:La/yp;

.field public F:Z

.field public q:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, La/Sc;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final K(F)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setElevation(F)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    instance-of v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 15
    .line 16
    invoke-virtual {p0, p1}, La/Sc;->e(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public final O(La/c6;Z)V
    .locals 2

    .line 1
    iget-object p1, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 2
    .line 3
    iget v0, p1, La/yp;->Qg:I

    .line 4
    .line 5
    if-gtz v0, :cond_0

    .line 6
    .line 7
    iget v1, p1, La/yp;->Tr:I

    .line 8
    .line 9
    if-lez v1, :cond_2

    .line 10
    .line 11
    :cond_0
    if-eqz p2, :cond_1

    .line 12
    .line 13
    iget p2, p1, La/yp;->Tr:I

    .line 14
    .line 15
    iput p2, p1, La/yp;->yd:I

    .line 16
    .line 17
    iput v0, p1, La/yp;->C6:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_1
    iput v0, p1, La/yp;->yd:I

    .line 21
    .line 22
    iget p2, p1, La/yp;->Tr:I

    .line 23
    .line 24
    iput p2, p1, La/yp;->C6:I

    .line 25
    .line 26
    :cond_2
    :goto_0
    return-void
.end method

.method public final R(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    instance-of v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 15
    .line 16
    invoke-virtual {p0, p1}, La/Sc;->e(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public final X(Landroid/util/AttributeSet;)V
    .locals 9

    .line 1
    invoke-super {p0, p1}, La/Sc;->X(Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    sget-object v0, La/dp;->h:[I

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz p1, :cond_3

    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    invoke-virtual {v3, p1, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    move v5, v2

    .line 23
    :goto_0
    if-ge v5, v4, :cond_2

    .line 24
    .line 25
    invoke-virtual {v3, v5}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    const/4 v7, 0x6

    .line 30
    if-ne v6, v7, :cond_0

    .line 31
    .line 32
    iput-boolean v1, p0, Landroidx/constraintlayout/helper/widget/Flow;->q:Z

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_0
    const/16 v7, 0x16

    .line 36
    .line 37
    if-ne v6, v7, :cond_1

    .line 38
    .line 39
    iput-boolean v1, p0, Landroidx/constraintlayout/helper/widget/Flow;->F:Z

    .line 40
    .line 41
    :cond_1
    :goto_1
    add-int/lit8 v5, v5, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    .line 45
    .line 46
    .line 47
    :cond_3
    new-instance v3, La/yp;

    .line 48
    .line 49
    invoke-direct {v3}, La/vZ;-><init>()V

    .line 50
    .line 51
    .line 52
    iput v2, v3, La/yp;->MX:I

    .line 53
    .line 54
    iput v2, v3, La/yp;->cS:I

    .line 55
    .line 56
    iput v2, v3, La/yp;->Qg:I

    .line 57
    .line 58
    iput v2, v3, La/yp;->Tr:I

    .line 59
    .line 60
    iput v2, v3, La/yp;->yd:I

    .line 61
    .line 62
    iput v2, v3, La/yp;->C6:I

    .line 63
    .line 64
    iput-boolean v2, v3, La/yp;->nA:Z

    .line 65
    .line 66
    iput v2, v3, La/yp;->Vm:I

    .line 67
    .line 68
    iput v2, v3, La/yp;->Vy:I

    .line 69
    .line 70
    new-instance v4, La/g7;

    .line 71
    .line 72
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 73
    .line 74
    .line 75
    iput-object v4, v3, La/yp;->an:La/g7;

    .line 76
    .line 77
    const/4 v4, 0x0

    .line 78
    iput-object v4, v3, La/yp;->cM:La/ka;

    .line 79
    .line 80
    const/4 v5, -0x1

    .line 81
    iput v5, v3, La/yp;->N3:I

    .line 82
    .line 83
    iput v5, v3, La/yp;->AW:I

    .line 84
    .line 85
    iput v5, v3, La/yp;->GI:I

    .line 86
    .line 87
    iput v5, v3, La/yp;->Hs:I

    .line 88
    .line 89
    iput v5, v3, La/yp;->IL:I

    .line 90
    .line 91
    iput v5, v3, La/yp;->Ey:I

    .line 92
    .line 93
    const/high16 v6, 0x3f000000    # 0.5f

    .line 94
    .line 95
    iput v6, v3, La/yp;->B2:F

    .line 96
    .line 97
    iput v6, v3, La/yp;->vz:F

    .line 98
    .line 99
    iput v6, v3, La/yp;->au:F

    .line 100
    .line 101
    iput v6, v3, La/yp;->sH:F

    .line 102
    .line 103
    iput v6, v3, La/yp;->Qn:F

    .line 104
    .line 105
    iput v6, v3, La/yp;->Pi:F

    .line 106
    .line 107
    iput v2, v3, La/yp;->ZZ:I

    .line 108
    .line 109
    iput v2, v3, La/yp;->rn:I

    .line 110
    .line 111
    const/4 v7, 0x2

    .line 112
    iput v7, v3, La/yp;->xY:I

    .line 113
    .line 114
    iput v7, v3, La/yp;->xK:I

    .line 115
    .line 116
    iput v2, v3, La/yp;->ID:I

    .line 117
    .line 118
    iput v5, v3, La/yp;->ck:I

    .line 119
    .line 120
    iput v2, v3, La/yp;->Ek:I

    .line 121
    .line 122
    new-instance v8, Ljava/util/ArrayList;

    .line 123
    .line 124
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 125
    .line 126
    .line 127
    iput-object v8, v3, La/yp;->Te:Ljava/util/ArrayList;

    .line 128
    .line 129
    iput-object v4, v3, La/yp;->cC:[La/c6;

    .line 130
    .line 131
    iput-object v4, v3, La/yp;->OS:[La/c6;

    .line 132
    .line 133
    iput-object v4, v3, La/yp;->Fl:[I

    .line 134
    .line 135
    iput v2, v3, La/yp;->Yo:I

    .line 136
    .line 137
    iput-object v3, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 138
    .line 139
    if-eqz p1, :cond_1f

    .line 140
    .line 141
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-virtual {v3, p1, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    move v3, v2

    .line 154
    :goto_2
    if-ge v3, v0, :cond_1e

    .line 155
    .line 156
    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 157
    .line 158
    .line 159
    move-result v4

    .line 160
    if-nez v4, :cond_4

    .line 161
    .line 162
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 163
    .line 164
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 165
    .line 166
    .line 167
    move-result v4

    .line 168
    iput v4, v8, La/yp;->Ek:I

    .line 169
    .line 170
    goto/16 :goto_3

    .line 171
    .line 172
    :cond_4
    if-ne v4, v1, :cond_5

    .line 173
    .line 174
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 175
    .line 176
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 177
    .line 178
    .line 179
    move-result v4

    .line 180
    iput v4, v8, La/yp;->MX:I

    .line 181
    .line 182
    iput v4, v8, La/yp;->cS:I

    .line 183
    .line 184
    iput v4, v8, La/yp;->Qg:I

    .line 185
    .line 186
    iput v4, v8, La/yp;->Tr:I

    .line 187
    .line 188
    goto/16 :goto_3

    .line 189
    .line 190
    :cond_5
    const/16 v8, 0x12

    .line 191
    .line 192
    if-ne v4, v8, :cond_6

    .line 193
    .line 194
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 195
    .line 196
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 197
    .line 198
    .line 199
    move-result v4

    .line 200
    iput v4, v8, La/yp;->Qg:I

    .line 201
    .line 202
    iput v4, v8, La/yp;->yd:I

    .line 203
    .line 204
    iput v4, v8, La/yp;->C6:I

    .line 205
    .line 206
    goto/16 :goto_3

    .line 207
    .line 208
    :cond_6
    const/16 v8, 0x13

    .line 209
    .line 210
    if-ne v4, v8, :cond_7

    .line 211
    .line 212
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 213
    .line 214
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 215
    .line 216
    .line 217
    move-result v4

    .line 218
    iput v4, v8, La/yp;->Tr:I

    .line 219
    .line 220
    goto/16 :goto_3

    .line 221
    .line 222
    :cond_7
    if-ne v4, v7, :cond_8

    .line 223
    .line 224
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 225
    .line 226
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 227
    .line 228
    .line 229
    move-result v4

    .line 230
    iput v4, v8, La/yp;->yd:I

    .line 231
    .line 232
    goto/16 :goto_3

    .line 233
    .line 234
    :cond_8
    const/4 v8, 0x3

    .line 235
    if-ne v4, v8, :cond_9

    .line 236
    .line 237
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 238
    .line 239
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 240
    .line 241
    .line 242
    move-result v4

    .line 243
    iput v4, v8, La/yp;->MX:I

    .line 244
    .line 245
    goto/16 :goto_3

    .line 246
    .line 247
    :cond_9
    const/4 v8, 0x4

    .line 248
    if-ne v4, v8, :cond_a

    .line 249
    .line 250
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 251
    .line 252
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 253
    .line 254
    .line 255
    move-result v4

    .line 256
    iput v4, v8, La/yp;->C6:I

    .line 257
    .line 258
    goto/16 :goto_3

    .line 259
    .line 260
    :cond_a
    const/4 v8, 0x5

    .line 261
    if-ne v4, v8, :cond_b

    .line 262
    .line 263
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 264
    .line 265
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 266
    .line 267
    .line 268
    move-result v4

    .line 269
    iput v4, v8, La/yp;->cS:I

    .line 270
    .line 271
    goto/16 :goto_3

    .line 272
    .line 273
    :cond_b
    const/16 v8, 0x36

    .line 274
    .line 275
    if-ne v4, v8, :cond_c

    .line 276
    .line 277
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 278
    .line 279
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 280
    .line 281
    .line 282
    move-result v4

    .line 283
    iput v4, v8, La/yp;->ID:I

    .line 284
    .line 285
    goto/16 :goto_3

    .line 286
    .line 287
    :cond_c
    const/16 v8, 0x2c

    .line 288
    .line 289
    if-ne v4, v8, :cond_d

    .line 290
    .line 291
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 292
    .line 293
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 294
    .line 295
    .line 296
    move-result v4

    .line 297
    iput v4, v8, La/yp;->N3:I

    .line 298
    .line 299
    goto/16 :goto_3

    .line 300
    .line 301
    :cond_d
    const/16 v8, 0x35

    .line 302
    .line 303
    if-ne v4, v8, :cond_e

    .line 304
    .line 305
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 306
    .line 307
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 308
    .line 309
    .line 310
    move-result v4

    .line 311
    iput v4, v8, La/yp;->AW:I

    .line 312
    .line 313
    goto/16 :goto_3

    .line 314
    .line 315
    :cond_e
    const/16 v8, 0x26

    .line 316
    .line 317
    if-ne v4, v8, :cond_f

    .line 318
    .line 319
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 320
    .line 321
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 322
    .line 323
    .line 324
    move-result v4

    .line 325
    iput v4, v8, La/yp;->GI:I

    .line 326
    .line 327
    goto/16 :goto_3

    .line 328
    .line 329
    :cond_f
    const/16 v8, 0x2e

    .line 330
    .line 331
    if-ne v4, v8, :cond_10

    .line 332
    .line 333
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 334
    .line 335
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 336
    .line 337
    .line 338
    move-result v4

    .line 339
    iput v4, v8, La/yp;->IL:I

    .line 340
    .line 341
    goto/16 :goto_3

    .line 342
    .line 343
    :cond_10
    const/16 v8, 0x28

    .line 344
    .line 345
    if-ne v4, v8, :cond_11

    .line 346
    .line 347
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 348
    .line 349
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 350
    .line 351
    .line 352
    move-result v4

    .line 353
    iput v4, v8, La/yp;->Hs:I

    .line 354
    .line 355
    goto/16 :goto_3

    .line 356
    .line 357
    :cond_11
    const/16 v8, 0x30

    .line 358
    .line 359
    if-ne v4, v8, :cond_12

    .line 360
    .line 361
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 362
    .line 363
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 364
    .line 365
    .line 366
    move-result v4

    .line 367
    iput v4, v8, La/yp;->Ey:I

    .line 368
    .line 369
    goto/16 :goto_3

    .line 370
    .line 371
    :cond_12
    const/16 v8, 0x2a

    .line 372
    .line 373
    if-ne v4, v8, :cond_13

    .line 374
    .line 375
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 376
    .line 377
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 378
    .line 379
    .line 380
    move-result v4

    .line 381
    iput v4, v8, La/yp;->B2:F

    .line 382
    .line 383
    goto/16 :goto_3

    .line 384
    .line 385
    :cond_13
    const/16 v8, 0x25

    .line 386
    .line 387
    if-ne v4, v8, :cond_14

    .line 388
    .line 389
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 390
    .line 391
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 392
    .line 393
    .line 394
    move-result v4

    .line 395
    iput v4, v8, La/yp;->au:F

    .line 396
    .line 397
    goto/16 :goto_3

    .line 398
    .line 399
    :cond_14
    const/16 v8, 0x2d

    .line 400
    .line 401
    if-ne v4, v8, :cond_15

    .line 402
    .line 403
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 404
    .line 405
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 406
    .line 407
    .line 408
    move-result v4

    .line 409
    iput v4, v8, La/yp;->Qn:F

    .line 410
    .line 411
    goto/16 :goto_3

    .line 412
    .line 413
    :cond_15
    const/16 v8, 0x27

    .line 414
    .line 415
    if-ne v4, v8, :cond_16

    .line 416
    .line 417
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 418
    .line 419
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 420
    .line 421
    .line 422
    move-result v4

    .line 423
    iput v4, v8, La/yp;->sH:F

    .line 424
    .line 425
    goto :goto_3

    .line 426
    :cond_16
    const/16 v8, 0x2f

    .line 427
    .line 428
    if-ne v4, v8, :cond_17

    .line 429
    .line 430
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 431
    .line 432
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 433
    .line 434
    .line 435
    move-result v4

    .line 436
    iput v4, v8, La/yp;->Pi:F

    .line 437
    .line 438
    goto :goto_3

    .line 439
    :cond_17
    const/16 v8, 0x33

    .line 440
    .line 441
    if-ne v4, v8, :cond_18

    .line 442
    .line 443
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 444
    .line 445
    invoke-virtual {p1, v4, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    .line 446
    .line 447
    .line 448
    move-result v4

    .line 449
    iput v4, v8, La/yp;->vz:F

    .line 450
    .line 451
    goto :goto_3

    .line 452
    :cond_18
    const/16 v8, 0x29

    .line 453
    .line 454
    if-ne v4, v8, :cond_19

    .line 455
    .line 456
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 457
    .line 458
    invoke-virtual {p1, v4, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 459
    .line 460
    .line 461
    move-result v4

    .line 462
    iput v4, v8, La/yp;->xY:I

    .line 463
    .line 464
    goto :goto_3

    .line 465
    :cond_19
    const/16 v8, 0x32

    .line 466
    .line 467
    if-ne v4, v8, :cond_1a

    .line 468
    .line 469
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 470
    .line 471
    invoke-virtual {p1, v4, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 472
    .line 473
    .line 474
    move-result v4

    .line 475
    iput v4, v8, La/yp;->xK:I

    .line 476
    .line 477
    goto :goto_3

    .line 478
    :cond_1a
    const/16 v8, 0x2b

    .line 479
    .line 480
    if-ne v4, v8, :cond_1b

    .line 481
    .line 482
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 483
    .line 484
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 485
    .line 486
    .line 487
    move-result v4

    .line 488
    iput v4, v8, La/yp;->ZZ:I

    .line 489
    .line 490
    goto :goto_3

    .line 491
    :cond_1b
    const/16 v8, 0x34

    .line 492
    .line 493
    if-ne v4, v8, :cond_1c

    .line 494
    .line 495
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 496
    .line 497
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 498
    .line 499
    .line 500
    move-result v4

    .line 501
    iput v4, v8, La/yp;->rn:I

    .line 502
    .line 503
    goto :goto_3

    .line 504
    :cond_1c
    const/16 v8, 0x31

    .line 505
    .line 506
    if-ne v4, v8, :cond_1d

    .line 507
    .line 508
    iget-object v8, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 509
    .line 510
    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 511
    .line 512
    .line 513
    move-result v4

    .line 514
    iput v4, v8, La/yp;->ck:I

    .line 515
    .line 516
    :cond_1d
    :goto_3
    add-int/lit8 v3, v3, 0x1

    .line 517
    .line 518
    goto/16 :goto_2

    .line 519
    .line 520
    :cond_1e
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 521
    .line 522
    .line 523
    :cond_1f
    iget-object p1, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    .line 524
    .line 525
    iput-object p1, p0, La/Sc;->d:La/vZ;

    .line 526
    .line 527
    invoke-virtual {p0}, La/Sc;->T()V

    .line 528
    .line 529
    .line 530
    return-void
.end method

.method public final i(Landroidx/constraintlayout/widget/ConstraintLayout;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, La/Sc;->e(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final m()V
    .locals 6

    .line 1
    invoke-super {p0}, La/Sc;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->q:Z

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    iget-boolean v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->F:Z

    .line 9
    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    instance-of v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 17
    .line 18
    if-eqz v1, :cond_3

    .line 19
    .line 20
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 21
    .line 22
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-virtual {p0}, Landroid/view/View;->getElevation()F

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    const/4 v3, 0x0

    .line 31
    :goto_0
    iget v4, p0, La/Sc;->R:I

    .line 32
    .line 33
    if-ge v3, v4, :cond_3

    .line 34
    .line 35
    iget-object v4, p0, La/Sc;->K:[I

    .line 36
    .line 37
    aget v4, v4, v3

    .line 38
    .line 39
    iget-object v5, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 40
    .line 41
    invoke-virtual {v5, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    check-cast v4, Landroid/view/View;

    .line 46
    .line 47
    if-eqz v4, :cond_2

    .line 48
    .line 49
    iget-boolean v5, p0, Landroidx/constraintlayout/helper/widget/Flow;->q:Z

    .line 50
    .line 51
    if-eqz v5, :cond_1

    .line 52
    .line 53
    invoke-virtual {v4, v1}, Landroid/view/View;->setVisibility(I)V

    .line 54
    .line 55
    .line 56
    :cond_1
    iget-boolean v5, p0, Landroidx/constraintlayout/helper/widget/Flow;->F:Z

    .line 57
    .line 58
    if-eqz v5, :cond_2

    .line 59
    .line 60
    const/4 v5, 0x0

    .line 61
    cmpl-float v5, v2, v5

    .line 62
    .line 63
    if-lez v5, :cond_2

    .line 64
    .line 65
    invoke-virtual {v4}, Landroid/view/View;->getTranslationZ()F

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    add-float/2addr v5, v2

    .line 70
    invoke-virtual {v4, v5}, Landroid/view/View;->setTranslationZ(F)V

    .line 71
    .line 72
    .line 73
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_3
    return-void
.end method

.method public final bridge synthetic onAttachedToWindow()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroidx/constraintlayout/helper/widget/Flow;->m()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final onMeasure(II)V
    .locals 1

    iget-object v0, p0, Landroidx/constraintlayout/helper/widget/Flow;->E:La/yp;

    invoke-virtual {p0, v0, p1, p2}, Landroidx/constraintlayout/helper/widget/Flow;->y(La/yp;II)V

    return-void
.end method

.method public final bridge synthetic setElevation(F)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/helper/widget/Flow;->K(F)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final bridge synthetic setVisibility(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/helper/widget/Flow;->R(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final y(La/yp;II)V
    .locals 41

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v10

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v11

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v12

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v13

    const/4 v14, 0x0

    if-eqz v9, :cond_7a

    .line 1
    iget v1, v9, La/vZ;->NE:I

    const/4 v15, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    if-lez v1, :cond_7

    .line 2
    iget-object v1, v9, La/c6;->B:La/c6;

    if-eqz v1, :cond_0

    check-cast v1, La/p3;

    .line 3
    iget-object v1, v1, La/p3;->Qg:La/ka;

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-nez v1, :cond_1

    .line 4
    iput v14, v9, La/yp;->Vm:I

    iput v14, v9, La/yp;->Vy:I

    .line 5
    :goto_1
    iput-boolean v14, v9, La/yp;->nA:Z

    goto/16 :goto_4a

    :cond_1
    move v3, v14

    .line 6
    :goto_2
    iget v4, v9, La/vZ;->NE:I

    if-ge v3, v4, :cond_7

    iget-object v4, v9, La/vZ;->Gy:[La/c6;

    aget-object v4, v4, v3

    if-nez v4, :cond_2

    goto :goto_3

    :cond_2
    instance-of v5, v4, La/Ou;

    if-eqz v5, :cond_3

    goto :goto_3

    :cond_3
    invoke-virtual {v4, v14}, La/c6;->M(I)I

    move-result v5

    invoke-virtual {v4, v7}, La/c6;->M(I)I

    move-result v6

    if-ne v5, v15, :cond_4

    iget v2, v4, La/c6;->L:I

    if-eq v2, v7, :cond_4

    if-ne v6, v15, :cond_4

    iget v2, v4, La/c6;->d:I

    if-eq v2, v7, :cond_4

    goto :goto_3

    :cond_4
    if-ne v5, v15, :cond_5

    move v5, v8

    :cond_5
    if-ne v6, v15, :cond_6

    move v6, v8

    :cond_6
    iget-object v2, v9, La/yp;->an:La/g7;

    iput v5, v2, La/g7;->w:I

    iput v6, v2, La/g7;->h:I

    invoke-virtual {v4}, La/c6;->K()I

    move-result v5

    iput v5, v2, La/g7;->p:I

    iget-object v2, v9, La/yp;->an:La/g7;

    invoke-virtual {v4}, La/c6;->T()I

    move-result v5

    iput v5, v2, La/g7;->e:I

    iget-object v2, v9, La/yp;->an:La/g7;

    invoke-virtual {v1, v4, v2}, La/ka;->h(La/c6;La/g7;)V

    iget-object v2, v9, La/yp;->an:La/g7;

    iget v2, v2, La/g7;->i:I

    invoke-virtual {v4, v2}, La/c6;->t(I)V

    iget-object v2, v9, La/yp;->an:La/g7;

    iget v2, v2, La/g7;->Q:I

    invoke-virtual {v4, v2}, La/c6;->v(I)V

    iget-object v2, v9, La/yp;->an:La/g7;

    iget v2, v2, La/g7;->X:I

    invoke-virtual {v4, v2}, La/c6;->u(I)V

    :goto_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 7
    :cond_7
    iget v6, v9, La/yp;->yd:I

    .line 8
    iget v5, v9, La/yp;->C6:I

    .line 9
    iget v4, v9, La/yp;->MX:I

    .line 10
    iget v3, v9, La/yp;->cS:I

    new-array v2, v8, [I

    sub-int v1, v11, v6

    sub-int/2addr v1, v5

    .line 11
    iget v15, v9, La/yp;->Ek:I

    if-ne v15, v7, :cond_8

    sub-int v1, v13, v4

    sub-int/2addr v1, v3

    :cond_8
    const/4 v8, -0x1

    if-nez v15, :cond_a

    iget v15, v9, La/yp;->N3:I

    if-ne v15, v8, :cond_9

    iput v14, v9, La/yp;->N3:I

    :cond_9
    iget v15, v9, La/yp;->AW:I

    if-ne v15, v8, :cond_c

    :goto_4
    iput v14, v9, La/yp;->AW:I

    goto :goto_5

    :cond_a
    iget v15, v9, La/yp;->N3:I

    if-ne v15, v8, :cond_b

    iput v14, v9, La/yp;->N3:I

    :cond_b
    iget v15, v9, La/yp;->AW:I

    if-ne v15, v8, :cond_c

    goto :goto_4

    :cond_c
    :goto_5
    iget-object v8, v9, La/vZ;->Gy:[La/c6;

    move v15, v14

    move/from16 v17, v15

    :goto_6
    iget v14, v9, La/vZ;->NE:I

    const/16 v7, 0x8

    if-ge v15, v14, :cond_e

    iget-object v14, v9, La/vZ;->Gy:[La/c6;

    aget-object v14, v14, v15

    .line 12
    iget v14, v14, La/c6;->mh:I

    if-ne v14, v7, :cond_d

    add-int/lit8 v17, v17, 0x1

    :cond_d
    add-int/lit8 v15, v15, 0x1

    const/4 v7, 0x1

    goto :goto_6

    :cond_e
    if-lez v17, :cond_11

    sub-int v14, v14, v17

    .line 13
    new-array v8, v14, [La/c6;

    const/4 v14, 0x0

    const/4 v15, 0x0

    :goto_7
    iget v7, v9, La/vZ;->NE:I

    if-ge v14, v7, :cond_10

    iget-object v7, v9, La/vZ;->Gy:[La/c6;

    aget-object v7, v7, v14

    move/from16 v19, v1

    .line 14
    iget v1, v7, La/c6;->mh:I

    move-object/from16 v20, v2

    const/16 v2, 0x8

    if-eq v1, v2, :cond_f

    .line 15
    aput-object v7, v8, v15

    add-int/lit8 v15, v15, 0x1

    :cond_f
    add-int/lit8 v14, v14, 0x1

    move/from16 v1, v19

    move-object/from16 v2, v20

    goto :goto_7

    :cond_10
    move/from16 v19, v1

    move-object/from16 v20, v2

    :goto_8
    move-object v14, v8

    goto :goto_9

    :cond_11
    move/from16 v19, v1

    move-object/from16 v20, v2

    move v15, v14

    goto :goto_8

    :goto_9
    iput-object v14, v9, La/yp;->fi:[La/c6;

    iput v15, v9, La/yp;->Yo:I

    iget v1, v9, La/yp;->ID:I

    iget-object v8, v9, La/yp;->Te:Ljava/util/ArrayList;

    if-eqz v1, :cond_6f

    iget-object v7, v9, La/c6;->s:La/bM;

    iget-object v2, v9, La/c6;->v:La/bM;

    iget-object v0, v9, La/c6;->j:La/bM;

    move-object/from16 v27, v0

    iget-object v0, v9, La/c6;->t:La/bM;

    move-object/from16 v28, v0

    iget-object v0, v9, La/c6;->HF:[I

    move-object/from16 v17, v7

    const/4 v7, 0x1

    if-eq v1, v7, :cond_54

    move/from16 v29, v13

    const/4 v13, 0x2

    if-eq v1, v13, :cond_2d

    const/4 v7, 0x3

    if-eq v1, v7, :cond_12

    :goto_a
    move/from16 v32, v3

    move/from16 v33, v4

    move/from16 v40, v5

    move/from16 v34, v6

    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v35, v12

    move-object/from16 v31, v20

    :goto_b
    const/4 v1, 0x0

    const/4 v2, 0x1

    goto/16 :goto_46

    :cond_12
    iget v7, v9, La/yp;->Ek:I

    if-nez v15, :cond_13

    goto :goto_a

    .line 16
    :cond_13
    invoke-virtual {v8}, Ljava/util/ArrayList;->clear()V

    new-instance v1, La/k6;

    iget-object v13, v9, La/c6;->v:La/bM;

    move/from16 v21, v5

    iget-object v5, v9, La/c6;->s:La/bM;

    move/from16 v22, v6

    iget-object v6, v9, La/c6;->j:La/bM;

    move-object/from16 v23, v8

    iget-object v8, v9, La/c6;->t:La/bM;

    move-object/from16 p2, v1

    move/from16 v30, v19

    move-object/from16 v19, v2

    move-object/from16 v31, v20

    move-object/from16 v2, p1

    move/from16 v32, v3

    move v3, v7

    move/from16 v33, v4

    move-object v4, v13

    move/from16 v13, v21

    move/from16 v34, v22

    move/from16 v36, v7

    move/from16 v35, v12

    const/4 v12, 0x1

    move-object v7, v8

    move-object/from16 v12, v23

    move/from16 v8, v30

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-nez v36, :cond_1b

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x0

    :goto_c
    if-ge v8, v15, :cond_1a

    const/4 v5, 0x1

    add-int/lit8 v7, v2, 0x1

    aget-object v6, v14, v8

    move/from16 v5, v30

    invoke-virtual {v9, v5, v6}, La/yp;->o(ILa/c6;)I

    move-result v16

    .line 17
    iget-object v2, v6, La/c6;->HF:[I

    const/16 v18, 0x0

    .line 18
    aget v2, v2, v18

    move-object/from16 p2, v6

    const/4 v6, 0x3

    if-ne v2, v6, :cond_14

    add-int/lit8 v3, v3, 0x1

    :cond_14
    move/from16 v18, v3

    if-eq v4, v5, :cond_15

    .line 19
    iget v2, v9, La/yp;->ZZ:I

    add-int/2addr v2, v4

    add-int v2, v2, v16

    if-le v2, v5, :cond_16

    :cond_15
    iget-object v2, v1, La/k6;->h:La/c6;

    if-eqz v2, :cond_16

    const/4 v2, 0x1

    goto :goto_d

    :cond_16
    const/4 v2, 0x0

    :goto_d
    if-nez v2, :cond_17

    if-lez v8, :cond_17

    iget v3, v9, La/yp;->ck:I

    if-lez v3, :cond_17

    if-le v7, v3, :cond_17

    goto :goto_e

    :cond_17
    if-eqz v2, :cond_18

    :goto_e
    new-instance v6, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v3, v9, La/c6;->s:La/bM;

    iget-object v2, v9, La/c6;->j:La/bM;

    iget-object v1, v9, La/c6;->t:La/bM;

    move-object/from16 v20, v1

    move-object v1, v6

    move-object/from16 v21, v2

    move-object/from16 v2, p1

    move-object/from16 v22, v3

    move/from16 v3, v36

    move/from16 v30, v5

    move-object/from16 v5, v22

    move/from16 v39, v10

    move/from16 v38, v11

    move-object/from16 v11, p2

    move-object v10, v6

    move-object/from16 v6, v21

    move/from16 v21, v7

    move-object/from16 v7, v20

    move/from16 v40, v13

    move v13, v8

    move/from16 v8, v30

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    iput v13, v10, La/k6;->y:I

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v1, v10

    move/from16 v4, v16

    move/from16 v2, v21

    goto :goto_10

    :cond_18
    move/from16 v30, v5

    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v40, v13

    move-object/from16 v11, p2

    move v13, v8

    if-lez v13, :cond_19

    iget v2, v9, La/yp;->ZZ:I

    add-int v2, v2, v16

    add-int/2addr v2, v4

    move v4, v2

    :goto_f
    const/4 v2, 0x0

    goto :goto_10

    :cond_19
    move/from16 v4, v16

    goto :goto_f

    :goto_10
    invoke-virtual {v1, v11}, La/k6;->w(La/c6;)V

    add-int/lit8 v8, v13, 0x1

    move/from16 v3, v18

    move/from16 v11, v38

    move/from16 v10, v39

    move/from16 v13, v40

    goto/16 :goto_c

    :cond_1a
    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v40, v13

    move/from16 v13, v30

    goto/16 :goto_15

    :cond_1b
    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v40, v13

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v10, 0x0

    :goto_11
    if-ge v10, v15, :cond_22

    aget-object v11, v14, v10

    move/from16 v13, v30

    invoke-virtual {v9, v13, v11}, La/yp;->g(ILa/c6;)I

    move-result v16

    .line 20
    iget-object v4, v11, La/c6;->HF:[I

    const/4 v5, 0x1

    .line 21
    aget v4, v4, v5

    const/4 v5, 0x3

    if-ne v4, v5, :cond_1c

    add-int/lit8 v2, v2, 0x1

    :cond_1c
    move/from16 v18, v2

    if-eq v3, v13, :cond_1d

    .line 22
    iget v2, v9, La/yp;->rn:I

    add-int/2addr v2, v3

    add-int v2, v2, v16

    if-le v2, v13, :cond_1e

    :cond_1d
    iget-object v2, v1, La/k6;->h:La/c6;

    if-eqz v2, :cond_1e

    const/4 v7, 0x1

    goto :goto_12

    :cond_1e
    const/4 v7, 0x0

    :goto_12
    if-nez v7, :cond_1f

    if-lez v10, :cond_1f

    iget v2, v9, La/yp;->ck:I

    if-lez v2, :cond_1f

    if-gez v2, :cond_1f

    goto :goto_13

    :cond_1f
    if-eqz v7, :cond_21

    :goto_13
    new-instance v8, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v5, v9, La/c6;->s:La/bM;

    iget-object v6, v9, La/c6;->j:La/bM;

    iget-object v7, v9, La/c6;->t:La/bM;

    move-object v1, v8

    move-object/from16 v2, p1

    move/from16 v3, v36

    move-object/from16 v30, v14

    move-object v14, v8

    move v8, v13

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    iput v10, v14, La/k6;->y:I

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v1, v14

    :cond_20
    move/from16 v3, v16

    goto :goto_14

    :cond_21
    move-object/from16 v30, v14

    if-lez v10, :cond_20

    iget v2, v9, La/yp;->rn:I

    add-int v2, v2, v16

    add-int/2addr v2, v3

    move v3, v2

    :goto_14
    invoke-virtual {v1, v11}, La/k6;->w(La/c6;)V

    add-int/lit8 v10, v10, 0x1

    move/from16 v2, v18

    move-object/from16 v14, v30

    move/from16 v30, v13

    goto :goto_11

    :cond_22
    move/from16 v13, v30

    move v3, v2

    :goto_15
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v1

    .line 23
    iget v2, v9, La/yp;->yd:I

    .line 24
    iget v4, v9, La/yp;->MX:I

    .line 25
    iget v5, v9, La/yp;->C6:I

    .line 26
    iget v6, v9, La/yp;->cS:I

    const/4 v7, 0x0

    .line 27
    aget v8, v0, v7

    const/4 v10, 0x2

    if-eq v8, v10, :cond_24

    const/4 v7, 0x1

    .line 28
    aget v0, v0, v7

    if-ne v0, v10, :cond_23

    goto :goto_16

    :cond_23
    const/4 v7, 0x0

    goto :goto_17

    :cond_24
    :goto_16
    const/4 v7, 0x1

    :goto_17
    if-lez v3, :cond_26

    if-eqz v7, :cond_26

    const/4 v0, 0x0

    :goto_18
    if-ge v0, v1, :cond_26

    .line 29
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/k6;

    if-nez v36, :cond_25

    invoke-virtual {v3}, La/k6;->e()I

    move-result v7

    :goto_19
    sub-int v7, v13, v7

    invoke-virtual {v3, v7}, La/k6;->i(I)V

    goto :goto_1a

    :cond_25
    invoke-virtual {v3}, La/k6;->p()I

    move-result v7

    goto :goto_19

    :goto_1a
    add-int/lit8 v0, v0, 0x1

    goto :goto_18

    :cond_26
    move v3, v2

    move-object/from16 v2, v17

    move-object/from16 v0, v19

    move-object/from16 v14, v27

    move-object/from16 v11, v28

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    :goto_1b
    if-ge v7, v1, :cond_2c

    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, La/k6;

    if-nez v36, :cond_29

    add-int/lit8 v6, v1, -0x1

    if-ge v7, v6, :cond_27

    add-int/lit8 v6, v7, 0x1

    invoke-virtual {v12, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/k6;

    .line 30
    iget-object v6, v6, La/k6;->h:La/c6;

    .line 31
    iget-object v6, v6, La/c6;->s:La/bM;

    move-object v11, v6

    move-object/from16 v37, v12

    const/4 v6, 0x0

    goto :goto_1c

    .line 32
    :cond_27
    iget v6, v9, La/yp;->cS:I

    move-object/from16 v37, v12

    move-object/from16 v11, v28

    .line 33
    :goto_1c
    iget-object v12, v15, La/k6;->h:La/c6;

    .line 34
    iget-object v12, v12, La/c6;->t:La/bM;

    move-object/from16 v16, v15

    move/from16 v17, v36

    move-object/from16 v18, v0

    move-object/from16 v19, v2

    move-object/from16 v20, v14

    move-object/from16 v21, v11

    move/from16 v22, v3

    move/from16 v23, v4

    move/from16 v24, v5

    move/from16 v25, v6

    move/from16 v26, v13

    invoke-virtual/range {v16 .. v26}, La/k6;->Q(ILa/bM;La/bM;La/bM;La/bM;IIIII)V

    invoke-virtual {v15}, La/k6;->e()I

    move-result v2

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v15}, La/k6;->p()I

    move-result v4

    add-int/2addr v4, v10

    if-lez v7, :cond_28

    iget v8, v9, La/yp;->rn:I

    add-int/2addr v4, v8

    :cond_28
    move/from16 p2, v1

    move v8, v2

    move v10, v4

    move-object v2, v12

    move-object/from16 v12, v37

    const/4 v4, 0x0

    goto :goto_1e

    :cond_29
    move-object/from16 v37, v12

    add-int/lit8 v5, v1, -0x1

    if-ge v7, v5, :cond_2a

    add-int/lit8 v5, v7, 0x1

    move-object/from16 v12, v37

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/k6;

    .line 35
    iget-object v5, v5, La/k6;->h:La/c6;

    .line 36
    iget-object v5, v5, La/c6;->v:La/bM;

    move/from16 p2, v1

    move-object v14, v5

    const/4 v5, 0x0

    goto :goto_1d

    :cond_2a
    move-object/from16 v12, v37

    .line 37
    iget v5, v9, La/yp;->C6:I

    move/from16 p2, v1

    move-object/from16 v14, v27

    .line 38
    :goto_1d
    iget-object v1, v15, La/k6;->h:La/c6;

    .line 39
    iget-object v1, v1, La/c6;->j:La/bM;

    move-object/from16 v16, v15

    move/from16 v17, v36

    move-object/from16 v18, v0

    move-object/from16 v19, v2

    move-object/from16 v20, v14

    move-object/from16 v21, v11

    move/from16 v22, v3

    move/from16 v23, v4

    move/from16 v24, v5

    move/from16 v25, v6

    move/from16 v26, v13

    invoke-virtual/range {v16 .. v26}, La/k6;->Q(ILa/bM;La/bM;La/bM;La/bM;IIIII)V

    invoke-virtual {v15}, La/k6;->e()I

    move-result v0

    add-int/2addr v0, v8

    invoke-virtual {v15}, La/k6;->p()I

    move-result v3

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-lez v7, :cond_2b

    iget v8, v9, La/yp;->ZZ:I

    add-int/2addr v0, v8

    :cond_2b
    move v8, v0

    move-object v0, v1

    move v10, v3

    const/4 v3, 0x0

    :goto_1e
    add-int/lit8 v7, v7, 0x1

    move/from16 v1, p2

    goto/16 :goto_1b

    :cond_2c
    const/4 v0, 0x0

    aput v8, v31, v0

    const/4 v0, 0x1

    aput v10, v31, v0

    goto/16 :goto_b

    :cond_2d
    move/from16 v32, v3

    move/from16 v33, v4

    move/from16 v40, v5

    move/from16 v34, v6

    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v35, v12

    move v10, v13

    move-object/from16 v30, v14

    move/from16 v13, v19

    move-object/from16 v31, v20

    .line 40
    iget v0, v9, La/yp;->Ek:I

    .line 41
    iget v1, v9, La/yp;->ck:I

    if-nez v0, :cond_33

    if-gtz v1, :cond_32

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1f
    if-ge v1, v15, :cond_31

    if-lez v1, :cond_2e

    iget v4, v9, La/yp;->ZZ:I

    add-int/2addr v2, v4

    :cond_2e
    aget-object v4, v30, v1

    if-nez v4, :cond_2f

    goto :goto_20

    :cond_2f
    invoke-virtual {v9, v13, v4}, La/yp;->o(ILa/c6;)I

    move-result v4

    add-int/2addr v4, v2

    if-le v4, v13, :cond_30

    goto :goto_21

    :cond_30
    add-int/lit8 v3, v3, 0x1

    move v2, v4

    :goto_20
    add-int/lit8 v1, v1, 0x1

    goto :goto_1f

    :cond_31
    :goto_21
    const/4 v1, 0x0

    goto :goto_25

    :cond_32
    move v3, v1

    goto :goto_21

    :cond_33
    if-gtz v1, :cond_38

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_22
    if-ge v1, v15, :cond_37

    if-lez v1, :cond_34

    iget v4, v9, La/yp;->rn:I

    add-int/2addr v2, v4

    :cond_34
    aget-object v4, v30, v1

    if-nez v4, :cond_35

    goto :goto_23

    :cond_35
    invoke-virtual {v9, v13, v4}, La/yp;->g(ILa/c6;)I

    move-result v4

    add-int/2addr v4, v2

    if-le v4, v13, :cond_36

    goto :goto_24

    :cond_36
    add-int/lit8 v3, v3, 0x1

    move v2, v4

    :goto_23
    add-int/lit8 v1, v1, 0x1

    goto :goto_22

    :cond_37
    :goto_24
    move v1, v3

    :cond_38
    const/4 v3, 0x0

    :goto_25
    iget-object v2, v9, La/yp;->Fl:[I

    if-nez v2, :cond_39

    new-array v2, v10, [I

    iput-object v2, v9, La/yp;->Fl:[I

    :cond_39
    if-nez v1, :cond_3a

    const/4 v2, 0x1

    if-eq v0, v2, :cond_3b

    :cond_3a
    if-nez v3, :cond_3c

    if-nez v0, :cond_3c

    :cond_3b
    const/4 v7, 0x1

    goto :goto_26

    :cond_3c
    const/4 v7, 0x0

    :goto_26
    if-nez v7, :cond_53

    if-nez v0, :cond_3d

    int-to-float v1, v15

    int-to-float v2, v3

    div-float/2addr v1, v2

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    double-to-int v1, v1

    goto :goto_27

    :cond_3d
    int-to-float v2, v15

    int-to-float v3, v1

    div-float/2addr v2, v3

    float-to-double v2, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v2

    double-to-int v3, v2

    :goto_27
    iget-object v2, v9, La/yp;->OS:[La/c6;

    if-eqz v2, :cond_3e

    array-length v4, v2

    if-ge v4, v3, :cond_3f

    :cond_3e
    const/4 v4, 0x0

    goto :goto_28

    :cond_3f
    const/4 v4, 0x0

    invoke-static {v2, v4}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_29

    :goto_28
    new-array v2, v3, [La/c6;

    iput-object v2, v9, La/yp;->OS:[La/c6;

    :goto_29
    iget-object v2, v9, La/yp;->cC:[La/c6;

    if-eqz v2, :cond_41

    array-length v5, v2

    if-ge v5, v1, :cond_40

    goto :goto_2a

    :cond_40
    invoke-static {v2, v4}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_2b

    :cond_41
    :goto_2a
    new-array v2, v1, [La/c6;

    iput-object v2, v9, La/yp;->cC:[La/c6;

    :goto_2b
    const/4 v2, 0x0

    :goto_2c
    if-ge v2, v3, :cond_4a

    const/4 v4, 0x0

    :goto_2d
    if-ge v4, v1, :cond_49

    mul-int v5, v4, v3

    add-int/2addr v5, v2

    const/4 v6, 0x1

    if-ne v0, v6, :cond_42

    mul-int v5, v2, v1

    add-int/2addr v5, v4

    :cond_42
    move-object/from16 v11, v30

    array-length v6, v11

    if-lt v5, v6, :cond_43

    goto :goto_2e

    :cond_43
    aget-object v5, v11, v5

    if-nez v5, :cond_44

    goto :goto_2e

    :cond_44
    invoke-virtual {v9, v13, v5}, La/yp;->o(ILa/c6;)I

    move-result v6

    iget-object v8, v9, La/yp;->OS:[La/c6;

    aget-object v8, v8, v2

    if-eqz v8, :cond_45

    invoke-virtual {v8}, La/c6;->K()I

    move-result v8

    if-ge v8, v6, :cond_46

    :cond_45
    iget-object v6, v9, La/yp;->OS:[La/c6;

    aput-object v5, v6, v2

    :cond_46
    invoke-virtual {v9, v13, v5}, La/yp;->g(ILa/c6;)I

    move-result v6

    iget-object v8, v9, La/yp;->cC:[La/c6;

    aget-object v8, v8, v4

    if-eqz v8, :cond_47

    invoke-virtual {v8}, La/c6;->T()I

    move-result v8

    if-ge v8, v6, :cond_48

    :cond_47
    iget-object v6, v9, La/yp;->cC:[La/c6;

    aput-object v5, v6, v4

    :cond_48
    :goto_2e
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v30, v11

    goto :goto_2d

    :cond_49
    move-object/from16 v11, v30

    add-int/lit8 v2, v2, 0x1

    goto :goto_2c

    :cond_4a
    move-object/from16 v11, v30

    const/4 v2, 0x0

    const/4 v4, 0x0

    :goto_2f
    if-ge v2, v3, :cond_4d

    iget-object v5, v9, La/yp;->OS:[La/c6;

    aget-object v5, v5, v2

    if-eqz v5, :cond_4c

    if-lez v2, :cond_4b

    iget v6, v9, La/yp;->ZZ:I

    add-int/2addr v4, v6

    :cond_4b
    invoke-virtual {v9, v13, v5}, La/yp;->o(ILa/c6;)I

    move-result v5

    add-int/2addr v5, v4

    move v4, v5

    :cond_4c
    add-int/lit8 v2, v2, 0x1

    goto :goto_2f

    :cond_4d
    const/4 v2, 0x0

    const/4 v5, 0x0

    :goto_30
    if-ge v2, v1, :cond_50

    iget-object v6, v9, La/yp;->cC:[La/c6;

    aget-object v6, v6, v2

    if-eqz v6, :cond_4f

    if-lez v2, :cond_4e

    iget v8, v9, La/yp;->rn:I

    add-int/2addr v5, v8

    :cond_4e
    invoke-virtual {v9, v13, v6}, La/yp;->g(ILa/c6;)I

    move-result v6

    add-int/2addr v6, v5

    move v5, v6

    :cond_4f
    add-int/lit8 v2, v2, 0x1

    goto :goto_30

    :cond_50
    const/4 v2, 0x0

    aput v4, v31, v2

    const/4 v2, 0x1

    aput v5, v31, v2

    if-nez v0, :cond_52

    if-le v4, v13, :cond_51

    if-le v3, v2, :cond_51

    add-int/lit8 v3, v3, -0x1

    goto :goto_31

    :cond_51
    move v7, v2

    goto :goto_31

    :cond_52
    if-le v5, v13, :cond_51

    if-le v1, v2, :cond_51

    add-int/lit8 v1, v1, -0x1

    :goto_31
    move-object/from16 v30, v11

    goto/16 :goto_26

    :cond_53
    const/4 v2, 0x1

    iget-object v0, v9, La/yp;->Fl:[I

    const/4 v4, 0x0

    aput v3, v0, v4

    aput v1, v0, v2

    goto/16 :goto_b

    :cond_54
    move/from16 v32, v3

    move/from16 v33, v4

    move/from16 v40, v5

    move/from16 v34, v6

    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v35, v12

    move/from16 v29, v13

    move-object v11, v14

    move/from16 v13, v19

    move-object/from16 v31, v20

    const/4 v10, 0x2

    move-object/from16 v19, v2

    move-object v12, v8

    .line 42
    iget v14, v9, La/yp;->Ek:I

    if-nez v15, :cond_55

    goto/16 :goto_b

    .line 43
    :cond_55
    invoke-virtual {v12}, Ljava/util/ArrayList;->clear()V

    new-instance v8, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v5, v9, La/c6;->s:La/bM;

    iget-object v6, v9, La/c6;->j:La/bM;

    iget-object v7, v9, La/c6;->t:La/bM;

    move-object v1, v8

    move-object/from16 v2, p1

    move v3, v14

    move-object v10, v8

    move v8, v13

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-nez v14, :cond_5d

    move-object v8, v10

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v10, 0x0

    :goto_32
    if-ge v10, v15, :cond_5c

    aget-object v7, v11, v10

    invoke-virtual {v9, v13, v7}, La/yp;->o(ILa/c6;)I

    move-result v16

    .line 44
    iget-object v3, v7, La/c6;->HF:[I

    const/4 v4, 0x0

    .line 45
    aget v3, v3, v4

    const/4 v4, 0x3

    if-ne v3, v4, :cond_56

    add-int/lit8 v1, v1, 0x1

    :cond_56
    move/from16 v18, v1

    if-eq v2, v13, :cond_57

    .line 46
    iget v1, v9, La/yp;->ZZ:I

    add-int/2addr v1, v2

    add-int v1, v1, v16

    if-le v1, v13, :cond_58

    :cond_57
    iget-object v1, v8, La/k6;->h:La/c6;

    if-eqz v1, :cond_58

    const/4 v1, 0x1

    goto :goto_33

    :cond_58
    const/4 v1, 0x0

    :goto_33
    if-nez v1, :cond_59

    if-lez v10, :cond_59

    iget v3, v9, La/yp;->ck:I

    if-lez v3, :cond_59

    rem-int v3, v10, v3

    if-nez v3, :cond_59

    goto :goto_34

    :cond_59
    if-eqz v1, :cond_5b

    :goto_34
    new-instance v8, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v5, v9, La/c6;->s:La/bM;

    iget-object v6, v9, La/c6;->j:La/bM;

    iget-object v3, v9, La/c6;->t:La/bM;

    move-object v1, v8

    move-object/from16 v2, p1

    move-object/from16 v20, v3

    move v3, v14

    move-object/from16 v21, v0

    move-object v0, v7

    move-object/from16 v7, v20

    move/from16 v30, v14

    move-object v14, v8

    move v8, v13

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    iput v10, v14, La/k6;->y:I

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v8, v14

    :cond_5a
    move/from16 v2, v16

    goto :goto_35

    :cond_5b
    move-object/from16 v21, v0

    move-object v0, v7

    move/from16 v30, v14

    if-lez v10, :cond_5a

    iget v1, v9, La/yp;->ZZ:I

    add-int v1, v1, v16

    add-int/2addr v1, v2

    move v2, v1

    :goto_35
    invoke-virtual {v8, v0}, La/k6;->w(La/c6;)V

    add-int/lit8 v10, v10, 0x1

    move/from16 v1, v18

    move-object/from16 v0, v21

    move/from16 v14, v30

    goto :goto_32

    :cond_5c
    move-object/from16 v21, v0

    move/from16 v30, v14

    goto/16 :goto_3a

    :cond_5d
    move-object/from16 v21, v0

    move/from16 v30, v14

    move-object v8, v10

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_36
    if-ge v0, v15, :cond_64

    aget-object v10, v11, v0

    invoke-virtual {v9, v13, v10}, La/yp;->g(ILa/c6;)I

    move-result v14

    .line 47
    iget-object v3, v10, La/c6;->HF:[I

    const/4 v4, 0x1

    .line 48
    aget v3, v3, v4

    const/4 v7, 0x3

    if-ne v3, v7, :cond_5e

    add-int/lit8 v1, v1, 0x1

    :cond_5e
    move/from16 v16, v1

    if-eq v2, v13, :cond_5f

    .line 49
    iget v1, v9, La/yp;->rn:I

    add-int/2addr v1, v2

    add-int/2addr v1, v14

    if-le v1, v13, :cond_60

    :cond_5f
    iget-object v1, v8, La/k6;->h:La/c6;

    if-eqz v1, :cond_60

    const/4 v1, 0x1

    goto :goto_37

    :cond_60
    const/4 v1, 0x0

    :goto_37
    if-nez v1, :cond_61

    if-lez v0, :cond_61

    iget v3, v9, La/yp;->ck:I

    if-lez v3, :cond_61

    rem-int v3, v0, v3

    if-nez v3, :cond_61

    goto :goto_38

    :cond_61
    if-eqz v1, :cond_63

    :goto_38
    new-instance v8, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v5, v9, La/c6;->s:La/bM;

    iget-object v6, v9, La/c6;->j:La/bM;

    iget-object v3, v9, La/c6;->t:La/bM;

    move-object v1, v8

    move-object/from16 v2, p1

    move-object/from16 v18, v3

    move/from16 v3, v30

    move/from16 v20, v7

    move-object/from16 v7, v18

    move-object/from16 v36, v11

    move-object v11, v8

    move v8, v13

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    iput v0, v11, La/k6;->y:I

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v8, v11

    :cond_62
    move v2, v14

    goto :goto_39

    :cond_63
    move/from16 v20, v7

    move-object/from16 v36, v11

    if-lez v0, :cond_62

    iget v1, v9, La/yp;->rn:I

    add-int/2addr v1, v14

    add-int/2addr v1, v2

    move v2, v1

    :goto_39
    invoke-virtual {v8, v10}, La/k6;->w(La/c6;)V

    add-int/lit8 v0, v0, 0x1

    move/from16 v1, v16

    move-object/from16 v11, v36

    goto :goto_36

    :cond_64
    :goto_3a
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 50
    iget v2, v9, La/yp;->yd:I

    .line 51
    iget v3, v9, La/yp;->MX:I

    .line 52
    iget v4, v9, La/yp;->C6:I

    .line 53
    iget v5, v9, La/yp;->cS:I

    const/4 v6, 0x0

    .line 54
    aget v7, v21, v6

    const/4 v6, 0x2

    if-eq v7, v6, :cond_66

    const/4 v7, 0x1

    .line 55
    aget v8, v21, v7

    if-ne v8, v6, :cond_65

    goto :goto_3b

    :cond_65
    const/4 v7, 0x0

    goto :goto_3c

    :cond_66
    :goto_3b
    const/4 v7, 0x1

    :goto_3c
    if-lez v1, :cond_68

    if-eqz v7, :cond_68

    const/4 v1, 0x0

    :goto_3d
    if-ge v1, v0, :cond_68

    .line 56
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/k6;

    if-nez v30, :cond_67

    invoke-virtual {v6}, La/k6;->e()I

    move-result v7

    :goto_3e
    sub-int v7, v13, v7

    invoke-virtual {v6, v7}, La/k6;->i(I)V

    goto :goto_3f

    :cond_67
    invoke-virtual {v6}, La/k6;->p()I

    move-result v7

    goto :goto_3e

    :goto_3f
    add-int/lit8 v1, v1, 0x1

    goto :goto_3d

    :cond_68
    move v6, v3

    move-object/from16 v1, v19

    move-object/from16 v14, v27

    move-object/from16 v11, v28

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    move v3, v2

    move-object/from16 v2, v17

    :goto_40
    if-ge v7, v0, :cond_6e

    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, La/k6;

    if-nez v30, :cond_6b

    add-int/lit8 v5, v0, -0x1

    if-ge v7, v5, :cond_69

    add-int/lit8 v5, v7, 0x1

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/k6;

    .line 57
    iget-object v5, v5, La/k6;->h:La/c6;

    .line 58
    iget-object v5, v5, La/c6;->s:La/bM;

    move-object v11, v5

    move-object/from16 v37, v12

    const/4 v5, 0x0

    goto :goto_41

    .line 59
    :cond_69
    iget v5, v9, La/yp;->cS:I

    move-object/from16 v37, v12

    move-object/from16 v11, v28

    .line 60
    :goto_41
    iget-object v12, v15, La/k6;->h:La/c6;

    .line 61
    iget-object v12, v12, La/c6;->t:La/bM;

    move-object/from16 v16, v15

    move/from16 v17, v30

    move-object/from16 v18, v1

    move-object/from16 v19, v2

    move-object/from16 v20, v14

    move-object/from16 v21, v11

    move/from16 v22, v3

    move/from16 v23, v6

    move/from16 v24, v4

    move/from16 v25, v5

    move/from16 v26, v13

    invoke-virtual/range {v16 .. v26}, La/k6;->Q(ILa/bM;La/bM;La/bM;La/bM;IIIII)V

    invoke-virtual {v15}, La/k6;->e()I

    move-result v2

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v15}, La/k6;->p()I

    move-result v6

    add-int/2addr v6, v10

    if-lez v7, :cond_6a

    iget v8, v9, La/yp;->rn:I

    add-int/2addr v6, v8

    :cond_6a
    move/from16 p2, v0

    move v8, v2

    move v10, v6

    move-object v2, v12

    move-object/from16 v12, v37

    const/4 v6, 0x0

    goto :goto_43

    :cond_6b
    move-object/from16 v37, v12

    add-int/lit8 v4, v0, -0x1

    if-ge v7, v4, :cond_6c

    add-int/lit8 v4, v7, 0x1

    move-object/from16 v12, v37

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/k6;

    .line 62
    iget-object v4, v4, La/k6;->h:La/c6;

    .line 63
    iget-object v4, v4, La/c6;->v:La/bM;

    move/from16 p2, v0

    move-object v14, v4

    const/4 v4, 0x0

    goto :goto_42

    :cond_6c
    move-object/from16 v12, v37

    .line 64
    iget v4, v9, La/yp;->C6:I

    move/from16 p2, v0

    move-object/from16 v14, v27

    .line 65
    :goto_42
    iget-object v0, v15, La/k6;->h:La/c6;

    .line 66
    iget-object v0, v0, La/c6;->j:La/bM;

    move-object/from16 v16, v15

    move/from16 v17, v30

    move-object/from16 v18, v1

    move-object/from16 v19, v2

    move-object/from16 v20, v14

    move-object/from16 v21, v11

    move/from16 v22, v3

    move/from16 v23, v6

    move/from16 v24, v4

    move/from16 v25, v5

    move/from16 v26, v13

    invoke-virtual/range {v16 .. v26}, La/k6;->Q(ILa/bM;La/bM;La/bM;La/bM;IIIII)V

    invoke-virtual {v15}, La/k6;->e()I

    move-result v1

    add-int/2addr v1, v8

    invoke-virtual {v15}, La/k6;->p()I

    move-result v3

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-lez v7, :cond_6d

    iget v8, v9, La/yp;->ZZ:I

    add-int/2addr v1, v8

    :cond_6d
    move v8, v1

    move v10, v3

    const/4 v3, 0x0

    move-object v1, v0

    :goto_43
    add-int/lit8 v7, v7, 0x1

    move/from16 v0, p2

    goto/16 :goto_40

    :cond_6e
    const/4 v0, 0x0

    aput v8, v31, v0

    const/4 v0, 0x1

    aput v10, v31, v0

    goto/16 :goto_b

    :cond_6f
    move/from16 v32, v3

    move/from16 v33, v4

    move/from16 v40, v5

    move/from16 v34, v6

    move/from16 v39, v10

    move/from16 v38, v11

    move/from16 v35, v12

    move/from16 v29, v13

    move-object/from16 v36, v14

    move/from16 v13, v19

    move-object/from16 v31, v20

    move-object v12, v8

    .line 67
    iget v0, v9, La/yp;->Ek:I

    if-nez v15, :cond_70

    goto/16 :goto_b

    .line 68
    :cond_70
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-nez v1, :cond_71

    new-instance v10, La/k6;

    iget-object v4, v9, La/c6;->v:La/bM;

    iget-object v5, v9, La/c6;->s:La/bM;

    iget-object v6, v9, La/c6;->j:La/bM;

    iget-object v7, v9, La/c6;->t:La/bM;

    move-object v1, v10

    move-object/from16 v2, p1

    move v3, v0

    move v8, v13

    invoke-direct/range {v1 .. v8}, La/k6;-><init>(La/yp;ILa/bM;La/bM;La/bM;La/bM;I)V

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_44

    :cond_71
    const/4 v1, 0x0

    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v10, v2

    check-cast v10, La/k6;

    .line 69
    iput v1, v10, La/k6;->p:I

    const/4 v2, 0x0

    .line 70
    iput-object v2, v10, La/k6;->h:La/c6;

    iput v1, v10, La/k6;->T:I

    iput v1, v10, La/k6;->m:I

    iput v1, v10, La/k6;->y:I

    iput v1, v10, La/k6;->K:I

    iput v1, v10, La/k6;->R:I

    .line 71
    iget-object v1, v9, La/c6;->v:La/bM;

    iget-object v2, v9, La/c6;->s:La/bM;

    iget-object v3, v9, La/c6;->j:La/bM;

    iget-object v4, v9, La/c6;->t:La/bM;

    .line 72
    iget v5, v9, La/yp;->yd:I

    .line 73
    iget v6, v9, La/yp;->MX:I

    .line 74
    iget v7, v9, La/yp;->C6:I

    .line 75
    iget v8, v9, La/yp;->cS:I

    move-object/from16 v16, v10

    move/from16 v17, v0

    move-object/from16 v18, v1

    move-object/from16 v19, v2

    move-object/from16 v20, v3

    move-object/from16 v21, v4

    move/from16 v22, v5

    move/from16 v23, v6

    move/from16 v24, v7

    move/from16 v25, v8

    move/from16 v26, v13

    .line 76
    invoke-virtual/range {v16 .. v26}, La/k6;->Q(ILa/bM;La/bM;La/bM;La/bM;IIIII)V

    :goto_44
    const/4 v0, 0x0

    :goto_45
    if-ge v0, v15, :cond_72

    aget-object v1, v36, v0

    invoke-virtual {v10, v1}, La/k6;->w(La/c6;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_45

    :cond_72
    invoke-virtual {v10}, La/k6;->e()I

    move-result v0

    const/4 v1, 0x0

    aput v0, v31, v1

    invoke-virtual {v10}, La/k6;->p()I

    move-result v0

    const/4 v2, 0x1

    aput v0, v31, v2

    :goto_46
    aget v0, v31, v1

    add-int v0, v0, v34

    add-int v0, v0, v40

    aget v1, v31, v2

    add-int v1, v1, v33

    add-int v1, v1, v32

    const/high16 v3, -0x80000000

    const/high16 v4, 0x40000000    # 2.0f

    move/from16 v5, v39

    if-ne v5, v4, :cond_73

    move/from16 v0, v35

    move/from16 v11, v38

    goto :goto_48

    :cond_73
    if-ne v5, v3, :cond_74

    move/from16 v6, v38

    .line 77
    invoke-static {v0, v6}, Ljava/lang/Math;->min(II)I

    move-result v11

    :goto_47
    move/from16 v0, v35

    goto :goto_48

    :cond_74
    if-nez v5, :cond_75

    move v11, v0

    goto :goto_47

    :cond_75
    move/from16 v0, v35

    const/4 v11, 0x0

    :goto_48
    if-ne v0, v4, :cond_76

    move/from16 v13, v29

    goto :goto_49

    :cond_76
    if-ne v0, v3, :cond_77

    move/from16 v3, v29

    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v13

    goto :goto_49

    :cond_77
    if-nez v0, :cond_78

    move v13, v1

    goto :goto_49

    :cond_78
    const/4 v13, 0x0

    .line 78
    :goto_49
    iput v11, v9, La/yp;->Vm:I

    iput v13, v9, La/yp;->Vy:I

    .line 79
    invoke-virtual {v9, v11}, La/c6;->t(I)V

    invoke-virtual {v9, v13}, La/c6;->v(I)V

    iget v0, v9, La/vZ;->NE:I

    if-lez v0, :cond_79

    move v14, v2

    goto/16 :goto_1

    :cond_79
    const/4 v14, 0x0

    goto/16 :goto_1

    .line 80
    :goto_4a
    iget v0, v9, La/yp;->Vm:I

    .line 81
    iget v1, v9, La/yp;->Vy:I

    move-object/from16 v2, p0

    .line 82
    invoke-virtual {v2, v0, v1}, Landroid/view/View;->setMeasuredDimension(II)V

    goto :goto_4b

    :cond_7a
    move-object v2, v0

    move v0, v14

    invoke-virtual {v2, v0, v0}, Landroid/view/View;->setMeasuredDimension(II)V

    :goto_4b
    return-void
.end method
