.class public abstract La/Fz;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract w(La/dA;)V
.end method
