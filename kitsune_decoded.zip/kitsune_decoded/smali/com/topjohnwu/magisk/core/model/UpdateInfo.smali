.class public final Lcom/topjohnwu/magisk/core/model/UpdateInfo;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime La/my;
    generateAdapter = true
.end annotation


# instance fields
.field public final w:Lcom/topjohnwu/magisk/core/model/MagiskJson;


# direct methods
.method public constructor <init>(Lcom/topjohnwu/magisk/core/model/MagiskJson;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/topjohnwu/magisk/core/model/MagiskJson;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 7

    .line 2
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    new-instance p1, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0xf

    const/4 v6, 0x0

    move-object v0, p1

    invoke-direct/range {v0 .. v6}, Lcom/topjohnwu/magisk/core/model/MagiskJson;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    :cond_0
    invoke-direct {p0, p1}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Lcom/topjohnwu/magisk/core/model/MagiskJson;)V

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    iget-object p1, p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    invoke-static {v1, p1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2

    return v2

    :cond_2
    return v0
.end method

.method public final hashCode()I
    .locals 1

    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    invoke-virtual {v0}, Lcom/topjohnwu/magisk/core/model/MagiskJson;->hashCode()I

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "UpdateInfo(magisk="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
