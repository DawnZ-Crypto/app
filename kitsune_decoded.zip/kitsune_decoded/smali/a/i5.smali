.class public final La/i5;
.super La/hY;
.source "SourceFile"


# instance fields
.field public synthetic L:Ljava/lang/Object;

.field public final synthetic d:La/Zx;

.field public f:I


# direct methods
.method public constructor <init>(La/Zx;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/i5;->d:La/Zx;

    invoke-direct {p0, p2}, La/hY;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La/i5;->L:Ljava/lang/Object;

    iget p1, p0, La/i5;->f:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La/i5;->f:I

    iget-object p1, p0, La/i5;->d:La/Zx;

    invoke-virtual {p1, p0}, La/Zx;->OS(La/hu;)Ljava/io/Serializable;

    move-result-object p1

    return-object p1
.end method
