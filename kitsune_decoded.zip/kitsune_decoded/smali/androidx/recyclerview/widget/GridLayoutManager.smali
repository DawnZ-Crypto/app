.class public Landroidx/recyclerview/widget/GridLayoutManager;
.super Landroidx/recyclerview/widget/LinearLayoutManager;
.source "SourceFile"


# instance fields
.field public U:I

.field public final j:Landroid/util/SparseIntArray;

.field public k:[I

.field public final n:Landroid/graphics/Rect;

.field public final s:Landroid/util/SparseIntArray;

.field public final t:La/GS;

.field public u:Z

.field public v:[Landroid/view/View;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(I)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->u:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->s:Landroid/util/SparseIntArray;

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->j:Landroid/util/SparseIntArray;

    new-instance v0, La/GS;

    invoke-direct {v0}, La/GS;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->n:Landroid/graphics/Rect;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->DT(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 1

    .line 2
    invoke-direct {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->u:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->s:Landroid/util/SparseIntArray;

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->j:Landroid/util/SparseIntArray;

    new-instance v0, La/GS;

    invoke-direct {v0}, La/GS;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->n:Landroid/graphics/Rect;

    invoke-static {p1, p2, p3, p4}, La/XG;->k(Landroid/content/Context;Landroid/util/AttributeSet;II)La/lS;

    move-result-object p1

    iget p1, p1, La/lS;->h:I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/GridLayoutManager;->DT(I)V

    return-void
.end method


# virtual methods
.method public final DT(I)V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->u:Z

    .line 8
    .line 9
    if-lt p1, v0, :cond_1

    .line 10
    .line 11
    iput p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 12
    .line 13
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 14
    .line 15
    invoke-virtual {p1}, La/GS;->e()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, La/XG;->lI()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 23
    .line 24
    const-string v1, "Span count should be at least 1. Provided "

    .line 25
    .line 26
    invoke-static {v1, p1}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    throw v0
.end method

.method public final Di()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    if-eqz v0, :cond_0

    array-length v0, v0

    iget v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    if-eq v0, v1, :cond_1

    :cond_0
    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    new-array v0, v0, [Landroid/view/View;

    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    :cond_1
    return-void
.end method

.method public final E(La/fl;La/R8;)I
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    iget p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    return p1

    :cond_0
    invoke-virtual {p2}, La/R8;->h()I

    move-result v0

    if-ge v0, v1, :cond_1

    const/4 p1, 0x0

    return p1

    :cond_1
    invoke-virtual {p2}, La/R8;->h()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p0, v0, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->ew(ILa/fl;La/R8;)I

    move-result p1

    add-int/2addr p1, v1

    return p1
.end method

.method public final Ek(La/fl;La/R8;La/M2;La/Lj;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    move-object/from16 v4, p4

    .line 10
    .line 11
    iget-object v5, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 12
    .line 13
    iget v6, v5, La/Tt;->e:I

    .line 14
    .line 15
    iget-object v5, v5, La/VO;->w:La/XG;

    .line 16
    .line 17
    packed-switch v6, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    iget v5, v5, La/XG;->T:I

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :pswitch_0
    iget v5, v5, La/XG;->m:I

    .line 24
    .line 25
    :goto_0
    const/4 v7, 0x1

    .line 26
    const/high16 v8, 0x40000000    # 2.0f

    .line 27
    .line 28
    if-eq v5, v8, :cond_0

    .line 29
    .line 30
    move v9, v7

    .line 31
    goto :goto_1

    .line 32
    :cond_0
    const/4 v9, 0x0

    .line 33
    :goto_1
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 34
    .line 35
    .line 36
    move-result v10

    .line 37
    if-lez v10, :cond_1

    .line 38
    .line 39
    iget-object v10, v0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 40
    .line 41
    iget v11, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 42
    .line 43
    aget v10, v10, v11

    .line 44
    .line 45
    goto :goto_2

    .line 46
    :cond_1
    const/4 v10, 0x0

    .line 47
    :goto_2
    if-eqz v9, :cond_2

    .line 48
    .line 49
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/GridLayoutManager;->FB()V

    .line 50
    .line 51
    .line 52
    :cond_2
    iget v11, v3, La/M2;->i:I

    .line 53
    .line 54
    if-ne v11, v7, :cond_3

    .line 55
    .line 56
    move v11, v7

    .line 57
    goto :goto_3

    .line 58
    :cond_3
    const/4 v11, 0x0

    .line 59
    :goto_3
    iget v12, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 60
    .line 61
    if-nez v11, :cond_4

    .line 62
    .line 63
    iget v12, v3, La/M2;->e:I

    .line 64
    .line 65
    invoke-virtual {v0, v12, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->qu(ILa/fl;La/R8;)I

    .line 66
    .line 67
    .line 68
    move-result v12

    .line 69
    iget v13, v3, La/M2;->e:I

    .line 70
    .line 71
    invoke-virtual {v0, v13, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->nd(ILa/fl;La/R8;)I

    .line 72
    .line 73
    .line 74
    move-result v13

    .line 75
    add-int/2addr v12, v13

    .line 76
    :cond_4
    const/4 v13, 0x0

    .line 77
    :goto_4
    iget v14, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 78
    .line 79
    if-ge v13, v14, :cond_8

    .line 80
    .line 81
    iget v14, v3, La/M2;->e:I

    .line 82
    .line 83
    if-ltz v14, :cond_8

    .line 84
    .line 85
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 86
    .line 87
    .line 88
    move-result v15

    .line 89
    if-ge v14, v15, :cond_8

    .line 90
    .line 91
    if-lez v12, :cond_8

    .line 92
    .line 93
    iget v14, v3, La/M2;->e:I

    .line 94
    .line 95
    invoke-virtual {v0, v14, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->nd(ILa/fl;La/R8;)I

    .line 96
    .line 97
    .line 98
    move-result v15

    .line 99
    iget v8, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 100
    .line 101
    if-gt v15, v8, :cond_7

    .line 102
    .line 103
    sub-int/2addr v12, v15

    .line 104
    if-gez v12, :cond_5

    .line 105
    .line 106
    goto :goto_5

    .line 107
    :cond_5
    invoke-virtual {v3, v1}, La/M2;->h(La/fl;)Landroid/view/View;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    if-nez v8, :cond_6

    .line 112
    .line 113
    goto :goto_5

    .line 114
    :cond_6
    iget-object v14, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 115
    .line 116
    aput-object v8, v14, v13

    .line 117
    .line 118
    add-int/lit8 v13, v13, 0x1

    .line 119
    .line 120
    const/high16 v8, 0x40000000    # 2.0f

    .line 121
    .line 122
    goto :goto_4

    .line 123
    :cond_7
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 124
    .line 125
    new-instance v2, Ljava/lang/StringBuilder;

    .line 126
    .line 127
    const-string v3, "Item at position "

    .line 128
    .line 129
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    const-string v3, " requires "

    .line 136
    .line 137
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    const-string v3, " spans but GridLayoutManager has only "

    .line 144
    .line 145
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    iget v3, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 149
    .line 150
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 151
    .line 152
    .line 153
    const-string v3, " spans."

    .line 154
    .line 155
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    throw v1

    .line 166
    :cond_8
    :goto_5
    if-nez v13, :cond_9

    .line 167
    .line 168
    iput-boolean v7, v4, La/Lj;->h:Z

    .line 169
    .line 170
    return-void

    .line 171
    :cond_9
    if-eqz v11, :cond_a

    .line 172
    .line 173
    move v15, v7

    .line 174
    move v14, v13

    .line 175
    const/4 v12, 0x0

    .line 176
    goto :goto_6

    .line 177
    :cond_a
    add-int/lit8 v12, v13, -0x1

    .line 178
    .line 179
    const/4 v14, -0x1

    .line 180
    const/4 v15, -0x1

    .line 181
    :goto_6
    const/4 v7, 0x0

    .line 182
    :goto_7
    if-eq v12, v14, :cond_b

    .line 183
    .line 184
    iget-object v6, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 185
    .line 186
    aget-object v6, v6, v12

    .line 187
    .line 188
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 189
    .line 190
    .line 191
    move-result-object v16

    .line 192
    move-object/from16 v8, v16

    .line 193
    .line 194
    check-cast v8, La/zj;

    .line 195
    .line 196
    invoke-static {v6}, La/XG;->U(Landroid/view/View;)I

    .line 197
    .line 198
    .line 199
    move-result v6

    .line 200
    invoke-virtual {v0, v6, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->nd(ILa/fl;La/R8;)I

    .line 201
    .line 202
    .line 203
    move-result v6

    .line 204
    iput v6, v8, La/zj;->Q:I

    .line 205
    .line 206
    iput v7, v8, La/zj;->i:I

    .line 207
    .line 208
    add-int/2addr v7, v6

    .line 209
    add-int/2addr v12, v15

    .line 210
    goto :goto_7

    .line 211
    :cond_b
    const/4 v1, 0x0

    .line 212
    const/4 v2, 0x0

    .line 213
    const/4 v6, 0x0

    .line 214
    :goto_8
    if-ge v2, v13, :cond_12

    .line 215
    .line 216
    iget-object v7, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 217
    .line 218
    aget-object v7, v7, v2

    .line 219
    .line 220
    iget-object v8, v3, La/M2;->M:Ljava/util/List;

    .line 221
    .line 222
    if-nez v8, :cond_d

    .line 223
    .line 224
    if-eqz v11, :cond_c

    .line 225
    .line 226
    const/4 v8, 0x0

    .line 227
    const/4 v12, -0x1

    .line 228
    invoke-virtual {v0, v7, v12, v8}, La/XG;->h(Landroid/view/View;IZ)V

    .line 229
    .line 230
    .line 231
    goto :goto_9

    .line 232
    :cond_c
    const/4 v8, 0x0

    .line 233
    const/4 v12, -0x1

    .line 234
    invoke-virtual {v0, v7, v8, v8}, La/XG;->h(Landroid/view/View;IZ)V

    .line 235
    .line 236
    .line 237
    goto :goto_9

    .line 238
    :cond_d
    const/4 v8, 0x0

    .line 239
    const/4 v12, -0x1

    .line 240
    if-eqz v11, :cond_e

    .line 241
    .line 242
    const/4 v14, 0x1

    .line 243
    invoke-virtual {v0, v7, v12, v14}, La/XG;->h(Landroid/view/View;IZ)V

    .line 244
    .line 245
    .line 246
    goto :goto_9

    .line 247
    :cond_e
    const/4 v14, 0x1

    .line 248
    invoke-virtual {v0, v7, v8, v14}, La/XG;->h(Landroid/view/View;IZ)V

    .line 249
    .line 250
    .line 251
    :goto_9
    iget-object v12, v0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 252
    .line 253
    iget-object v14, v0, Landroidx/recyclerview/widget/GridLayoutManager;->n:Landroid/graphics/Rect;

    .line 254
    .line 255
    if-nez v12, :cond_f

    .line 256
    .line 257
    invoke-virtual {v14, v8, v8, v8, v8}, Landroid/graphics/Rect;->set(IIII)V

    .line 258
    .line 259
    .line 260
    goto :goto_a

    .line 261
    :cond_f
    invoke-virtual {v12, v7}, Landroidx/recyclerview/widget/RecyclerView;->t(Landroid/view/View;)Landroid/graphics/Rect;

    .line 262
    .line 263
    .line 264
    move-result-object v12

    .line 265
    invoke-virtual {v14, v12}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 266
    .line 267
    .line 268
    :goto_a
    invoke-virtual {v0, v7, v5, v8}, Landroidx/recyclerview/widget/GridLayoutManager;->hn(Landroid/view/View;IZ)V

    .line 269
    .line 270
    .line 271
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 272
    .line 273
    invoke-virtual {v8, v7}, La/Tt;->p(Landroid/view/View;)I

    .line 274
    .line 275
    .line 276
    move-result v8

    .line 277
    if-le v8, v6, :cond_10

    .line 278
    .line 279
    move v6, v8

    .line 280
    :cond_10
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 281
    .line 282
    .line 283
    move-result-object v8

    .line 284
    check-cast v8, La/zj;

    .line 285
    .line 286
    iget-object v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 287
    .line 288
    invoke-virtual {v12, v7}, La/Tt;->T(Landroid/view/View;)I

    .line 289
    .line 290
    .line 291
    move-result v7

    .line 292
    int-to-float v7, v7

    .line 293
    const/high16 v12, 0x3f800000    # 1.0f

    .line 294
    .line 295
    mul-float/2addr v7, v12

    .line 296
    iget v8, v8, La/zj;->Q:I

    .line 297
    .line 298
    int-to-float v8, v8

    .line 299
    div-float/2addr v7, v8

    .line 300
    cmpl-float v8, v7, v1

    .line 301
    .line 302
    if-lez v8, :cond_11

    .line 303
    .line 304
    move v1, v7

    .line 305
    :cond_11
    add-int/lit8 v2, v2, 0x1

    .line 306
    .line 307
    goto :goto_8

    .line 308
    :cond_12
    if-eqz v9, :cond_14

    .line 309
    .line 310
    iget v2, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 311
    .line 312
    int-to-float v2, v2

    .line 313
    mul-float/2addr v1, v2

    .line 314
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 315
    .line 316
    .line 317
    move-result v1

    .line 318
    invoke-static {v1, v10}, Ljava/lang/Math;->max(II)I

    .line 319
    .line 320
    .line 321
    move-result v1

    .line 322
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/GridLayoutManager;->dB(I)V

    .line 323
    .line 324
    .line 325
    const/4 v6, 0x0

    .line 326
    const/4 v8, 0x0

    .line 327
    :goto_b
    if-ge v8, v13, :cond_14

    .line 328
    .line 329
    iget-object v1, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 330
    .line 331
    aget-object v1, v1, v8

    .line 332
    .line 333
    const/4 v2, 0x1

    .line 334
    const/high16 v5, 0x40000000    # 2.0f

    .line 335
    .line 336
    invoke-virtual {v0, v1, v5, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->hn(Landroid/view/View;IZ)V

    .line 337
    .line 338
    .line 339
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 340
    .line 341
    invoke-virtual {v2, v1}, La/Tt;->p(Landroid/view/View;)I

    .line 342
    .line 343
    .line 344
    move-result v1

    .line 345
    if-le v1, v6, :cond_13

    .line 346
    .line 347
    move v6, v1

    .line 348
    :cond_13
    add-int/lit8 v8, v8, 0x1

    .line 349
    .line 350
    goto :goto_b

    .line 351
    :cond_14
    const/4 v8, 0x0

    .line 352
    :goto_c
    if-ge v8, v13, :cond_18

    .line 353
    .line 354
    iget-object v1, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 355
    .line 356
    aget-object v1, v1, v8

    .line 357
    .line 358
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 359
    .line 360
    invoke-virtual {v2, v1}, La/Tt;->p(Landroid/view/View;)I

    .line 361
    .line 362
    .line 363
    move-result v2

    .line 364
    if-eq v2, v6, :cond_16

    .line 365
    .line 366
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 367
    .line 368
    .line 369
    move-result-object v2

    .line 370
    check-cast v2, La/zj;

    .line 371
    .line 372
    iget-object v5, v2, La/Mk;->h:Landroid/graphics/Rect;

    .line 373
    .line 374
    iget v7, v5, Landroid/graphics/Rect;->top:I

    .line 375
    .line 376
    iget v9, v5, Landroid/graphics/Rect;->bottom:I

    .line 377
    .line 378
    add-int/2addr v7, v9

    .line 379
    iget v9, v2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 380
    .line 381
    add-int/2addr v7, v9

    .line 382
    iget v9, v2, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 383
    .line 384
    add-int/2addr v7, v9

    .line 385
    iget v9, v5, Landroid/graphics/Rect;->left:I

    .line 386
    .line 387
    iget v5, v5, Landroid/graphics/Rect;->right:I

    .line 388
    .line 389
    add-int/2addr v9, v5

    .line 390
    iget v5, v2, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 391
    .line 392
    add-int/2addr v9, v5

    .line 393
    iget v5, v2, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 394
    .line 395
    add-int/2addr v9, v5

    .line 396
    iget v5, v2, La/zj;->i:I

    .line 397
    .line 398
    iget v10, v2, La/zj;->Q:I

    .line 399
    .line 400
    invoke-virtual {v0, v5, v10}, Landroidx/recyclerview/widget/GridLayoutManager;->JD(II)I

    .line 401
    .line 402
    .line 403
    move-result v5

    .line 404
    iget v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 405
    .line 406
    const/4 v11, 0x1

    .line 407
    if-ne v10, v11, :cond_15

    .line 408
    .line 409
    iget v2, v2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 410
    .line 411
    const/4 v10, 0x0

    .line 412
    const/high16 v11, 0x40000000    # 2.0f

    .line 413
    .line 414
    invoke-static {v5, v11, v9, v2, v10}, La/XG;->F(IIIIZ)I

    .line 415
    .line 416
    .line 417
    move-result v2

    .line 418
    sub-int v5, v6, v7

    .line 419
    .line 420
    invoke-static {v5, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 421
    .line 422
    .line 423
    move-result v5

    .line 424
    goto :goto_d

    .line 425
    :cond_15
    const/4 v10, 0x0

    .line 426
    const/high16 v11, 0x40000000    # 2.0f

    .line 427
    .line 428
    sub-int v9, v6, v9

    .line 429
    .line 430
    invoke-static {v9, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 431
    .line 432
    .line 433
    move-result v9

    .line 434
    iget v2, v2, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 435
    .line 436
    invoke-static {v5, v11, v7, v2, v10}, La/XG;->F(IIIIZ)I

    .line 437
    .line 438
    .line 439
    move-result v5

    .line 440
    move v2, v9

    .line 441
    :goto_d
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 442
    .line 443
    .line 444
    move-result-object v7

    .line 445
    check-cast v7, La/Mk;

    .line 446
    .line 447
    invoke-virtual {v0, v1, v2, v5, v7}, La/XG;->nA(Landroid/view/View;IILa/Mk;)Z

    .line 448
    .line 449
    .line 450
    move-result v7

    .line 451
    if-eqz v7, :cond_17

    .line 452
    .line 453
    invoke-virtual {v1, v2, v5}, Landroid/view/View;->measure(II)V

    .line 454
    .line 455
    .line 456
    goto :goto_e

    .line 457
    :cond_16
    const/4 v10, 0x0

    .line 458
    const/high16 v11, 0x40000000    # 2.0f

    .line 459
    .line 460
    :cond_17
    :goto_e
    add-int/lit8 v8, v8, 0x1

    .line 461
    .line 462
    goto :goto_c

    .line 463
    :cond_18
    const/4 v10, 0x0

    .line 464
    iput v6, v4, La/Lj;->w:I

    .line 465
    .line 466
    iget v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 467
    .line 468
    const/4 v2, 0x1

    .line 469
    if-ne v1, v2, :cond_1a

    .line 470
    .line 471
    iget v1, v3, La/M2;->Q:I

    .line 472
    .line 473
    const/4 v2, -0x1

    .line 474
    iget v8, v3, La/M2;->h:I

    .line 475
    .line 476
    if-ne v1, v2, :cond_19

    .line 477
    .line 478
    sub-int v1, v8, v6

    .line 479
    .line 480
    move v3, v1

    .line 481
    move v1, v10

    .line 482
    move v2, v1

    .line 483
    goto :goto_10

    .line 484
    :cond_19
    add-int v1, v8, v6

    .line 485
    .line 486
    move v3, v8

    .line 487
    move v2, v10

    .line 488
    move v8, v1

    .line 489
    move v1, v2

    .line 490
    goto :goto_10

    .line 491
    :cond_1a
    const/4 v2, -0x1

    .line 492
    iget v1, v3, La/M2;->Q:I

    .line 493
    .line 494
    iget v8, v3, La/M2;->h:I

    .line 495
    .line 496
    if-ne v1, v2, :cond_1b

    .line 497
    .line 498
    sub-int v1, v8, v6

    .line 499
    .line 500
    move v2, v8

    .line 501
    :goto_f
    move v3, v10

    .line 502
    move v8, v3

    .line 503
    goto :goto_10

    .line 504
    :cond_1b
    add-int v1, v8, v6

    .line 505
    .line 506
    move v2, v1

    .line 507
    move v1, v8

    .line 508
    goto :goto_f

    .line 509
    :goto_10
    move v6, v10

    .line 510
    :goto_11
    if-ge v6, v13, :cond_20

    .line 511
    .line 512
    iget-object v5, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 513
    .line 514
    aget-object v5, v5, v6

    .line 515
    .line 516
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 517
    .line 518
    .line 519
    move-result-object v7

    .line 520
    check-cast v7, La/zj;

    .line 521
    .line 522
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 523
    .line 524
    const/4 v10, 0x1

    .line 525
    if-ne v9, v10, :cond_1d

    .line 526
    .line 527
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    .line 528
    .line 529
    .line 530
    move-result v1

    .line 531
    if-eqz v1, :cond_1c

    .line 532
    .line 533
    invoke-virtual/range {p0 .. p0}, La/XG;->D()I

    .line 534
    .line 535
    .line 536
    move-result v1

    .line 537
    iget-object v2, v0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 538
    .line 539
    iget v9, v0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 540
    .line 541
    iget v10, v7, La/zj;->i:I

    .line 542
    .line 543
    sub-int/2addr v9, v10

    .line 544
    aget v2, v2, v9

    .line 545
    .line 546
    add-int/2addr v1, v2

    .line 547
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 548
    .line 549
    invoke-virtual {v2, v5}, La/Tt;->T(Landroid/view/View;)I

    .line 550
    .line 551
    .line 552
    move-result v2

    .line 553
    sub-int v2, v1, v2

    .line 554
    .line 555
    move/from16 v17, v2

    .line 556
    .line 557
    move v2, v1

    .line 558
    move/from16 v1, v17

    .line 559
    .line 560
    goto :goto_12

    .line 561
    :cond_1c
    invoke-virtual/range {p0 .. p0}, La/XG;->D()I

    .line 562
    .line 563
    .line 564
    move-result v1

    .line 565
    iget-object v2, v0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 566
    .line 567
    iget v9, v7, La/zj;->i:I

    .line 568
    .line 569
    aget v2, v2, v9

    .line 570
    .line 571
    add-int/2addr v1, v2

    .line 572
    iget-object v2, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 573
    .line 574
    invoke-virtual {v2, v5}, La/Tt;->T(Landroid/view/View;)I

    .line 575
    .line 576
    .line 577
    move-result v2

    .line 578
    add-int/2addr v2, v1

    .line 579
    goto :goto_12

    .line 580
    :cond_1d
    invoke-virtual/range {p0 .. p0}, La/XG;->u()I

    .line 581
    .line 582
    .line 583
    move-result v3

    .line 584
    iget-object v8, v0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 585
    .line 586
    iget v9, v7, La/zj;->i:I

    .line 587
    .line 588
    aget v8, v8, v9

    .line 589
    .line 590
    add-int/2addr v3, v8

    .line 591
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 592
    .line 593
    invoke-virtual {v8, v5}, La/Tt;->T(Landroid/view/View;)I

    .line 594
    .line 595
    .line 596
    move-result v8

    .line 597
    add-int/2addr v8, v3

    .line 598
    :goto_12
    invoke-static {v5, v1, v3, v2, v8}, La/XG;->n(Landroid/view/View;IIII)V

    .line 599
    .line 600
    .line 601
    iget-object v9, v7, La/Mk;->w:La/Ty;

    .line 602
    .line 603
    invoke-virtual {v9}, La/Ty;->I()Z

    .line 604
    .line 605
    .line 606
    move-result v9

    .line 607
    if-nez v9, :cond_1e

    .line 608
    .line 609
    iget-object v7, v7, La/Mk;->w:La/Ty;

    .line 610
    .line 611
    invoke-virtual {v7}, La/Ty;->m()Z

    .line 612
    .line 613
    .line 614
    move-result v7

    .line 615
    if-eqz v7, :cond_1f

    .line 616
    .line 617
    :cond_1e
    const/4 v7, 0x1

    .line 618
    goto :goto_13

    .line 619
    :cond_1f
    const/4 v7, 0x1

    .line 620
    goto :goto_14

    .line 621
    :goto_13
    iput-boolean v7, v4, La/Lj;->p:Z

    .line 622
    .line 623
    :goto_14
    iget-boolean v9, v4, La/Lj;->e:Z

    .line 624
    .line 625
    invoke-virtual {v5}, Landroid/view/View;->hasFocusable()Z

    .line 626
    .line 627
    .line 628
    move-result v5

    .line 629
    or-int/2addr v5, v9

    .line 630
    iput-boolean v5, v4, La/Lj;->e:Z

    .line 631
    .line 632
    add-int/lit8 v6, v6, 0x1

    .line 633
    .line 634
    goto :goto_11

    .line 635
    :cond_20
    iget-object v1, v0, Landroidx/recyclerview/widget/GridLayoutManager;->v:[Landroid/view/View;

    .line 636
    .line 637
    const/4 v2, 0x0

    .line 638
    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 639
    .line 640
    .line 641
    return-void

    .line 642
    nop

    .line 643
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final FB()V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    iget v0, p0, La/XG;->y:I

    .line 7
    .line 8
    invoke-virtual {p0}, La/XG;->Y()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    sub-int/2addr v0, v1

    .line 13
    invoke-virtual {p0}, La/XG;->D()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    :goto_0
    sub-int/2addr v0, v1

    .line 18
    goto :goto_1

    .line 19
    :cond_0
    iget v0, p0, La/XG;->K:I

    .line 20
    .line 21
    invoke-virtual {p0}, La/XG;->P()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    sub-int/2addr v0, v1

    .line 26
    invoke-virtual {p0}, La/XG;->u()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    goto :goto_0

    .line 31
    :goto_1
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/GridLayoutManager;->dB(I)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final FL(II)V
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 2
    .line 3
    invoke-virtual {p1}, La/GS;->e()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, La/GS;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Landroid/util/SparseIntArray;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final G()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 2
    .line 3
    invoke-virtual {v0}, La/GS;->e()V

    .line 4
    .line 5
    .line 6
    iget-object v0, v0, La/GS;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/util/SparseIntArray;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/util/SparseIntArray;->clear()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final Gy(ILa/fl;La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->FB()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->Di()V

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Gy(ILa/fl;La/R8;)I

    move-result p1

    return p1
.end method

.method public final J(II)V
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 2
    .line 3
    invoke-virtual {p1}, La/GS;->e()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, La/GS;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Landroid/util/SparseIntArray;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final JD(II)I
    .locals 3

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    iget v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    sub-int v2, v1, p1

    aget v2, v0, v2

    sub-int/2addr v1, p1

    sub-int/2addr v1, p2

    aget p1, v0, v1

    sub-int/2addr v2, p1

    return v2

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    add-int/2addr p2, p1

    aget p2, v0, p2

    aget p1, v0, p1

    sub-int/2addr p2, p1

    return p2
.end method

.method public final K(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hs(La/R8;)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public final M(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->GI(La/R8;)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public final N(La/fl;La/R8;Landroid/view/View;La/sH;)V
    .locals 7

    .line 1
    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, La/zj;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0, p3, p4}, La/XG;->b(Landroid/view/View;La/sH;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    check-cast v0, La/zj;

    .line 14
    .line 15
    iget-object p3, v0, La/Mk;->w:La/Ty;

    .line 16
    .line 17
    invoke-virtual {p3}, La/Ty;->p()I

    .line 18
    .line 19
    .line 20
    move-result p3

    .line 21
    invoke-virtual {p0, p3, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->ew(ILa/fl;La/R8;)I

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    iget p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 26
    .line 27
    iget-object p3, p4, La/sH;->w:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 28
    .line 29
    if-nez p2, :cond_1

    .line 30
    .line 31
    iget v1, v0, La/zj;->i:I

    .line 32
    .line 33
    iget v2, v0, La/zj;->Q:I

    .line 34
    .line 35
    const/4 v4, 0x1

    .line 36
    const/4 v6, 0x0

    .line 37
    const/4 v5, 0x0

    .line 38
    move v3, p1

    .line 39
    :goto_0
    invoke-static/range {v1 .. v6}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-virtual {p3, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCollectionItemInfo(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    const/4 v2, 0x1

    .line 48
    iget v3, v0, La/zj;->i:I

    .line 49
    .line 50
    iget v4, v0, La/zj;->Q:I

    .line 51
    .line 52
    const/4 v6, 0x0

    .line 53
    const/4 v5, 0x0

    .line 54
    move v1, p1

    .line 55
    goto :goto_0

    .line 56
    :goto_1
    return-void
.end method

.method public final N3(La/R8;La/M2;La/Ge;)V
    .locals 5

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    move v2, v1

    .line 5
    :goto_0
    iget v3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 6
    .line 7
    if-ge v2, v3, :cond_0

    .line 8
    .line 9
    iget v3, p2, La/M2;->e:I

    .line 10
    .line 11
    if-ltz v3, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, La/R8;->h()I

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    if-ge v3, v4, :cond_0

    .line 18
    .line 19
    if-lez v0, :cond_0

    .line 20
    .line 21
    iget v3, p2, La/M2;->e:I

    .line 22
    .line 23
    iget v4, p2, La/M2;->X:I

    .line 24
    .line 25
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    invoke-virtual {p3, v3, v4}, La/Ge;->h(II)V

    .line 30
    .line 31
    .line 32
    iget-object v3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 33
    .line 34
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    add-int/lit8 v0, v0, -0x1

    .line 38
    .line 39
    iget v3, p2, La/M2;->e:I

    .line 40
    .line 41
    iget v4, p2, La/M2;->i:I

    .line 42
    .line 43
    add-int/2addr v3, v4

    .line 44
    iput v3, p2, La/M2;->e:I

    .line 45
    .line 46
    add-int/lit8 v2, v2, 0x1

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    return-void
.end method

.method public final Pc(II)V
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 2
    .line 3
    invoke-virtual {p1}, La/GS;->e()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, La/GS;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Landroid/util/SparseIntArray;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final Q(La/Mk;)Z
    .locals 0

    .line 1
    instance-of p1, p1, La/zj;

    return p1
.end method

.method public final T(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hs(La/R8;)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public final Te(La/fl;La/R8;La/us;I)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->FB()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, La/R8;->h()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-lez v0, :cond_3

    .line 9
    .line 10
    iget-boolean v0, p2, La/R8;->X:Z

    .line 11
    .line 12
    if-nez v0, :cond_3

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    if-ne p4, v0, :cond_0

    .line 16
    .line 17
    move p4, v0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 p4, 0x0

    .line 20
    :goto_0
    iget v1, p3, La/us;->h:I

    .line 21
    .line 22
    invoke-virtual {p0, v1, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->qu(ILa/fl;La/R8;)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz p4, :cond_1

    .line 27
    .line 28
    :goto_1
    if-lez v1, :cond_3

    .line 29
    .line 30
    iget p4, p3, La/us;->h:I

    .line 31
    .line 32
    if-lez p4, :cond_3

    .line 33
    .line 34
    add-int/lit8 p4, p4, -0x1

    .line 35
    .line 36
    iput p4, p3, La/us;->h:I

    .line 37
    .line 38
    invoke-virtual {p0, p4, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->qu(ILa/fl;La/R8;)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    goto :goto_1

    .line 43
    :cond_1
    invoke-virtual {p2}, La/R8;->h()I

    .line 44
    .line 45
    .line 46
    move-result p4

    .line 47
    sub-int/2addr p4, v0

    .line 48
    iget v0, p3, La/us;->h:I

    .line 49
    .line 50
    :goto_2
    if-ge v0, p4, :cond_2

    .line 51
    .line 52
    add-int/lit8 v2, v0, 0x1

    .line 53
    .line 54
    invoke-virtual {p0, v2, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->qu(ILa/fl;La/R8;)I

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-le v3, v1, :cond_2

    .line 59
    .line 60
    move v0, v2

    .line 61
    move v1, v3

    .line 62
    goto :goto_2

    .line 63
    :cond_2
    iput v0, p3, La/us;->h:I

    .line 64
    .line 65
    :cond_3
    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->Di()V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final VQ(ILa/fl;La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->FB()V

    invoke-virtual {p0}, Landroidx/recyclerview/widget/GridLayoutManager;->Di()V

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->VQ(ILa/fl;La/R8;)I

    move-result p1

    return p1
.end method

.method public final XS(Z)V
    .locals 1

    .line 1
    if-nez p1, :cond_0

    const/4 p1, 0x0

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->XS(Z)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "GridLayoutManager does not support stack from end. Consider using reverse layout"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final Z(La/fl;La/R8;La/sH;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3}, La/XG;->Z(La/fl;La/R8;La/sH;)V

    const-class p1, Landroid/widget/GridView;

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p3, p1}, La/sH;->V(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final ZZ(La/fl;La/R8;ZZ)Landroid/view/View;
    .locals 9

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    .line 2
    .line 3
    .line 4
    move-result p3

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz p4, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, La/XG;->q()I

    .line 9
    .line 10
    .line 11
    move-result p3

    .line 12
    sub-int/2addr p3, v0

    .line 13
    const/4 p4, -0x1

    .line 14
    move v0, p4

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 p4, 0x0

    .line 17
    move v8, p4

    .line 18
    move p4, p3

    .line 19
    move p3, v8

    .line 20
    :goto_0
    invoke-virtual {p2}, La/R8;->h()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    .line 25
    .line 26
    .line 27
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 28
    .line 29
    invoke-virtual {v2}, La/Tt;->Q()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 34
    .line 35
    invoke-virtual {v3}, La/Tt;->i()I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    const/4 v4, 0x0

    .line 40
    move-object v5, v4

    .line 41
    :goto_1
    if-eq p3, p4, :cond_6

    .line 42
    .line 43
    invoke-virtual {p0, p3}, La/XG;->W(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    invoke-static {v6}, La/XG;->U(Landroid/view/View;)I

    .line 48
    .line 49
    .line 50
    move-result v7

    .line 51
    if-ltz v7, :cond_5

    .line 52
    .line 53
    if-ge v7, v1, :cond_5

    .line 54
    .line 55
    invoke-virtual {p0, v7, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->qu(ILa/fl;La/R8;)I

    .line 56
    .line 57
    .line 58
    move-result v7

    .line 59
    if-eqz v7, :cond_1

    .line 60
    .line 61
    goto :goto_3

    .line 62
    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    check-cast v7, La/Mk;

    .line 67
    .line 68
    iget-object v7, v7, La/Mk;->w:La/Ty;

    .line 69
    .line 70
    invoke-virtual {v7}, La/Ty;->I()Z

    .line 71
    .line 72
    .line 73
    move-result v7

    .line 74
    if-eqz v7, :cond_2

    .line 75
    .line 76
    if-nez v5, :cond_5

    .line 77
    .line 78
    move-object v5, v6

    .line 79
    goto :goto_3

    .line 80
    :cond_2
    iget-object v7, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 81
    .line 82
    invoke-virtual {v7, v6}, La/Tt;->e(Landroid/view/View;)I

    .line 83
    .line 84
    .line 85
    move-result v7

    .line 86
    if-ge v7, v3, :cond_4

    .line 87
    .line 88
    iget-object v7, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 89
    .line 90
    invoke-virtual {v7, v6}, La/Tt;->h(Landroid/view/View;)I

    .line 91
    .line 92
    .line 93
    move-result v7

    .line 94
    if-ge v7, v2, :cond_3

    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_3
    return-object v6

    .line 98
    :cond_4
    :goto_2
    if-nez v4, :cond_5

    .line 99
    .line 100
    move-object v4, v6

    .line 101
    :cond_5
    :goto_3
    add-int/2addr p3, v0

    .line 102
    goto :goto_1

    .line 103
    :cond_6
    if-eqz v4, :cond_7

    .line 104
    .line 105
    goto :goto_4

    .line 106
    :cond_7
    move-object v4, v5

    .line 107
    :goto_4
    return-object v4
.end method

.method public final an()Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->u:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final c(Landroid/view/View;ILa/fl;La/R8;)Landroid/view/View;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p3

    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    iget-object v3, v0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    move-object/from16 v5, p1

    .line 11
    .line 12
    if-nez v3, :cond_0

    .line 13
    .line 14
    :goto_0
    move-object v3, v4

    .line 15
    goto :goto_2

    .line 16
    :cond_0
    invoke-virtual {v3, v5}, Landroidx/recyclerview/widget/RecyclerView;->P(Landroid/view/View;)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    if-nez v3, :cond_1

    .line 21
    .line 22
    :goto_1
    goto :goto_0

    .line 23
    :cond_1
    iget-object v6, v0, La/XG;->w:La/D6;

    .line 24
    .line 25
    invoke-virtual {v6, v3}, La/D6;->I(Landroid/view/View;)Z

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    if-eqz v6, :cond_2

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_2
    :goto_2
    if-nez v3, :cond_3

    .line 33
    .line 34
    return-object v4

    .line 35
    :cond_3
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    check-cast v6, La/zj;

    .line 40
    .line 41
    iget v7, v6, La/zj;->i:I

    .line 42
    .line 43
    iget v6, v6, La/zj;->Q:I

    .line 44
    .line 45
    add-int/2addr v6, v7

    .line 46
    invoke-super/range {p0 .. p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->c(Landroid/view/View;ILa/fl;La/R8;)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    if-nez v5, :cond_4

    .line 51
    .line 52
    return-object v4

    .line 53
    :cond_4
    move/from16 v5, p2

    .line 54
    .line 55
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->IL(I)I

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    const/4 v9, 0x1

    .line 60
    if-ne v5, v9, :cond_5

    .line 61
    .line 62
    move v5, v9

    .line 63
    goto :goto_3

    .line 64
    :cond_5
    const/4 v5, 0x0

    .line 65
    :goto_3
    iget-boolean v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 66
    .line 67
    const/4 v11, -0x1

    .line 68
    if-eq v5, v10, :cond_6

    .line 69
    .line 70
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    sub-int/2addr v5, v9

    .line 75
    move v10, v11

    .line 76
    move v12, v10

    .line 77
    goto :goto_4

    .line 78
    :cond_6
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 79
    .line 80
    .line 81
    move-result v5

    .line 82
    move v10, v5

    .line 83
    move v12, v9

    .line 84
    const/4 v5, 0x0

    .line 85
    :goto_4
    iget v13, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 86
    .line 87
    if-ne v13, v9, :cond_7

    .line 88
    .line 89
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    .line 90
    .line 91
    .line 92
    move-result v13

    .line 93
    if-eqz v13, :cond_7

    .line 94
    .line 95
    move v13, v9

    .line 96
    goto :goto_5

    .line 97
    :cond_7
    const/4 v13, 0x0

    .line 98
    :goto_5
    invoke-virtual {v0, v5, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->ew(ILa/fl;La/R8;)I

    .line 99
    .line 100
    .line 101
    move-result v14

    .line 102
    move v8, v11

    .line 103
    move v15, v8

    .line 104
    move/from16 v16, v12

    .line 105
    .line 106
    const/4 v9, 0x0

    .line 107
    const/4 v12, 0x0

    .line 108
    move v11, v5

    .line 109
    move-object v5, v4

    .line 110
    :goto_6
    if-eq v11, v10, :cond_8

    .line 111
    .line 112
    move/from16 v17, v10

    .line 113
    .line 114
    invoke-virtual {v0, v11, v1, v2}, Landroidx/recyclerview/widget/GridLayoutManager;->ew(ILa/fl;La/R8;)I

    .line 115
    .line 116
    .line 117
    move-result v10

    .line 118
    invoke-virtual {v0, v11}, La/XG;->W(I)Landroid/view/View;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    if-ne v1, v3, :cond_9

    .line 123
    .line 124
    :cond_8
    :goto_7
    move-object/from16 v21, v5

    .line 125
    .line 126
    goto/16 :goto_10

    .line 127
    .line 128
    :cond_9
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 129
    .line 130
    .line 131
    move-result v18

    .line 132
    if-eqz v18, :cond_c

    .line 133
    .line 134
    if-eq v10, v14, :cond_c

    .line 135
    .line 136
    if-eqz v4, :cond_a

    .line 137
    .line 138
    goto :goto_7

    .line 139
    :cond_a
    move-object/from16 v18, v3

    .line 140
    .line 141
    move-object/from16 v21, v5

    .line 142
    .line 143
    :cond_b
    move/from16 v19, v9

    .line 144
    .line 145
    const/4 v9, 0x1

    .line 146
    goto/16 :goto_e

    .line 147
    .line 148
    :cond_c
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 149
    .line 150
    .line 151
    move-result-object v10

    .line 152
    check-cast v10, La/zj;

    .line 153
    .line 154
    iget v2, v10, La/zj;->i:I

    .line 155
    .line 156
    move-object/from16 v18, v3

    .line 157
    .line 158
    iget v3, v10, La/zj;->Q:I

    .line 159
    .line 160
    add-int/2addr v3, v2

    .line 161
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 162
    .line 163
    .line 164
    move-result v19

    .line 165
    if-eqz v19, :cond_d

    .line 166
    .line 167
    if-ne v2, v7, :cond_d

    .line 168
    .line 169
    if-ne v3, v6, :cond_d

    .line 170
    .line 171
    return-object v1

    .line 172
    :cond_d
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 173
    .line 174
    .line 175
    move-result v19

    .line 176
    if-eqz v19, :cond_e

    .line 177
    .line 178
    if-eqz v4, :cond_f

    .line 179
    .line 180
    :cond_e
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 181
    .line 182
    .line 183
    move-result v19

    .line 184
    if-nez v19, :cond_10

    .line 185
    .line 186
    if-nez v5, :cond_10

    .line 187
    .line 188
    :cond_f
    move-object/from16 v21, v5

    .line 189
    .line 190
    :goto_8
    move/from16 v19, v9

    .line 191
    .line 192
    const/4 v9, 0x1

    .line 193
    goto :goto_d

    .line 194
    :cond_10
    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    .line 195
    .line 196
    .line 197
    move-result v19

    .line 198
    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    .line 199
    .line 200
    .line 201
    move-result v20

    .line 202
    move-object/from16 v21, v5

    .line 203
    .line 204
    sub-int v5, v20, v19

    .line 205
    .line 206
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 207
    .line 208
    .line 209
    move-result v19

    .line 210
    if-eqz v19, :cond_13

    .line 211
    .line 212
    if-le v5, v9, :cond_11

    .line 213
    .line 214
    :goto_9
    goto :goto_8

    .line 215
    :cond_11
    if-ne v5, v9, :cond_b

    .line 216
    .line 217
    if-le v2, v15, :cond_12

    .line 218
    .line 219
    const/4 v5, 0x1

    .line 220
    goto :goto_a

    .line 221
    :cond_12
    const/4 v5, 0x0

    .line 222
    :goto_a
    if-ne v13, v5, :cond_b

    .line 223
    .line 224
    goto :goto_9

    .line 225
    :cond_13
    if-nez v4, :cond_b

    .line 226
    .line 227
    move/from16 v19, v9

    .line 228
    .line 229
    iget-object v9, v0, La/XG;->p:La/v5;

    .line 230
    .line 231
    invoke-virtual {v9, v1}, La/v5;->T(Landroid/view/View;)Z

    .line 232
    .line 233
    .line 234
    move-result v9

    .line 235
    if-eqz v9, :cond_14

    .line 236
    .line 237
    iget-object v9, v0, La/XG;->e:La/v5;

    .line 238
    .line 239
    invoke-virtual {v9, v1}, La/v5;->T(Landroid/view/View;)Z

    .line 240
    .line 241
    .line 242
    move-result v9

    .line 243
    if-eqz v9, :cond_14

    .line 244
    .line 245
    const/4 v9, 0x1

    .line 246
    const/16 v20, 0x1

    .line 247
    .line 248
    goto :goto_b

    .line 249
    :cond_14
    const/4 v9, 0x1

    .line 250
    const/16 v20, 0x0

    .line 251
    .line 252
    :goto_b
    xor-int/lit8 v20, v20, 0x1

    .line 253
    .line 254
    if-eqz v20, :cond_18

    .line 255
    .line 256
    if-le v5, v12, :cond_15

    .line 257
    .line 258
    goto :goto_d

    .line 259
    :cond_15
    if-ne v5, v12, :cond_18

    .line 260
    .line 261
    if-le v2, v8, :cond_16

    .line 262
    .line 263
    move v5, v9

    .line 264
    goto :goto_c

    .line 265
    :cond_16
    const/4 v5, 0x0

    .line 266
    :goto_c
    if-ne v13, v5, :cond_18

    .line 267
    .line 268
    :goto_d
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    .line 269
    .line 270
    .line 271
    move-result v5

    .line 272
    if-eqz v5, :cond_17

    .line 273
    .line 274
    iget v4, v10, La/zj;->i:I

    .line 275
    .line 276
    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    .line 277
    .line 278
    .line 279
    move-result v3

    .line 280
    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    .line 281
    .line 282
    .line 283
    move-result v2

    .line 284
    sub-int v2, v3, v2

    .line 285
    .line 286
    move/from16 v19, v2

    .line 287
    .line 288
    move v15, v4

    .line 289
    move-object/from16 v5, v21

    .line 290
    .line 291
    move-object v4, v1

    .line 292
    goto :goto_f

    .line 293
    :cond_17
    iget v5, v10, La/zj;->i:I

    .line 294
    .line 295
    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    .line 296
    .line 297
    .line 298
    move-result v3

    .line 299
    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    .line 300
    .line 301
    .line 302
    move-result v2

    .line 303
    sub-int v12, v3, v2

    .line 304
    .line 305
    move v8, v5

    .line 306
    move-object v5, v1

    .line 307
    goto :goto_f

    .line 308
    :cond_18
    :goto_e
    move-object/from16 v5, v21

    .line 309
    .line 310
    :goto_f
    add-int v11, v11, v16

    .line 311
    .line 312
    move-object/from16 v1, p3

    .line 313
    .line 314
    move-object/from16 v2, p4

    .line 315
    .line 316
    move/from16 v10, v17

    .line 317
    .line 318
    move-object/from16 v3, v18

    .line 319
    .line 320
    move/from16 v9, v19

    .line 321
    .line 322
    goto/16 :goto_6

    .line 323
    .line 324
    :goto_10
    if-eqz v4, :cond_19

    .line 325
    .line 326
    goto :goto_11

    .line 327
    :cond_19
    move-object/from16 v4, v21

    .line 328
    .line 329
    :goto_11
    return-object v4
.end method

.method public final cS(Landroid/graphics/Rect;II)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1, p2, p3}, La/XG;->cS(Landroid/graphics/Rect;II)V

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-virtual {p0}, La/XG;->D()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-virtual {p0}, La/XG;->Y()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    add-int/2addr v1, v0

    .line 17
    invoke-virtual {p0}, La/XG;->u()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p0}, La/XG;->P()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    add-int/2addr v2, v0

    .line 26
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 27
    .line 28
    const/4 v3, 0x1

    .line 29
    if-ne v0, v3, :cond_1

    .line 30
    .line 31
    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    add-int/2addr p1, v2

    .line 36
    iget-object v0, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 37
    .line 38
    sget-object v2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 39
    .line 40
    invoke-static {v0}, La/Tl;->e(Landroid/view/View;)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-static {p3, p1, v0}, La/XG;->X(III)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    iget-object p3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 49
    .line 50
    array-length v0, p3

    .line 51
    sub-int/2addr v0, v3

    .line 52
    aget p3, p3, v0

    .line 53
    .line 54
    add-int/2addr p3, v1

    .line 55
    iget-object v0, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 56
    .line 57
    invoke-static {v0}, La/Tl;->i(Landroid/view/View;)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    invoke-static {p2, p3, v0}, La/XG;->X(III)I

    .line 62
    .line 63
    .line 64
    move-result p2

    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    add-int/2addr p1, v1

    .line 71
    iget-object v0, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 72
    .line 73
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 74
    .line 75
    invoke-static {v0}, La/Tl;->i(Landroid/view/View;)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    invoke-static {p2, p1, v0}, La/XG;->X(III)I

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 84
    .line 85
    array-length v0, p1

    .line 86
    sub-int/2addr v0, v3

    .line 87
    aget p1, p1, v0

    .line 88
    .line 89
    add-int/2addr p1, v2

    .line 90
    iget-object v0, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 91
    .line 92
    invoke-static {v0}, La/Tl;->e(Landroid/view/View;)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    invoke-static {p3, p1, v0}, La/XG;->X(III)I

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    :goto_0
    iget-object p3, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 101
    .line 102
    invoke-static {p3, p2, p1}, Landroidx/recyclerview/widget/RecyclerView;->X(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 103
    .line 104
    .line 105
    return-void
.end method

.method public final d()La/Mk;
    .locals 3

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, -0x1

    const/4 v2, -0x2

    if-nez v0, :cond_0

    new-instance v0, La/zj;

    invoke-direct {v0, v2, v1}, La/zj;-><init>(II)V

    return-object v0

    :cond_0
    new-instance v0, La/zj;

    invoke-direct {v0, v1, v2}, La/zj;-><init>(II)V

    return-object v0
.end method

.method public final dB(I)V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 2
    .line 3
    iget v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    array-length v3, v0

    .line 9
    add-int/lit8 v4, v1, 0x1

    .line 10
    .line 11
    if-ne v3, v4, :cond_0

    .line 12
    .line 13
    array-length v3, v0

    .line 14
    sub-int/2addr v3, v2

    .line 15
    aget v3, v0, v3

    .line 16
    .line 17
    if-eq v3, p1, :cond_1

    .line 18
    .line 19
    :cond_0
    add-int/lit8 v0, v1, 0x1

    .line 20
    .line 21
    new-array v0, v0, [I

    .line 22
    .line 23
    :cond_1
    const/4 v3, 0x0

    .line 24
    aput v3, v0, v3

    .line 25
    .line 26
    div-int v4, p1, v1

    .line 27
    .line 28
    rem-int/2addr p1, v1

    .line 29
    move v5, v3

    .line 30
    :goto_0
    if-gt v2, v1, :cond_3

    .line 31
    .line 32
    add-int/2addr v3, p1

    .line 33
    if-lez v3, :cond_2

    .line 34
    .line 35
    sub-int v6, v1, v3

    .line 36
    .line 37
    if-ge v6, p1, :cond_2

    .line 38
    .line 39
    add-int/lit8 v6, v4, 0x1

    .line 40
    .line 41
    sub-int/2addr v3, v1

    .line 42
    goto :goto_1

    .line 43
    :cond_2
    move v6, v4

    .line 44
    :goto_1
    add-int/2addr v5, v6

    .line 45
    aput v5, v0, v2

    .line 46
    .line 47
    add-int/lit8 v2, v2, 0x1

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_3
    iput-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->k:[I

    .line 51
    .line 52
    return-void
.end method

.method public final ew(ILa/fl;La/R8;)I
    .locals 1

    .line 1
    iget-boolean p3, p3, La/R8;->X:Z

    .line 2
    .line 3
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 4
    .line 5
    if-nez p3, :cond_0

    .line 6
    .line 7
    iget p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 8
    .line 9
    invoke-virtual {v0, p1, p2}, La/GS;->w(II)I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    return p1

    .line 14
    :cond_0
    invoke-virtual {p2, p1}, La/fl;->h(I)I

    .line 15
    .line 16
    .line 17
    move-result p2

    .line 18
    const/4 p3, -0x1

    .line 19
    if-ne p2, p3, :cond_1

    .line 20
    .line 21
    new-instance p2, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    const-string p3, "Cannot find span size for pre layout position. "

    .line 24
    .line 25
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    const-string p2, "GridLayoutManager"

    .line 36
    .line 37
    invoke-static {p2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    const/4 p1, 0x0

    .line 41
    return p1

    .line 42
    :cond_1
    iget p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 43
    .line 44
    invoke-virtual {v0, p2, p1}, La/GS;->w(II)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    return p1
.end method

.method public final f(Landroid/content/Context;Landroid/util/AttributeSet;)La/Mk;
    .locals 1

    .line 1
    new-instance v0, La/zj;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, La/Mk;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, -0x1

    .line 7
    iput p1, v0, La/zj;->i:I

    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    iput p1, v0, La/zj;->Q:I

    .line 11
    .line 12
    return-object v0
.end method

.method public final hn(Landroid/view/View;IZ)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, La/zj;

    .line 6
    .line 7
    iget-object v1, v0, La/Mk;->h:Landroid/graphics/Rect;

    .line 8
    .line 9
    iget v2, v1, Landroid/graphics/Rect;->top:I

    .line 10
    .line 11
    iget v3, v1, Landroid/graphics/Rect;->bottom:I

    .line 12
    .line 13
    add-int/2addr v2, v3

    .line 14
    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 15
    .line 16
    add-int/2addr v2, v3

    .line 17
    iget v3, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 18
    .line 19
    add-int/2addr v2, v3

    .line 20
    iget v3, v1, Landroid/graphics/Rect;->left:I

    .line 21
    .line 22
    iget v1, v1, Landroid/graphics/Rect;->right:I

    .line 23
    .line 24
    add-int/2addr v3, v1

    .line 25
    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 26
    .line 27
    add-int/2addr v3, v1

    .line 28
    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 29
    .line 30
    add-int/2addr v3, v1

    .line 31
    iget v1, v0, La/zj;->i:I

    .line 32
    .line 33
    iget v4, v0, La/zj;->Q:I

    .line 34
    .line 35
    invoke-virtual {p0, v1, v4}, Landroidx/recyclerview/widget/GridLayoutManager;->JD(II)I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 40
    .line 41
    const/4 v5, 0x0

    .line 42
    const/4 v6, 0x1

    .line 43
    if-ne v4, v6, :cond_0

    .line 44
    .line 45
    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 46
    .line 47
    invoke-static {v1, p2, v3, v4, v5}, La/XG;->F(IIIIZ)I

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 52
    .line 53
    invoke-virtual {v1}, La/Tt;->X()I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    iget v3, p0, La/XG;->m:I

    .line 58
    .line 59
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 60
    .line 61
    invoke-static {v1, v3, v2, v0, v6}, La/XG;->F(IIIIZ)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    goto :goto_0

    .line 66
    :cond_0
    iget v4, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 67
    .line 68
    invoke-static {v1, p2, v2, v4, v5}, La/XG;->F(IIIIZ)I

    .line 69
    .line 70
    .line 71
    move-result p2

    .line 72
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 73
    .line 74
    invoke-virtual {v1}, La/Tt;->X()I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    iget v2, p0, La/XG;->T:I

    .line 79
    .line 80
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 81
    .line 82
    invoke-static {v1, v2, v3, v0, v6}, La/XG;->F(IIIIZ)I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    move v7, v0

    .line 87
    move v0, p2

    .line 88
    move p2, v7

    .line 89
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    check-cast v1, La/Mk;

    .line 94
    .line 95
    if-eqz p3, :cond_1

    .line 96
    .line 97
    invoke-virtual {p0, p1, p2, v0, v1}, La/XG;->nA(Landroid/view/View;IILa/Mk;)Z

    .line 98
    .line 99
    .line 100
    move-result p3

    .line 101
    goto :goto_1

    .line 102
    :cond_1
    invoke-virtual {p0, p1, p2, v0, v1}, La/XG;->yd(Landroid/view/View;IILa/Mk;)Z

    .line 103
    .line 104
    .line 105
    move-result p3

    .line 106
    :goto_1
    if-eqz p3, :cond_2

    .line 107
    .line 108
    invoke-virtual {p1, p2, v0}, Landroid/view/View;->measure(II)V

    .line 109
    .line 110
    .line 111
    :cond_2
    return-void
.end method

.method public final l(Landroid/view/ViewGroup$LayoutParams;)La/Mk;
    .locals 3

    .line 1
    instance-of v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, -0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    new-instance v0, La/zj;

    .line 8
    .line 9
    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 10
    .line 11
    invoke-direct {v0, p1}, La/Mk;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    .line 12
    .line 13
    .line 14
    iput v2, v0, La/zj;->i:I

    .line 15
    .line 16
    iput v1, v0, La/zj;->Q:I

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_0
    new-instance v0, La/zj;

    .line 20
    .line 21
    invoke-direct {v0, p1}, La/Mk;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 22
    .line 23
    .line 24
    iput v2, v0, La/zj;->i:I

    .line 25
    .line 26
    iput v1, v0, La/zj;->Q:I

    .line 27
    .line 28
    return-object v0
.end method

.method public final nd(ILa/fl;La/R8;)I
    .locals 3

    .line 1
    iget-boolean p3, p3, La/R8;->X:Z

    .line 2
    .line 3
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez p3, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    return v1

    .line 12
    :cond_0
    iget-object p3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->s:Landroid/util/SparseIntArray;

    .line 13
    .line 14
    const/4 v2, -0x1

    .line 15
    invoke-virtual {p3, p1, v2}, Landroid/util/SparseIntArray;->get(II)I

    .line 16
    .line 17
    .line 18
    move-result p3

    .line 19
    if-eq p3, v2, :cond_1

    .line 20
    .line 21
    return p3

    .line 22
    :cond_1
    invoke-virtual {p2, p1}, La/fl;->h(I)I

    .line 23
    .line 24
    .line 25
    move-result p2

    .line 26
    if-ne p2, v2, :cond_2

    .line 27
    .line 28
    new-instance p2, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string p3, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    .line 31
    .line 32
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    const-string p2, "GridLayoutManager"

    .line 43
    .line 44
    invoke-static {p2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    return v1

    .line 48
    :cond_2
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    return v1
.end method

.method public final p7(La/R8;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->p7(La/R8;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->u:Z

    return-void
.end method

.method public final qu(ILa/fl;La/R8;)I
    .locals 2

    .line 1
    iget-boolean p3, p3, La/R8;->X:Z

    .line 2
    .line 3
    iget-object v0, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 4
    .line 5
    if-nez p3, :cond_0

    .line 6
    .line 7
    iget p2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 8
    .line 9
    invoke-virtual {v0, p1, p2}, La/GS;->h(II)I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    return p1

    .line 14
    :cond_0
    iget-object p3, p0, Landroidx/recyclerview/widget/GridLayoutManager;->j:Landroid/util/SparseIntArray;

    .line 15
    .line 16
    const/4 v1, -0x1

    .line 17
    invoke-virtual {p3, p1, v1}, Landroid/util/SparseIntArray;->get(II)I

    .line 18
    .line 19
    .line 20
    move-result p3

    .line 21
    if-eq p3, v1, :cond_1

    .line 22
    .line 23
    return p3

    .line 24
    :cond_1
    invoke-virtual {p2, p1}, La/fl;->h(I)I

    .line 25
    .line 26
    .line 27
    move-result p2

    .line 28
    if-ne p2, v1, :cond_2

    .line 29
    .line 30
    new-instance p2, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string p3, "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:"

    .line 33
    .line 34
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    const-string p2, "GridLayoutManager"

    .line 45
    .line 46
    invoke-static {p2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    const/4 p1, 0x0

    .line 50
    return p1

    .line 51
    :cond_2
    iget p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    .line 52
    .line 53
    invoke-virtual {v0, p2, p1}, La/GS;->h(II)I

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    return p1
.end method

.method public final rC(La/fl;La/R8;)V
    .locals 7

    .line 1
    iget-boolean v0, p2, La/R8;->X:Z

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->j:Landroid/util/SparseIntArray;

    .line 4
    .line 5
    iget-object v2, p0, Landroidx/recyclerview/widget/GridLayoutManager;->s:Landroid/util/SparseIntArray;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, La/XG;->q()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    if-ge v3, v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p0, v3}, La/XG;->W(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    check-cast v4, La/zj;

    .line 25
    .line 26
    iget-object v5, v4, La/Mk;->w:La/Ty;

    .line 27
    .line 28
    invoke-virtual {v5}, La/Ty;->p()I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    iget v6, v4, La/zj;->Q:I

    .line 33
    .line 34
    invoke-virtual {v2, v5, v6}, Landroid/util/SparseIntArray;->put(II)V

    .line 35
    .line 36
    .line 37
    iget v4, v4, La/zj;->i:I

    .line 38
    .line 39
    invoke-virtual {v1, v5, v4}, Landroid/util/SparseIntArray;->put(II)V

    .line 40
    .line 41
    .line 42
    add-int/lit8 v3, v3, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->rC(La/fl;La/R8;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2}, Landroid/util/SparseIntArray;->clear()V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v1}, Landroid/util/SparseIntArray;->clear()V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final rV(II)V
    .locals 0

    .line 1
    iget-object p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->t:La/GS;

    .line 2
    .line 3
    invoke-virtual {p1}, La/GS;->e()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, La/GS;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Landroid/util/SparseIntArray;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/util/SparseIntArray;->clear()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final v(La/fl;La/R8;)I
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez v0, :cond_0

    iget p1, p0, Landroidx/recyclerview/widget/GridLayoutManager;->U:I

    return p1

    :cond_0
    invoke-virtual {p2}, La/R8;->h()I

    move-result v0

    const/4 v1, 0x1

    if-ge v0, v1, :cond_1

    const/4 p1, 0x0

    return p1

    :cond_1
    invoke-virtual {p2}, La/R8;->h()I

    move-result v0

    sub-int/2addr v0, v1

    invoke-virtual {p0, v0, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->ew(ILa/fl;La/R8;)I

    move-result p1

    add-int/2addr p1, v1

    return p1
.end method

.method public final y(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->GI(La/R8;)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method
