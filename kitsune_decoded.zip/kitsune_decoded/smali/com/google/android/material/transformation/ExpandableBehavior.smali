.class public abstract Lcom/google/android/material/transformation/ExpandableBehavior;
.super La/AC;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/AC;"
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field public w:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 2
    const/4 p1, 0x0

    invoke-direct {p0, p1}, La/AC;-><init>(I)V

    iput p1, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    return-void
.end method


# virtual methods
.method public final O(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 4

    .line 1
    sget-object p3, La/sI;->w:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    invoke-static {p2}, La/AM;->p(Landroid/view/View;)Z

    .line 4
    .line 5
    .line 6
    move-result p3

    .line 7
    const/4 v0, 0x0

    .line 8
    if-nez p3, :cond_5

    .line 9
    .line 10
    invoke-virtual {p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->M(Landroid/view/View;)Ljava/util/ArrayList;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 15
    .line 16
    .line 17
    move-result p3

    .line 18
    move v1, v0

    .line 19
    :goto_0
    if-ge v1, p3, :cond_1

    .line 20
    .line 21
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Landroid/view/View;

    .line 26
    .line 27
    invoke-virtual {p0, p2, v2}, Lcom/google/android/material/transformation/ExpandableBehavior;->h(Landroid/view/View;Landroid/view/View;)Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    check-cast v2, La/MS;

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const/4 v2, 0x0

    .line 40
    :goto_1
    if-eqz v2, :cond_5

    .line 41
    .line 42
    move-object p1, v2

    .line 43
    check-cast p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 44
    .line 45
    iget-object p1, p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->H:La/og;

    .line 46
    .line 47
    iget-boolean p1, p1, La/og;->w:Z

    .line 48
    .line 49
    const/4 p3, 0x2

    .line 50
    const/4 v1, 0x1

    .line 51
    iget v3, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    .line 52
    .line 53
    if-eqz p1, :cond_2

    .line 54
    .line 55
    if-eqz v3, :cond_3

    .line 56
    .line 57
    if-ne v3, p3, :cond_5

    .line 58
    .line 59
    goto :goto_2

    .line 60
    :cond_2
    if-ne v3, v1, :cond_5

    .line 61
    .line 62
    :cond_3
    :goto_2
    if-eqz p1, :cond_4

    .line 63
    .line 64
    move p3, v1

    .line 65
    :cond_4
    iput p3, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    .line 66
    .line 67
    invoke-virtual {p2}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    new-instance v1, La/xD;

    .line 72
    .line 73
    invoke-direct {v1, p0, p2, p3, v2}, La/xD;-><init>(Lcom/google/android/material/transformation/ExpandableBehavior;Landroid/view/View;ILa/MS;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 77
    .line 78
    .line 79
    :cond_5
    return v0
.end method

.method public final e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 3

    .line 1
    check-cast p3, La/MS;

    .line 2
    .line 3
    move-object p1, p3

    .line 4
    check-cast p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 5
    .line 6
    iget-object p1, p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->H:La/og;

    .line 7
    .line 8
    iget-boolean p1, p1, La/og;->w:Z

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    const/4 v1, 0x1

    .line 12
    iget v2, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    if-ne v2, v0, :cond_3

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    if-ne v2, v1, :cond_3

    .line 22
    .line 23
    :cond_1
    :goto_0
    if-eqz p1, :cond_2

    .line 24
    .line 25
    move v0, v1

    .line 26
    :cond_2
    iput v0, p0, Lcom/google/android/material/transformation/ExpandableBehavior;->w:I

    .line 27
    .line 28
    check-cast p3, Landroid/view/View;

    .line 29
    .line 30
    invoke-virtual {p0, p3, p2, p1, v1}, Lcom/google/android/material/transformation/ExpandableBehavior;->f(Landroid/view/View;Landroid/view/View;ZZ)V

    .line 31
    .line 32
    .line 33
    return v1

    .line 34
    :cond_3
    const/4 p1, 0x0

    .line 35
    return p1
.end method

.method public abstract f(Landroid/view/View;Landroid/view/View;ZZ)V
.end method

.method public abstract h(Landroid/view/View;Landroid/view/View;)Z
.end method
