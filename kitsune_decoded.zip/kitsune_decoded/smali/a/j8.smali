.class public final La/j8;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final w:La/j8;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/j8;

    invoke-direct {v0}, La/j8;-><init>()V

    sput-object v0, La/j8;->w:La/j8;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    return-void
.end method
