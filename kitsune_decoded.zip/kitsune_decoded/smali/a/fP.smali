.class public interface abstract La/fP;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/hu;
