.class public final La/uq;
.super La/hY;
.source "SourceFile"


# instance fields
.field public L:La/GN;

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic f:La/GN;

.field public l:I


# direct methods
.method public constructor <init>(La/GN;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/uq;->f:La/GN;

    invoke-direct {p0, p2}, La/hY;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La/uq;->d:Ljava/lang/Object;

    iget p1, p0, La/uq;->l:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La/uq;->l:I

    iget-object p1, p0, La/uq;->f:La/GN;

    invoke-virtual {p1, p0}, La/GN;->w(La/hu;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
