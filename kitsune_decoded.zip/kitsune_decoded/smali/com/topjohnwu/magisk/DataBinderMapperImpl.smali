.class public Lcom/topjohnwu/magisk/DataBinderMapperImpl;
.super La/AI;
.source "SourceFile"


# static fields
.field public static final w:Landroid/util/SparseIntArray;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Landroid/util/SparseIntArray;

    const/16 v1, 0x24

    invoke-direct {v0, v1}, Landroid/util/SparseIntArray;-><init>(I)V

    sput-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->w:Landroid/util/SparseIntArray;

    const v2, 0x7f0c001c

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c001d

    const/4 v3, 0x2

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c002e

    const/4 v3, 0x3

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c002f

    const/4 v3, 0x4

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0030

    const/4 v3, 0x5

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0031

    const/4 v3, 0x6

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0033

    const/4 v3, 0x7

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0034

    const/16 v3, 0x8

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0035

    const/16 v3, 0x9

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0036

    const/16 v3, 0xa

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0037

    const/16 v3, 0xb

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0038

    const/16 v3, 0xc

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0039

    const/16 v3, 0xd

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c003a

    const/16 v3, 0xe

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c003b

    const/16 v3, 0xf

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c003e

    const/16 v3, 0x10

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c003f

    const/16 v3, 0x11

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0040

    const/16 v3, 0x12

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0041

    const/16 v3, 0x13

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0042

    const/16 v3, 0x14

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0043

    const/16 v3, 0x15

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0044

    const/16 v3, 0x16

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0045

    const/16 v3, 0x17

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0046

    const/16 v3, 0x18

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0047

    const/16 v3, 0x19

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0048

    const/16 v3, 0x1a

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0049

    const/16 v3, 0x1b

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004a

    const/16 v3, 0x1c

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004b

    const/16 v3, 0x1d

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004c

    const/16 v3, 0x1e

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004d

    const/16 v3, 0x1f

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004e

    const/16 v3, 0x20

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c004f

    const/16 v3, 0x21

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0051

    const/16 v3, 0x22

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0052

    const/16 v3, 0x23

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    const v2, 0x7f0c0053

    invoke-virtual {v0, v2, v1}, Landroid/util/SparseIntArray;->put(II)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Landroid/view/View;I)Landroidx/databinding/w;
    .locals 1

    .line 1
    sget-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->w:Landroid/util/SparseIntArray;

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Landroid/util/SparseIntArray;->get(I)I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    if-lez p2, :cond_25

    .line 8
    .line 9
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_24

    .line 14
    .line 15
    packed-switch p2, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    goto/16 :goto_0

    .line 19
    .line 20
    :pswitch_0
    const-string p2, "layout/item_theme_0"

    .line 21
    .line 22
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result p2

    .line 26
    if-eqz p2, :cond_0

    .line 27
    .line 28
    new-instance p2, La/X4;

    .line 29
    .line 30
    invoke-direct {p2, p1}, La/X4;-><init>(Landroid/view/View;)V

    .line 31
    .line 32
    .line 33
    return-object p2

    .line 34
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 35
    .line 36
    const-string p2, "The tag for item_theme is invalid. Received: "

    .line 37
    .line 38
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :pswitch_1
    const-string p2, "layout/item_text_0"

    .line 47
    .line 48
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result p2

    .line 52
    if-eqz p2, :cond_1

    .line 53
    .line 54
    new-instance p2, La/YZ;

    .line 55
    .line 56
    invoke-direct {p2, p1}, La/YZ;-><init>(Landroid/view/View;)V

    .line 57
    .line 58
    .line 59
    return-object p2

    .line 60
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 61
    .line 62
    const-string p2, "The tag for item_text is invalid. Received: "

    .line 63
    .line 64
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw p1

    .line 72
    :pswitch_2
    const-string p2, "layout/item_tappable_headline_0"

    .line 73
    .line 74
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result p2

    .line 78
    if-eqz p2, :cond_2

    .line 79
    .line 80
    new-instance p2, La/db;

    .line 81
    .line 82
    invoke-direct {p2, p1}, La/db;-><init>(Landroid/view/View;)V

    .line 83
    .line 84
    .line 85
    return-object p2

    .line 86
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 87
    .line 88
    const-string p2, "The tag for item_tappable_headline is invalid. Received: "

    .line 89
    .line 90
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    throw p1

    .line 98
    :pswitch_3
    const-string p2, "layout/item_settings_section_0"

    .line 99
    .line 100
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result p2

    .line 104
    if-eqz p2, :cond_3

    .line 105
    .line 106
    new-instance p2, La/nu;

    .line 107
    .line 108
    invoke-direct {p2, p1}, La/nu;-><init>(Landroid/view/View;)V

    .line 109
    .line 110
    .line 111
    return-object p2

    .line 112
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 113
    .line 114
    const-string p2, "The tag for item_settings_section is invalid. Received: "

    .line 115
    .line 116
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p2

    .line 120
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :pswitch_4
    const-string p2, "layout/item_settings_0"

    .line 125
    .line 126
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result p2

    .line 130
    if-eqz p2, :cond_4

    .line 131
    .line 132
    new-instance p2, La/PY;

    .line 133
    .line 134
    invoke-direct {p2, p1}, La/PY;-><init>(Landroid/view/View;)V

    .line 135
    .line 136
    .line 137
    return-object p2

    .line 138
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 139
    .line 140
    const-string p2, "The tag for item_settings is invalid. Received: "

    .line 141
    .line 142
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object p2

    .line 146
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw p1

    .line 150
    :pswitch_5
    const-string p2, "layout/item_policy_md2_0"

    .line 151
    .line 152
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result p2

    .line 156
    if-eqz p2, :cond_5

    .line 157
    .line 158
    new-instance p2, La/km;

    .line 159
    .line 160
    invoke-direct {p2, p1}, La/km;-><init>(Landroid/view/View;)V

    .line 161
    .line 162
    .line 163
    return-object p2

    .line 164
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 165
    .line 166
    const-string p2, "The tag for item_policy_md2 is invalid. Received: "

    .line 167
    .line 168
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object p2

    .line 172
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    throw p1

    .line 176
    :pswitch_6
    const-string p2, "layout/item_module_md2_0"

    .line 177
    .line 178
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    move-result p2

    .line 182
    if-eqz p2, :cond_6

    .line 183
    .line 184
    new-instance p2, La/kp;

    .line 185
    .line 186
    invoke-direct {p2, p1}, La/kp;-><init>(Landroid/view/View;)V

    .line 187
    .line 188
    .line 189
    return-object p2

    .line 190
    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 191
    .line 192
    const-string p2, "The tag for item_module_md2 is invalid. Received: "

    .line 193
    .line 194
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p2

    .line 198
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    throw p1

    .line 202
    :pswitch_7
    const-string p2, "layout/item_module_download_0"

    .line 203
    .line 204
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    move-result p2

    .line 208
    if-eqz p2, :cond_7

    .line 209
    .line 210
    new-instance p2, La/fJ;

    .line 211
    .line 212
    invoke-direct {p2, p1}, La/fJ;-><init>(Landroid/view/View;)V

    .line 213
    .line 214
    .line 215
    return-object p2

    .line 216
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 217
    .line 218
    const-string p2, "The tag for item_module_download is invalid. Received: "

    .line 219
    .line 220
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object p2

    .line 224
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    throw p1

    .line 228
    :pswitch_8
    const-string p2, "layout/item_log_track_md2_0"

    .line 229
    .line 230
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 231
    .line 232
    .line 233
    move-result p2

    .line 234
    if-eqz p2, :cond_8

    .line 235
    .line 236
    new-instance p2, La/wq;

    .line 237
    .line 238
    invoke-direct {p2, p1}, La/wq;-><init>(Landroid/view/View;)V

    .line 239
    .line 240
    .line 241
    return-object p2

    .line 242
    :cond_8
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 243
    .line 244
    const-string p2, "The tag for item_log_track_md2 is invalid. Received: "

    .line 245
    .line 246
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object p2

    .line 250
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    throw p1

    .line 254
    :pswitch_9
    const-string p2, "layout/item_log_textview_0"

    .line 255
    .line 256
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result p2

    .line 260
    if-eqz p2, :cond_9

    .line 261
    .line 262
    new-instance p2, La/wQ;

    .line 263
    .line 264
    invoke-direct {p2, p1}, La/wQ;-><init>(Landroid/view/View;)V

    .line 265
    .line 266
    .line 267
    return-object p2

    .line 268
    :cond_9
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 269
    .line 270
    const-string p2, "The tag for item_log_textview is invalid. Received: "

    .line 271
    .line 272
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object p2

    .line 276
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 277
    .line 278
    .line 279
    throw p1

    .line 280
    :pswitch_a
    const-string p2, "layout/item_log_access_md2_0"

    .line 281
    .line 282
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-result p2

    .line 286
    if-eqz p2, :cond_a

    .line 287
    .line 288
    new-instance p2, La/JY;

    .line 289
    .line 290
    invoke-direct {p2, p1}, La/JY;-><init>(Landroid/view/View;)V

    .line 291
    .line 292
    .line 293
    return-object p2

    .line 294
    :cond_a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 295
    .line 296
    const-string p2, "The tag for item_log_access_md2 is invalid. Received: "

    .line 297
    .line 298
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 299
    .line 300
    .line 301
    move-result-object p2

    .line 302
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 303
    .line 304
    .line 305
    throw p1

    .line 306
    :pswitch_b
    const-string p2, "layout/item_list_single_line_0"

    .line 307
    .line 308
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result p2

    .line 312
    if-eqz p2, :cond_b

    .line 313
    .line 314
    new-instance p2, La/pB;

    .line 315
    .line 316
    invoke-direct {p2, p1}, La/pB;-><init>(Landroid/view/View;)V

    .line 317
    .line 318
    .line 319
    return-object p2

    .line 320
    :cond_b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 321
    .line 322
    const-string p2, "The tag for item_list_single_line is invalid. Received: "

    .line 323
    .line 324
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object p2

    .line 328
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 329
    .line 330
    .line 331
    throw p1

    .line 332
    :pswitch_c
    const-string p2, "layout/item_icon_link_0"

    .line 333
    .line 334
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 335
    .line 336
    .line 337
    move-result p2

    .line 338
    if-eqz p2, :cond_c

    .line 339
    .line 340
    new-instance p2, La/fr;

    .line 341
    .line 342
    invoke-direct {p2, p1}, La/fr;-><init>(Landroid/view/View;)V

    .line 343
    .line 344
    .line 345
    return-object p2

    .line 346
    :cond_c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 347
    .line 348
    const-string p2, "The tag for item_icon_link is invalid. Received: "

    .line 349
    .line 350
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 351
    .line 352
    .line 353
    move-result-object p2

    .line 354
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    throw p1

    .line 358
    :pswitch_d
    const-string p2, "layout/item_hide_process_md2_0"

    .line 359
    .line 360
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 361
    .line 362
    .line 363
    move-result p2

    .line 364
    if-eqz p2, :cond_d

    .line 365
    .line 366
    new-instance p2, La/X2;

    .line 367
    .line 368
    invoke-direct {p2, p1}, La/X2;-><init>(Landroid/view/View;)V

    .line 369
    .line 370
    .line 371
    return-object p2

    .line 372
    :cond_d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 373
    .line 374
    const-string p2, "The tag for item_hide_process_md2 is invalid. Received: "

    .line 375
    .line 376
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object p2

    .line 380
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 381
    .line 382
    .line 383
    throw p1

    .line 384
    :pswitch_e
    const-string p2, "layout/item_hide_md2_0"

    .line 385
    .line 386
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 387
    .line 388
    .line 389
    move-result p2

    .line 390
    if-eqz p2, :cond_e

    .line 391
    .line 392
    new-instance p2, La/XX;

    .line 393
    .line 394
    invoke-direct {p2, p1}, La/XX;-><init>(Landroid/view/View;)V

    .line 395
    .line 396
    .line 397
    return-object p2

    .line 398
    :cond_e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 399
    .line 400
    const-string p2, "The tag for item_hide_md2 is invalid. Received: "

    .line 401
    .line 402
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object p2

    .line 406
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 407
    .line 408
    .line 409
    throw p1

    .line 410
    :pswitch_f
    const-string p2, "layout/item_developer_0"

    .line 411
    .line 412
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 413
    .line 414
    .line 415
    move-result p2

    .line 416
    if-eqz p2, :cond_f

    .line 417
    .line 418
    new-instance p2, La/E1;

    .line 419
    .line 420
    invoke-direct {p2, p1}, La/E1;-><init>(Landroid/view/View;)V

    .line 421
    .line 422
    .line 423
    return-object p2

    .line 424
    :cond_f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 425
    .line 426
    const-string p2, "The tag for item_developer is invalid. Received: "

    .line 427
    .line 428
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object p2

    .line 432
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    throw p1

    .line 436
    :pswitch_10
    const-string p2, "layout/item_console_md2_0"

    .line 437
    .line 438
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 439
    .line 440
    .line 441
    move-result p2

    .line 442
    if-eqz p2, :cond_10

    .line 443
    .line 444
    new-instance p2, La/MW;

    .line 445
    .line 446
    invoke-direct {p2, p1}, La/MW;-><init>(Landroid/view/View;)V

    .line 447
    .line 448
    .line 449
    return-object p2

    .line 450
    :cond_10
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 451
    .line 452
    const-string p2, "The tag for item_console_md2 is invalid. Received: "

    .line 453
    .line 454
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 455
    .line 456
    .line 457
    move-result-object p2

    .line 458
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 459
    .line 460
    .line 461
    throw p1

    .line 462
    :pswitch_11
    const-string p2, "layout/include_log_superuser_0"

    .line 463
    .line 464
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 465
    .line 466
    .line 467
    move-result p2

    .line 468
    if-eqz p2, :cond_11

    .line 469
    .line 470
    new-instance p2, La/ti;

    .line 471
    .line 472
    invoke-direct {p2, p1}, La/ti;-><init>(Landroid/view/View;)V

    .line 473
    .line 474
    .line 475
    return-object p2

    .line 476
    :cond_11
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 477
    .line 478
    const-string p2, "The tag for include_log_superuser is invalid. Received: "

    .line 479
    .line 480
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 481
    .line 482
    .line 483
    move-result-object p2

    .line 484
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 485
    .line 486
    .line 487
    throw p1

    .line 488
    :pswitch_12
    const-string p2, "layout/include_log_magisk_0"

    .line 489
    .line 490
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 491
    .line 492
    .line 493
    move-result p2

    .line 494
    if-eqz p2, :cond_12

    .line 495
    .line 496
    new-instance p2, La/fx;

    .line 497
    .line 498
    invoke-direct {p2, p1}, La/fx;-><init>(Landroid/view/View;)V

    .line 499
    .line 500
    .line 501
    return-object p2

    .line 502
    :cond_12
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 503
    .line 504
    const-string p2, "The tag for include_log_magisk is invalid. Received: "

    .line 505
    .line 506
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 507
    .line 508
    .line 509
    move-result-object p2

    .line 510
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    throw p1

    .line 514
    :pswitch_13
    const-string p2, "layout/include_home_manager_0"

    .line 515
    .line 516
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 517
    .line 518
    .line 519
    move-result p2

    .line 520
    if-eqz p2, :cond_13

    .line 521
    .line 522
    new-instance p2, La/ql;

    .line 523
    .line 524
    invoke-direct {p2, p1}, La/ql;-><init>(Landroid/view/View;)V

    .line 525
    .line 526
    .line 527
    return-object p2

    .line 528
    :cond_13
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 529
    .line 530
    const-string p2, "The tag for include_home_manager is invalid. Received: "

    .line 531
    .line 532
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 533
    .line 534
    .line 535
    move-result-object p2

    .line 536
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    throw p1

    .line 540
    :pswitch_14
    const-string p2, "layout/include_home_magisk_0"

    .line 541
    .line 542
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 543
    .line 544
    .line 545
    move-result p2

    .line 546
    if-eqz p2, :cond_14

    .line 547
    .line 548
    new-instance p2, La/Hw;

    .line 549
    .line 550
    invoke-direct {p2, p1}, La/Hw;-><init>(Landroid/view/View;)V

    .line 551
    .line 552
    .line 553
    return-object p2

    .line 554
    :cond_14
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 555
    .line 556
    const-string p2, "The tag for include_home_magisk is invalid. Received: "

    .line 557
    .line 558
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object p2

    .line 562
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 563
    .line 564
    .line 565
    throw p1

    .line 566
    :pswitch_15
    const-string p2, "layout/fragment_theme_md2_0"

    .line 567
    .line 568
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 569
    .line 570
    .line 571
    move-result p2

    .line 572
    if-eqz p2, :cond_15

    .line 573
    .line 574
    new-instance p2, La/P8;

    .line 575
    .line 576
    invoke-direct {p2, p1}, La/P8;-><init>(Landroid/view/View;)V

    .line 577
    .line 578
    .line 579
    return-object p2

    .line 580
    :cond_15
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 581
    .line 582
    const-string p2, "The tag for fragment_theme_md2 is invalid. Received: "

    .line 583
    .line 584
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object p2

    .line 588
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 589
    .line 590
    .line 591
    throw p1

    .line 592
    :pswitch_16
    const-string p2, "layout/fragment_superuser_md2_0"

    .line 593
    .line 594
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result p2

    .line 598
    if-eqz p2, :cond_16

    .line 599
    .line 600
    new-instance p2, La/uS;

    .line 601
    .line 602
    invoke-direct {p2, p1}, La/uS;-><init>(Landroid/view/View;)V

    .line 603
    .line 604
    .line 605
    return-object p2

    .line 606
    :cond_16
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 607
    .line 608
    const-string p2, "The tag for fragment_superuser_md2 is invalid. Received: "

    .line 609
    .line 610
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 611
    .line 612
    .line 613
    move-result-object p2

    .line 614
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 615
    .line 616
    .line 617
    throw p1

    .line 618
    :pswitch_17
    const-string p2, "layout/fragment_settings_md2_0"

    .line 619
    .line 620
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 621
    .line 622
    .line 623
    move-result p2

    .line 624
    if-eqz p2, :cond_17

    .line 625
    .line 626
    new-instance p2, La/Lb;

    .line 627
    .line 628
    invoke-direct {p2, p1}, La/Lb;-><init>(Landroid/view/View;)V

    .line 629
    .line 630
    .line 631
    return-object p2

    .line 632
    :cond_17
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 633
    .line 634
    const-string p2, "The tag for fragment_settings_md2 is invalid. Received: "

    .line 635
    .line 636
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 637
    .line 638
    .line 639
    move-result-object p2

    .line 640
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 641
    .line 642
    .line 643
    throw p1

    .line 644
    :pswitch_18
    const-string p2, "layout/fragment_module_md2_0"

    .line 645
    .line 646
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 647
    .line 648
    .line 649
    move-result p2

    .line 650
    if-eqz p2, :cond_18

    .line 651
    .line 652
    new-instance p2, La/cA;

    .line 653
    .line 654
    invoke-direct {p2, p1}, La/cA;-><init>(Landroid/view/View;)V

    .line 655
    .line 656
    .line 657
    return-object p2

    .line 658
    :cond_18
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 659
    .line 660
    const-string p2, "The tag for fragment_module_md2 is invalid. Received: "

    .line 661
    .line 662
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 663
    .line 664
    .line 665
    move-result-object p2

    .line 666
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 667
    .line 668
    .line 669
    throw p1

    .line 670
    :pswitch_19
    const-string p2, "layout/fragment_log_md2_0"

    .line 671
    .line 672
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 673
    .line 674
    .line 675
    move-result p2

    .line 676
    if-eqz p2, :cond_19

    .line 677
    .line 678
    new-instance p2, La/HU;

    .line 679
    .line 680
    invoke-direct {p2, p1}, La/HU;-><init>(Landroid/view/View;)V

    .line 681
    .line 682
    .line 683
    return-object p2

    .line 684
    :cond_19
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 685
    .line 686
    const-string p2, "The tag for fragment_log_md2 is invalid. Received: "

    .line 687
    .line 688
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 689
    .line 690
    .line 691
    move-result-object p2

    .line 692
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 693
    .line 694
    .line 695
    throw p1

    .line 696
    :pswitch_1a
    const-string p2, "layout/fragment_install_md2_0"

    .line 697
    .line 698
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 699
    .line 700
    .line 701
    move-result p2

    .line 702
    if-eqz p2, :cond_1a

    .line 703
    .line 704
    new-instance p2, La/lv;

    .line 705
    .line 706
    invoke-direct {p2, p1}, La/lv;-><init>(Landroid/view/View;)V

    .line 707
    .line 708
    .line 709
    return-object p2

    .line 710
    :cond_1a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 711
    .line 712
    const-string p2, "The tag for fragment_install_md2 is invalid. Received: "

    .line 713
    .line 714
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 715
    .line 716
    .line 717
    move-result-object p2

    .line 718
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 719
    .line 720
    .line 721
    throw p1

    .line 722
    :pswitch_1b
    const-string p2, "layout/fragment_home_md2_0"

    .line 723
    .line 724
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 725
    .line 726
    .line 727
    move-result p2

    .line 728
    if-eqz p2, :cond_1b

    .line 729
    .line 730
    new-instance p2, La/st;

    .line 731
    .line 732
    invoke-direct {p2, p1}, La/st;-><init>(Landroid/view/View;)V

    .line 733
    .line 734
    .line 735
    return-object p2

    .line 736
    :cond_1b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 737
    .line 738
    const-string p2, "The tag for fragment_home_md2 is invalid. Received: "

    .line 739
    .line 740
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 741
    .line 742
    .line 743
    move-result-object p2

    .line 744
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 745
    .line 746
    .line 747
    throw p1

    .line 748
    :pswitch_1c
    const-string p2, "layout/fragment_flash_md2_0"

    .line 749
    .line 750
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 751
    .line 752
    .line 753
    move-result p2

    .line 754
    if-eqz p2, :cond_1c

    .line 755
    .line 756
    new-instance p2, La/pt;

    .line 757
    .line 758
    invoke-direct {p2, p1}, La/pt;-><init>(Landroid/view/View;)V

    .line 759
    .line 760
    .line 761
    return-object p2

    .line 762
    :cond_1c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 763
    .line 764
    const-string p2, "The tag for fragment_flash_md2 is invalid. Received: "

    .line 765
    .line 766
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 767
    .line 768
    .line 769
    move-result-object p2

    .line 770
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 771
    .line 772
    .line 773
    throw p1

    .line 774
    :pswitch_1d
    const-string p2, "layout/fragment_deny_md2_0"

    .line 775
    .line 776
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 777
    .line 778
    .line 779
    move-result p2

    .line 780
    if-eqz p2, :cond_1d

    .line 781
    .line 782
    new-instance p2, La/RT;

    .line 783
    .line 784
    invoke-direct {p2, p1}, La/RT;-><init>(Landroid/view/View;)V

    .line 785
    .line 786
    .line 787
    return-object p2

    .line 788
    :cond_1d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 789
    .line 790
    const-string p2, "The tag for fragment_deny_md2 is invalid. Received: "

    .line 791
    .line 792
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 793
    .line 794
    .line 795
    move-result-object p2

    .line 796
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 797
    .line 798
    .line 799
    throw p1

    .line 800
    :pswitch_1e
    const-string p2, "layout/dialog_settings_update_channel_0"

    .line 801
    .line 802
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 803
    .line 804
    .line 805
    move-result p2

    .line 806
    if-eqz p2, :cond_1e

    .line 807
    .line 808
    new-instance p2, La/oY;

    .line 809
    .line 810
    invoke-direct {p2, p1}, La/oY;-><init>(Landroid/view/View;)V

    .line 811
    .line 812
    .line 813
    return-object p2

    .line 814
    :cond_1e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 815
    .line 816
    const-string p2, "The tag for dialog_settings_update_channel is invalid. Received: "

    .line 817
    .line 818
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 819
    .line 820
    .line 821
    move-result-object p2

    .line 822
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 823
    .line 824
    .line 825
    throw p1

    .line 826
    :pswitch_1f
    const-string p2, "layout/dialog_settings_download_path_0"

    .line 827
    .line 828
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 829
    .line 830
    .line 831
    move-result p2

    .line 832
    if-eqz p2, :cond_1f

    .line 833
    .line 834
    new-instance p2, La/pz;

    .line 835
    .line 836
    invoke-direct {p2, p1}, La/pz;-><init>(Landroid/view/View;)V

    .line 837
    .line 838
    .line 839
    return-object p2

    .line 840
    :cond_1f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 841
    .line 842
    const-string p2, "The tag for dialog_settings_download_path is invalid. Received: "

    .line 843
    .line 844
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 845
    .line 846
    .line 847
    move-result-object p2

    .line 848
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 849
    .line 850
    .line 851
    throw p1

    .line 852
    :pswitch_20
    const-string p2, "layout/dialog_settings_app_name_0"

    .line 853
    .line 854
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 855
    .line 856
    .line 857
    move-result p2

    .line 858
    if-eqz p2, :cond_20

    .line 859
    .line 860
    new-instance p2, La/D5;

    .line 861
    .line 862
    invoke-direct {p2, p1}, La/D5;-><init>(Landroid/view/View;)V

    .line 863
    .line 864
    .line 865
    return-object p2

    .line 866
    :cond_20
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 867
    .line 868
    const-string p2, "The tag for dialog_settings_app_name is invalid. Received: "

    .line 869
    .line 870
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 871
    .line 872
    .line 873
    move-result-object p2

    .line 874
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 875
    .line 876
    .line 877
    throw p1

    .line 878
    :pswitch_21
    const-string p2, "layout/dialog_magisk_base_0"

    .line 879
    .line 880
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 881
    .line 882
    .line 883
    move-result p2

    .line 884
    if-eqz p2, :cond_21

    .line 885
    .line 886
    new-instance p2, La/QI;

    .line 887
    .line 888
    invoke-direct {p2, p1}, La/QI;-><init>(Landroid/view/View;)V

    .line 889
    .line 890
    .line 891
    return-object p2

    .line 892
    :cond_21
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 893
    .line 894
    const-string p2, "The tag for dialog_magisk_base is invalid. Received: "

    .line 895
    .line 896
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 897
    .line 898
    .line 899
    move-result-object p2

    .line 900
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 901
    .line 902
    .line 903
    throw p1

    .line 904
    :pswitch_22
    const-string p2, "layout/activity_request_0"

    .line 905
    .line 906
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 907
    .line 908
    .line 909
    move-result p2

    .line 910
    if-eqz p2, :cond_22

    .line 911
    .line 912
    new-instance p2, La/lB;

    .line 913
    .line 914
    invoke-direct {p2, p1}, La/lB;-><init>(Landroid/view/View;)V

    .line 915
    .line 916
    .line 917
    return-object p2

    .line 918
    :cond_22
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 919
    .line 920
    const-string p2, "The tag for activity_request is invalid. Received: "

    .line 921
    .line 922
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 923
    .line 924
    .line 925
    move-result-object p2

    .line 926
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 927
    .line 928
    .line 929
    throw p1

    .line 930
    :pswitch_23
    const-string p2, "layout/activity_main_md2_0"

    .line 931
    .line 932
    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 933
    .line 934
    .line 935
    move-result p2

    .line 936
    if-eqz p2, :cond_23

    .line 937
    .line 938
    new-instance p2, La/dy;

    .line 939
    .line 940
    invoke-direct {p2, p1}, La/dy;-><init>(Landroid/view/View;)V

    .line 941
    .line 942
    .line 943
    return-object p2

    .line 944
    :cond_23
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 945
    .line 946
    const-string p2, "The tag for activity_main_md2 is invalid. Received: "

    .line 947
    .line 948
    invoke-static {p2, v0}, La/zq;->O(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    .line 949
    .line 950
    .line 951
    move-result-object p2

    .line 952
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 953
    .line 954
    .line 955
    throw p1

    .line 956
    :cond_24
    new-instance p1, Ljava/lang/RuntimeException;

    .line 957
    .line 958
    const-string p2, "view must have a tag"

    .line 959
    .line 960
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 961
    .line 962
    .line 963
    throw p1

    .line 964
    :cond_25
    :goto_0
    const/4 p1, 0x0

    .line 965
    return-object p1

    .line 966
    nop

    .line 967
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final p([Landroid/view/View;I)Landroidx/databinding/w;
    .locals 2

    .line 1
    array-length v0, p1

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    sget-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->w:Landroid/util/SparseIntArray;

    invoke-virtual {v0, p2}, Landroid/util/SparseIntArray;->get(I)I

    move-result p2

    if-lez p2, :cond_2

    const/4 p2, 0x0

    aget-object p1, p1, p2

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/RuntimeException;

    const-string p2, "view must have a tag"

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    return-object v1
.end method

.method public final w()Ljava/util/List;
    .locals 2

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v1, Landroidx/databinding/library/baseAdapters/DataBinderMapperImpl;

    invoke-direct {v1}, Landroidx/databinding/library/baseAdapters/DataBinderMapperImpl;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method
