.class public final La/jY;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/nY;


# static fields
.field public static final L:La/jY;

.field public static final R:La/jY;


# instance fields
.field public final synthetic K:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/jY;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La/jY;-><init>(I)V

    sput-object v0, La/jY;->R:La/jY;

    new-instance v0, La/jY;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La/jY;-><init>(I)V

    sput-object v0, La/jY;->L:La/jY;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, La/jY;->K:I

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    invoke-direct {p0, p1}, La/ig;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final V(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, La/jY;->K:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-nez p1, :cond_0

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    :goto_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    :pswitch_0
    return-object p1

    .line 16
    nop

    .line 17
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
