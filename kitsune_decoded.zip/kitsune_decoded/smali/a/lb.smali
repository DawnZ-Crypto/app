.class public final La/lb;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/OnReceiveContentListener;


# instance fields
.field public final w:La/Og;


# direct methods
.method public constructor <init>(La/Og;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/lb;->w:La/Og;

    return-void
.end method


# virtual methods
.method public final onReceiveContent(Landroid/view/View;Landroid/view/ContentInfo;)Landroid/view/ContentInfo;
    .locals 2

    .line 1
    new-instance v0, La/J5;

    .line 2
    .line 3
    new-instance v1, La/ze;

    .line 4
    .line 5
    invoke-direct {v1, p2}, La/ze;-><init>(Landroid/view/ContentInfo;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1}, La/J5;-><init>(La/Wq;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, La/lb;->w:La/Og;

    .line 12
    .line 13
    check-cast v1, La/Kx;

    .line 14
    .line 15
    invoke-virtual {v1, p1, v0}, La/Kx;->w(Landroid/view/View;La/J5;)La/J5;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    if-nez p1, :cond_0

    .line 20
    .line 21
    const/4 p1, 0x0

    .line 22
    return-object p1

    .line 23
    :cond_0
    if-ne p1, v0, :cond_1

    .line 24
    .line 25
    return-object p2

    .line 26
    :cond_1
    iget-object p1, p1, La/J5;->w:La/Wq;

    .line 27
    .line 28
    invoke-interface {p1}, La/Wq;->X()Landroid/view/ContentInfo;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {p1}, La/e;->X(Ljava/lang/Object;)Landroid/view/ContentInfo;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    return-object p1
.end method
