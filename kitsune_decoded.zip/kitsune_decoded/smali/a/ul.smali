.class public final La/ul;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/nY;


# instance fields
.field public final synthetic K:I

.field public final synthetic L:La/Cu;

.field public final synthetic R:La/hb;


# direct methods
.method public synthetic constructor <init>(La/Cu;La/Cu;I)V
    .locals 0

    .line 1
    iput p3, p0, La/ul;->K:I

    .line 2
    .line 3
    iput-object p1, p0, La/ul;->R:La/hb;

    .line 4
    .line 5
    iput-object p2, p0, La/ul;->L:La/Cu;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, La/ig;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final bridge synthetic V(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    sget-object v0, La/rr;->w:La/rr;

    .line 2
    .line 3
    iget v1, p0, La/ul;->K:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/lang/Boolean;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    invoke-virtual {p0, p1}, La/ul;->h(Z)V

    .line 15
    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    invoke-virtual {p0, p1}, La/ul;->h(Z)V

    .line 25
    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    invoke-virtual {p0, p1}, La/ul;->h(Z)V

    .line 35
    .line 36
    .line 37
    return-object v0

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h(Z)V
    .locals 4

    .line 1
    const v0, 0x7f12004a

    .line 2
    .line 3
    .line 4
    iget v1, p0, La/ul;->K:I

    .line 5
    .line 6
    iget-object v2, p0, La/ul;->L:La/Cu;

    .line 7
    .line 8
    iget-object v3, p0, La/ul;->R:La/hb;

    .line 9
    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    if-nez p1, :cond_0

    .line 14
    .line 15
    new-instance p1, La/Tv;

    .line 16
    .line 17
    const v0, 0x7f120075

    .line 18
    .line 19
    .line 20
    invoke-direct {p1, v0}, La/Tv;-><init>(I)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v3, p1}, La/hb;->m(La/I2;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    new-instance p1, La/Rb;

    .line 28
    .line 29
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2, p1}, La/hb;->y(La/uD;)V

    .line 33
    .line 34
    .line 35
    :goto_0
    return-void

    .line 36
    :pswitch_0
    if-nez p1, :cond_1

    .line 37
    .line 38
    new-instance p1, La/Tv;

    .line 39
    .line 40
    invoke-direct {p1, v0}, La/Tv;-><init>(I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v3, p1}, La/hb;->m(La/I2;)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    new-instance p1, La/ul;

    .line 48
    .line 49
    const/4 v0, 0x2

    .line 50
    invoke-direct {p1, v2, v2, v0}, La/ul;-><init>(La/Cu;La/Cu;I)V

    .line 51
    .line 52
    .line 53
    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    .line 54
    .line 55
    invoke-virtual {v2, v0, p1}, La/hb;->K(Ljava/lang/String;La/nY;)V

    .line 56
    .line 57
    .line 58
    :goto_1
    return-void

    .line 59
    :pswitch_1
    if-nez p1, :cond_2

    .line 60
    .line 61
    new-instance p1, La/Tv;

    .line 62
    .line 63
    invoke-direct {p1, v0}, La/Tv;-><init>(I)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v3, p1}, La/hb;->m(La/I2;)V

    .line 67
    .line 68
    .line 69
    goto :goto_2

    .line 70
    :cond_2
    new-instance p1, La/jR;

    .line 71
    .line 72
    const v0, 0x7f090040

    .line 73
    .line 74
    .line 75
    invoke-direct {p1, v0}, La/jR;-><init>(I)V

    .line 76
    .line 77
    .line 78
    const/4 v0, 0x0

    .line 79
    invoke-virtual {v2, p1, v0}, La/hb;->V(La/EI;Z)V

    .line 80
    .line 81
    .line 82
    :goto_2
    return-void

    .line 83
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
