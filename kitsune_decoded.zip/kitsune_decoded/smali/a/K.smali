.class public final La/K;
.super La/Y;
.source "SourceFile"


# static fields
.field public static final K:[La/K;


# instance fields
.field public final X:[B


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/q5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput v1, v0, La/q5;->w:I

    .line 8
    .line 9
    const/16 v1, 0xa

    .line 10
    .line 11
    iput v1, v0, La/q5;->h:I

    .line 12
    .line 13
    const/16 v0, 0xc

    .line 14
    .line 15
    new-array v0, v0, [La/K;

    .line 16
    .line 17
    sput-object v0, La/K;->K:[La/K;

    .line 18
    .line 19
    return-void
.end method

.method public constructor <init>([BZ)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, La/W;->E([B)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_3

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    aget-byte v1, p1, v0

    .line 12
    .line 13
    and-int/lit16 v1, v1, 0x80

    .line 14
    .line 15
    if-nez v1, :cond_2

    .line 16
    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, La/rx;->m([B)[B

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move-object p2, p1

    .line 25
    :goto_0
    iput-object p2, p0, La/K;->X:[B

    .line 26
    .line 27
    array-length p2, p1

    .line 28
    add-int/lit8 p2, p2, -0x1

    .line 29
    .line 30
    :goto_1
    if-ge v0, p2, :cond_1

    .line 31
    .line 32
    aget-byte v1, p1, v0

    .line 33
    .line 34
    add-int/lit8 v0, v0, 0x1

    .line 35
    .line 36
    aget-byte v2, p1, v0

    .line 37
    .line 38
    shr-int/lit8 v2, v2, 0x7

    .line 39
    .line 40
    if-ne v1, v2, :cond_1

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    return-void

    .line 44
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 45
    .line 46
    const-string p2, "enumerated must be non-negative"

    .line 47
    .line 48
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p1

    .line 52
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 53
    .line 54
    const-string p2, "malformed enumerated"

    .line 55
    .line 56
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw p1
.end method


# virtual methods
.method public final K(Z)I
    .locals 1

    .line 1
    iget-object v0, p0, La/K;->X:[B

    array-length v0, v0

    invoke-static {v0, p1}, La/sR;->X(IZ)I

    move-result p1

    return p1
.end method

.method public final T(La/Y;)Z
    .locals 1

    .line 1
    instance-of v0, p1, La/K;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return p1

    .line 7
    :cond_0
    check-cast p1, La/K;

    .line 8
    .line 9
    iget-object p1, p1, La/K;->X:[B

    .line 10
    .line 11
    iget-object v0, p0, La/K;->X:[B

    .line 12
    .line 13
    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, La/K;->X:[B

    invoke-static {v0}, La/rx;->Z([B)I

    move-result v0

    return v0
.end method

.method public final m(La/sR;Z)V
    .locals 2

    .line 1
    const/16 v0, 0xa

    iget-object v1, p0, La/K;->X:[B

    invoke-virtual {p1, v0, p2, v1}, La/sR;->y(IZ[B)V

    return-void
.end method

.method public final y()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method
