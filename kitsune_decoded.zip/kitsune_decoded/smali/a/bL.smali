.class public final La/bL;
.super La/SN;
.source "SourceFile"


# static fields
.field public static final E:La/xi;

.field public static final H:La/xi;

.field public static final P:La/xi;

.field public static final S:La/xi;

.field public static final z:La/xi;


# instance fields
.field public F:Ljava/lang/String;

.field public W:J

.field public final d:La/wI;

.field public final f:La/WI;

.field public l:I

.field public q:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, La/xi;->L:La/xi;

    .line 2
    .line 3
    const-string v0, "\'\\"

    .line 4
    .line 5
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, La/bL;->E:La/xi;

    .line 10
    .line 11
    const-string v0, "\"\\"

    .line 12
    .line 13
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, La/bL;->S:La/xi;

    .line 18
    .line 19
    const-string v0, "{}[]:, \n\t\r\u000c/\\;#="

    .line 20
    .line 21
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, La/bL;->H:La/xi;

    .line 26
    .line 27
    const-string v0, "\n\r"

    .line 28
    .line 29
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    sput-object v0, La/bL;->z:La/xi;

    .line 34
    .line 35
    const-string v0, "*/"

    .line 36
    .line 37
    invoke-static {v0}, La/oK;->M(Ljava/lang/String;)La/xi;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, La/bL;->P:La/xi;

    .line 42
    .line 43
    return-void
.end method

.method public constructor <init>(La/wI;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x20

    .line 5
    .line 6
    new-array v1, v0, [I

    .line 7
    .line 8
    iput-object v1, p0, La/SN;->K:[I

    .line 9
    .line 10
    new-array v1, v0, [Ljava/lang/String;

    .line 11
    .line 12
    iput-object v1, p0, La/SN;->R:[Ljava/lang/String;

    .line 13
    .line 14
    new-array v0, v0, [I

    .line 15
    .line 16
    iput-object v0, p0, La/SN;->L:[I

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    iput v0, p0, La/bL;->l:I

    .line 20
    .line 21
    iput-object p1, p0, La/bL;->d:La/wI;

    .line 22
    .line 23
    invoke-interface {p1}, La/wI;->p()La/WI;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    iput-object p1, p0, La/bL;->f:La/WI;

    .line 28
    .line 29
    const/4 p1, 0x6

    .line 30
    invoke-virtual {p0, p1}, La/SN;->y6(I)V

    .line 31
    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final B1()I
    .locals 1

    .line 1
    iget v0, p0, La/bL;->l:I

    if-nez v0, :cond_0

    invoke-virtual {p0}, La/bL;->Gy()I

    move-result v0

    :cond_0
    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    throw v0

    :pswitch_0
    const/16 v0, 0xa

    return v0

    :pswitch_1
    const/4 v0, 0x7

    return v0

    :pswitch_2
    const/4 v0, 0x5

    return v0

    :pswitch_3
    const/4 v0, 0x6

    return v0

    :pswitch_4
    const/16 v0, 0x9

    return v0

    :pswitch_5
    const/16 v0, 0x8

    return v0

    :pswitch_6
    const/4 v0, 0x2

    return v0

    :pswitch_7
    const/4 v0, 0x1

    return v0

    :pswitch_8
    const/4 v0, 0x4

    return v0

    :pswitch_9
    const/4 v0, 0x3

    return v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final C6()Ljava/lang/String;
    .locals 4

    .line 1
    sget-object v0, La/bL;->H:La/xi;

    .line 2
    .line 3
    iget-object v1, p0, La/bL;->d:La/wI;

    .line 4
    .line 5
    invoke-interface {v1, v0}, La/wI;->n(La/xi;)J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    const-wide/16 v2, -0x1

    .line 10
    .line 11
    cmp-long v2, v0, v2

    .line 12
    .line 13
    iget-object v3, p0, La/bL;->f:La/WI;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    sget-object v2, La/kg;->w:Ljava/nio/charset/Charset;

    .line 21
    .line 22
    invoke-virtual {v3, v0, v1, v2}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-virtual {v3}, La/WI;->VQ()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    :goto_0
    return-object v0
.end method

.method public final Gy()I
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La/SN;->K:[I

    .line 4
    .line 5
    iget v2, v0, La/SN;->X:I

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    sub-int/2addr v2, v3

    .line 9
    aget v4, v1, v2

    .line 10
    .line 11
    const/16 v9, 0x5d

    .line 12
    .line 13
    iget-object v12, v0, La/bL;->d:La/wI;

    .line 14
    .line 15
    const/4 v13, 0x3

    .line 16
    const/16 v14, 0x3b

    .line 17
    .line 18
    const/16 v15, 0x2c

    .line 19
    .line 20
    const-wide/16 v5, 0x0

    .line 21
    .line 22
    const/4 v8, 0x4

    .line 23
    const/4 v10, 0x5

    .line 24
    const/4 v7, 0x2

    .line 25
    const/16 v18, 0x0

    .line 26
    .line 27
    iget-object v11, v0, La/bL;->f:La/WI;

    .line 28
    .line 29
    if-ne v4, v3, :cond_1

    .line 30
    .line 31
    aput v7, v1, v2

    .line 32
    .line 33
    :cond_0
    :goto_0
    const/4 v1, 0x0

    .line 34
    goto/16 :goto_1

    .line 35
    .line 36
    :cond_1
    if-ne v4, v7, :cond_4

    .line 37
    .line 38
    invoke-virtual {v0, v3}, La/bL;->Tr(Z)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-virtual {v11}, La/WI;->eH()B

    .line 43
    .line 44
    .line 45
    if-eq v1, v15, :cond_0

    .line 46
    .line 47
    if-eq v1, v14, :cond_3

    .line 48
    .line 49
    if-ne v1, v9, :cond_2

    .line 50
    .line 51
    iput v8, v0, La/bL;->l:I

    .line 52
    .line 53
    return v8

    .line 54
    :cond_2
    const-string v1, "Unterminated array"

    .line 55
    .line 56
    invoke-virtual {v0, v1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw v18

    .line 60
    :cond_3
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_4
    if-eq v4, v13, :cond_5

    .line 65
    .line 66
    if-ne v4, v10, :cond_6

    .line 67
    .line 68
    :cond_5
    move v3, v8

    .line 69
    goto/16 :goto_1a

    .line 70
    .line 71
    :cond_6
    if-ne v4, v8, :cond_8

    .line 72
    .line 73
    aput v10, v1, v2

    .line 74
    .line 75
    invoke-virtual {v0, v3}, La/bL;->Tr(Z)I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    invoke-virtual {v11}, La/WI;->eH()B

    .line 80
    .line 81
    .line 82
    const/16 v2, 0x3a

    .line 83
    .line 84
    if-eq v1, v2, :cond_0

    .line 85
    .line 86
    const/16 v2, 0x3d

    .line 87
    .line 88
    if-ne v1, v2, :cond_7

    .line 89
    .line 90
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 91
    .line 92
    .line 93
    const-wide/16 v1, 0x1

    .line 94
    .line 95
    invoke-interface {v12, v1, v2}, La/wI;->Y(J)Z

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    if-eqz v1, :cond_0

    .line 100
    .line 101
    invoke-virtual {v11, v5, v6}, La/WI;->mh(J)B

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    const/16 v2, 0x3e

    .line 106
    .line 107
    if-ne v1, v2, :cond_0

    .line 108
    .line 109
    invoke-virtual {v11}, La/WI;->eH()B

    .line 110
    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_7
    const-string v1, "Expected \':\'"

    .line 114
    .line 115
    invoke-virtual {v0, v1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    throw v18

    .line 119
    :cond_8
    const/4 v8, 0x6

    .line 120
    if-ne v4, v8, :cond_9

    .line 121
    .line 122
    const/4 v8, 0x7

    .line 123
    aput v8, v1, v2

    .line 124
    .line 125
    goto :goto_0

    .line 126
    :cond_9
    const/4 v8, 0x7

    .line 127
    const/4 v1, 0x0

    .line 128
    if-ne v4, v8, :cond_b

    .line 129
    .line 130
    invoke-virtual {v0, v1}, La/bL;->Tr(Z)I

    .line 131
    .line 132
    .line 133
    move-result v2

    .line 134
    const/4 v8, -0x1

    .line 135
    if-ne v2, v8, :cond_a

    .line 136
    .line 137
    const/16 v1, 0x12

    .line 138
    .line 139
    iput v1, v0, La/bL;->l:I

    .line 140
    .line 141
    return v1

    .line 142
    :cond_a
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 143
    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_b
    const/16 v2, 0x9

    .line 147
    .line 148
    if-eq v4, v2, :cond_3c

    .line 149
    .line 150
    const/16 v2, 0x8

    .line 151
    .line 152
    if-eq v4, v2, :cond_3b

    .line 153
    .line 154
    :goto_1
    invoke-virtual {v0, v3}, La/bL;->Tr(Z)I

    .line 155
    .line 156
    .line 157
    move-result v2

    .line 158
    const/16 v8, 0x22

    .line 159
    .line 160
    if-eq v2, v8, :cond_3a

    .line 161
    .line 162
    const/16 v8, 0x27

    .line 163
    .line 164
    if-eq v2, v8, :cond_39

    .line 165
    .line 166
    if-eq v2, v15, :cond_35

    .line 167
    .line 168
    if-eq v2, v14, :cond_35

    .line 169
    .line 170
    const/16 v8, 0x5b

    .line 171
    .line 172
    if-eq v2, v8, :cond_34

    .line 173
    .line 174
    if-eq v2, v9, :cond_33

    .line 175
    .line 176
    const/16 v4, 0x7b

    .line 177
    .line 178
    if-eq v2, v4, :cond_32

    .line 179
    .line 180
    invoke-virtual {v11, v5, v6}, La/WI;->mh(J)B

    .line 181
    .line 182
    .line 183
    move-result v2

    .line 184
    const/16 v4, 0x74

    .line 185
    .line 186
    if-eq v2, v4, :cond_11

    .line 187
    .line 188
    const/16 v4, 0x54

    .line 189
    .line 190
    if-ne v2, v4, :cond_c

    .line 191
    .line 192
    goto :goto_5

    .line 193
    :cond_c
    const/16 v4, 0x66

    .line 194
    .line 195
    if-eq v2, v4, :cond_10

    .line 196
    .line 197
    const/16 v4, 0x46

    .line 198
    .line 199
    if-ne v2, v4, :cond_d

    .line 200
    .line 201
    goto :goto_4

    .line 202
    :cond_d
    const/16 v4, 0x6e

    .line 203
    .line 204
    if-eq v2, v4, :cond_f

    .line 205
    .line 206
    const/16 v4, 0x4e

    .line 207
    .line 208
    if-ne v2, v4, :cond_e

    .line 209
    .line 210
    goto :goto_3

    .line 211
    :cond_e
    :goto_2
    move v8, v1

    .line 212
    goto :goto_8

    .line 213
    :cond_f
    :goto_3
    const-string v2, "null"

    .line 214
    .line 215
    const-string v4, "NULL"

    .line 216
    .line 217
    const/4 v8, 0x7

    .line 218
    goto :goto_6

    .line 219
    :cond_10
    :goto_4
    const-string v2, "false"

    .line 220
    .line 221
    const-string v4, "FALSE"

    .line 222
    .line 223
    const/4 v8, 0x6

    .line 224
    goto :goto_6

    .line 225
    :cond_11
    :goto_5
    const-string v2, "true"

    .line 226
    .line 227
    const-string v4, "TRUE"

    .line 228
    .line 229
    move v8, v10

    .line 230
    :goto_6
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 231
    .line 232
    .line 233
    move-result v9

    .line 234
    move v14, v3

    .line 235
    :goto_7
    if-ge v14, v9, :cond_14

    .line 236
    .line 237
    add-int/lit8 v15, v14, 0x1

    .line 238
    .line 239
    int-to-long v5, v15

    .line 240
    invoke-interface {v12, v5, v6}, La/wI;->Y(J)Z

    .line 241
    .line 242
    .line 243
    move-result v5

    .line 244
    if-nez v5, :cond_12

    .line 245
    .line 246
    goto :goto_2

    .line 247
    :cond_12
    int-to-long v5, v14

    .line 248
    invoke-virtual {v11, v5, v6}, La/WI;->mh(J)B

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    invoke-virtual {v2, v14}, Ljava/lang/String;->charAt(I)C

    .line 253
    .line 254
    .line 255
    move-result v6

    .line 256
    if-eq v5, v6, :cond_13

    .line 257
    .line 258
    invoke-virtual {v4, v14}, Ljava/lang/String;->charAt(I)C

    .line 259
    .line 260
    .line 261
    move-result v6

    .line 262
    if-eq v5, v6, :cond_13

    .line 263
    .line 264
    goto :goto_2

    .line 265
    :cond_13
    move v14, v15

    .line 266
    const-wide/16 v5, 0x0

    .line 267
    .line 268
    goto :goto_7

    .line 269
    :cond_14
    add-int/lit8 v2, v9, 0x1

    .line 270
    .line 271
    int-to-long v4, v2

    .line 272
    invoke-interface {v12, v4, v5}, La/wI;->Y(J)Z

    .line 273
    .line 274
    .line 275
    move-result v2

    .line 276
    if-eqz v2, :cond_15

    .line 277
    .line 278
    int-to-long v4, v9

    .line 279
    invoke-virtual {v11, v4, v5}, La/WI;->mh(J)B

    .line 280
    .line 281
    .line 282
    move-result v2

    .line 283
    invoke-virtual {v0, v2}, La/bL;->cS(I)Z

    .line 284
    .line 285
    .line 286
    move-result v2

    .line 287
    if-eqz v2, :cond_15

    .line 288
    .line 289
    goto :goto_2

    .line 290
    :cond_15
    int-to-long v4, v9

    .line 291
    invoke-virtual {v11, v4, v5}, La/WI;->F(J)V

    .line 292
    .line 293
    .line 294
    iput v8, v0, La/bL;->l:I

    .line 295
    .line 296
    :goto_8
    if-eqz v8, :cond_16

    .line 297
    .line 298
    return v8

    .line 299
    :cond_16
    move v2, v1

    .line 300
    move v4, v2

    .line 301
    move v6, v4

    .line 302
    move v5, v3

    .line 303
    const-wide/16 v8, 0x0

    .line 304
    .line 305
    :goto_9
    add-int/lit8 v14, v4, 0x1

    .line 306
    .line 307
    move-wide/from16 v16, v8

    .line 308
    .line 309
    int-to-long v7, v14

    .line 310
    invoke-interface {v12, v7, v8}, La/wI;->Y(J)Z

    .line 311
    .line 312
    .line 313
    move-result v7

    .line 314
    if-nez v7, :cond_17

    .line 315
    .line 316
    :goto_a
    const/4 v3, 0x2

    .line 317
    goto/16 :goto_11

    .line 318
    .line 319
    :cond_17
    int-to-long v7, v4

    .line 320
    invoke-virtual {v11, v7, v8}, La/WI;->mh(J)B

    .line 321
    .line 322
    .line 323
    move-result v7

    .line 324
    const/16 v8, 0x2b

    .line 325
    .line 326
    if-eq v7, v8, :cond_2f

    .line 327
    .line 328
    const/16 v8, 0x45

    .line 329
    .line 330
    if-eq v7, v8, :cond_2d

    .line 331
    .line 332
    const/16 v8, 0x65

    .line 333
    .line 334
    if-eq v7, v8, :cond_2d

    .line 335
    .line 336
    const/16 v8, 0x2d

    .line 337
    .line 338
    if-eq v7, v8, :cond_2b

    .line 339
    .line 340
    const/16 v8, 0x2e

    .line 341
    .line 342
    if-eq v7, v8, :cond_2a

    .line 343
    .line 344
    const/16 v8, 0x30

    .line 345
    .line 346
    if-lt v7, v8, :cond_23

    .line 347
    .line 348
    const/16 v8, 0x39

    .line 349
    .line 350
    if-le v7, v8, :cond_18

    .line 351
    .line 352
    goto :goto_10

    .line 353
    :cond_18
    if-eq v2, v3, :cond_19

    .line 354
    .line 355
    if-nez v2, :cond_1a

    .line 356
    .line 357
    :cond_19
    const/4 v3, 0x6

    .line 358
    goto :goto_f

    .line 359
    :cond_1a
    const/4 v4, 0x2

    .line 360
    if-ne v2, v4, :cond_1f

    .line 361
    .line 362
    const-wide/16 v8, 0x0

    .line 363
    .line 364
    cmp-long v4, v16, v8

    .line 365
    .line 366
    if-nez v4, :cond_1c

    .line 367
    .line 368
    :cond_1b
    move v10, v1

    .line 369
    goto/16 :goto_18

    .line 370
    .line 371
    :cond_1c
    const-wide/16 v8, 0xa

    .line 372
    .line 373
    mul-long v8, v8, v16

    .line 374
    .line 375
    add-int/lit8 v7, v7, -0x30

    .line 376
    .line 377
    int-to-long v3, v7

    .line 378
    sub-long/2addr v8, v3

    .line 379
    const-wide v3, -0xcccccccccccccccL

    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    cmp-long v3, v16, v3

    .line 385
    .line 386
    if-gtz v3, :cond_1e

    .line 387
    .line 388
    if-nez v3, :cond_1d

    .line 389
    .line 390
    cmp-long v3, v8, v16

    .line 391
    .line 392
    if-gez v3, :cond_1d

    .line 393
    .line 394
    goto :goto_b

    .line 395
    :cond_1d
    move v3, v1

    .line 396
    goto :goto_c

    .line 397
    :cond_1e
    :goto_b
    const/4 v3, 0x1

    .line 398
    :goto_c
    and-int/2addr v5, v3

    .line 399
    :goto_d
    const/4 v3, 0x6

    .line 400
    goto/16 :goto_17

    .line 401
    .line 402
    :cond_1f
    if-ne v2, v13, :cond_20

    .line 403
    .line 404
    move-wide/from16 v8, v16

    .line 405
    .line 406
    const/4 v2, 0x4

    .line 407
    goto :goto_d

    .line 408
    :cond_20
    const/4 v3, 0x6

    .line 409
    if-eq v2, v10, :cond_22

    .line 410
    .line 411
    if-ne v2, v3, :cond_21

    .line 412
    .line 413
    goto :goto_e

    .line 414
    :cond_21
    move-wide/from16 v8, v16

    .line 415
    .line 416
    goto/16 :goto_17

    .line 417
    .line 418
    :cond_22
    :goto_e
    move-wide/from16 v8, v16

    .line 419
    .line 420
    const/4 v2, 0x7

    .line 421
    goto/16 :goto_17

    .line 422
    .line 423
    :goto_f
    add-int/lit8 v7, v7, -0x30

    .line 424
    .line 425
    neg-int v2, v7

    .line 426
    int-to-long v8, v2

    .line 427
    const/4 v2, 0x2

    .line 428
    goto/16 :goto_17

    .line 429
    .line 430
    :cond_23
    :goto_10
    invoke-virtual {v0, v7}, La/bL;->cS(I)Z

    .line 431
    .line 432
    .line 433
    move-result v3

    .line 434
    if-nez v3, :cond_1b

    .line 435
    .line 436
    goto :goto_a

    .line 437
    :goto_11
    if-ne v2, v3, :cond_28

    .line 438
    .line 439
    if-eqz v5, :cond_25

    .line 440
    .line 441
    const-wide/high16 v7, -0x8000000000000000L

    .line 442
    .line 443
    cmp-long v3, v16, v7

    .line 444
    .line 445
    if-nez v3, :cond_24

    .line 446
    .line 447
    if-eqz v6, :cond_25

    .line 448
    .line 449
    :cond_24
    const-wide/16 v7, 0x0

    .line 450
    .line 451
    goto :goto_12

    .line 452
    :cond_25
    const/4 v3, 0x2

    .line 453
    goto :goto_15

    .line 454
    :goto_12
    cmp-long v3, v16, v7

    .line 455
    .line 456
    if-nez v3, :cond_26

    .line 457
    .line 458
    if-nez v6, :cond_25

    .line 459
    .line 460
    :cond_26
    if-eqz v6, :cond_27

    .line 461
    .line 462
    move-wide/from16 v8, v16

    .line 463
    .line 464
    goto :goto_13

    .line 465
    :cond_27
    move-wide/from16 v7, v16

    .line 466
    .line 467
    neg-long v8, v7

    .line 468
    :goto_13
    iput-wide v8, v0, La/bL;->W:J

    .line 469
    .line 470
    int-to-long v1, v4

    .line 471
    invoke-virtual {v11, v1, v2}, La/WI;->F(J)V

    .line 472
    .line 473
    .line 474
    const/16 v10, 0x10

    .line 475
    .line 476
    :goto_14
    iput v10, v0, La/bL;->l:I

    .line 477
    .line 478
    goto :goto_18

    .line 479
    :cond_28
    :goto_15
    if-eq v2, v3, :cond_29

    .line 480
    .line 481
    const/4 v3, 0x4

    .line 482
    if-eq v2, v3, :cond_29

    .line 483
    .line 484
    const/4 v3, 0x7

    .line 485
    if-ne v2, v3, :cond_1b

    .line 486
    .line 487
    :cond_29
    iput v4, v0, La/bL;->q:I

    .line 488
    .line 489
    const/16 v10, 0x11

    .line 490
    .line 491
    goto :goto_14

    .line 492
    :cond_2a
    move-wide/from16 v7, v16

    .line 493
    .line 494
    const/4 v3, 0x6

    .line 495
    const/4 v4, 0x2

    .line 496
    if-ne v2, v4, :cond_1b

    .line 497
    .line 498
    move-wide v8, v7

    .line 499
    move v2, v13

    .line 500
    goto :goto_17

    .line 501
    :cond_2b
    move-wide/from16 v7, v16

    .line 502
    .line 503
    const/4 v3, 0x6

    .line 504
    const/4 v4, 0x2

    .line 505
    if-nez v2, :cond_2c

    .line 506
    .line 507
    move-wide v8, v7

    .line 508
    const/4 v2, 0x1

    .line 509
    const/4 v6, 0x1

    .line 510
    goto :goto_17

    .line 511
    :cond_2c
    if-ne v2, v10, :cond_1b

    .line 512
    .line 513
    :goto_16
    move v2, v3

    .line 514
    move-wide v8, v7

    .line 515
    goto :goto_17

    .line 516
    :cond_2d
    move-wide/from16 v7, v16

    .line 517
    .line 518
    const/4 v3, 0x6

    .line 519
    const/4 v4, 0x2

    .line 520
    if-eq v2, v4, :cond_2e

    .line 521
    .line 522
    const/4 v4, 0x4

    .line 523
    if-ne v2, v4, :cond_1b

    .line 524
    .line 525
    :cond_2e
    move-wide v8, v7

    .line 526
    move v2, v10

    .line 527
    goto :goto_17

    .line 528
    :cond_2f
    move-wide/from16 v7, v16

    .line 529
    .line 530
    const/4 v3, 0x6

    .line 531
    if-ne v2, v10, :cond_1b

    .line 532
    .line 533
    goto :goto_16

    .line 534
    :goto_17
    move v4, v14

    .line 535
    const/4 v3, 0x1

    .line 536
    const/4 v7, 0x2

    .line 537
    goto/16 :goto_9

    .line 538
    .line 539
    :goto_18
    if-eqz v10, :cond_30

    .line 540
    .line 541
    return v10

    .line 542
    :cond_30
    const-wide/16 v1, 0x0

    .line 543
    .line 544
    invoke-virtual {v11, v1, v2}, La/WI;->mh(J)B

    .line 545
    .line 546
    .line 547
    move-result v1

    .line 548
    invoke-virtual {v0, v1}, La/bL;->cS(I)Z

    .line 549
    .line 550
    .line 551
    move-result v1

    .line 552
    if-eqz v1, :cond_31

    .line 553
    .line 554
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 555
    .line 556
    .line 557
    const/16 v1, 0xa

    .line 558
    .line 559
    iput v1, v0, La/bL;->l:I

    .line 560
    .line 561
    return v1

    .line 562
    :cond_31
    const-string v1, "Expected value"

    .line 563
    .line 564
    invoke-virtual {v0, v1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 565
    .line 566
    .line 567
    throw v18

    .line 568
    :cond_32
    invoke-virtual {v11}, La/WI;->eH()B

    .line 569
    .line 570
    .line 571
    const/4 v1, 0x1

    .line 572
    iput v1, v0, La/bL;->l:I

    .line 573
    .line 574
    return v1

    .line 575
    :cond_33
    move v1, v3

    .line 576
    if-ne v4, v1, :cond_36

    .line 577
    .line 578
    invoke-virtual {v11}, La/WI;->eH()B

    .line 579
    .line 580
    .line 581
    const/4 v1, 0x4

    .line 582
    iput v1, v0, La/bL;->l:I

    .line 583
    .line 584
    return v1

    .line 585
    :cond_34
    invoke-virtual {v11}, La/WI;->eH()B

    .line 586
    .line 587
    .line 588
    iput v13, v0, La/bL;->l:I

    .line 589
    .line 590
    return v13

    .line 591
    :cond_35
    move v1, v3

    .line 592
    :cond_36
    if-eq v4, v1, :cond_38

    .line 593
    .line 594
    const/4 v1, 0x2

    .line 595
    if-ne v4, v1, :cond_37

    .line 596
    .line 597
    goto :goto_19

    .line 598
    :cond_37
    const-string v1, "Unexpected value"

    .line 599
    .line 600
    invoke-virtual {v0, v1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 601
    .line 602
    .line 603
    throw v18

    .line 604
    :cond_38
    :goto_19
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 605
    .line 606
    .line 607
    const/4 v1, 0x7

    .line 608
    iput v1, v0, La/bL;->l:I

    .line 609
    .line 610
    return v1

    .line 611
    :cond_39
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 612
    .line 613
    .line 614
    invoke-virtual {v11}, La/WI;->eH()B

    .line 615
    .line 616
    .line 617
    const/16 v1, 0x8

    .line 618
    .line 619
    iput v1, v0, La/bL;->l:I

    .line 620
    .line 621
    return v1

    .line 622
    :cond_3a
    invoke-virtual {v11}, La/WI;->eH()B

    .line 623
    .line 624
    .line 625
    const/16 v1, 0x9

    .line 626
    .line 627
    iput v1, v0, La/bL;->l:I

    .line 628
    .line 629
    return v1

    .line 630
    :cond_3b
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 631
    .line 632
    const-string v2, "JsonReader is closed"

    .line 633
    .line 634
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 635
    .line 636
    .line 637
    throw v1

    .line 638
    :cond_3c
    throw v18

    .line 639
    :goto_1a
    aput v3, v1, v2

    .line 640
    .line 641
    const/16 v1, 0x7d

    .line 642
    .line 643
    if-ne v4, v10, :cond_3f

    .line 644
    .line 645
    const/4 v2, 0x1

    .line 646
    invoke-virtual {v0, v2}, La/bL;->Tr(Z)I

    .line 647
    .line 648
    .line 649
    move-result v3

    .line 650
    invoke-virtual {v11}, La/WI;->eH()B

    .line 651
    .line 652
    .line 653
    if-eq v3, v15, :cond_3f

    .line 654
    .line 655
    if-eq v3, v14, :cond_3e

    .line 656
    .line 657
    if-ne v3, v1, :cond_3d

    .line 658
    .line 659
    const/4 v1, 0x2

    .line 660
    iput v1, v0, La/bL;->l:I

    .line 661
    .line 662
    return v1

    .line 663
    :cond_3d
    const-string v1, "Unterminated object"

    .line 664
    .line 665
    invoke-virtual {v0, v1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 666
    .line 667
    .line 668
    throw v18

    .line 669
    :cond_3e
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 670
    .line 671
    .line 672
    :cond_3f
    const/4 v2, 0x1

    .line 673
    invoke-virtual {v0, v2}, La/bL;->Tr(Z)I

    .line 674
    .line 675
    .line 676
    move-result v2

    .line 677
    const/16 v3, 0x22

    .line 678
    .line 679
    if-eq v2, v3, :cond_44

    .line 680
    .line 681
    const/16 v3, 0x27

    .line 682
    .line 683
    if-eq v2, v3, :cond_43

    .line 684
    .line 685
    const-string v3, "Expected name"

    .line 686
    .line 687
    if-eq v2, v1, :cond_41

    .line 688
    .line 689
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 690
    .line 691
    .line 692
    int-to-char v1, v2

    .line 693
    invoke-virtual {v0, v1}, La/bL;->cS(I)Z

    .line 694
    .line 695
    .line 696
    move-result v1

    .line 697
    if-eqz v1, :cond_40

    .line 698
    .line 699
    const/16 v1, 0xe

    .line 700
    .line 701
    iput v1, v0, La/bL;->l:I

    .line 702
    .line 703
    return v1

    .line 704
    :cond_40
    invoke-virtual {v0, v3}, La/SN;->VQ(Ljava/lang/String;)V

    .line 705
    .line 706
    .line 707
    throw v18

    .line 708
    :cond_41
    if-eq v4, v10, :cond_42

    .line 709
    .line 710
    invoke-virtual {v11}, La/WI;->eH()B

    .line 711
    .line 712
    .line 713
    const/4 v1, 0x2

    .line 714
    iput v1, v0, La/bL;->l:I

    .line 715
    .line 716
    return v1

    .line 717
    :cond_42
    invoke-virtual {v0, v3}, La/SN;->VQ(Ljava/lang/String;)V

    .line 718
    .line 719
    .line 720
    throw v18

    .line 721
    :cond_43
    invoke-virtual {v11}, La/WI;->eH()B

    .line 722
    .line 723
    .line 724
    invoke-virtual/range {p0 .. p0}, La/bL;->HF()V

    .line 725
    .line 726
    .line 727
    const/16 v1, 0xc

    .line 728
    .line 729
    iput v1, v0, La/bL;->l:I

    .line 730
    .line 731
    return v1

    .line 732
    :cond_44
    invoke-virtual {v11}, La/WI;->eH()B

    .line 733
    .line 734
    .line 735
    const/16 v1, 0xd

    .line 736
    .line 737
    iput v1, v0, La/bL;->l:I

    .line 738
    .line 739
    return v1
.end method

.method public final HF()V
    .locals 1

    .line 1
    const-string v0, "Use JsonReader.setLenient(true) to accept malformed JSON"

    invoke-virtual {p0, v0}, La/SN;->VQ(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public final I()V
    .locals 3

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/4 v1, 0x4

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    iget v0, p0, La/SN;->X:I

    .line 13
    .line 14
    add-int/lit8 v1, v0, -0x1

    .line 15
    .line 16
    iput v1, p0, La/SN;->X:I

    .line 17
    .line 18
    iget-object v1, p0, La/SN;->L:[I

    .line 19
    .line 20
    add-int/lit8 v0, v0, -0x2

    .line 21
    .line 22
    aget v2, v1, v0

    .line 23
    .line 24
    add-int/lit8 v2, v2, 0x1

    .line 25
    .line 26
    aput v2, v1, v0

    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    iput v0, p0, La/bL;->l:I

    .line 30
    .line 31
    return-void

    .line 32
    :cond_1
    new-instance v0, La/P5;

    .line 33
    .line 34
    new-instance v1, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string v2, "Expected END_ARRAY but was "

    .line 37
    .line 38
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0}, La/bL;->B1()I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    const-string v2, " at path "

    .line 53
    .line 54
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw v0
.end method

.method public final MX(Ljava/lang/String;La/dh;)I
    .locals 4

    .line 1
    iget-object v0, p2, La/dh;->K:Ljava/lang/Object;

    check-cast v0, [Ljava/lang/String;

    array-length v0, v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p2, La/dh;->K:Ljava/lang/Object;

    check-cast v3, [Ljava/lang/String;

    aget-object v3, v3, v2

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    iput v1, p0, La/bL;->l:I

    iget-object p1, p0, La/SN;->L:[I

    iget p2, p0, La/SN;->X:I

    add-int/lit8 p2, p2, -0x1

    aget v0, p1, p2

    add-int/lit8 v0, v0, 0x1

    aput v0, p1, p2

    return v2

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    return p1
.end method

.method public final NE(Ljava/lang/String;La/dh;)I
    .locals 4

    .line 1
    iget-object v0, p2, La/dh;->K:Ljava/lang/Object;

    check-cast v0, [Ljava/lang/String;

    array-length v0, v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v3, p2, La/dh;->K:Ljava/lang/Object;

    check-cast v3, [Ljava/lang/String;

    aget-object v3, v3, v2

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    iput v1, p0, La/bL;->l:I

    iget-object p2, p0, La/SN;->R:[Ljava/lang/String;

    iget v0, p0, La/SN;->X:I

    add-int/lit8 v0, v0, -0x1

    aput-object p1, p2, v0

    return v2

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    return p1
.end method

.method public final Pb()V
    .locals 4

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/16 v1, 0xe

    .line 10
    .line 11
    if-ne v0, v1, :cond_2

    .line 12
    .line 13
    sget-object v0, La/bL;->H:La/xi;

    .line 14
    .line 15
    iget-object v1, p0, La/bL;->d:La/wI;

    .line 16
    .line 17
    invoke-interface {v1, v0}, La/wI;->n(La/xi;)J

    .line 18
    .line 19
    .line 20
    move-result-wide v0

    .line 21
    const-wide/16 v2, -0x1

    .line 22
    .line 23
    cmp-long v2, v0, v2

    .line 24
    .line 25
    iget-object v3, p0, La/bL;->f:La/WI;

    .line 26
    .line 27
    if-eqz v2, :cond_1

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    iget-wide v0, v3, La/WI;->K:J

    .line 31
    .line 32
    :goto_0
    invoke-virtual {v3, v0, v1}, La/WI;->F(J)V

    .line 33
    .line 34
    .line 35
    goto :goto_2

    .line 36
    :cond_2
    const/16 v1, 0xd

    .line 37
    .line 38
    if-ne v0, v1, :cond_3

    .line 39
    .line 40
    sget-object v0, La/bL;->S:La/xi;

    .line 41
    .line 42
    :goto_1
    invoke-virtual {p0, v0}, La/bL;->Vm(La/xi;)V

    .line 43
    .line 44
    .line 45
    goto :goto_2

    .line 46
    :cond_3
    const/16 v1, 0xc

    .line 47
    .line 48
    if-ne v0, v1, :cond_4

    .line 49
    .line 50
    sget-object v0, La/bL;->E:La/xi;

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_4
    const/16 v1, 0xf

    .line 54
    .line 55
    if-ne v0, v1, :cond_5

    .line 56
    .line 57
    :goto_2
    const/4 v0, 0x0

    .line 58
    iput v0, p0, La/bL;->l:I

    .line 59
    .line 60
    iget-object v0, p0, La/SN;->R:[Ljava/lang/String;

    .line 61
    .line 62
    iget v1, p0, La/SN;->X:I

    .line 63
    .line 64
    add-int/lit8 v1, v1, -0x1

    .line 65
    .line 66
    const-string v2, "null"

    .line 67
    .line 68
    aput-object v2, v0, v1

    .line 69
    .line 70
    return-void

    .line 71
    :cond_5
    new-instance v0, La/P5;

    .line 72
    .line 73
    new-instance v1, Ljava/lang/StringBuilder;

    .line 74
    .line 75
    const-string v2, "Expected a name but was "

    .line 76
    .line 77
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0}, La/bL;->B1()I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    const-string v2, " at path "

    .line 92
    .line 93
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    throw v0
.end method

.method public final Qg()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/16 v1, 0xe

    .line 10
    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, La/bL;->C6()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    const/16 v1, 0xd

    .line 19
    .line 20
    if-ne v0, v1, :cond_2

    .line 21
    .line 22
    sget-object v0, La/bL;->S:La/xi;

    .line 23
    .line 24
    :goto_0
    invoke-virtual {p0, v0}, La/bL;->yd(La/xi;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    goto :goto_1

    .line 29
    :cond_2
    const/16 v1, 0xc

    .line 30
    .line 31
    if-ne v0, v1, :cond_3

    .line 32
    .line 33
    sget-object v0, La/bL;->E:La/xi;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_3
    const/16 v1, 0xf

    .line 37
    .line 38
    if-ne v0, v1, :cond_4

    .line 39
    .line 40
    iget-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 41
    .line 42
    const/4 v1, 0x0

    .line 43
    iput-object v1, p0, La/bL;->F:Ljava/lang/String;

    .line 44
    .line 45
    :goto_1
    const/4 v1, 0x0

    .line 46
    iput v1, p0, La/bL;->l:I

    .line 47
    .line 48
    iget-object v1, p0, La/SN;->R:[Ljava/lang/String;

    .line 49
    .line 50
    iget v2, p0, La/SN;->X:I

    .line 51
    .line 52
    add-int/lit8 v2, v2, -0x1

    .line 53
    .line 54
    aput-object v0, v1, v2

    .line 55
    .line 56
    return-object v0

    .line 57
    :cond_4
    new-instance v0, La/P5;

    .line 58
    .line 59
    new-instance v1, Ljava/lang/StringBuilder;

    .line 60
    .line 61
    const-string v2, "Expected a name but was "

    .line 62
    .line 63
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {p0}, La/bL;->B1()I

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    const-string v2, " at path "

    .line 78
    .line 79
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    throw v0
.end method

.method public final T()V
    .locals 5

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/4 v1, 0x2

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    iget v0, p0, La/SN;->X:I

    .line 13
    .line 14
    add-int/lit8 v2, v0, -0x1

    .line 15
    .line 16
    iput v2, p0, La/SN;->X:I

    .line 17
    .line 18
    iget-object v3, p0, La/SN;->R:[Ljava/lang/String;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    aput-object v4, v3, v2

    .line 22
    .line 23
    iget-object v2, p0, La/SN;->L:[I

    .line 24
    .line 25
    sub-int/2addr v0, v1

    .line 26
    aget v1, v2, v0

    .line 27
    .line 28
    add-int/lit8 v1, v1, 0x1

    .line 29
    .line 30
    aput v1, v2, v0

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    iput v0, p0, La/bL;->l:I

    .line 34
    .line 35
    return-void

    .line 36
    :cond_1
    new-instance v0, La/P5;

    .line 37
    .line 38
    new-instance v1, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    const-string v2, "Expected END_OBJECT but was "

    .line 41
    .line 42
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0}, La/bL;->B1()I

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    const-string v2, " at path "

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    throw v0
.end method

.method public final Tr(Z)I
    .locals 12

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    move v1, v0

    .line 3
    :goto_1
    add-int/lit8 v2, v1, 0x1

    .line 4
    .line 5
    int-to-long v3, v2

    .line 6
    iget-object v5, p0, La/bL;->d:La/wI;

    .line 7
    .line 8
    invoke-interface {v5, v3, v4}, La/wI;->Y(J)Z

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    if-eqz v3, :cond_c

    .line 13
    .line 14
    int-to-long v3, v1

    .line 15
    iget-object v1, p0, La/bL;->f:La/WI;

    .line 16
    .line 17
    invoke-virtual {v1, v3, v4}, La/WI;->mh(J)B

    .line 18
    .line 19
    .line 20
    move-result v6

    .line 21
    const/16 v7, 0xa

    .line 22
    .line 23
    if-eq v6, v7, :cond_b

    .line 24
    .line 25
    const/16 v7, 0x20

    .line 26
    .line 27
    if-eq v6, v7, :cond_b

    .line 28
    .line 29
    const/16 v7, 0xd

    .line 30
    .line 31
    if-eq v6, v7, :cond_b

    .line 32
    .line 33
    const/16 v7, 0x9

    .line 34
    .line 35
    if-ne v6, v7, :cond_0

    .line 36
    .line 37
    goto/16 :goto_6

    .line 38
    .line 39
    :cond_0
    invoke-virtual {v1, v3, v4}, La/WI;->F(J)V

    .line 40
    .line 41
    .line 42
    sget-object v2, La/bL;->z:La/xi;

    .line 43
    .line 44
    const-wide/16 v3, -0x1

    .line 45
    .line 46
    const-wide/16 v7, 0x1

    .line 47
    .line 48
    const/16 v9, 0x2f

    .line 49
    .line 50
    if-ne v6, v9, :cond_8

    .line 51
    .line 52
    const-wide/16 v10, 0x2

    .line 53
    .line 54
    invoke-interface {v5, v10, v11}, La/wI;->Y(J)Z

    .line 55
    .line 56
    .line 57
    move-result v10

    .line 58
    if-nez v10, :cond_1

    .line 59
    .line 60
    return v6

    .line 61
    :cond_1
    invoke-virtual {p0}, La/bL;->HF()V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1, v7, v8}, La/WI;->mh(J)B

    .line 65
    .line 66
    .line 67
    move-result v10

    .line 68
    const/16 v11, 0x2a

    .line 69
    .line 70
    if-eq v10, v11, :cond_4

    .line 71
    .line 72
    if-eq v10, v9, :cond_2

    .line 73
    .line 74
    return v6

    .line 75
    :cond_2
    invoke-virtual {v1}, La/WI;->eH()B

    .line 76
    .line 77
    .line 78
    invoke-virtual {v1}, La/WI;->eH()B

    .line 79
    .line 80
    .line 81
    invoke-interface {v5, v2}, La/wI;->n(La/xi;)J

    .line 82
    .line 83
    .line 84
    move-result-wide v5

    .line 85
    cmp-long v2, v5, v3

    .line 86
    .line 87
    if-eqz v2, :cond_3

    .line 88
    .line 89
    add-long/2addr v5, v7

    .line 90
    goto :goto_2

    .line 91
    :cond_3
    iget-wide v5, v1, La/WI;->K:J

    .line 92
    .line 93
    :goto_2
    invoke-virtual {v1, v5, v6}, La/WI;->F(J)V

    .line 94
    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_4
    invoke-virtual {v1}, La/WI;->eH()B

    .line 98
    .line 99
    .line 100
    invoke-virtual {v1}, La/WI;->eH()B

    .line 101
    .line 102
    .line 103
    sget-object v2, La/bL;->P:La/xi;

    .line 104
    .line 105
    invoke-interface {v5, v2}, La/wI;->D(La/xi;)J

    .line 106
    .line 107
    .line 108
    move-result-wide v5

    .line 109
    cmp-long v3, v5, v3

    .line 110
    .line 111
    if-eqz v3, :cond_5

    .line 112
    .line 113
    const/4 v3, 0x1

    .line 114
    goto :goto_3

    .line 115
    :cond_5
    move v3, v0

    .line 116
    :goto_3
    if-eqz v3, :cond_6

    .line 117
    .line 118
    iget-object v2, v2, La/xi;->X:[B

    .line 119
    .line 120
    array-length v2, v2

    .line 121
    int-to-long v7, v2

    .line 122
    add-long/2addr v5, v7

    .line 123
    goto :goto_4

    .line 124
    :cond_6
    iget-wide v5, v1, La/WI;->K:J

    .line 125
    .line 126
    :goto_4
    invoke-virtual {v1, v5, v6}, La/WI;->F(J)V

    .line 127
    .line 128
    .line 129
    if-eqz v3, :cond_7

    .line 130
    .line 131
    goto/16 :goto_0

    .line 132
    .line 133
    :cond_7
    const-string p1, "Unterminated comment"

    .line 134
    .line 135
    invoke-virtual {p0, p1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    const/4 p1, 0x0

    .line 139
    throw p1

    .line 140
    :cond_8
    const/16 v9, 0x23

    .line 141
    .line 142
    if-ne v6, v9, :cond_a

    .line 143
    .line 144
    invoke-virtual {p0}, La/bL;->HF()V

    .line 145
    .line 146
    .line 147
    invoke-interface {v5, v2}, La/wI;->n(La/xi;)J

    .line 148
    .line 149
    .line 150
    move-result-wide v5

    .line 151
    cmp-long v2, v5, v3

    .line 152
    .line 153
    if-eqz v2, :cond_9

    .line 154
    .line 155
    add-long/2addr v5, v7

    .line 156
    goto :goto_5

    .line 157
    :cond_9
    iget-wide v5, v1, La/WI;->K:J

    .line 158
    .line 159
    :goto_5
    invoke-virtual {v1, v5, v6}, La/WI;->F(J)V

    .line 160
    .line 161
    .line 162
    goto/16 :goto_0

    .line 163
    .line 164
    :cond_a
    return v6

    .line 165
    :cond_b
    :goto_6
    move v1, v2

    .line 166
    goto/16 :goto_1

    .line 167
    .line 168
    :cond_c
    if-nez p1, :cond_d

    .line 169
    .line 170
    const/4 p1, -0x1

    .line 171
    return p1

    .line 172
    :cond_d
    new-instance p1, Ljava/io/EOFException;

    .line 173
    .line 174
    const-string v0, "End of input"

    .line 175
    .line 176
    invoke-direct {p1, v0}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw p1
.end method

.method public final U()Z
    .locals 2

    .line 1
    iget v0, p0, La/bL;->l:I

    if-nez v0, :cond_0

    invoke-virtual {p0}, La/bL;->Gy()I

    move-result v0

    :cond_0
    const/4 v1, 0x2

    if-eq v0, v1, :cond_1

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    const/16 v1, 0x12

    if-eq v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final Vm(La/xi;)V
    .locals 7

    .line 1
    :goto_0
    iget-object v0, p0, La/bL;->d:La/wI;

    invoke-interface {v0, p1}, La/wI;->n(La/xi;)J

    move-result-wide v0

    const-wide/16 v2, -0x1

    cmp-long v2, v0, v2

    if-eqz v2, :cond_1

    iget-object v2, p0, La/bL;->f:La/WI;

    invoke-virtual {v2, v0, v1}, La/WI;->mh(J)B

    move-result v3

    const/16 v4, 0x5c

    const-wide/16 v5, 0x1

    add-long/2addr v0, v5

    invoke-virtual {v2, v0, v1}, La/WI;->F(J)V

    if-ne v3, v4, :cond_0

    invoke-virtual {p0}, La/bL;->nA()C

    goto :goto_0

    :cond_0
    return-void

    :cond_1
    const-string p1, "Unterminated string"

    invoke-virtual {p0, p1}, La/SN;->VQ(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1
.end method

.method public final ZU()V
    .locals 3

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/4 v1, 0x7

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput v0, p0, La/bL;->l:I

    .line 14
    .line 15
    iget-object v0, p0, La/SN;->L:[I

    .line 16
    .line 17
    iget v1, p0, La/SN;->X:I

    .line 18
    .line 19
    add-int/lit8 v1, v1, -0x1

    .line 20
    .line 21
    aget v2, v0, v1

    .line 22
    .line 23
    add-int/lit8 v2, v2, 0x1

    .line 24
    .line 25
    aput v2, v0, v1

    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    new-instance v0, La/P5;

    .line 29
    .line 30
    new-instance v1, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v2, "Expected null but was "

    .line 33
    .line 34
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p0}, La/bL;->B1()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    const-string v2, " at path "

    .line 49
    .line 50
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    throw v0
.end method

.method public final cS(I)Z
    .locals 1

    .line 1
    const/16 v0, 0x9

    if-eq p1, v0, :cond_1

    const/16 v0, 0xa

    if-eq p1, v0, :cond_1

    const/16 v0, 0xc

    if-eq p1, v0, :cond_1

    const/16 v0, 0xd

    if-eq p1, v0, :cond_1

    const/16 v0, 0x20

    if-eq p1, v0, :cond_1

    const/16 v0, 0x23

    if-eq p1, v0, :cond_0

    const/16 v0, 0x2c

    if-eq p1, v0, :cond_1

    const/16 v0, 0x2f

    if-eq p1, v0, :cond_0

    const/16 v0, 0x3d

    if-eq p1, v0, :cond_0

    const/16 v0, 0x7b

    if-eq p1, v0, :cond_1

    const/16 v0, 0x7d

    if-eq p1, v0, :cond_1

    const/16 v0, 0x3a

    if-eq p1, v0, :cond_1

    const/16 v0, 0x3b

    if-eq p1, v0, :cond_0

    packed-switch p1, :pswitch_data_0

    const/4 p1, 0x1

    return p1

    :cond_0
    :pswitch_0
    invoke-virtual {p0}, La/bL;->HF()V

    :cond_1
    :pswitch_1
    const/4 p1, 0x0

    return p1

    :pswitch_data_0
    .packed-switch 0x5b
        :pswitch_1
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final close()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    iput v0, p0, La/bL;->l:I

    iget-object v1, p0, La/SN;->K:[I

    const/16 v2, 0x8

    aput v2, v1, v0

    const/4 v0, 0x1

    iput v0, p0, La/SN;->X:I

    iget-object v0, p0, La/bL;->f:La/WI;

    invoke-virtual {v0}, La/WI;->w()V

    iget-object v0, p0, La/bL;->d:La/wI;

    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    return-void
.end method

.method public final h()V
    .locals 3

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/4 v1, 0x1

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    invoke-virtual {p0, v0}, La/SN;->y6(I)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput v0, p0, La/bL;->l:I

    .line 18
    .line 19
    return-void

    .line 20
    :cond_1
    new-instance v0, La/P5;

    .line 21
    .line 22
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    const-string v2, "Expected BEGIN_OBJECT but was "

    .line 25
    .line 26
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, La/bL;->B1()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v2, " at path "

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw v0
.end method

.method public final lI()V
    .locals 10

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    :cond_0
    iget v2, p0, La/bL;->l:I

    .line 4
    .line 5
    if-nez v2, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    :cond_1
    const/4 v3, 0x1

    .line 12
    const/4 v4, 0x3

    .line 13
    if-ne v2, v4, :cond_2

    .line 14
    .line 15
    invoke-virtual {p0, v3}, La/SN;->y6(I)V

    .line 16
    .line 17
    .line 18
    :goto_0
    add-int/lit8 v1, v1, 0x1

    .line 19
    .line 20
    goto/16 :goto_6

    .line 21
    .line 22
    :cond_2
    if-ne v2, v3, :cond_3

    .line 23
    .line 24
    invoke-virtual {p0, v4}, La/SN;->y6(I)V

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_3
    const/4 v4, 0x4

    .line 29
    const-string v5, " at path "

    .line 30
    .line 31
    const-string v6, "Expected a value but was "

    .line 32
    .line 33
    if-ne v2, v4, :cond_5

    .line 34
    .line 35
    add-int/lit8 v1, v1, -0x1

    .line 36
    .line 37
    if-ltz v1, :cond_4

    .line 38
    .line 39
    iget v2, p0, La/SN;->X:I

    .line 40
    .line 41
    sub-int/2addr v2, v3

    .line 42
    iput v2, p0, La/SN;->X:I

    .line 43
    .line 44
    goto/16 :goto_6

    .line 45
    .line 46
    :cond_4
    new-instance v0, La/P5;

    .line 47
    .line 48
    new-instance v1, Ljava/lang/StringBuilder;

    .line 49
    .line 50
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0}, La/bL;->B1()I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :cond_5
    const/4 v4, 0x2

    .line 83
    if-ne v2, v4, :cond_7

    .line 84
    .line 85
    add-int/lit8 v1, v1, -0x1

    .line 86
    .line 87
    if-ltz v1, :cond_6

    .line 88
    .line 89
    iget v2, p0, La/SN;->X:I

    .line 90
    .line 91
    sub-int/2addr v2, v3

    .line 92
    iput v2, p0, La/SN;->X:I

    .line 93
    .line 94
    goto/16 :goto_6

    .line 95
    .line 96
    :cond_6
    new-instance v0, La/P5;

    .line 97
    .line 98
    new-instance v1, Ljava/lang/StringBuilder;

    .line 99
    .line 100
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p0}, La/bL;->B1()I

    .line 104
    .line 105
    .line 106
    move-result v2

    .line 107
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    throw v0

    .line 132
    :cond_7
    const/16 v4, 0xe

    .line 133
    .line 134
    iget-object v7, p0, La/bL;->f:La/WI;

    .line 135
    .line 136
    if-eq v2, v4, :cond_f

    .line 137
    .line 138
    const/16 v4, 0xa

    .line 139
    .line 140
    if-ne v2, v4, :cond_8

    .line 141
    .line 142
    goto :goto_4

    .line 143
    :cond_8
    const/16 v4, 0x9

    .line 144
    .line 145
    if-eq v2, v4, :cond_e

    .line 146
    .line 147
    const/16 v4, 0xd

    .line 148
    .line 149
    if-ne v2, v4, :cond_9

    .line 150
    .line 151
    goto :goto_3

    .line 152
    :cond_9
    const/16 v4, 0x8

    .line 153
    .line 154
    if-eq v2, v4, :cond_d

    .line 155
    .line 156
    const/16 v4, 0xc

    .line 157
    .line 158
    if-ne v2, v4, :cond_a

    .line 159
    .line 160
    goto :goto_1

    .line 161
    :cond_a
    const/16 v4, 0x11

    .line 162
    .line 163
    if-ne v2, v4, :cond_b

    .line 164
    .line 165
    iget v2, p0, La/bL;->q:I

    .line 166
    .line 167
    int-to-long v4, v2

    .line 168
    invoke-virtual {v7, v4, v5}, La/WI;->F(J)V

    .line 169
    .line 170
    .line 171
    goto :goto_6

    .line 172
    :cond_b
    const/16 v4, 0x12

    .line 173
    .line 174
    if-eq v2, v4, :cond_c

    .line 175
    .line 176
    goto :goto_6

    .line 177
    :cond_c
    new-instance v0, La/P5;

    .line 178
    .line 179
    new-instance v1, Ljava/lang/StringBuilder;

    .line 180
    .line 181
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {p0}, La/bL;->B1()I

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v2

    .line 192
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object v2

    .line 202
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    throw v0

    .line 213
    :cond_d
    :goto_1
    sget-object v2, La/bL;->E:La/xi;

    .line 214
    .line 215
    :goto_2
    invoke-virtual {p0, v2}, La/bL;->Vm(La/xi;)V

    .line 216
    .line 217
    .line 218
    goto :goto_6

    .line 219
    :cond_e
    :goto_3
    sget-object v2, La/bL;->S:La/xi;

    .line 220
    .line 221
    goto :goto_2

    .line 222
    :cond_f
    :goto_4
    sget-object v2, La/bL;->H:La/xi;

    .line 223
    .line 224
    iget-object v4, p0, La/bL;->d:La/wI;

    .line 225
    .line 226
    invoke-interface {v4, v2}, La/wI;->n(La/xi;)J

    .line 227
    .line 228
    .line 229
    move-result-wide v4

    .line 230
    const-wide/16 v8, -0x1

    .line 231
    .line 232
    cmp-long v2, v4, v8

    .line 233
    .line 234
    if-eqz v2, :cond_10

    .line 235
    .line 236
    goto :goto_5

    .line 237
    :cond_10
    iget-wide v4, v7, La/WI;->K:J

    .line 238
    .line 239
    :goto_5
    invoke-virtual {v7, v4, v5}, La/WI;->F(J)V

    .line 240
    .line 241
    .line 242
    :goto_6
    iput v0, p0, La/bL;->l:I

    .line 243
    .line 244
    if-nez v1, :cond_0

    .line 245
    .line 246
    iget-object v0, p0, La/SN;->L:[I

    .line 247
    .line 248
    iget v1, p0, La/SN;->X:I

    .line 249
    .line 250
    sub-int/2addr v1, v3

    .line 251
    aget v2, v0, v1

    .line 252
    .line 253
    add-int/2addr v2, v3

    .line 254
    aput v2, v0, v1

    .line 255
    .line 256
    iget-object v0, p0, La/SN;->R:[Ljava/lang/String;

    .line 257
    .line 258
    const-string v2, "null"

    .line 259
    .line 260
    aput-object v2, v0, v1

    .line 261
    .line 262
    return-void
.end method

.method public final mh()I
    .locals 8

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/16 v1, 0x10

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    const-string v3, " at path "

    .line 13
    .line 14
    const-string v4, "Expected an int but was "

    .line 15
    .line 16
    if-ne v0, v1, :cond_2

    .line 17
    .line 18
    iget-wide v0, p0, La/bL;->W:J

    .line 19
    .line 20
    long-to-int v5, v0

    .line 21
    int-to-long v6, v5

    .line 22
    cmp-long v0, v0, v6

    .line 23
    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    iput v2, p0, La/bL;->l:I

    .line 27
    .line 28
    iget-object v0, p0, La/SN;->L:[I

    .line 29
    .line 30
    iget v1, p0, La/SN;->X:I

    .line 31
    .line 32
    add-int/lit8 v1, v1, -0x1

    .line 33
    .line 34
    aget v2, v0, v1

    .line 35
    .line 36
    add-int/lit8 v2, v2, 0x1

    .line 37
    .line 38
    aput v2, v0, v1

    .line 39
    .line 40
    return v5

    .line 41
    :cond_1
    new-instance v0, La/P5;

    .line 42
    .line 43
    new-instance v1, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-wide v4, p0, La/bL;->W:J

    .line 49
    .line 50
    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :cond_2
    const/16 v1, 0x11

    .line 72
    .line 73
    const/16 v5, 0xb

    .line 74
    .line 75
    if-ne v0, v1, :cond_3

    .line 76
    .line 77
    iget v0, p0, La/bL;->q:I

    .line 78
    .line 79
    int-to-long v0, v0

    .line 80
    iget-object v6, p0, La/bL;->f:La/WI;

    .line 81
    .line 82
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    sget-object v7, La/kg;->w:Ljava/nio/charset/Charset;

    .line 86
    .line 87
    invoke-virtual {v6, v0, v1, v7}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    iput-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 92
    .line 93
    goto :goto_3

    .line 94
    :cond_3
    const/16 v1, 0x9

    .line 95
    .line 96
    if-eq v0, v1, :cond_6

    .line 97
    .line 98
    const/16 v6, 0x8

    .line 99
    .line 100
    if-ne v0, v6, :cond_4

    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_4
    if-ne v0, v5, :cond_5

    .line 104
    .line 105
    goto :goto_3

    .line 106
    :cond_5
    new-instance v0, La/P5;

    .line 107
    .line 108
    new-instance v1, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p0}, La/bL;->B1()I

    .line 114
    .line 115
    .line 116
    move-result v2

    .line 117
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v2

    .line 131
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    throw v0

    .line 142
    :cond_6
    :goto_0
    if-ne v0, v1, :cond_7

    .line 143
    .line 144
    sget-object v0, La/bL;->S:La/xi;

    .line 145
    .line 146
    :goto_1
    invoke-virtual {p0, v0}, La/bL;->yd(La/xi;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    goto :goto_2

    .line 151
    :cond_7
    sget-object v0, La/bL;->E:La/xi;

    .line 152
    .line 153
    goto :goto_1

    .line 154
    :goto_2
    iput-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 155
    .line 156
    :try_start_0
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    iput v2, p0, La/bL;->l:I

    .line 161
    .line 162
    iget-object v1, p0, La/SN;->L:[I

    .line 163
    .line 164
    iget v6, p0, La/SN;->X:I

    .line 165
    .line 166
    add-int/lit8 v6, v6, -0x1

    .line 167
    .line 168
    aget v7, v1, v6

    .line 169
    .line 170
    add-int/lit8 v7, v7, 0x1

    .line 171
    .line 172
    aput v7, v1, v6
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 173
    .line 174
    return v0

    .line 175
    :catch_0
    :goto_3
    iput v5, p0, La/bL;->l:I

    .line 176
    .line 177
    :try_start_1
    iget-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 178
    .line 179
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 180
    .line 181
    .line 182
    move-result-wide v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 183
    double-to-int v5, v0

    .line 184
    int-to-double v6, v5

    .line 185
    cmpl-double v0, v6, v0

    .line 186
    .line 187
    if-nez v0, :cond_8

    .line 188
    .line 189
    const/4 v0, 0x0

    .line 190
    iput-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 191
    .line 192
    iput v2, p0, La/bL;->l:I

    .line 193
    .line 194
    iget-object v0, p0, La/SN;->L:[I

    .line 195
    .line 196
    iget v1, p0, La/SN;->X:I

    .line 197
    .line 198
    add-int/lit8 v1, v1, -0x1

    .line 199
    .line 200
    aget v2, v0, v1

    .line 201
    .line 202
    add-int/lit8 v2, v2, 0x1

    .line 203
    .line 204
    aput v2, v0, v1

    .line 205
    .line 206
    return v5

    .line 207
    :cond_8
    new-instance v0, La/P5;

    .line 208
    .line 209
    new-instance v1, Ljava/lang/StringBuilder;

    .line 210
    .line 211
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    iget-object v2, p0, La/bL;->F:Ljava/lang/String;

    .line 215
    .line 216
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 220
    .line 221
    .line 222
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 227
    .line 228
    .line 229
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v1

    .line 233
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    throw v0

    .line 237
    :catch_1
    new-instance v0, La/P5;

    .line 238
    .line 239
    new-instance v1, Ljava/lang/StringBuilder;

    .line 240
    .line 241
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    iget-object v2, p0, La/bL;->F:Ljava/lang/String;

    .line 245
    .line 246
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 247
    .line 248
    .line 249
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 250
    .line 251
    .line 252
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object v2

    .line 256
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 257
    .line 258
    .line 259
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v1

    .line 263
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    throw v0
.end method

.method public final nA()C
    .locals 9

    .line 1
    iget-object v0, p0, La/bL;->d:La/wI;

    .line 2
    .line 3
    const-wide/16 v1, 0x1

    .line 4
    .line 5
    invoke-interface {v0, v1, v2}, La/wI;->Y(J)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_c

    .line 11
    .line 12
    iget-object v1, p0, La/bL;->f:La/WI;

    .line 13
    .line 14
    invoke-virtual {v1}, La/WI;->eH()B

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    const/16 v4, 0xa

    .line 19
    .line 20
    if-eq v3, v4, :cond_b

    .line 21
    .line 22
    const/16 v5, 0x22

    .line 23
    .line 24
    if-eq v3, v5, :cond_b

    .line 25
    .line 26
    const/16 v5, 0x27

    .line 27
    .line 28
    if-eq v3, v5, :cond_b

    .line 29
    .line 30
    const/16 v5, 0x2f

    .line 31
    .line 32
    if-eq v3, v5, :cond_b

    .line 33
    .line 34
    const/16 v5, 0x5c

    .line 35
    .line 36
    if-eq v3, v5, :cond_b

    .line 37
    .line 38
    const/16 v5, 0x62

    .line 39
    .line 40
    if-eq v3, v5, :cond_a

    .line 41
    .line 42
    const/16 v5, 0x66

    .line 43
    .line 44
    if-eq v3, v5, :cond_9

    .line 45
    .line 46
    const/16 v6, 0x6e

    .line 47
    .line 48
    if-eq v3, v6, :cond_8

    .line 49
    .line 50
    const/16 v4, 0x72

    .line 51
    .line 52
    if-eq v3, v4, :cond_7

    .line 53
    .line 54
    const/16 v4, 0x74

    .line 55
    .line 56
    if-eq v3, v4, :cond_6

    .line 57
    .line 58
    const/16 v4, 0x75

    .line 59
    .line 60
    if-ne v3, v4, :cond_5

    .line 61
    .line 62
    const-wide/16 v3, 0x4

    .line 63
    .line 64
    invoke-interface {v0, v3, v4}, La/wI;->Y(J)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_4

    .line 69
    .line 70
    const/4 v0, 0x0

    .line 71
    move v6, v0

    .line 72
    :goto_0
    const/4 v7, 0x4

    .line 73
    if-ge v0, v7, :cond_3

    .line 74
    .line 75
    int-to-long v7, v0

    .line 76
    invoke-virtual {v1, v7, v8}, La/WI;->mh(J)B

    .line 77
    .line 78
    .line 79
    move-result v7

    .line 80
    shl-int/lit8 v6, v6, 0x4

    .line 81
    .line 82
    int-to-char v6, v6

    .line 83
    const/16 v8, 0x30

    .line 84
    .line 85
    if-lt v7, v8, :cond_0

    .line 86
    .line 87
    const/16 v8, 0x39

    .line 88
    .line 89
    if-gt v7, v8, :cond_0

    .line 90
    .line 91
    add-int/lit8 v7, v7, -0x30

    .line 92
    .line 93
    :goto_1
    add-int/2addr v7, v6

    .line 94
    int-to-char v6, v7

    .line 95
    goto :goto_2

    .line 96
    :cond_0
    const/16 v8, 0x61

    .line 97
    .line 98
    if-lt v7, v8, :cond_1

    .line 99
    .line 100
    if-gt v7, v5, :cond_1

    .line 101
    .line 102
    add-int/lit8 v7, v7, -0x57

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_1
    const/16 v8, 0x41

    .line 106
    .line 107
    if-lt v7, v8, :cond_2

    .line 108
    .line 109
    const/16 v8, 0x46

    .line 110
    .line 111
    if-gt v7, v8, :cond_2

    .line 112
    .line 113
    add-int/lit8 v7, v7, -0x37

    .line 114
    .line 115
    goto :goto_1

    .line 116
    :goto_2
    add-int/lit8 v0, v0, 0x1

    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_2
    sget-object v0, La/kg;->w:Ljava/nio/charset/Charset;

    .line 120
    .line 121
    invoke-virtual {v1, v3, v4, v0}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    const-string v1, "\\u"

    .line 126
    .line 127
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-virtual {p0, v0}, La/SN;->VQ(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    throw v2

    .line 135
    :cond_3
    invoke-virtual {v1, v3, v4}, La/WI;->F(J)V

    .line 136
    .line 137
    .line 138
    return v6

    .line 139
    :cond_4
    new-instance v0, Ljava/io/EOFException;

    .line 140
    .line 141
    new-instance v1, Ljava/lang/StringBuilder;

    .line 142
    .line 143
    const-string v2, "Unterminated escape sequence at path "

    .line 144
    .line 145
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v2

    .line 152
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    throw v0

    .line 163
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string v1, "Invalid escape sequence: \\"

    .line 166
    .line 167
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    int-to-char v1, v3

    .line 171
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-virtual {p0, v0}, La/SN;->VQ(Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    throw v2

    .line 182
    :cond_6
    const/16 v0, 0x9

    .line 183
    .line 184
    return v0

    .line 185
    :cond_7
    const/16 v0, 0xd

    .line 186
    .line 187
    return v0

    .line 188
    :cond_8
    return v4

    .line 189
    :cond_9
    const/16 v0, 0xc

    .line 190
    .line 191
    return v0

    .line 192
    :cond_a
    const/16 v0, 0x8

    .line 193
    .line 194
    return v0

    .line 195
    :cond_b
    int-to-char v0, v3

    .line 196
    return v0

    .line 197
    :cond_c
    const-string v0, "Unterminated escape sequence"

    .line 198
    .line 199
    invoke-virtual {p0, v0}, La/SN;->VQ(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    throw v2
.end method

.method public final rZ()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/16 v1, 0xa

    .line 10
    .line 11
    if-ne v0, v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, La/bL;->C6()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    const/16 v1, 0x9

    .line 19
    .line 20
    if-ne v0, v1, :cond_2

    .line 21
    .line 22
    sget-object v0, La/bL;->S:La/xi;

    .line 23
    .line 24
    :goto_0
    invoke-virtual {p0, v0}, La/bL;->yd(La/xi;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    goto :goto_1

    .line 29
    :cond_2
    const/16 v1, 0x8

    .line 30
    .line 31
    if-ne v0, v1, :cond_3

    .line 32
    .line 33
    sget-object v0, La/bL;->E:La/xi;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_3
    const/16 v1, 0xb

    .line 37
    .line 38
    if-ne v0, v1, :cond_4

    .line 39
    .line 40
    iget-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 41
    .line 42
    const/4 v1, 0x0

    .line 43
    iput-object v1, p0, La/bL;->F:Ljava/lang/String;

    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_4
    const/16 v1, 0x10

    .line 47
    .line 48
    if-ne v0, v1, :cond_5

    .line 49
    .line 50
    iget-wide v0, p0, La/bL;->W:J

    .line 51
    .line 52
    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    goto :goto_1

    .line 57
    :cond_5
    const/16 v1, 0x11

    .line 58
    .line 59
    if-ne v0, v1, :cond_6

    .line 60
    .line 61
    iget v0, p0, La/bL;->q:I

    .line 62
    .line 63
    int-to-long v0, v0

    .line 64
    iget-object v2, p0, La/bL;->f:La/WI;

    .line 65
    .line 66
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    sget-object v3, La/kg;->w:Ljava/nio/charset/Charset;

    .line 70
    .line 71
    invoke-virtual {v2, v0, v1, v3}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    :goto_1
    const/4 v1, 0x0

    .line 76
    iput v1, p0, La/bL;->l:I

    .line 77
    .line 78
    iget-object v1, p0, La/SN;->L:[I

    .line 79
    .line 80
    iget v2, p0, La/SN;->X:I

    .line 81
    .line 82
    add-int/lit8 v2, v2, -0x1

    .line 83
    .line 84
    aget v3, v1, v2

    .line 85
    .line 86
    add-int/lit8 v3, v3, 0x1

    .line 87
    .line 88
    aput v3, v1, v2

    .line 89
    .line 90
    return-object v0

    .line 91
    :cond_6
    new-instance v0, La/P5;

    .line 92
    .line 93
    new-instance v1, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    const-string v2, "Expected a string but was "

    .line 96
    .line 97
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p0}, La/bL;->B1()I

    .line 101
    .line 102
    .line 103
    move-result v2

    .line 104
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    const-string v2, " at path "

    .line 112
    .line 113
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "JsonReader("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, La/bL;->d:La/wI;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w()V
    .locals 3

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/4 v1, 0x3

    .line 10
    if-ne v0, v1, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    invoke-virtual {p0, v0}, La/SN;->y6(I)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, La/SN;->L:[I

    .line 17
    .line 18
    iget v2, p0, La/SN;->X:I

    .line 19
    .line 20
    sub-int/2addr v2, v0

    .line 21
    const/4 v0, 0x0

    .line 22
    aput v0, v1, v2

    .line 23
    .line 24
    iput v0, p0, La/bL;->l:I

    .line 25
    .line 26
    return-void

    .line 27
    :cond_1
    new-instance v0, La/P5;

    .line 28
    .line 29
    new-instance v1, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    const-string v2, "Expected BEGIN_ARRAY but was "

    .line 32
    .line 33
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0}, La/bL;->B1()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string v2, " at path "

    .line 48
    .line 49
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    throw v0
.end method

.method public final x()D
    .locals 8

    .line 1
    iget v0, p0, La/bL;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, La/bL;->Gy()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    :cond_0
    const/16 v1, 0x10

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_1

    .line 13
    .line 14
    iput v2, p0, La/bL;->l:I

    .line 15
    .line 16
    iget-object v0, p0, La/SN;->L:[I

    .line 17
    .line 18
    iget v1, p0, La/SN;->X:I

    .line 19
    .line 20
    add-int/lit8 v1, v1, -0x1

    .line 21
    .line 22
    aget v2, v0, v1

    .line 23
    .line 24
    add-int/lit8 v2, v2, 0x1

    .line 25
    .line 26
    aput v2, v0, v1

    .line 27
    .line 28
    iget-wide v0, p0, La/bL;->W:J

    .line 29
    .line 30
    long-to-double v0, v0

    .line 31
    return-wide v0

    .line 32
    :cond_1
    const/16 v1, 0x11

    .line 33
    .line 34
    const-string v3, "Expected a double but was "

    .line 35
    .line 36
    const/16 v4, 0xb

    .line 37
    .line 38
    const-string v5, " at path "

    .line 39
    .line 40
    if-ne v0, v1, :cond_2

    .line 41
    .line 42
    iget v0, p0, La/bL;->q:I

    .line 43
    .line 44
    int-to-long v0, v0

    .line 45
    iget-object v6, p0, La/bL;->f:La/WI;

    .line 46
    .line 47
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    sget-object v7, La/kg;->w:Ljava/nio/charset/Charset;

    .line 51
    .line 52
    invoke-virtual {v6, v0, v1, v7}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    :goto_0
    iput-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 57
    .line 58
    goto :goto_2

    .line 59
    :cond_2
    const/16 v1, 0x9

    .line 60
    .line 61
    if-ne v0, v1, :cond_3

    .line 62
    .line 63
    sget-object v0, La/bL;->S:La/xi;

    .line 64
    .line 65
    :goto_1
    invoke-virtual {p0, v0}, La/bL;->yd(La/xi;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    goto :goto_0

    .line 70
    :cond_3
    const/16 v1, 0x8

    .line 71
    .line 72
    if-ne v0, v1, :cond_4

    .line 73
    .line 74
    sget-object v0, La/bL;->E:La/xi;

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_4
    const/16 v1, 0xa

    .line 78
    .line 79
    if-ne v0, v1, :cond_5

    .line 80
    .line 81
    invoke-virtual {p0}, La/bL;->C6()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    goto :goto_0

    .line 86
    :cond_5
    if-ne v0, v4, :cond_7

    .line 87
    .line 88
    :goto_2
    iput v4, p0, La/bL;->l:I

    .line 89
    .line 90
    :try_start_0
    iget-object v0, p0, La/bL;->F:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 93
    .line 94
    .line 95
    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 96
    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    .line 97
    .line 98
    .line 99
    move-result v3

    .line 100
    if-nez v3, :cond_6

    .line 101
    .line 102
    invoke-static {v0, v1}, Ljava/lang/Double;->isInfinite(D)Z

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    if-nez v3, :cond_6

    .line 107
    .line 108
    const/4 v3, 0x0

    .line 109
    iput-object v3, p0, La/bL;->F:Ljava/lang/String;

    .line 110
    .line 111
    iput v2, p0, La/bL;->l:I

    .line 112
    .line 113
    iget-object v2, p0, La/SN;->L:[I

    .line 114
    .line 115
    iget v3, p0, La/SN;->X:I

    .line 116
    .line 117
    add-int/lit8 v3, v3, -0x1

    .line 118
    .line 119
    aget v4, v2, v3

    .line 120
    .line 121
    add-int/lit8 v4, v4, 0x1

    .line 122
    .line 123
    aput v4, v2, v3

    .line 124
    .line 125
    return-wide v0

    .line 126
    :cond_6
    new-instance v2, La/tH;

    .line 127
    .line 128
    new-instance v3, Ljava/lang/StringBuilder;

    .line 129
    .line 130
    const-string v4, "JSON forbids NaN and infinities: "

    .line 131
    .line 132
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    invoke-direct {v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    throw v2

    .line 156
    :catch_0
    new-instance v0, La/P5;

    .line 157
    .line 158
    new-instance v1, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    iget-object v2, p0, La/bL;->F:Ljava/lang/String;

    .line 164
    .line 165
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw v0

    .line 186
    :cond_7
    new-instance v0, La/P5;

    .line 187
    .line 188
    new-instance v1, Ljava/lang/StringBuilder;

    .line 189
    .line 190
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {p0}, La/bL;->B1()I

    .line 194
    .line 195
    .line 196
    move-result v2

    .line 197
    invoke-static {v2}, La/zq;->H(I)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    invoke-virtual {p0}, La/SN;->f()Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v2

    .line 211
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    throw v0
.end method

.method public final xF(La/dh;)I
    .locals 4

    .line 1
    iget v0, p0, La/bL;->l:I

    if-nez v0, :cond_0

    invoke-virtual {p0}, La/bL;->Gy()I

    move-result v0

    :cond_0
    const/16 v1, 0xc

    const/4 v2, -0x1

    if-lt v0, v1, :cond_5

    const/16 v1, 0xf

    if-le v0, v1, :cond_1

    goto :goto_0

    :cond_1
    if-ne v0, v1, :cond_2

    iget-object v0, p0, La/bL;->F:Ljava/lang/String;

    invoke-virtual {p0, v0, p1}, La/bL;->NE(Ljava/lang/String;La/dh;)I

    move-result p1

    return p1

    :cond_2
    iget-object v0, p1, La/dh;->R:Ljava/lang/Object;

    check-cast v0, La/xj;

    iget-object v3, p0, La/bL;->d:La/wI;

    invoke-interface {v3, v0}, La/wI;->u(La/xj;)I

    move-result v0

    if-eq v0, v2, :cond_3

    const/4 v1, 0x0

    iput v1, p0, La/bL;->l:I

    iget-object v1, p0, La/SN;->R:[Ljava/lang/String;

    iget v2, p0, La/SN;->X:I

    add-int/lit8 v2, v2, -0x1

    iget-object p1, p1, La/dh;->K:Ljava/lang/Object;

    check-cast p1, [Ljava/lang/String;

    aget-object p1, p1, v0

    aput-object p1, v1, v2

    return v0

    :cond_3
    iget-object v0, p0, La/SN;->R:[Ljava/lang/String;

    iget v3, p0, La/SN;->X:I

    add-int/lit8 v3, v3, -0x1

    aget-object v0, v0, v3

    invoke-virtual {p0}, La/bL;->Qg()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3, p1}, La/bL;->NE(Ljava/lang/String;La/dh;)I

    move-result p1

    if-ne p1, v2, :cond_4

    iput v1, p0, La/bL;->l:I

    iput-object v3, p0, La/bL;->F:Ljava/lang/String;

    iget-object v1, p0, La/SN;->R:[Ljava/lang/String;

    iget v2, p0, La/SN;->X:I

    add-int/lit8 v2, v2, -0x1

    aput-object v0, v1, v2

    :cond_4
    return p1

    :cond_5
    :goto_0
    return v2
.end method

.method public final yd(La/xi;)Ljava/lang/String;
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    move-object v1, v0

    .line 3
    :goto_0
    iget-object v2, p0, La/bL;->d:La/wI;

    .line 4
    .line 5
    invoke-interface {v2, p1}, La/wI;->n(La/xi;)J

    .line 6
    .line 7
    .line 8
    move-result-wide v2

    .line 9
    const-wide/16 v4, -0x1

    .line 10
    .line 11
    cmp-long v4, v2, v4

    .line 12
    .line 13
    if-eqz v4, :cond_3

    .line 14
    .line 15
    iget-object v4, p0, La/bL;->f:La/WI;

    .line 16
    .line 17
    invoke-virtual {v4, v2, v3}, La/WI;->mh(J)B

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    const/16 v6, 0x5c

    .line 22
    .line 23
    if-ne v5, v6, :cond_1

    .line 24
    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    new-instance v1, Ljava/lang/StringBuilder;

    .line 28
    .line 29
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 30
    .line 31
    .line 32
    :cond_0
    sget-object v5, La/kg;->w:Ljava/nio/charset/Charset;

    .line 33
    .line 34
    invoke-virtual {v4, v2, v3, v5}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v4}, La/WI;->eH()B

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0}, La/bL;->nA()C

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    if-nez v1, :cond_2

    .line 53
    .line 54
    sget-object p1, La/kg;->w:Ljava/nio/charset/Charset;

    .line 55
    .line 56
    invoke-virtual {v4, v2, v3, p1}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-virtual {v4}, La/WI;->eH()B

    .line 61
    .line 62
    .line 63
    return-object p1

    .line 64
    :cond_2
    sget-object p1, La/kg;->w:Ljava/nio/charset/Charset;

    .line 65
    .line 66
    invoke-virtual {v4, v2, v3, p1}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v4}, La/WI;->eH()B

    .line 74
    .line 75
    .line 76
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    return-object p1

    .line 81
    :cond_3
    const-string p1, "Unterminated string"

    .line 82
    .line 83
    invoke-virtual {p0, p1}, La/SN;->VQ(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    throw v0
.end method
