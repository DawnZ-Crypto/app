.class public final Lcom/topjohnwu/magisk/core/model/ModuleJson;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime La/my;
    generateAdapter = true
.end annotation


# instance fields
.field public final e:Ljava/lang/String;

.field public final h:I

.field public final p:Ljava/lang/String;

.field public final w:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    iput p2, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    iput-object p3, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    iput-object p4, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    check-cast p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;

    iget-object v1, p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    iget-object v3, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    invoke-static {v3, v1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v2

    :cond_2
    iget v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    iget v3, p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    if-eq v1, v3, :cond_3

    return v2

    :cond_3
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    iget-object v3, p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    invoke-static {v1, v3}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    return v2

    :cond_4
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    iget-object p1, p1, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    invoke-static {v1, p1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5

    return v2

    :cond_5
    return v0
.end method

.method public final hashCode()I
    .locals 2

    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ModuleJson(version="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", versionCode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", zipUrl="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", changelog="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
