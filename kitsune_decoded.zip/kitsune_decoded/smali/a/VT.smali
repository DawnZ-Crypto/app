.class public La/VT;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic F:I


# instance fields
.field public K:La/mE;

.field public L:Ljava/lang/CharSequence;

.field public R:Ljava/lang/String;

.field public W:I

.field public final X:Ljava/lang/String;

.field public final d:Ljava/util/ArrayList;

.field public final f:La/a1;

.field public final l:Ljava/util/LinkedHashMap;

.field public q:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    return-void
.end method

.method public constructor <init>(La/Z5;)V
    .locals 1

    .line 1
    sget-object v0, La/zd;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-static {p1}, La/eI;->K(Ljava/lang/Class;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, La/VT;-><init>(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/VT;->X:Ljava/lang/String;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La/VT;->d:Ljava/util/ArrayList;

    new-instance p1, La/a1;

    invoke-direct {p1}, La/a1;-><init>()V

    iput-object p1, p0, La/VT;->f:La/a1;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, La/VT;->l:Ljava/util/LinkedHashMap;

    return-void
.end method


# virtual methods
.method public final O(Ljava/lang/String;)La/Nd;
    .locals 3

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    const-string v0, "android-app://androidx.navigation/"

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const-string p1, ""

    .line 11
    .line 12
    :goto_0
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    new-instance v0, La/yW;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    const/16 v2, 0x9

    .line 20
    .line 21
    invoke-direct {v0, p1, v1, v1, v2}, La/yW;-><init>(Landroid/net/Uri;Ljava/lang/Object;Ljava/lang/Comparable;I)V

    .line 22
    .line 23
    .line 24
    instance-of p1, p0, La/mE;

    .line 25
    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    move-object p1, p0

    .line 29
    check-cast p1, La/mE;

    .line 30
    .line 31
    invoke-virtual {p1, v0}, La/mE;->m(La/yW;)La/Nd;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    invoke-virtual {p0, v0}, La/VT;->Q(La/yW;)La/Nd;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    :goto_1
    return-object p1
.end method

.method public Q(La/yW;)La/Nd;
    .locals 19

    .line 1
    move-object/from16 v7, p0

    .line 2
    .line 3
    move-object/from16 v8, p1

    .line 4
    .line 5
    iget-object v0, v7, La/VT;->d:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v9, 0x0

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    return-object v9

    .line 15
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v10

    .line 19
    move-object v11, v9

    .line 20
    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_24

    .line 25
    .line 26
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, La/By;

    .line 31
    .line 32
    iget-object v1, v8, La/yW;->K:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v1, Landroid/net/Uri;

    .line 35
    .line 36
    iget-object v2, v7, La/VT;->l:Ljava/util/LinkedHashMap;

    .line 37
    .line 38
    if-eqz v1, :cond_c

    .line 39
    .line 40
    iget-object v5, v0, La/By;->Q:La/Yi;

    .line 41
    .line 42
    invoke-virtual {v5}, La/Yi;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v5

    .line 46
    check-cast v5, Ljava/util/regex/Pattern;

    .line 47
    .line 48
    if-eqz v5, :cond_1

    .line 49
    .line 50
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v6

    .line 54
    invoke-virtual {v5, v6}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    goto :goto_1

    .line 59
    :cond_1
    move-object v5, v9

    .line 60
    :goto_1
    if-nez v5, :cond_2

    .line 61
    .line 62
    goto/16 :goto_6

    .line 63
    .line 64
    :cond_2
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->matches()Z

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    if-nez v6, :cond_3

    .line 69
    .line 70
    goto/16 :goto_6

    .line 71
    .line 72
    :cond_3
    new-instance v6, Landroid/os/Bundle;

    .line 73
    .line 74
    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, v5, v6, v2}, La/By;->h(Ljava/util/regex/Matcher;Landroid/os/Bundle;Ljava/util/LinkedHashMap;)Z

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    if-nez v5, :cond_4

    .line 82
    .line 83
    goto/16 :goto_6

    .line 84
    .line 85
    :cond_4
    iget-object v5, v0, La/By;->X:La/Yi;

    .line 86
    .line 87
    invoke-virtual {v5}, La/Yi;->getValue()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    check-cast v5, Ljava/lang/Boolean;

    .line 92
    .line 93
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    if-eqz v5, :cond_5

    .line 98
    .line 99
    invoke-virtual {v0, v1, v6, v2}, La/By;->p(Landroid/net/Uri;Landroid/os/Bundle;Ljava/util/LinkedHashMap;)Z

    .line 100
    .line 101
    .line 102
    move-result v5

    .line 103
    if-nez v5, :cond_5

    .line 104
    .line 105
    goto/16 :goto_6

    .line 106
    .line 107
    :cond_5
    invoke-virtual {v1}, Landroid/net/Uri;->getFragment()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    iget-object v12, v0, La/By;->m:La/Yi;

    .line 112
    .line 113
    invoke-virtual {v12}, La/Yi;->getValue()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v12

    .line 117
    check-cast v12, Ljava/util/regex/Pattern;

    .line 118
    .line 119
    if-eqz v12, :cond_6

    .line 120
    .line 121
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v5

    .line 125
    invoke-virtual {v12, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    goto :goto_2

    .line 130
    :cond_6
    move-object v5, v9

    .line 131
    :goto_2
    if-nez v5, :cond_7

    .line 132
    .line 133
    goto :goto_5

    .line 134
    :cond_7
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->matches()Z

    .line 135
    .line 136
    .line 137
    move-result v12

    .line 138
    if-nez v12, :cond_8

    .line 139
    .line 140
    goto :goto_5

    .line 141
    :cond_8
    iget-object v12, v0, La/By;->M:La/Y0;

    .line 142
    .line 143
    invoke-interface {v12}, La/Y0;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v12

    .line 147
    check-cast v12, Ljava/util/List;

    .line 148
    .line 149
    new-instance v13, Ljava/util/ArrayList;

    .line 150
    .line 151
    invoke-static {v12}, La/cl;->DT(Ljava/lang/Iterable;)I

    .line 152
    .line 153
    .line 154
    move-result v14

    .line 155
    invoke-direct {v13, v14}, Ljava/util/ArrayList;-><init>(I)V

    .line 156
    .line 157
    .line 158
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 159
    .line 160
    .line 161
    move-result-object v12

    .line 162
    const/4 v14, 0x0

    .line 163
    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 164
    .line 165
    .line 166
    move-result v15

    .line 167
    if-eqz v15, :cond_b

    .line 168
    .line 169
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v15

    .line 173
    add-int/lit8 v3, v14, 0x1

    .line 174
    .line 175
    if-ltz v14, :cond_a

    .line 176
    .line 177
    check-cast v15, Ljava/lang/String;

    .line 178
    .line 179
    invoke-virtual {v5, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v14

    .line 183
    invoke-static {v14}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v14

    .line 187
    invoke-virtual {v2, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v17

    .line 191
    move-object/from16 v4, v17

    .line 192
    .line 193
    check-cast v4, La/bj;

    .line 194
    .line 195
    if-eqz v4, :cond_9

    .line 196
    .line 197
    :try_start_0
    iget-object v4, v4, La/bj;->w:La/vo;

    .line 198
    .line 199
    invoke-virtual {v4, v14}, La/vo;->p(Ljava/lang/String;)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v14

    .line 203
    invoke-virtual {v4, v6, v15, v14}, La/vo;->i(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    goto :goto_4

    .line 207
    :cond_9
    invoke-virtual {v6, v15, v14}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 208
    .line 209
    .line 210
    :goto_4
    sget-object v4, La/rr;->w:La/rr;

    .line 211
    .line 212
    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move v14, v3

    .line 216
    goto :goto_3

    .line 217
    :cond_a
    invoke-static {}, La/rE;->cC()V

    .line 218
    .line 219
    .line 220
    throw v9

    .line 221
    :catch_0
    :cond_b
    :goto_5
    new-instance v3, La/Rw;

    .line 222
    .line 223
    const/4 v4, 0x0

    .line 224
    invoke-direct {v3, v4, v6}, La/Rw;-><init>(ILandroid/os/Bundle;)V

    .line 225
    .line 226
    .line 227
    invoke-static {v2, v3}, La/rE;->Qg(Ljava/util/LinkedHashMap;La/nY;)Ljava/util/ArrayList;

    .line 228
    .line 229
    .line 230
    move-result-object v3

    .line 231
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 232
    .line 233
    .line 234
    move-result v3

    .line 235
    const/4 v4, 0x1

    .line 236
    xor-int/2addr v3, v4

    .line 237
    if-eqz v3, :cond_d

    .line 238
    .line 239
    :cond_c
    :goto_6
    move-object v6, v9

    .line 240
    :cond_d
    if-eqz v1, :cond_10

    .line 241
    .line 242
    iget-object v3, v0, La/By;->w:Ljava/lang/String;

    .line 243
    .line 244
    if-nez v3, :cond_e

    .line 245
    .line 246
    goto :goto_8

    .line 247
    :cond_e
    invoke-virtual {v1}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    .line 248
    .line 249
    .line 250
    move-result-object v4

    .line 251
    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    invoke-virtual {v3}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    .line 256
    .line 257
    .line 258
    move-result-object v3

    .line 259
    instance-of v5, v4, Ljava/util/Collection;

    .line 260
    .line 261
    if-eqz v5, :cond_f

    .line 262
    .line 263
    new-instance v5, Ljava/util/LinkedHashSet;

    .line 264
    .line 265
    invoke-direct {v5, v4}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    .line 266
    .line 267
    .line 268
    goto :goto_7

    .line 269
    :cond_f
    new-instance v5, Ljava/util/LinkedHashSet;

    .line 270
    .line 271
    invoke-direct {v5}, Ljava/util/LinkedHashSet;-><init>()V

    .line 272
    .line 273
    .line 274
    invoke-static {v4, v5}, La/ar;->lB(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    .line 275
    .line 276
    .line 277
    :goto_7
    invoke-interface {v5, v3}, Ljava/util/Collection;->retainAll(Ljava/util/Collection;)Z

    .line 278
    .line 279
    .line 280
    invoke-interface {v5}, Ljava/util/Set;->size()I

    .line 281
    .line 282
    .line 283
    move-result v3

    .line 284
    move v4, v3

    .line 285
    goto :goto_9

    .line 286
    :cond_10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 287
    .line 288
    .line 289
    :goto_8
    const/4 v4, 0x0

    .line 290
    :goto_9
    iget-object v3, v8, La/yW;->R:Ljava/lang/Object;

    .line 291
    .line 292
    check-cast v3, Ljava/lang/String;

    .line 293
    .line 294
    if-eqz v3, :cond_11

    .line 295
    .line 296
    iget-object v5, v0, La/By;->h:Ljava/lang/String;

    .line 297
    .line 298
    invoke-static {v3, v5}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v3

    .line 302
    if-eqz v3, :cond_11

    .line 303
    .line 304
    const/4 v5, 0x1

    .line 305
    goto :goto_a

    .line 306
    :cond_11
    const/4 v5, 0x0

    .line 307
    :goto_a
    iget-object v3, v8, La/yW;->L:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v3, Ljava/lang/String;

    .line 310
    .line 311
    if-eqz v3, :cond_1a

    .line 312
    .line 313
    iget-object v13, v0, La/By;->p:Ljava/lang/String;

    .line 314
    .line 315
    if-eqz v13, :cond_18

    .line 316
    .line 317
    iget-object v14, v0, La/By;->K:La/Yi;

    .line 318
    .line 319
    invoke-virtual {v14}, La/Yi;->getValue()Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    move-result-object v14

    .line 323
    check-cast v14, Ljava/util/regex/Pattern;

    .line 324
    .line 325
    invoke-virtual {v14, v3}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 326
    .line 327
    .line 328
    move-result-object v14

    .line 329
    invoke-virtual {v14}, Ljava/util/regex/Matcher;->matches()Z

    .line 330
    .line 331
    .line 332
    move-result v14

    .line 333
    if-nez v14, :cond_12

    .line 334
    .line 335
    goto/16 :goto_11

    .line 336
    .line 337
    :cond_12
    new-instance v14, La/FY;

    .line 338
    .line 339
    const-string v15, "/"

    .line 340
    .line 341
    invoke-direct {v14, v15}, La/FY;-><init>(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    const/4 v9, 0x0

    .line 345
    invoke-virtual {v14, v9, v13}, La/FY;->w(ILjava/lang/CharSequence;)Ljava/util/List;

    .line 346
    .line 347
    .line 348
    move-result-object v13

    .line 349
    invoke-interface {v13}, Ljava/util/List;->isEmpty()Z

    .line 350
    .line 351
    .line 352
    move-result v9

    .line 353
    sget-object v14, La/LL;->X:La/LL;

    .line 354
    .line 355
    if-nez v9, :cond_14

    .line 356
    .line 357
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 358
    .line 359
    .line 360
    move-result v9

    .line 361
    invoke-interface {v13, v9}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 362
    .line 363
    .line 364
    move-result-object v9

    .line 365
    :goto_b
    invoke-interface {v9}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 366
    .line 367
    .line 368
    move-result v18

    .line 369
    if-eqz v18, :cond_14

    .line 370
    .line 371
    invoke-interface {v9}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    move-result-object v18

    .line 375
    check-cast v18, Ljava/lang/String;

    .line 376
    .line 377
    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->length()I

    .line 378
    .line 379
    .line 380
    move-result v18

    .line 381
    if-nez v18, :cond_13

    .line 382
    .line 383
    goto :goto_b

    .line 384
    :cond_13
    invoke-interface {v9}, Ljava/util/ListIterator;->nextIndex()I

    .line 385
    .line 386
    .line 387
    move-result v9

    .line 388
    const/4 v12, 0x1

    .line 389
    add-int/2addr v9, v12

    .line 390
    invoke-static {v13, v9}, La/ar;->JF(Ljava/util/List;I)Ljava/util/List;

    .line 391
    .line 392
    .line 393
    move-result-object v9

    .line 394
    :goto_c
    const/4 v13, 0x0

    .line 395
    goto :goto_d

    .line 396
    :cond_14
    const/4 v12, 0x1

    .line 397
    move-object v9, v14

    .line 398
    goto :goto_c

    .line 399
    :goto_d
    invoke-interface {v9, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 400
    .line 401
    .line 402
    move-result-object v16

    .line 403
    move-object/from16 v13, v16

    .line 404
    .line 405
    check-cast v13, Ljava/lang/String;

    .line 406
    .line 407
    invoke-interface {v9, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v9

    .line 411
    check-cast v9, Ljava/lang/String;

    .line 412
    .line 413
    new-instance v12, La/FY;

    .line 414
    .line 415
    invoke-direct {v12, v15}, La/FY;-><init>(Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    const/4 v15, 0x0

    .line 419
    invoke-virtual {v12, v15, v3}, La/FY;->w(ILjava/lang/CharSequence;)Ljava/util/List;

    .line 420
    .line 421
    .line 422
    move-result-object v3

    .line 423
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 424
    .line 425
    .line 426
    move-result v12

    .line 427
    if-nez v12, :cond_16

    .line 428
    .line 429
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 430
    .line 431
    .line 432
    move-result v12

    .line 433
    invoke-interface {v3, v12}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 434
    .line 435
    .line 436
    move-result-object v12

    .line 437
    :goto_e
    invoke-interface {v12}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 438
    .line 439
    .line 440
    move-result v15

    .line 441
    if-eqz v15, :cond_16

    .line 442
    .line 443
    invoke-interface {v12}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v15

    .line 447
    check-cast v15, Ljava/lang/String;

    .line 448
    .line 449
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    .line 450
    .line 451
    .line 452
    move-result v15

    .line 453
    if-nez v15, :cond_15

    .line 454
    .line 455
    goto :goto_e

    .line 456
    :cond_15
    invoke-interface {v12}, Ljava/util/ListIterator;->nextIndex()I

    .line 457
    .line 458
    .line 459
    move-result v12

    .line 460
    const/4 v15, 0x1

    .line 461
    add-int/2addr v12, v15

    .line 462
    invoke-static {v3, v12}, La/ar;->JF(Ljava/util/List;I)Ljava/util/List;

    .line 463
    .line 464
    .line 465
    move-result-object v14

    .line 466
    :goto_f
    const/4 v3, 0x0

    .line 467
    goto :goto_10

    .line 468
    :cond_16
    const/4 v15, 0x1

    .line 469
    goto :goto_f

    .line 470
    :goto_10
    invoke-interface {v14, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 471
    .line 472
    .line 473
    move-result-object v12

    .line 474
    check-cast v12, Ljava/lang/String;

    .line 475
    .line 476
    invoke-interface {v14, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v14

    .line 480
    check-cast v14, Ljava/lang/String;

    .line 481
    .line 482
    invoke-static {v13, v12}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v12

    .line 486
    if-eqz v12, :cond_17

    .line 487
    .line 488
    const/4 v3, 0x2

    .line 489
    :cond_17
    invoke-static {v9, v14}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 490
    .line 491
    .line 492
    move-result v9

    .line 493
    if-eqz v9, :cond_19

    .line 494
    .line 495
    add-int/lit8 v3, v3, 0x1

    .line 496
    .line 497
    goto :goto_12

    .line 498
    :cond_18
    :goto_11
    const/4 v3, -0x1

    .line 499
    :cond_19
    :goto_12
    move v9, v3

    .line 500
    goto :goto_13

    .line 501
    :cond_1a
    const/4 v9, -0x1

    .line 502
    :goto_13
    if-nez v6, :cond_21

    .line 503
    .line 504
    if-nez v5, :cond_1b

    .line 505
    .line 506
    const/4 v3, -0x1

    .line 507
    if-le v9, v3, :cond_22

    .line 508
    .line 509
    :cond_1b
    new-instance v3, Landroid/os/Bundle;

    .line 510
    .line 511
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 512
    .line 513
    .line 514
    if-nez v1, :cond_1c

    .line 515
    .line 516
    goto :goto_15

    .line 517
    :cond_1c
    iget-object v12, v0, La/By;->Q:La/Yi;

    .line 518
    .line 519
    invoke-virtual {v12}, La/Yi;->getValue()Ljava/lang/Object;

    .line 520
    .line 521
    .line 522
    move-result-object v12

    .line 523
    check-cast v12, Ljava/util/regex/Pattern;

    .line 524
    .line 525
    if-eqz v12, :cond_1d

    .line 526
    .line 527
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 528
    .line 529
    .line 530
    move-result-object v13

    .line 531
    invoke-virtual {v12, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 532
    .line 533
    .line 534
    move-result-object v12

    .line 535
    goto :goto_14

    .line 536
    :cond_1d
    const/4 v12, 0x0

    .line 537
    :goto_14
    if-nez v12, :cond_1e

    .line 538
    .line 539
    goto :goto_15

    .line 540
    :cond_1e
    invoke-virtual {v12}, Ljava/util/regex/Matcher;->matches()Z

    .line 541
    .line 542
    .line 543
    move-result v13

    .line 544
    if-nez v13, :cond_1f

    .line 545
    .line 546
    goto :goto_15

    .line 547
    :cond_1f
    invoke-virtual {v0, v12, v3, v2}, La/By;->h(Ljava/util/regex/Matcher;Landroid/os/Bundle;Ljava/util/LinkedHashMap;)Z

    .line 548
    .line 549
    .line 550
    iget-object v12, v0, La/By;->X:La/Yi;

    .line 551
    .line 552
    invoke-virtual {v12}, La/Yi;->getValue()Ljava/lang/Object;

    .line 553
    .line 554
    .line 555
    move-result-object v12

    .line 556
    check-cast v12, Ljava/lang/Boolean;

    .line 557
    .line 558
    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    .line 559
    .line 560
    .line 561
    move-result v12

    .line 562
    if-eqz v12, :cond_20

    .line 563
    .line 564
    invoke-virtual {v0, v1, v3, v2}, La/By;->p(Landroid/net/Uri;Landroid/os/Bundle;Ljava/util/LinkedHashMap;)Z

    .line 565
    .line 566
    .line 567
    :cond_20
    :goto_15
    new-instance v1, La/Rw;

    .line 568
    .line 569
    const/4 v12, 0x1

    .line 570
    invoke-direct {v1, v12, v3}, La/Rw;-><init>(ILandroid/os/Bundle;)V

    .line 571
    .line 572
    .line 573
    invoke-static {v2, v1}, La/rE;->Qg(Ljava/util/LinkedHashMap;La/nY;)Ljava/util/ArrayList;

    .line 574
    .line 575
    .line 576
    move-result-object v1

    .line 577
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 578
    .line 579
    .line 580
    move-result v1

    .line 581
    if-eqz v1, :cond_22

    .line 582
    .line 583
    :cond_21
    new-instance v12, La/Nd;

    .line 584
    .line 585
    iget-boolean v3, v0, La/By;->R:Z

    .line 586
    .line 587
    move-object v0, v12

    .line 588
    move-object/from16 v1, p0

    .line 589
    .line 590
    move-object v2, v6

    .line 591
    move v6, v9

    .line 592
    invoke-direct/range {v0 .. v6}, La/Nd;-><init>(La/VT;Landroid/os/Bundle;ZIZI)V

    .line 593
    .line 594
    .line 595
    if-eqz v11, :cond_23

    .line 596
    .line 597
    invoke-virtual {v12, v11}, La/Nd;->w(La/Nd;)I

    .line 598
    .line 599
    .line 600
    move-result v0

    .line 601
    if-lez v0, :cond_22

    .line 602
    .line 603
    goto :goto_17

    .line 604
    :cond_22
    :goto_16
    const/4 v9, 0x0

    .line 605
    goto/16 :goto_0

    .line 606
    .line 607
    :cond_23
    :goto_17
    move-object v11, v12

    .line 608
    goto :goto_16

    .line 609
    :cond_24
    return-object v11
.end method

.method public V(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 10

    .line 1
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, La/Cn;->i:[I

    .line 6
    .line 7
    invoke-virtual {v0, p2, v1}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    const/4 v0, 0x2

    .line 12
    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    const-string v1, "android-app://androidx.navigation/"

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    const/4 v3, 0x1

    .line 20
    const/4 v4, 0x0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    iput v4, p0, La/VT;->W:I

    .line 24
    .line 25
    iput-object v2, p0, La/VT;->R:Ljava/lang/String;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-static {v0}, La/ge;->sH(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    xor-int/2addr v5, v3

    .line 33
    if-eqz v5, :cond_5

    .line 34
    .line 35
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    iput v6, p0, La/VT;->W:I

    .line 44
    .line 45
    iput-object v2, p0, La/VT;->R:Ljava/lang/String;

    .line 46
    .line 47
    new-instance v6, La/By;

    .line 48
    .line 49
    invoke-direct {v6, v5, v2, v2}, La/By;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0, v6}, La/VT;->h(La/By;)V

    .line 53
    .line 54
    .line 55
    :goto_0
    iget-object v5, p0, La/VT;->d:Ljava/util/ArrayList;

    .line 56
    .line 57
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    :cond_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 62
    .line 63
    .line 64
    move-result v7

    .line 65
    if-eqz v7, :cond_3

    .line 66
    .line 67
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    move-object v8, v7

    .line 72
    check-cast v8, La/By;

    .line 73
    .line 74
    iget-object v8, v8, La/By;->w:Ljava/lang/String;

    .line 75
    .line 76
    iget-object v9, p0, La/VT;->q:Ljava/lang/String;

    .line 77
    .line 78
    if-eqz v9, :cond_2

    .line 79
    .line 80
    invoke-virtual {v1, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    goto :goto_1

    .line 85
    :cond_2
    const-string v9, ""

    .line 86
    .line 87
    :goto_1
    invoke-static {v8, v9}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v8

    .line 91
    if-eqz v8, :cond_1

    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_3
    move-object v7, v2

    .line 95
    :goto_2
    invoke-static {v5}, La/A8;->X(Ljava/util/AbstractCollection;)Ljava/util/Collection;

    .line 96
    .line 97
    .line 98
    invoke-interface {v5, v7}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    iput-object v0, p0, La/VT;->q:Ljava/lang/String;

    .line 102
    .line 103
    invoke-virtual {p2, v3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_4

    .line 108
    .line 109
    invoke-virtual {p2, v3, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    iput v0, p0, La/VT;->W:I

    .line 114
    .line 115
    iput-object v2, p0, La/VT;->R:Ljava/lang/String;

    .line 116
    .line 117
    invoke-static {p1, v0}, La/eI;->T(Landroid/content/Context;I)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    iput-object p1, p0, La/VT;->R:Ljava/lang/String;

    .line 122
    .line 123
    :cond_4
    invoke-virtual {p2, v4}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    iput-object p1, p0, La/VT;->L:Ljava/lang/CharSequence;

    .line 128
    .line 129
    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    .line 130
    .line 131
    .line 132
    return-void

    .line 133
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 134
    .line 135
    const-string p2, "Cannot have an empty route"

    .line 136
    .line 137
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object p2

    .line 141
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    throw p1
.end method

.method public final e(La/VT;)[I
    .locals 6

    .line 1
    new-instance v0, La/qP;

    .line 2
    .line 3
    invoke-direct {v0}, La/qP;-><init>()V

    .line 4
    .line 5
    .line 6
    move-object v1, p0

    .line 7
    :goto_0
    iget-object v2, v1, La/VT;->K:La/mE;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    iget-object v3, p1, La/VT;->K:La/mE;

    .line 12
    .line 13
    goto :goto_1

    .line 14
    :cond_0
    const/4 v3, 0x0

    .line 15
    :goto_1
    if-eqz v3, :cond_1

    .line 16
    .line 17
    iget-object v3, p1, La/VT;->K:La/mE;

    .line 18
    .line 19
    iget v4, v1, La/VT;->W:I

    .line 20
    .line 21
    const/4 v5, 0x1

    .line 22
    invoke-virtual {v3, v4, v5}, La/mE;->M(IZ)La/VT;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    if-ne v3, v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {v0, v1}, La/qP;->e(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    goto :goto_2

    .line 32
    :cond_1
    if-eqz v2, :cond_2

    .line 33
    .line 34
    iget v3, v2, La/mE;->S:I

    .line 35
    .line 36
    iget v4, v1, La/VT;->W:I

    .line 37
    .line 38
    if-eq v3, v4, :cond_3

    .line 39
    .line 40
    :cond_2
    invoke-virtual {v0, v1}, La/qP;->e(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_3
    invoke-static {v2, p1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_4

    .line 48
    .line 49
    goto :goto_2

    .line 50
    :cond_4
    if-nez v2, :cond_6

    .line 51
    .line 52
    :goto_2
    invoke-static {v0}, La/ar;->ic(Ljava/lang/Iterable;)Ljava/util/List;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    new-instance v0, Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-static {p1}, La/cl;->DT(Ljava/lang/Iterable;)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 63
    .line 64
    .line 65
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_5

    .line 74
    .line 75
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, La/VT;

    .line 80
    .line 81
    iget v1, v1, La/VT;->W:I

    .line 82
    .line 83
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    goto :goto_3

    .line 91
    :cond_5
    invoke-static {v0}, La/ar;->jS(Ljava/util/ArrayList;)[I

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    return-object p1

    .line 96
    :cond_6
    move-object v1, v2

    .line 97
    goto :goto_0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_8

    .line 7
    .line 8
    instance-of v2, p1, La/VT;

    .line 9
    .line 10
    if-nez v2, :cond_1

    .line 11
    .line 12
    goto/16 :goto_5

    .line 13
    .line 14
    :cond_1
    iget-object v2, p0, La/VT;->d:Ljava/util/ArrayList;

    .line 15
    .line 16
    check-cast p1, La/VT;

    .line 17
    .line 18
    iget-object v3, p1, La/VT;->d:Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-static {v2, v3}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    iget-object v3, p0, La/VT;->f:La/a1;

    .line 25
    .line 26
    invoke-virtual {v3}, La/a1;->O()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    iget-object v5, p1, La/VT;->f:La/a1;

    .line 31
    .line 32
    invoke-virtual {v5}, La/a1;->O()I

    .line 33
    .line 34
    .line 35
    move-result v6

    .line 36
    if-ne v4, v6, :cond_4

    .line 37
    .line 38
    new-instance v4, La/kZ;

    .line 39
    .line 40
    invoke-direct {v4, v3}, La/kZ;-><init>(La/a1;)V

    .line 41
    .line 42
    .line 43
    invoke-static {v4}, La/yZ;->nA(Ljava/util/Iterator;)La/WH;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-interface {v4}, La/WH;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_3

    .line 56
    .line 57
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    check-cast v6, Ljava/lang/Number;

    .line 62
    .line 63
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 64
    .line 65
    .line 66
    move-result v6

    .line 67
    const/4 v7, 0x0

    .line 68
    invoke-virtual {v3, v6, v7}, La/a1;->i(ILjava/lang/Integer;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    invoke-virtual {v5, v6, v7}, La/a1;->i(ILjava/lang/Integer;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    invoke-static {v8, v6}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    if-nez v6, :cond_2

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    move v3, v0

    .line 84
    goto :goto_1

    .line 85
    :cond_4
    :goto_0
    move v3, v1

    .line 86
    :goto_1
    iget-object v4, p0, La/VT;->l:Ljava/util/LinkedHashMap;

    .line 87
    .line 88
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 89
    .line 90
    .line 91
    move-result v5

    .line 92
    iget-object v6, p1, La/VT;->l:Ljava/util/LinkedHashMap;

    .line 93
    .line 94
    invoke-interface {v6}, Ljava/util/Map;->size()I

    .line 95
    .line 96
    .line 97
    move-result v7

    .line 98
    if-ne v5, v7, :cond_6

    .line 99
    .line 100
    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    new-instance v5, La/me;

    .line 105
    .line 106
    invoke-direct {v5, v0, v4}, La/me;-><init>(ILjava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v5}, La/me;->iterator()Ljava/util/Iterator;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 114
    .line 115
    .line 116
    move-result v5

    .line 117
    if-eqz v5, :cond_5

    .line 118
    .line 119
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    check-cast v5, Ljava/util/Map$Entry;

    .line 124
    .line 125
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v7

    .line 129
    invoke-interface {v6, v7}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v7

    .line 133
    if-eqz v7, :cond_6

    .line 134
    .line 135
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    invoke-virtual {v6, v7}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v7

    .line 143
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    invoke-static {v7, v5}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v5

    .line 151
    if-eqz v5, :cond_6

    .line 152
    .line 153
    goto :goto_2

    .line 154
    :cond_5
    move v4, v0

    .line 155
    goto :goto_3

    .line 156
    :cond_6
    move v4, v1

    .line 157
    :goto_3
    iget v5, p0, La/VT;->W:I

    .line 158
    .line 159
    iget v6, p1, La/VT;->W:I

    .line 160
    .line 161
    if-ne v5, v6, :cond_7

    .line 162
    .line 163
    iget-object v5, p0, La/VT;->q:Ljava/lang/String;

    .line 164
    .line 165
    iget-object p1, p1, La/VT;->q:Ljava/lang/String;

    .line 166
    .line 167
    invoke-static {v5, p1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result p1

    .line 171
    if-eqz p1, :cond_7

    .line 172
    .line 173
    if-eqz v2, :cond_7

    .line 174
    .line 175
    if-eqz v3, :cond_7

    .line 176
    .line 177
    if-eqz v4, :cond_7

    .line 178
    .line 179
    goto :goto_4

    .line 180
    :cond_7
    move v0, v1

    .line 181
    :goto_4
    return v0

    .line 182
    :cond_8
    :goto_5
    return v1
.end method

.method public final h(La/By;)V
    .locals 3

    .line 1
    iget-object v0, p0, La/VT;->l:Ljava/util/LinkedHashMap;

    new-instance v1, La/HY;

    const/4 v2, 0x1

    invoke-direct {v1, v2, p1}, La/HY;-><init>(ILjava/lang/Object;)V

    invoke-static {v0, v1}, La/rE;->Qg(Ljava/util/LinkedHashMap;La/nY;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, p0, La/VT;->d:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Deep link "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, La/By;->w:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " can\'t be used to open destination "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ".\nFollowing required arguments are missing: "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public hashCode()I
    .locals 7

    .line 1
    iget v0, p0, La/VT;->W:I

    .line 2
    .line 3
    mul-int/lit8 v0, v0, 0x1f

    .line 4
    .line 5
    iget-object v1, p0, La/VT;->q:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    move v1, v2

    .line 16
    :goto_0
    add-int/2addr v0, v1

    .line 17
    iget-object v1, p0, La/VT;->d:Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    if-eqz v3, :cond_4

    .line 28
    .line 29
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    check-cast v3, La/By;

    .line 34
    .line 35
    mul-int/lit8 v0, v0, 0x1f

    .line 36
    .line 37
    iget-object v4, v3, La/By;->w:Ljava/lang/String;

    .line 38
    .line 39
    if-eqz v4, :cond_1

    .line 40
    .line 41
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    goto :goto_2

    .line 46
    :cond_1
    move v4, v2

    .line 47
    :goto_2
    add-int/2addr v0, v4

    .line 48
    mul-int/lit8 v0, v0, 0x1f

    .line 49
    .line 50
    iget-object v4, v3, La/By;->h:Ljava/lang/String;

    .line 51
    .line 52
    if-eqz v4, :cond_2

    .line 53
    .line 54
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    goto :goto_3

    .line 59
    :cond_2
    move v4, v2

    .line 60
    :goto_3
    add-int/2addr v0, v4

    .line 61
    mul-int/lit8 v0, v0, 0x1f

    .line 62
    .line 63
    iget-object v3, v3, La/By;->p:Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v3, :cond_3

    .line 66
    .line 67
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    goto :goto_4

    .line 72
    :cond_3
    move v3, v2

    .line 73
    :goto_4
    add-int/2addr v0, v3

    .line 74
    goto :goto_1

    .line 75
    :cond_4
    new-instance v1, La/Oi;

    .line 76
    .line 77
    iget-object v3, p0, La/VT;->f:La/a1;

    .line 78
    .line 79
    invoke-direct {v1, v2, v3}, La/Oi;-><init>(ILjava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_5
    invoke-virtual {v1}, La/Oi;->hasNext()Z

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    if-eqz v3, :cond_8

    .line 87
    .line 88
    invoke-virtual {v1}, La/Oi;->next()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    check-cast v3, La/R5;

    .line 93
    .line 94
    mul-int/lit8 v0, v0, 0x1f

    .line 95
    .line 96
    iget v4, v3, La/R5;->w:I

    .line 97
    .line 98
    add-int/2addr v0, v4

    .line 99
    mul-int/lit8 v0, v0, 0x1f

    .line 100
    .line 101
    iget-object v4, v3, La/R5;->h:La/i1;

    .line 102
    .line 103
    if-eqz v4, :cond_6

    .line 104
    .line 105
    invoke-virtual {v4}, La/i1;->hashCode()I

    .line 106
    .line 107
    .line 108
    move-result v4

    .line 109
    goto :goto_5

    .line 110
    :cond_6
    move v4, v2

    .line 111
    :goto_5
    add-int/2addr v0, v4

    .line 112
    iget-object v4, v3, La/R5;->p:Landroid/os/Bundle;

    .line 113
    .line 114
    if-eqz v4, :cond_5

    .line 115
    .line 116
    invoke-virtual {v4}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    if-eqz v4, :cond_5

    .line 121
    .line 122
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 123
    .line 124
    .line 125
    move-result-object v4

    .line 126
    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    if-eqz v5, :cond_5

    .line 131
    .line 132
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v5

    .line 136
    check-cast v5, Ljava/lang/String;

    .line 137
    .line 138
    mul-int/lit8 v0, v0, 0x1f

    .line 139
    .line 140
    iget-object v6, v3, La/R5;->p:Landroid/os/Bundle;

    .line 141
    .line 142
    invoke-virtual {v6, v5}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    if-eqz v5, :cond_7

    .line 147
    .line 148
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    .line 149
    .line 150
    .line 151
    move-result v5

    .line 152
    goto :goto_7

    .line 153
    :cond_7
    move v5, v2

    .line 154
    :goto_7
    add-int/2addr v0, v5

    .line 155
    goto :goto_6

    .line 156
    :cond_8
    iget-object v1, p0, La/VT;->l:Ljava/util/LinkedHashMap;

    .line 157
    .line 158
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 159
    .line 160
    .line 161
    move-result-object v3

    .line 162
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    :goto_8
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 167
    .line 168
    .line 169
    move-result v4

    .line 170
    if-eqz v4, :cond_a

    .line 171
    .line 172
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v4

    .line 176
    check-cast v4, Ljava/lang/String;

    .line 177
    .line 178
    mul-int/lit8 v0, v0, 0x1f

    .line 179
    .line 180
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 181
    .line 182
    .line 183
    move-result v5

    .line 184
    add-int/2addr v5, v0

    .line 185
    mul-int/lit8 v5, v5, 0x1f

    .line 186
    .line 187
    invoke-virtual {v1, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    if-eqz v0, :cond_9

    .line 192
    .line 193
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    goto :goto_9

    .line 198
    :cond_9
    move v0, v2

    .line 199
    :goto_9
    add-int/2addr v0, v5

    .line 200
    goto :goto_8

    .line 201
    :cond_a
    return v0
.end method

.method public final i(I)La/R5;
    .locals 3

    .line 1
    iget-object v0, p0, La/VT;->f:La/a1;

    .line 2
    .line 3
    invoke-virtual {v0}, La/a1;->O()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_0

    .line 9
    .line 10
    move-object v0, v2

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {v0, p1, v2}, La/a1;->i(ILjava/lang/Integer;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, La/R5;

    .line 17
    .line 18
    :goto_0
    if-nez v0, :cond_1

    .line 19
    .line 20
    iget-object v0, p0, La/VT;->K:La/mE;

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    invoke-virtual {v0, p1}, La/VT;->i(I)La/R5;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    goto :goto_1

    .line 29
    :cond_1
    move-object v2, v0

    .line 30
    :cond_2
    :goto_1
    return-object v2
.end method

.method public final p(Landroid/os/Bundle;)Landroid/os/Bundle;
    .locals 6

    .line 1
    iget-object v0, p0, La/VT;->l:Ljava/util/LinkedHashMap;

    .line 2
    .line 3
    if-nez p1, :cond_1

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    return-object p1

    .line 15
    :cond_1
    new-instance v1, Landroid/os/Bundle;

    .line 16
    .line 17
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    :cond_2
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-eqz v3, :cond_3

    .line 33
    .line 34
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Ljava/util/Map$Entry;

    .line 39
    .line 40
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    check-cast v4, Ljava/lang/String;

    .line 45
    .line 46
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    check-cast v3, La/bj;

    .line 51
    .line 52
    iget-boolean v5, v3, La/bj;->p:Z

    .line 53
    .line 54
    if-eqz v5, :cond_2

    .line 55
    .line 56
    iget-object v5, v3, La/bj;->w:La/vo;

    .line 57
    .line 58
    iget-object v3, v3, La/bj;->e:Ljava/lang/Object;

    .line 59
    .line 60
    invoke-virtual {v5, v1, v4, v3}, La/vo;->i(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_3
    if-eqz p1, :cond_6

    .line 65
    .line 66
    invoke-virtual {v1, p1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_6

    .line 82
    .line 83
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    check-cast v0, Ljava/util/Map$Entry;

    .line 88
    .line 89
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    check-cast v2, Ljava/lang/String;

    .line 94
    .line 95
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    check-cast v0, La/bj;

    .line 100
    .line 101
    iget-boolean v3, v0, La/bj;->h:Z

    .line 102
    .line 103
    iget-object v0, v0, La/bj;->w:La/vo;

    .line 104
    .line 105
    if-nez v3, :cond_4

    .line 106
    .line 107
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    if-eqz v3, :cond_4

    .line 112
    .line 113
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    if-eqz v3, :cond_5

    .line 118
    .line 119
    :cond_4
    :try_start_0
    invoke-virtual {v0, v2, v1}, La/vo;->w(Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    .line 120
    .line 121
    .line 122
    goto :goto_1

    .line 123
    :catch_0
    :cond_5
    new-instance p1, Ljava/lang/StringBuilder;

    .line 124
    .line 125
    const-string v1, "Wrong argument type for \'"

    .line 126
    .line 127
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    const-string v1, "\' in argument bundle. "

    .line 134
    .line 135
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v0}, La/vo;->h()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    const-string v0, " expected."

    .line 146
    .line 147
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 155
    .line 156
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    throw v0

    .line 164
    :cond_6
    return-object v1
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/VT;->R:Ljava/lang/String;

    if-nez v1, :cond_0

    const-string v1, "0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, La/VT;->W:I

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/VT;->q:Ljava/lang/String;

    if-eqz v1, :cond_2

    invoke-static {v1}, La/ge;->sH(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    const-string v1, " route="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/VT;->q:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    :goto_0
    iget-object v1, p0, La/VT;->L:Ljava/lang/CharSequence;

    if-eqz v1, :cond_3

    const-string v1, " label="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, La/VT;->L:Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    :cond_3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
