.class public final La/Bc;
.super La/Qg;
.source "SourceFile"


# instance fields
.field public final synthetic e:I

.field public final i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, La/Bc;->e:I

    iput-object p2, p0, La/Bc;->i:Ljava/lang/Object;

    .line 1
    invoke-direct {p0}, La/Qg;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/textfield/TextInputLayout;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, La/Bc;->e:I

    .line 2
    invoke-direct {p0}, La/Qg;-><init>()V

    iput-object p1, p0, La/Bc;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final X(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 1

    .line 1
    iget v0, p0, La/Bc;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2, p3}, La/Qg;->X(Landroid/view/View;ILandroid/os/Bundle;)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    return p1

    .line 11
    :pswitch_0
    const/high16 v0, 0x100000

    .line 12
    .line 13
    if-ne p2, v0, :cond_0

    .line 14
    .line 15
    iget-object p1, p0, La/Bc;->i:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p1, La/sl;

    .line 18
    .line 19
    check-cast p1, La/kG;

    .line 20
    .line 21
    const/4 p2, 0x3

    .line 22
    invoke-virtual {p1, p2}, La/sl;->w(I)V

    .line 23
    .line 24
    .line 25
    const/4 p1, 0x1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-super {p0, p1, p2, p3}, La/Qg;->X(Landroid/view/View;ILandroid/os/Bundle;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    :goto_0
    return p1

    .line 32
    nop

    .line 33
    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_0
    .end packed-switch
.end method

.method public final e(Landroid/view/View;La/sH;)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v2, La/sH;->w:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 8
    .line 9
    iget v4, v0, La/Bc;->e:I

    .line 10
    .line 11
    const/4 v6, 0x0

    .line 12
    iget-object v7, v0, La/Bc;->i:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 v8, 0x1

    .line 15
    iget-object v9, v0, La/Qg;->w:Landroid/view/View$AccessibilityDelegate;

    .line 16
    .line 17
    packed-switch v4, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    invoke-virtual {v9, v1, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 21
    .line 22
    .line 23
    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    .line 24
    .line 25
    iget-object v1, v7, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 26
    .line 27
    const/4 v4, 0x0

    .line 28
    if-eqz v1, :cond_0

    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    move-object v1, v4

    .line 36
    :goto_0
    iget-boolean v9, v7, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 37
    .line 38
    if-eqz v9, :cond_1

    .line 39
    .line 40
    iget-object v9, v7, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    move-object v9, v4

    .line 44
    :goto_1
    iget-object v10, v7, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 45
    .line 46
    iget-boolean v11, v10, La/A7;->L:Z

    .line 47
    .line 48
    if-eqz v11, :cond_2

    .line 49
    .line 50
    iget-object v11, v10, La/A7;->R:Ljava/lang/CharSequence;

    .line 51
    .line 52
    goto :goto_2

    .line 53
    :cond_2
    move-object v11, v4

    .line 54
    :goto_2
    iget-boolean v12, v7, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 55
    .line 56
    if-eqz v12, :cond_3

    .line 57
    .line 58
    iget-object v12, v7, Lcom/google/android/material/textfield/TextInputLayout;->k:Ljava/lang/CharSequence;

    .line 59
    .line 60
    goto :goto_3

    .line 61
    :cond_3
    move-object v12, v4

    .line 62
    :goto_3
    iget v13, v7, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 63
    .line 64
    iget-boolean v14, v7, Lcom/google/android/material/textfield/TextInputLayout;->S:Z

    .line 65
    .line 66
    if-eqz v14, :cond_4

    .line 67
    .line 68
    iget-boolean v14, v7, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 69
    .line 70
    if-eqz v14, :cond_4

    .line 71
    .line 72
    iget-object v14, v7, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 73
    .line 74
    if-eqz v14, :cond_4

    .line 75
    .line 76
    invoke-virtual {v14}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    :cond_4
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 81
    .line 82
    .line 83
    move-result v14

    .line 84
    xor-int/lit8 v15, v14, 0x1

    .line 85
    .line 86
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 87
    .line 88
    .line 89
    move-result v16

    .line 90
    xor-int/lit8 v16, v16, 0x1

    .line 91
    .line 92
    iget-boolean v5, v7, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 93
    .line 94
    xor-int/2addr v5, v8

    .line 95
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 96
    .line 97
    .line 98
    move-result v17

    .line 99
    xor-int/lit8 v17, v17, 0x1

    .line 100
    .line 101
    if-nez v17, :cond_5

    .line 102
    .line 103
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 104
    .line 105
    .line 106
    move-result v18

    .line 107
    if-nez v18, :cond_6

    .line 108
    .line 109
    :cond_5
    move v6, v8

    .line 110
    :cond_6
    if-eqz v16, :cond_7

    .line 111
    .line 112
    invoke-interface {v9}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v8

    .line 116
    goto :goto_4

    .line 117
    :cond_7
    const-string v8, ""

    .line 118
    .line 119
    :goto_4
    iget-object v9, v7, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 120
    .line 121
    iget-object v0, v9, La/dX;->R:La/c8;

    .line 122
    .line 123
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 124
    .line 125
    .line 126
    move-result v16

    .line 127
    if-nez v16, :cond_8

    .line 128
    .line 129
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLabelFor(Landroid/view/View;)V

    .line 130
    .line 131
    .line 132
    :goto_5
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setTraversalAfter(Landroid/view/View;)V

    .line 133
    .line 134
    .line 135
    goto :goto_6

    .line 136
    :cond_8
    iget-object v0, v9, La/dX;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 137
    .line 138
    goto :goto_5

    .line 139
    :goto_6
    const-string v0, ", "

    .line 140
    .line 141
    if-eqz v15, :cond_9

    .line 142
    .line 143
    invoke-virtual {v2, v1}, La/sH;->M(Ljava/lang/CharSequence;)V

    .line 144
    .line 145
    .line 146
    goto :goto_7

    .line 147
    :cond_9
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 148
    .line 149
    .line 150
    move-result v9

    .line 151
    if-nez v9, :cond_a

    .line 152
    .line 153
    invoke-virtual {v2, v8}, La/sH;->M(Ljava/lang/CharSequence;)V

    .line 154
    .line 155
    .line 156
    if-eqz v5, :cond_b

    .line 157
    .line 158
    if-eqz v12, :cond_b

    .line 159
    .line 160
    new-instance v5, Ljava/lang/StringBuilder;

    .line 161
    .line 162
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v5

    .line 178
    invoke-virtual {v2, v5}, La/sH;->M(Ljava/lang/CharSequence;)V

    .line 179
    .line 180
    .line 181
    goto :goto_7

    .line 182
    :cond_a
    if-eqz v12, :cond_b

    .line 183
    .line 184
    invoke-virtual {v2, v12}, La/sH;->M(Ljava/lang/CharSequence;)V

    .line 185
    .line 186
    .line 187
    :cond_b
    :goto_7
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 188
    .line 189
    .line 190
    move-result v5

    .line 191
    if-nez v5, :cond_f

    .line 192
    .line 193
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 194
    .line 195
    const/16 v9, 0x1a

    .line 196
    .line 197
    if-lt v5, v9, :cond_c

    .line 198
    .line 199
    invoke-virtual {v2, v8}, La/sH;->I(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    goto :goto_8

    .line 203
    :cond_c
    if-eqz v15, :cond_d

    .line 204
    .line 205
    new-instance v12, Ljava/lang/StringBuilder;

    .line 206
    .line 207
    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 211
    .line 212
    .line 213
    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v8

    .line 223
    :cond_d
    invoke-virtual {v2, v8}, La/sH;->M(Ljava/lang/CharSequence;)V

    .line 224
    .line 225
    .line 226
    :goto_8
    if-lt v5, v9, :cond_e

    .line 227
    .line 228
    invoke-static {v3, v14}, La/p;->W(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 229
    .line 230
    .line 231
    goto :goto_9

    .line 232
    :cond_e
    const/4 v0, 0x4

    .line 233
    invoke-virtual {v2, v0, v14}, La/sH;->O(IZ)V

    .line 234
    .line 235
    .line 236
    :cond_f
    :goto_9
    if-eqz v1, :cond_10

    .line 237
    .line 238
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    .line 239
    .line 240
    .line 241
    move-result v0

    .line 242
    if-ne v0, v13, :cond_10

    .line 243
    .line 244
    move v5, v13

    .line 245
    goto :goto_a

    .line 246
    :cond_10
    const/4 v5, -0x1

    .line 247
    :goto_a
    invoke-virtual {v3, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMaxTextLength(I)V

    .line 248
    .line 249
    .line 250
    if-eqz v6, :cond_12

    .line 251
    .line 252
    if-eqz v17, :cond_11

    .line 253
    .line 254
    goto :goto_b

    .line 255
    :cond_11
    move-object v11, v4

    .line 256
    :goto_b
    invoke-virtual {v3, v11}, Landroid/view/accessibility/AccessibilityNodeInfo;->setError(Ljava/lang/CharSequence;)V

    .line 257
    .line 258
    .line 259
    :cond_12
    iget-object v0, v10, La/A7;->S:La/c8;

    .line 260
    .line 261
    if-eqz v0, :cond_13

    .line 262
    .line 263
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setLabelFor(Landroid/view/View;)V

    .line 264
    .line 265
    .line 266
    :cond_13
    iget-object v0, v7, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 267
    .line 268
    invoke-virtual {v0}, La/h9;->h()La/sb;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    invoke-virtual {v0, v2}, La/sb;->y(La/sH;)V

    .line 273
    .line 274
    .line 275
    return-void

    .line 276
    :pswitch_0
    invoke-virtual {v9, v1, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 277
    .line 278
    .line 279
    const/high16 v0, 0x100000

    .line 280
    .line 281
    invoke-virtual {v2, v0}, La/sH;->w(I)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {v3, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setDismissable(Z)V

    .line 285
    .line 286
    .line 287
    return-void

    .line 288
    :pswitch_1
    invoke-virtual {v9, v1, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 289
    .line 290
    .line 291
    check-cast v7, Lcom/google/android/material/internal/NavigationMenuItemView;

    .line 292
    .line 293
    iget-boolean v0, v7, Lcom/google/android/material/internal/NavigationMenuItemView;->n:Z

    .line 294
    .line 295
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 296
    .line 297
    .line 298
    return-void

    .line 299
    :pswitch_2
    invoke-virtual {v9, v1, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 300
    .line 301
    .line 302
    check-cast v7, Lcom/google/android/material/internal/CheckableImageButton;

    .line 303
    .line 304
    iget-boolean v0, v7, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    .line 305
    .line 306
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v7}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 310
    .line 311
    .line 312
    move-result v0

    .line 313
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 314
    .line 315
    .line 316
    return-void

    .line 317
    :pswitch_3
    invoke-virtual {v9, v1, v3}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 318
    .line 319
    .line 320
    const/4 v4, 0x0

    .line 321
    const/4 v5, 0x1

    .line 322
    check-cast v7, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    .line 323
    .line 324
    sget v0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->S:I

    .line 325
    .line 326
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 327
    .line 328
    .line 329
    instance-of v0, v1, Lcom/google/android/material/button/MaterialButton;

    .line 330
    .line 331
    if-nez v0, :cond_15

    .line 332
    .line 333
    :cond_14
    const/4 v6, -0x1

    .line 334
    goto :goto_d

    .line 335
    :cond_15
    move v0, v6

    .line 336
    :goto_c
    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    .line 337
    .line 338
    .line 339
    move-result v2

    .line 340
    if-ge v6, v2, :cond_14

    .line 341
    .line 342
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 343
    .line 344
    .line 345
    move-result-object v2

    .line 346
    if-ne v2, v1, :cond_16

    .line 347
    .line 348
    move v6, v0

    .line 349
    goto :goto_d

    .line 350
    :cond_16
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 351
    .line 352
    .line 353
    move-result-object v2

    .line 354
    instance-of v2, v2, Lcom/google/android/material/button/MaterialButton;

    .line 355
    .line 356
    if-eqz v2, :cond_17

    .line 357
    .line 358
    invoke-virtual {v7, v6}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(I)Z

    .line 359
    .line 360
    .line 361
    move-result v2

    .line 362
    if-eqz v2, :cond_17

    .line 363
    .line 364
    add-int/lit8 v0, v0, 0x1

    .line 365
    .line 366
    :cond_17
    add-int/lit8 v6, v6, 0x1

    .line 367
    .line 368
    goto :goto_c

    .line 369
    :goto_d
    const/4 v7, 0x1

    .line 370
    move-object v0, v1

    .line 371
    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    .line 372
    .line 373
    invoke-virtual {v0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    .line 374
    .line 375
    .line 376
    move-result v9

    .line 377
    const/4 v8, 0x0

    .line 378
    invoke-static/range {v4 .. v9}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;->obtain(IIIIZZ)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCollectionItemInfo(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionItemInfo;)V

    .line 383
    .line 384
    .line 385
    return-void

    .line 386
    nop

    .line 387
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget v0, p0, La/Bc;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2}, La/Qg;->i(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-super {p0, p1, p2}, La/Qg;->i(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, La/Bc;->i:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Lcom/google/android/material/textfield/TextInputLayout;

    .line 16
    .line 17
    iget-object p1, p1, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 18
    .line 19
    invoke-virtual {p1}, La/h9;->h()La/sb;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p1, p2}, La/sb;->K(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_0
    .end packed-switch
.end method

.method public final p(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget v0, p0, La/Bc;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2}, La/Qg;->p(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-super {p0, p1, p2}, La/Qg;->p(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, La/Bc;->i:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Lcom/google/android/material/internal/CheckableImageButton;

    .line 16
    .line 17
    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    invoke-virtual {p2, p1}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
