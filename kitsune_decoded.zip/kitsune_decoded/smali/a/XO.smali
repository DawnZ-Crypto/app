.class public final La/XO;
.super La/TZ;
.source "SourceFile"


# instance fields
.field public final synthetic K:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, La/XO;->K:I

    .line 2
    .line 3
    const/4 p1, 0x3

    .line 4
    invoke-direct {p0, p1}, La/TZ;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final rZ(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    .line 1
    iget v0, p0, La/XO;->K:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p2, La/vF;

    .line 10
    .line 11
    check-cast p3, Landroidx/databinding/w;

    .line 12
    .line 13
    check-cast p4, Ljava/lang/Void;

    .line 14
    .line 15
    if-eq p1, v3, :cond_1

    .line 16
    .line 17
    if-eq p1, v2, :cond_0

    .line 18
    .line 19
    if-eq p1, v1, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    iget-object p1, p2, La/vF;->w:La/zZ;

    .line 27
    .line 28
    invoke-virtual {p1, p3}, La/zZ;->F9(Landroidx/databinding/w;)V

    .line 29
    .line 30
    .line 31
    :goto_0
    return-void

    .line 32
    :pswitch_0
    check-cast p2, La/Jh;

    .line 33
    .line 34
    check-cast p3, La/hc;

    .line 35
    .line 36
    check-cast p4, Ljava/lang/Void;

    .line 37
    .line 38
    invoke-virtual {p2, p1, p3}, La/Jh;->w(ILa/hc;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :pswitch_1
    check-cast p2, La/dI;

    .line 43
    .line 44
    check-cast p3, La/OV;

    .line 45
    .line 46
    check-cast p4, La/R7;

    .line 47
    .line 48
    if-eq p1, v3, :cond_5

    .line 49
    .line 50
    if-eq p1, v2, :cond_4

    .line 51
    .line 52
    if-eq p1, v1, :cond_3

    .line 53
    .line 54
    const/4 v0, 0x4

    .line 55
    if-eq p1, v0, :cond_2

    .line 56
    .line 57
    invoke-virtual {p2, p3}, La/dI;->w(La/OV;)V

    .line 58
    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_2
    iget p1, p4, La/R7;->w:I

    .line 62
    .line 63
    iget p4, p4, La/R7;->h:I

    .line 64
    .line 65
    invoke-virtual {p2, p3, p1, p4}, La/dI;->Q(La/OV;II)V

    .line 66
    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_3
    iget p1, p4, La/R7;->w:I

    .line 70
    .line 71
    iget v0, p4, La/R7;->p:I

    .line 72
    .line 73
    iget p4, p4, La/R7;->h:I

    .line 74
    .line 75
    invoke-virtual {p2, p3, p1, v0, p4}, La/dI;->i(La/OV;III)V

    .line 76
    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_4
    iget p1, p4, La/R7;->w:I

    .line 80
    .line 81
    iget p4, p4, La/R7;->h:I

    .line 82
    .line 83
    invoke-virtual {p2, p3, p1, p4}, La/dI;->e(La/OV;II)V

    .line 84
    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_5
    iget p1, p4, La/R7;->w:I

    .line 88
    .line 89
    iget p4, p4, La/R7;->h:I

    .line 90
    .line 91
    invoke-virtual {p2, p3, p1, p4}, La/dI;->h(La/OV;II)V

    .line 92
    .line 93
    .line 94
    :goto_1
    return-void

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
