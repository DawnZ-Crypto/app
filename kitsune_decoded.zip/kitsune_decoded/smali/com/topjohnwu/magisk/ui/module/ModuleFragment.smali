.class public final Lcom/topjohnwu/magisk/ui/module/ModuleFragment;
.super La/zZ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/uk;",
        ">;"
    }
.end annotation


# static fields
.field public static final synthetic Pb:I


# instance fields
.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0038

    iput v0, p0, Lcom/topjohnwu/magisk/ui/module/ModuleFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/module/ModuleFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 4

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    invoke-virtual {p0}, La/zr;->f()Landroid/content/res/Resources;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const v2, 0x7f1200b1

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/module/ModuleFragment;->xF:La/Y0;

    .line 26
    .line 27
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, La/YJ;

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    sget-object v0, La/YJ;->S:La/bc;

    .line 37
    .line 38
    new-instance v1, La/HY;

    .line 39
    .line 40
    const/16 v2, 0xa

    .line 41
    .line 42
    invoke-direct {v1, v2, p0}, La/HY;-><init>(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    new-instance v2, La/Do;

    .line 46
    .line 47
    const/4 v3, 0x5

    .line 48
    invoke-direct {v2, v3, v1}, La/Do;-><init>(ILa/nY;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0, p0, v2}, Landroidx/lifecycle/h;->i(La/RH;La/yb;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final bridge synthetic F9(Landroidx/databinding/w;)V
    .locals 0

    .line 1
    check-cast p1, La/uk;

    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/module/ModuleFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/module/ModuleFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/YJ;

    .line 8
    .line 9
    return-object v0
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, La/zZ;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 p1, 0x0

    .line 10
    :goto_0
    check-cast p1, La/uk;

    .line 11
    .line 12
    iget-object p1, p1, La/uk;->t:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    const p2, 0x7f0700af

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x5

    .line 18
    invoke-static {p1, p2, v0}, La/rx;->Q(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 19
    .line 20
    .line 21
    invoke-static {p1}, La/rx;->X(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1}, La/rx;->S(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 25
    .line 26
    .line 27
    new-instance p2, La/Qb;

    .line 28
    .line 29
    const/4 v0, 0x1

    .line 30
    invoke-direct {p2, p1, v0}, La/Qb;-><init>(Landroidx/recyclerview/widget/RecyclerView;I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 34
    .line 35
    .line 36
    return-void
.end method
