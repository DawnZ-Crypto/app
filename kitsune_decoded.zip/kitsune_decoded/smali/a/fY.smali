.class public interface abstract La/fY;
.super Ljava/lang/Object;
.source "SourceFile"
