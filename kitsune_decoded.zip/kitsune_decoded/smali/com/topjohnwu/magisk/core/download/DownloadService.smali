.class public final Lcom/topjohnwu/magisk/core/download/DownloadService;
.super La/US;
.source "SourceFile"


# static fields
.field public static final synthetic d:I


# instance fields
.field public final L:La/gC;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La/US;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/gC;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, La/gC;-><init>(La/P7;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/download/DownloadService;->L:La/gC;

    .line 11
    .line 12
    return-void
.end method

.method public static final e(Lcom/topjohnwu/magisk/core/download/DownloadService;La/cq;Landroid/net/Uri;)V
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/zip/ZipInputStream;

    .line 5
    .line 6
    instance-of v1, p1, Ljava/io/BufferedInputStream;

    .line 7
    .line 8
    const/16 v2, 0x2000

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    check-cast p1, Ljava/io/BufferedInputStream;

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    new-instance v1, Ljava/io/BufferedInputStream;

    .line 16
    .line 17
    invoke-direct {v1, p1, v2}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;I)V

    .line 18
    .line 19
    .line 20
    move-object p1, v1

    .line 21
    :goto_0
    invoke-direct {v0, p1}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 22
    .line 23
    .line 24
    new-instance p1, Ljava/util/zip/ZipOutputStream;

    .line 25
    .line 26
    sget-object v1, La/uv;->w:Landroid/content/Context;

    .line 27
    .line 28
    const/4 v3, 0x0

    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_1
    move-object v1, v3

    .line 33
    :goto_1
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v4, "rwt"

    .line 38
    .line 39
    invoke-virtual {v1, p2, v4}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/OutputStream;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    if-eqz p2, :cond_5

    .line 44
    .line 45
    instance-of v1, p2, Ljava/io/BufferedOutputStream;

    .line 46
    .line 47
    if-eqz v1, :cond_2

    .line 48
    .line 49
    check-cast p2, Ljava/io/BufferedOutputStream;

    .line 50
    .line 51
    goto :goto_2

    .line 52
    :cond_2
    new-instance v1, Ljava/io/BufferedOutputStream;

    .line 53
    .line 54
    invoke-direct {v1, p2, v2}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;I)V

    .line 55
    .line 56
    .line 57
    move-object p2, v1

    .line 58
    :goto_2
    invoke-direct {p1, p2}, Ljava/util/zip/ZipOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 59
    .line 60
    .line 61
    :try_start_0
    new-instance p2, Ljava/util/zip/ZipEntry;

    .line 62
    .line 63
    const-string v1, "META-INF/"

    .line 64
    .line 65
    invoke-direct {p2, v1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1, p2}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 69
    .line 70
    .line 71
    new-instance p2, Ljava/util/zip/ZipEntry;

    .line 72
    .line 73
    const-string v1, "META-INF/com/"

    .line 74
    .line 75
    invoke-direct {p2, v1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1, p2}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 79
    .line 80
    .line 81
    new-instance p2, Ljava/util/zip/ZipEntry;

    .line 82
    .line 83
    const-string v1, "META-INF/com/google/"

    .line 84
    .line 85
    invoke-direct {p2, v1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1, p2}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 89
    .line 90
    .line 91
    new-instance p2, Ljava/util/zip/ZipEntry;

    .line 92
    .line 93
    const-string v1, "META-INF/com/google/android/"

    .line 94
    .line 95
    invoke-direct {p2, v1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p1, p2}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 99
    .line 100
    .line 101
    new-instance p2, Ljava/util/zip/ZipEntry;

    .line 102
    .line 103
    const-string v1, "META-INF/com/google/android/update-binary"

    .line 104
    .line 105
    invoke-direct {p2, v1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p1, p2}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    const-string p2, "module_installer.sh"

    .line 116
    .line 117
    invoke-virtual {p0, p2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    invoke-static {p0, p1}, La/A8;->R(Ljava/io/InputStream;Ljava/io/OutputStream;)J

    .line 122
    .line 123
    .line 124
    new-instance p0, Ljava/util/zip/ZipEntry;

    .line 125
    .line 126
    const-string p2, "META-INF/com/google/android/updater-script"

    .line 127
    .line 128
    invoke-direct {p0, p2}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1, p0}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 132
    .line 133
    .line 134
    const-string p0, "#MAGISK\n"

    .line 135
    .line 136
    sget-object p2, La/kg;->w:Ljava/nio/charset/Charset;

    .line 137
    .line 138
    invoke-virtual {p0, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 139
    .line 140
    .line 141
    move-result-object p0

    .line 142
    invoke-virtual {p1, p0}, Ljava/io/OutputStream;->write([B)V

    .line 143
    .line 144
    .line 145
    :cond_3
    :goto_3
    invoke-virtual {v0}, Ljava/util/zip/ZipInputStream;->getNextEntry()Ljava/util/zip/ZipEntry;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    if-eqz p0, :cond_4

    .line 150
    .line 151
    invoke-virtual {p0}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object p2

    .line 155
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 156
    .line 157
    .line 158
    move-result v1

    .line 159
    if-lez v1, :cond_3

    .line 160
    .line 161
    const-string v1, "META-INF"

    .line 162
    .line 163
    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    if-nez v1, :cond_3

    .line 168
    .line 169
    new-instance v1, Ljava/util/zip/ZipEntry;

    .line 170
    .line 171
    invoke-direct {v1, p2}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p1, v1}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {p0}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    .line 178
    .line 179
    .line 180
    move-result p0

    .line 181
    if-nez p0, :cond_3

    .line 182
    .line 183
    invoke-static {v0, p1}, La/A8;->R(Ljava/io/InputStream;Ljava/io/OutputStream;)J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 184
    .line 185
    .line 186
    goto :goto_3

    .line 187
    :catchall_0
    move-exception p0

    .line 188
    goto :goto_4

    .line 189
    :cond_4
    :try_start_1
    invoke-static {p1, v3}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 190
    .line 191
    .line 192
    invoke-static {v0, v3}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :catchall_1
    move-exception p0

    .line 197
    goto :goto_5

    .line 198
    :goto_4
    :try_start_2
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 199
    :catchall_2
    move-exception p2

    .line 200
    :try_start_3
    invoke-static {p1, p0}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 201
    .line 202
    .line 203
    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 204
    :goto_5
    :try_start_4
    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 205
    :catchall_3
    move-exception p1

    .line 206
    invoke-static {v0, p0}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 207
    .line 208
    .line 209
    throw p1

    .line 210
    :cond_5
    new-instance p0, Ljava/io/FileNotFoundException;

    .line 211
    .line 212
    invoke-direct {p0}, Ljava/io/FileNotFoundException;-><init>()V

    .line 213
    .line 214
    .line 215
    throw p0
.end method

.method public static final i(La/yX;La/cq;Ljava/io/OutputStream;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, La/yX;->X()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string p0, ".apk"

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-static {p0, v0}, La/Qr;->z(Ljava/lang/String;Z)La/Yf;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-interface {p0}, La/Yf;->w()Landroid/net/Uri;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, La/Qr;->t(Landroid/net/Uri;)Ljava/io/OutputStream;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    new-instance v1, La/MI;

    .line 36
    .line 37
    invoke-direct {v1, p0, p2, v0}, La/MI;-><init>(Ljava/io/OutputStream;Ljava/io/OutputStream;I)V

    .line 38
    .line 39
    .line 40
    invoke-static {p1, v1}, La/Iw;->w(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public static final p(Lcom/topjohnwu/magisk/core/download/DownloadService;La/cq;La/yX;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {}, La/rx;->Pc()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_5

    .line 10
    .line 11
    new-instance v0, Ljava/io/File;

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, La/A8;->S(Landroid/content/pm/ApplicationInfo;)Ljava/io/File;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    const-string v3, "update.apk"

    .line 22
    .line 23
    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :try_start_0
    new-instance v2, Ljava/io/FileOutputStream;

    .line 27
    .line 28
    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 29
    .line 30
    .line 31
    invoke-static {p2, p1, v2}, Lcom/topjohnwu/magisk/core/download/DownloadService;->i(La/yX;La/cq;Ljava/io/OutputStream;)V

    .line 32
    .line 33
    .line 34
    new-instance p1, Ljava/util/zip/ZipFile;

    .line 35
    .line 36
    invoke-direct {p1, v0}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V

    .line 37
    .line 38
    .line 39
    new-instance v2, Ljava/util/Properties;

    .line 40
    .line 41
    invoke-direct {v2}, Ljava/util/Properties;-><init>()V

    .line 42
    .line 43
    .line 44
    new-instance v3, Ljava/io/ByteArrayInputStream;

    .line 45
    .line 46
    invoke-virtual {p1}, Ljava/util/zip/ZipFile;->getComment()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    sget-object v5, La/kg;->w:Ljava/nio/charset/Charset;

    .line 51
    .line 52
    invoke-virtual {v4, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    invoke-direct {v3, v4}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v2, v3}, Ljava/util/Properties;->load(Ljava/io/InputStream;)V

    .line 60
    .line 61
    .line 62
    const-string v3, "stubVersion"

    .line 63
    .line 64
    invoke-virtual {v2, v3}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    invoke-static {v2}, La/M0;->cM(Ljava/lang/String;)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    if-eqz v2, :cond_0

    .line 73
    .line 74
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    goto :goto_0

    .line 79
    :catch_0
    move-exception p0

    .line 80
    goto/16 :goto_2

    .line 81
    .line 82
    :cond_0
    const/4 v2, -0x1

    .line 83
    :goto_0
    sget-object v3, La/Mv;->h:La/sR;

    .line 84
    .line 85
    iget-object v3, v3, La/sR;->K:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v3, [Ljava/lang/Object;

    .line 88
    .line 89
    const/4 v4, 0x0

    .line 90
    aget-object v3, v3, v4

    .line 91
    .line 92
    check-cast v3, Ljava/lang/Integer;

    .line 93
    .line 94
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 95
    .line 96
    .line 97
    move-result v3

    .line 98
    if-ge v3, v2, :cond_3

    .line 99
    .line 100
    iget v2, p2, La/yX;->K:I

    .line 101
    .line 102
    new-instance v3, La/HY;

    .line 103
    .line 104
    const/4 v4, 0x4

    .line 105
    invoke-direct {v3, v4, p0}, La/HY;-><init>(ILjava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0, v2, v3}, La/US;->h(ILa/nY;)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p2}, La/yX;->e()Landroid/net/Uri;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-static {v2}, La/cH;->F(Landroid/net/Uri;)Ljava/io/File;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    const-string v3, "assets/stub.apk"

    .line 120
    .line 121
    invoke-virtual {p1, v3}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    invoke-virtual {p1, v3}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    invoke-static {v2, v3}, La/Iw;->h(Ljava/io/File;Ljava/io/InputStream;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, Ljava/util/zip/ZipFile;->close()V

    .line 133
    .line 134
    .line 135
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iget-object p1, p1, Landroid/content/pm/ApplicationInfo;->nonLocalizedLabel:Ljava/lang/CharSequence;

    .line 140
    .line 141
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-static {p0, v1, v1, v1}, La/A8;->xF(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;La/lw;)La/Q;

    .line 146
    .line 147
    .line 148
    move-result-object v4

    .line 149
    invoke-virtual {v4, p0}, La/Q;->h(Landroid/content/Context;)La/i;

    .line 150
    .line 151
    .line 152
    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 153
    :try_start_1
    invoke-static {p0, v2, v5, v3, p1}, La/Qr;->g(Landroid/content/Context;Ljava/io/File;Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/CharSequence;)Z

    .line 154
    .line 155
    .line 156
    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 157
    if-nez p0, :cond_1

    .line 158
    .line 159
    :try_start_2
    invoke-static {v5, v1}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 160
    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_1
    invoke-static {v5, v1}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v4}, La/Q;->p()Landroid/content/Intent;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    :goto_1
    if-eqz v1, :cond_2

    .line 171
    .line 172
    iput-object v1, p2, La/yX;->d:Landroid/content/Intent;

    .line 173
    .line 174
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    .line 175
    .line 176
    .line 177
    goto :goto_3

    .line 178
    :cond_2
    new-instance p0, Ljava/io/IOException;

    .line 179
    .line 180
    const-string p1, "HideAPK patch error"

    .line 181
    .line 182
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw p0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 186
    :catchall_0
    move-exception p0

    .line 187
    :try_start_3
    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 188
    :catchall_1
    move-exception p1

    .line 189
    :try_start_4
    invoke-static {v5, p0}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 190
    .line 191
    .line 192
    throw p1

    .line 193
    :cond_3
    sget-object p1, La/dO;->w:La/dO;

    .line 194
    .line 195
    sget-object p1, La/dO;->h:Ljava/lang/ref/WeakReference;

    .line 196
    .line 197
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    check-cast p1, Landroid/app/Activity;

    .line 202
    .line 203
    if-eqz p1, :cond_4

    .line 204
    .line 205
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    invoke-virtual {p1}, Landroid/app/Activity;->finishAffinity()V

    .line 218
    .line 219
    .line 220
    invoke-virtual {p1, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 221
    .line 222
    .line 223
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-virtual {p1, v4}, Ljava/lang/Runtime;->exit(I)V

    .line 228
    .line 229
    .line 230
    sget-object v1, La/rr;->w:La/rr;

    .line 231
    .line 232
    :cond_4
    if-nez v1, :cond_6

    .line 233
    .line 234
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object p0

    .line 242
    invoke-virtual {p1, p0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    const p1, 0x10008000

    .line 247
    .line 248
    .line 249
    invoke-virtual {p0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 250
    .line 251
    .line 252
    iput-object p0, p2, La/yX;->d:Landroid/content/Intent;

    .line 253
    .line 254
    sget-object p0, La/AH;->R:La/AH;

    .line 255
    .line 256
    iput-object p0, p2, La/yX;->L:La/Lc;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 257
    .line 258
    goto :goto_3

    .line 259
    :goto_2
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 260
    .line 261
    .line 262
    throw p0

    .line 263
    :cond_5
    invoke-static {p0, v1, v1, v1}, La/A8;->xF(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;La/lw;)La/Q;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-virtual {v0, p0}, La/Q;->h(Landroid/content/Context;)La/i;

    .line 268
    .line 269
    .line 270
    move-result-object p0

    .line 271
    invoke-static {p2, p1, p0}, Lcom/topjohnwu/magisk/core/download/DownloadService;->i(La/yX;La/cq;Ljava/io/OutputStream;)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {v0}, La/Q;->p()Landroid/content/Intent;

    .line 275
    .line 276
    .line 277
    move-result-object p0

    .line 278
    iput-object p0, p2, La/yX;->d:Landroid/content/Intent;

    .line 279
    .line 280
    :cond_6
    :goto_3
    return-void
.end method


# virtual methods
.method public final onDestroy()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/download/DownloadService;->L:La/gC;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, La/uH;->w(Ljava/util/concurrent/CancellationException;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 1

    .line 1
    const-string p2, "subject"

    .line 2
    .line 3
    invoke-virtual {p1, p2}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, La/Au;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, La/Au;->i()I

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    sget-object p3, La/QP;->K:La/QP;

    .line 16
    .line 17
    invoke-virtual {p0, p2, p3}, La/US;->h(ILa/nY;)V

    .line 18
    .line 19
    .line 20
    iget-object p2, p0, Lcom/topjohnwu/magisk/core/download/DownloadService;->L:La/gC;

    .line 21
    .line 22
    sget-object p3, La/Th;->h:La/Zs;

    .line 23
    .line 24
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-static {p2, p3}, La/A8;->rV(La/oj;La/oj;)La/oj;

    .line 28
    .line 29
    .line 30
    move-result-object p2

    .line 31
    invoke-static {p2}, La/rE;->w(La/oj;)La/gf;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    new-instance p3, La/kl;

    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    invoke-direct {p3, p0, p1, v0}, La/kl;-><init>(Lcom/topjohnwu/magisk/core/download/DownloadService;La/Au;La/hu;)V

    .line 39
    .line 40
    .line 41
    const/4 p1, 0x3

    .line 42
    invoke-static {p2, v0, p3, p1}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 43
    .line 44
    .line 45
    :cond_0
    const/4 p1, 0x2

    .line 46
    return p1
.end method
