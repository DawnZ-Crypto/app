.class public Lcom/google/android/material/button/MaterialButton;
.super La/Bz;
.source "SourceFile"

# interfaces
.implements Landroid/widget/Checkable;
.implements La/Io;


# static fields
.field public static final k:[I

.field public static final v:[I


# instance fields
.field public D:Z

.field public E:Ljava/lang/String;

.field public F:Landroid/graphics/drawable/Drawable;

.field public H:I

.field public final P:I

.field public final S:I

.field public final U:I

.field public final W:Landroid/graphics/PorterDuff$Mode;

.field public final d:La/Dg;

.field public final f:Ljava/util/LinkedHashSet;

.field public l:La/ze;

.field public final q:Landroid/content/res/ColorStateList;

.field public u:Z

.field public z:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const v0, 0x101009f

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/button/MaterialButton;->k:[I

    const v0, 0x10100a0

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/button/MaterialButton;->v:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    const v0, 0x7f0402f6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 20

    move-object/from16 v0, p0

    move-object/from16 v7, p2

    move/from16 v8, p3

    const v9, 0x7f13042f

    move-object/from16 v1, p1

    invoke-static {v1, v7, v8, v9}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, v7, v8}, La/Bz;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v1, v0, Lcom/google/android/material/button/MaterialButton;->f:Ljava/util/LinkedHashSet;

    const/4 v10, 0x0

    iput-boolean v10, v0, Lcom/google/android/material/button/MaterialButton;->D:Z

    iput-boolean v10, v0, Lcom/google/android/material/button/MaterialButton;->u:Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v11

    sget-object v3, La/tS;->L:[I

    const v5, 0x7f13042f

    new-array v6, v10, [I

    move-object v1, v11

    move-object/from16 v2, p2

    move/from16 v4, p3

    invoke-static/range {v1 .. v6}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object v1

    const/16 v2, 0xc

    invoke-virtual {v1, v2, v10}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    iput v2, v0, Lcom/google/android/material/button/MaterialButton;->P:I

    const/16 v3, 0xf

    const/4 v4, -0x1

    invoke-virtual {v1, v3, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-static {v3, v5}, La/rE;->C6(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v3

    iput-object v3, v0, Lcom/google/android/material/button/MaterialButton;->W:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/16 v6, 0xe

    invoke-static {v3, v1, v6}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v3

    iput-object v3, v0, Lcom/google/android/material/button/MaterialButton;->q:Landroid/content/res/ColorStateList;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/16 v6, 0xa

    invoke-static {v3, v1, v6}, La/rx;->t(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    iput-object v3, v0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    const/16 v3, 0xb

    const/4 v6, 0x1

    invoke-virtual {v1, v3, v6}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v3

    iput v3, v0, Lcom/google/android/material/button/MaterialButton;->U:I

    const/16 v3, 0xd

    invoke-virtual {v1, v3, v10}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v3

    iput v3, v0, Lcom/google/android/material/button/MaterialButton;->S:I

    invoke-static {v11, v7, v8, v9}, La/c9;->h(Landroid/content/Context;Landroid/util/AttributeSet;II)La/as;

    move-result-object v3

    invoke-virtual {v3}, La/as;->w()La/c9;

    move-result-object v3

    new-instance v7, La/Dg;

    invoke-direct {v7, v0, v3}, La/Dg;-><init>(Lcom/google/android/material/button/MaterialButton;La/c9;)V

    iput-object v7, v0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 2
    invoke-virtual {v1, v6, v10}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v3

    iput v3, v7, La/Dg;->p:I

    const/4 v3, 0x2

    invoke-virtual {v1, v3, v10}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v8

    iput v8, v7, La/Dg;->e:I

    const/4 v8, 0x3

    invoke-virtual {v1, v8, v10}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v8

    iput v8, v7, La/Dg;->i:I

    const/4 v8, 0x4

    invoke-virtual {v1, v8, v10}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v8

    iput v8, v7, La/Dg;->Q:I

    const/16 v8, 0x8

    invoke-virtual {v1, v8}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v9

    if-eqz v9, :cond_0

    invoke-virtual {v1, v8, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iget-object v9, v7, La/Dg;->h:La/c9;

    int-to-float v8, v8

    .line 3
    invoke-virtual {v9}, La/c9;->Q()La/as;

    move-result-object v9

    .line 4
    new-instance v11, La/r;

    invoke-direct {v11, v8}, La/r;-><init>(F)V

    iput-object v11, v9, La/as;->i:La/cv;

    .line 5
    new-instance v11, La/r;

    invoke-direct {v11, v8}, La/r;-><init>(F)V

    iput-object v11, v9, La/as;->Q:La/cv;

    .line 6
    new-instance v11, La/r;

    invoke-direct {v11, v8}, La/r;-><init>(F)V

    iput-object v11, v9, La/as;->X:La/cv;

    .line 7
    new-instance v11, La/r;

    invoke-direct {v11, v8}, La/r;-><init>(F)V

    iput-object v11, v9, La/as;->O:La/cv;

    .line 8
    invoke-virtual {v9}, La/as;->w()La/c9;

    move-result-object v8

    .line 9
    invoke-virtual {v7, v8}, La/Dg;->p(La/c9;)V

    :cond_0
    const/16 v8, 0x14

    invoke-virtual {v1, v8, v10}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iput v8, v7, La/Dg;->X:I

    const/4 v8, 0x7

    invoke-virtual {v1, v8, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v8

    invoke-static {v8, v5}, La/rE;->C6(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v5

    iput-object v5, v7, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/4 v8, 0x6

    invoke-static {v5, v1, v8}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v5

    iput-object v5, v7, La/Dg;->V:Landroid/content/res/ColorStateList;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/16 v8, 0x13

    invoke-static {v5, v1, v8}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v5

    iput-object v5, v7, La/Dg;->I:Landroid/content/res/ColorStateList;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/16 v8, 0x10

    invoke-static {v5, v1, v8}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v5

    iput-object v5, v7, La/Dg;->M:Landroid/content/res/ColorStateList;

    const/4 v5, 0x5

    invoke-virtual {v1, v5, v10}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    iput-boolean v5, v7, La/Dg;->K:Z

    const/16 v5, 0x9

    invoke-virtual {v1, v5, v10}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    iput v5, v7, La/Dg;->d:I

    const/16 v5, 0x15

    invoke-virtual {v1, v5, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    iput-boolean v5, v7, La/Dg;->R:Z

    sget-object v5, La/sI;->w:Ljava/util/WeakHashMap;

    .line 10
    invoke-static/range {p0 .. p0}, La/XC;->Q(Landroid/view/View;)I

    move-result v5

    .line 11
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v8

    .line 12
    invoke-static/range {p0 .. p0}, La/XC;->i(Landroid/view/View;)I

    move-result v9

    .line 13
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v11

    invoke-virtual {v1, v10}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v12

    if-eqz v12, :cond_1

    iput-boolean v6, v7, La/Dg;->y:Z

    iget-object v3, v7, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 14
    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->V(Landroid/content/res/ColorStateList;)V

    iget-object v3, v7, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->I(Landroid/graphics/PorterDuff$Mode;)V

    move v3, v10

    goto/16 :goto_1

    .line 15
    :cond_1
    new-instance v12, La/ex;

    iget-object v13, v7, La/Dg;->h:La/c9;

    invoke-direct {v12, v13}, La/ex;-><init>(La/c9;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    invoke-virtual {v12, v13}, La/ex;->T(Landroid/content/Context;)V

    iget-object v13, v7, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 16
    invoke-static {v12, v13}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    iget-object v13, v7, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    if-eqz v13, :cond_2

    .line 17
    invoke-static {v12, v13}, La/YU;->V(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    iget v13, v7, La/Dg;->X:I

    int-to-float v13, v13

    iget-object v14, v7, La/Dg;->I:Landroid/content/res/ColorStateList;

    iget-object v15, v12, La/ex;->X:La/JP;

    .line 18
    iput v13, v15, La/JP;->M:F

    invoke-virtual {v12}, La/ex;->invalidateSelf()V

    iget-object v13, v12, La/ex;->X:La/JP;

    .line 19
    iget-object v15, v13, La/JP;->e:Landroid/content/res/ColorStateList;

    if-eq v15, v14, :cond_3

    iput-object v14, v13, La/JP;->e:Landroid/content/res/ColorStateList;

    invoke-virtual {v12}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v13

    invoke-virtual {v12, v13}, La/ex;->onStateChange([I)Z

    .line 20
    :cond_3
    new-instance v13, La/ex;

    iget-object v14, v7, La/Dg;->h:La/c9;

    invoke-direct {v13, v14}, La/ex;-><init>(La/c9;)V

    invoke-virtual {v13, v10}, La/ex;->setTint(I)V

    iget v14, v7, La/Dg;->X:I

    int-to-float v14, v14

    iget-boolean v15, v7, La/Dg;->m:Z

    if-eqz v15, :cond_4

    const v15, 0x7f04012d

    invoke-static {v0, v15}, La/rE;->o(Landroid/view/View;I)I

    move-result v15

    goto :goto_0

    :cond_4
    move v15, v10

    :goto_0
    iget-object v6, v13, La/ex;->X:La/JP;

    .line 21
    iput v14, v6, La/JP;->M:F

    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 22
    invoke-static {v15}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    iget-object v14, v13, La/ex;->X:La/JP;

    .line 23
    iget-object v15, v14, La/JP;->e:Landroid/content/res/ColorStateList;

    if-eq v15, v6, :cond_5

    iput-object v6, v14, La/JP;->e:Landroid/content/res/ColorStateList;

    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v6

    invoke-virtual {v13, v6}, La/ex;->onStateChange([I)Z

    .line 24
    :cond_5
    new-instance v6, La/ex;

    iget-object v14, v7, La/Dg;->h:La/c9;

    invoke-direct {v6, v14}, La/ex;-><init>(La/c9;)V

    iput-object v6, v7, La/Dg;->T:La/ex;

    .line 25
    invoke-static {v6, v4}, La/YU;->X(Landroid/graphics/drawable/Drawable;I)V

    .line 26
    new-instance v4, Landroid/graphics/drawable/RippleDrawable;

    iget-object v6, v7, La/Dg;->M:Landroid/content/res/ColorStateList;

    invoke-static {v6}, La/J3;->h(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v6

    new-instance v15, Landroid/graphics/drawable/LayerDrawable;

    new-array v3, v3, [Landroid/graphics/drawable/Drawable;

    aput-object v13, v3, v10

    const/4 v13, 0x1

    aput-object v12, v3, v13

    invoke-direct {v15, v3}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 27
    new-instance v3, Landroid/graphics/drawable/InsetDrawable;

    iget v12, v7, La/Dg;->p:I

    iget v14, v7, La/Dg;->i:I

    iget v13, v7, La/Dg;->e:I

    iget v10, v7, La/Dg;->Q:I

    move/from16 v17, v14

    move-object v14, v3

    move/from16 v16, v12

    move/from16 v18, v13

    move/from16 v19, v10

    invoke-direct/range {v14 .. v19}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    iget-object v10, v7, La/Dg;->T:La/ex;

    .line 28
    invoke-direct {v4, v6, v3, v10}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    iput-object v4, v7, La/Dg;->L:Landroid/graphics/drawable/RippleDrawable;

    .line 29
    invoke-virtual {v0, v4}, Lcom/google/android/material/button/MaterialButton;->O(Landroid/graphics/drawable/RippleDrawable;)V

    const/4 v3, 0x0

    .line 30
    invoke-virtual {v7, v3}, La/Dg;->h(Z)La/ex;

    move-result-object v4

    if-eqz v4, :cond_6

    iget v6, v7, La/Dg;->d:I

    int-to-float v6, v6

    .line 31
    invoke-virtual {v4, v6}, La/ex;->y(F)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_6
    :goto_1
    iget v4, v7, La/Dg;->p:I

    add-int/2addr v5, v4

    iget v4, v7, La/Dg;->i:I

    add-int/2addr v8, v4

    iget v4, v7, La/Dg;->e:I

    add-int/2addr v9, v4

    iget v4, v7, La/Dg;->Q:I

    add-int/2addr v11, v4

    .line 32
    invoke-static {v0, v5, v8, v9, v11}, La/XC;->M(Landroid/view/View;IIII)V

    .line 33
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    iget-object v1, v0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_7

    const/4 v10, 0x1

    goto :goto_2

    :cond_7
    move v10, v3

    :goto_2
    invoke-virtual {v0, v10}, Lcom/google/android/material/button/MaterialButton;->M(Z)V

    return-void
.end method


# virtual methods
.method public final I(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 8
    .line 9
    iget-object v1, v0, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 10
    .line 11
    if-eq v1, p1, :cond_1

    .line 12
    .line 13
    iput-object p1, v0, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    invoke-virtual {v0, p1}, La/Dg;->h(Z)La/ex;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    iget-object v1, v0, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 23
    .line 24
    if-eqz v1, :cond_1

    .line 25
    .line 26
    invoke-virtual {v0, p1}, La/Dg;->h(Z)La/ex;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v0, v0, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 31
    .line 32
    invoke-static {p1, v0}, La/YU;->V(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    iget-object v0, p0, La/Bz;->K:La/kU;

    .line 37
    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    invoke-virtual {v0, p1}, La/kU;->I(Landroid/graphics/PorterDuff$Mode;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    :goto_0
    return-void
.end method

.method public final M(Z)V
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_3

    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iput-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 11
    .line 12
    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->q:Landroid/content/res/ColorStateList;

    .line 13
    .line 14
    invoke-static {v0, v2}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->W:Landroid/graphics/PorterDuff$Mode;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 22
    .line 23
    invoke-static {v2, v0}, La/YU;->V(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->S:I

    .line 27
    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    move v2, v0

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 33
    .line 34
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    :goto_0
    if-eqz v0, :cond_2

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_2
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 42
    .line 43
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    :goto_1
    iget-object v3, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 48
    .line 49
    iget v4, p0, Lcom/google/android/material/button/MaterialButton;->H:I

    .line 50
    .line 51
    iget v5, p0, Lcom/google/android/material/button/MaterialButton;->z:I

    .line 52
    .line 53
    add-int/2addr v2, v4

    .line 54
    add-int/2addr v0, v5

    .line 55
    invoke-virtual {v3, v4, v5, v2, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 56
    .line 57
    .line 58
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    invoke-virtual {v0, v1, p1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 61
    .line 62
    .line 63
    :cond_3
    if-eqz p1, :cond_4

    .line 64
    .line 65
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->X()V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_4
    invoke-static {p0}, La/aK;->w(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    const/4 v0, 0x0

    .line 74
    aget-object v0, p1, v0

    .line 75
    .line 76
    aget-object v2, p1, v1

    .line 77
    .line 78
    const/4 v3, 0x2

    .line 79
    aget-object p1, p1, v3

    .line 80
    .line 81
    iget v4, p0, Lcom/google/android/material/button/MaterialButton;->U:I

    .line 82
    .line 83
    if-eq v4, v1, :cond_5

    .line 84
    .line 85
    if-ne v4, v3, :cond_6

    .line 86
    .line 87
    :cond_5
    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 88
    .line 89
    if-ne v0, v1, :cond_a

    .line 90
    .line 91
    :cond_6
    const/4 v0, 0x3

    .line 92
    if-eq v4, v0, :cond_7

    .line 93
    .line 94
    const/4 v0, 0x4

    .line 95
    if-ne v4, v0, :cond_8

    .line 96
    .line 97
    :cond_7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 98
    .line 99
    if-ne p1, v0, :cond_a

    .line 100
    .line 101
    :cond_8
    const/16 p1, 0x10

    .line 102
    .line 103
    if-eq v4, p1, :cond_9

    .line 104
    .line 105
    const/16 p1, 0x20

    .line 106
    .line 107
    if-ne v4, p1, :cond_b

    .line 108
    .line 109
    :cond_9
    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 110
    .line 111
    if-eq v2, p1, :cond_b

    .line 112
    .line 113
    :cond_a
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->X()V

    .line 114
    .line 115
    .line 116
    :cond_b
    return-void
.end method

.method public final O(Landroid/graphics/drawable/RippleDrawable;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, La/Bz;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final T(II)V
    .locals 10

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz v0, :cond_19

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    goto/16 :goto_c

    .line 12
    .line 13
    :cond_0
    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->U:I

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    const/4 v2, 0x2

    .line 17
    const/4 v3, 0x1

    .line 18
    if-eq v0, v3, :cond_2

    .line 19
    .line 20
    if-ne v0, v2, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    move v4, v1

    .line 24
    goto :goto_1

    .line 25
    :cond_2
    :goto_0
    move v4, v3

    .line 26
    :goto_1
    iget v5, p0, Lcom/google/android/material/button/MaterialButton;->P:I

    .line 27
    .line 28
    iget v6, p0, Lcom/google/android/material/button/MaterialButton;->S:I

    .line 29
    .line 30
    const/4 v7, 0x4

    .line 31
    const/4 v8, 0x3

    .line 32
    if-nez v4, :cond_9

    .line 33
    .line 34
    if-eq v0, v8, :cond_9

    .line 35
    .line 36
    if-ne v0, v7, :cond_3

    .line 37
    .line 38
    goto/16 :goto_5

    .line 39
    .line 40
    :cond_3
    const/16 p1, 0x10

    .line 41
    .line 42
    if-eq v0, p1, :cond_4

    .line 43
    .line 44
    const/16 v4, 0x20

    .line 45
    .line 46
    if-ne v0, v4, :cond_17

    .line 47
    .line 48
    :cond_4
    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->H:I

    .line 49
    .line 50
    if-ne v0, p1, :cond_5

    .line 51
    .line 52
    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->z:I

    .line 53
    .line 54
    :goto_2
    invoke-virtual {p0, v1}, Lcom/google/android/material/button/MaterialButton;->M(Z)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_5
    if-nez v6, :cond_6

    .line 59
    .line 60
    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 61
    .line 62
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    :cond_6
    invoke-virtual {p0}, Landroid/widget/TextView;->getLineCount()I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-le p1, v3, :cond_7

    .line 71
    .line 72
    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-virtual {p1}, Landroid/text/Layout;->getHeight()I

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    goto :goto_3

    .line 81
    :cond_7
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    if-eqz v3, :cond_8

    .line 98
    .line 99
    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    invoke-interface {v3, v0, p0}, Landroid/text/method/TransformationMethod;->getTransformation(Ljava/lang/CharSequence;Landroid/view/View;)Ljava/lang/CharSequence;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    :cond_8
    new-instance v3, Landroid/graphics/Rect;

    .line 112
    .line 113
    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 117
    .line 118
    .line 119
    move-result v4

    .line 120
    invoke-virtual {p1, v0, v1, v4, v3}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 124
    .line 125
    .line 126
    move-result p1

    .line 127
    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    .line 132
    .line 133
    .line 134
    move-result v0

    .line 135
    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    .line 136
    .line 137
    .line 138
    move-result p1

    .line 139
    :goto_3
    sub-int/2addr p2, p1

    .line 140
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 141
    .line 142
    .line 143
    move-result p1

    .line 144
    sub-int/2addr p2, p1

    .line 145
    sub-int/2addr p2, v6

    .line 146
    sub-int/2addr p2, v5

    .line 147
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    sub-int/2addr p2, p1

    .line 152
    div-int/2addr p2, v2

    .line 153
    invoke-static {v1, p2}, Ljava/lang/Math;->max(II)I

    .line 154
    .line 155
    .line 156
    move-result p1

    .line 157
    iget p2, p0, Lcom/google/android/material/button/MaterialButton;->z:I

    .line 158
    .line 159
    if-eq p2, p1, :cond_17

    .line 160
    .line 161
    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->z:I

    .line 162
    .line 163
    :goto_4
    invoke-virtual {p0, v1}, Lcom/google/android/material/button/MaterialButton;->M(Z)V

    .line 164
    .line 165
    .line 166
    goto/16 :goto_a

    .line 167
    .line 168
    :cond_9
    :goto_5
    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->z:I

    .line 169
    .line 170
    invoke-virtual {p0}, Landroid/view/View;->getTextAlignment()I

    .line 171
    .line 172
    .line 173
    move-result p2

    .line 174
    if-eq p2, v3, :cond_c

    .line 175
    .line 176
    const/4 v4, 0x6

    .line 177
    if-eq p2, v4, :cond_b

    .line 178
    .line 179
    if-eq p2, v8, :cond_b

    .line 180
    .line 181
    if-eq p2, v7, :cond_a

    .line 182
    .line 183
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    .line 184
    .line 185
    goto :goto_6

    .line 186
    :cond_a
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    .line 187
    .line 188
    goto :goto_6

    .line 189
    :cond_b
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    .line 190
    .line 191
    goto :goto_6

    .line 192
    :cond_c
    invoke-virtual {p0}, Landroid/widget/TextView;->getGravity()I

    .line 193
    .line 194
    .line 195
    move-result p2

    .line 196
    const v4, 0x800007

    .line 197
    .line 198
    .line 199
    and-int/2addr p2, v4

    .line 200
    if-eq p2, v3, :cond_e

    .line 201
    .line 202
    const/4 v4, 0x5

    .line 203
    if-eq p2, v4, :cond_d

    .line 204
    .line 205
    const v4, 0x800005

    .line 206
    .line 207
    .line 208
    if-eq p2, v4, :cond_d

    .line 209
    .line 210
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    .line 211
    .line 212
    goto :goto_6

    .line 213
    :cond_d
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    .line 214
    .line 215
    goto :goto_6

    .line 216
    :cond_e
    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    .line 217
    .line 218
    :goto_6
    if-eq v0, v3, :cond_18

    .line 219
    .line 220
    if-eq v0, v8, :cond_18

    .line 221
    .line 222
    if-ne v0, v2, :cond_f

    .line 223
    .line 224
    sget-object v2, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    .line 225
    .line 226
    if-eq p2, v2, :cond_18

    .line 227
    .line 228
    :cond_f
    if-ne v0, v7, :cond_10

    .line 229
    .line 230
    sget-object v2, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    .line 231
    .line 232
    if-ne p2, v2, :cond_10

    .line 233
    .line 234
    goto :goto_b

    .line 235
    :cond_10
    if-nez v6, :cond_11

    .line 236
    .line 237
    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 238
    .line 239
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 240
    .line 241
    .line 242
    move-result v6

    .line 243
    :cond_11
    invoke-virtual {p0}, Landroid/widget/TextView;->getLineCount()I

    .line 244
    .line 245
    .line 246
    move-result v2

    .line 247
    const/4 v4, 0x0

    .line 248
    move v8, v1

    .line 249
    :goto_7
    if-ge v8, v2, :cond_12

    .line 250
    .line 251
    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    .line 252
    .line 253
    .line 254
    move-result-object v9

    .line 255
    invoke-virtual {v9, v8}, Landroid/text/Layout;->getLineWidth(I)F

    .line 256
    .line 257
    .line 258
    move-result v9

    .line 259
    invoke-static {v4, v9}, Ljava/lang/Math;->max(FF)F

    .line 260
    .line 261
    .line 262
    move-result v4

    .line 263
    add-int/lit8 v8, v8, 0x1

    .line 264
    .line 265
    goto :goto_7

    .line 266
    :cond_12
    float-to-double v8, v4

    .line 267
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 268
    .line 269
    .line 270
    move-result-wide v8

    .line 271
    double-to-int v2, v8

    .line 272
    sub-int/2addr p1, v2

    .line 273
    sget-object v2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 274
    .line 275
    invoke-static {p0}, La/XC;->i(Landroid/view/View;)I

    .line 276
    .line 277
    .line 278
    move-result v2

    .line 279
    sub-int/2addr p1, v2

    .line 280
    sub-int/2addr p1, v6

    .line 281
    sub-int/2addr p1, v5

    .line 282
    invoke-static {p0}, La/XC;->Q(Landroid/view/View;)I

    .line 283
    .line 284
    .line 285
    move-result v2

    .line 286
    sub-int/2addr p1, v2

    .line 287
    sget-object v2, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    .line 288
    .line 289
    if-ne p2, v2, :cond_13

    .line 290
    .line 291
    div-int/lit8 p1, p1, 0x2

    .line 292
    .line 293
    :cond_13
    invoke-static {p0}, La/XC;->e(Landroid/view/View;)I

    .line 294
    .line 295
    .line 296
    move-result p2

    .line 297
    if-ne p2, v3, :cond_14

    .line 298
    .line 299
    move p2, v3

    .line 300
    goto :goto_8

    .line 301
    :cond_14
    move p2, v1

    .line 302
    :goto_8
    if-ne v0, v7, :cond_15

    .line 303
    .line 304
    goto :goto_9

    .line 305
    :cond_15
    move v3, v1

    .line 306
    :goto_9
    if-eq p2, v3, :cond_16

    .line 307
    .line 308
    neg-int p1, p1

    .line 309
    :cond_16
    iget p2, p0, Lcom/google/android/material/button/MaterialButton;->H:I

    .line 310
    .line 311
    if-eq p2, p1, :cond_17

    .line 312
    .line 313
    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->H:I

    .line 314
    .line 315
    goto/16 :goto_4

    .line 316
    .line 317
    :cond_17
    :goto_a
    return-void

    .line 318
    :cond_18
    :goto_b
    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->H:I

    .line 319
    .line 320
    goto/16 :goto_2

    .line 321
    .line 322
    :cond_19
    :goto_c
    return-void
.end method

.method public final V(Landroid/content/res/ColorStateList;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 8
    .line 9
    iget-object v1, v0, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 10
    .line 11
    if-eq v1, p1, :cond_1

    .line 12
    .line 13
    iput-object p1, v0, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    invoke-virtual {v0, p1}, La/Dg;->h(Z)La/ex;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    invoke-virtual {v0, p1}, La/Dg;->h(Z)La/ex;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    iget-object v0, v0, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 27
    .line 28
    invoke-static {p1, v0}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    iget-object v0, p0, La/Bz;->K:La/kU;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    invoke-virtual {v0, p1}, La/kU;->V(Landroid/content/res/ColorStateList;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    :goto_0
    return-void
.end method

.method public final X()V
    .locals 3

    .line 1
    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->U:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eq v0, v1, :cond_1

    .line 5
    .line 6
    const/4 v2, 0x2

    .line 7
    if-ne v0, v2, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v1, 0x0

    .line 11
    :cond_1
    :goto_0
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_2

    .line 13
    .line 14
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 15
    .line 16
    invoke-static {p0, v0, v2, v2, v2}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 17
    .line 18
    .line 19
    goto :goto_2

    .line 20
    :cond_2
    const/4 v1, 0x3

    .line 21
    if-eq v0, v1, :cond_5

    .line 22
    .line 23
    const/4 v1, 0x4

    .line 24
    if-ne v0, v1, :cond_3

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :cond_3
    const/16 v1, 0x10

    .line 28
    .line 29
    if-eq v0, v1, :cond_4

    .line 30
    .line 31
    const/16 v1, 0x20

    .line 32
    .line 33
    if-ne v0, v1, :cond_6

    .line 34
    .line 35
    :cond_4
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 36
    .line 37
    invoke-static {p0, v2, v0, v2, v2}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 38
    .line 39
    .line 40
    goto :goto_2

    .line 41
    :cond_5
    :goto_1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 42
    .line 43
    invoke-static {p0, v2, v2, v0, v2}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 44
    .line 45
    .line 46
    :cond_6
    :goto_2
    return-void
.end method

.method public final e()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-boolean v0, v0, La/Dg;->y:Z

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    return v0
.end method

.method public final getBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 8
    .line 9
    iget-object v0, v0, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v0, p0, La/Bz;->K:La/kU;

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {v0}, La/kU;->p()Landroid/content/res/ColorStateList;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    const/4 v0, 0x0

    .line 22
    :goto_0
    return-object v0
.end method

.method public final getBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 8
    .line 9
    iget-object v0, v0, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v0, p0, La/Bz;->K:La/kU;

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {v0}, La/kU;->e()Landroid/graphics/PorterDuff$Mode;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    const/4 v0, 0x0

    .line 22
    :goto_0
    return-object v0
.end method

.method public final h(La/c9;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    invoke-virtual {v0, p1}, La/Dg;->p(La/c9;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final isChecked()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    return v0
.end method

.method public onAttachedToWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/widget/Button;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 12
    .line 13
    invoke-virtual {v1, v0}, La/Dg;->h(Z)La/ex;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {p0, v0}, La/rx;->GI(Landroid/view/View;La/ex;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final onCreateDrawableState(I)[I
    .locals 1

    add-int/lit8 p1, p1, 0x2

    invoke-super {p0, p1}, Landroid/widget/Button;->onCreateDrawableState(I)[I

    move-result-object p1

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->p()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/google/android/material/button/MaterialButton;->k:[I

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/google/android/material/button/MaterialButton;->v:[I

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_1
    return-object p1
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, La/Bz;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->E:Ljava/lang/String;

    .line 5
    .line 6
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->E:Ljava/lang/String;

    .line 13
    .line 14
    goto :goto_1

    .line 15
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->p()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    const-class v0, Landroid/widget/CompoundButton;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const-class v0, Landroid/widget/Button;

    .line 25
    .line 26
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    :goto_1
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, La/Bz;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->E:Ljava/lang/String;

    .line 5
    .line 6
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->E:Ljava/lang/String;

    .line 13
    .line 14
    goto :goto_1

    .line 15
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->p()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    const-class v0, Landroid/widget/CompoundButton;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const-class v0, Landroid/widget/Button;

    .line 25
    .line 26
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    :goto_1
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->p()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final onLayout(ZIIII)V
    .locals 0

    invoke-super/range {p0 .. p5}, La/Bz;->onLayout(ZIIII)V

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/button/MaterialButton;->T(II)V

    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    .line 1
    instance-of v0, p1, La/K8;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/widget/Button;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, La/K8;

    .line 10
    .line 11
    iget-object v0, p1, La/o;->X:Landroid/os/Parcelable;

    .line 12
    .line 13
    invoke-super {p0, v0}, Landroid/widget/Button;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 14
    .line 15
    .line 16
    iget-boolean p1, p1, La/K8;->R:Z

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/widget/Button;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, La/K8;

    .line 6
    .line 7
    invoke-direct {v1, v0}, La/o;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    .line 11
    .line 12
    iput-boolean v0, v1, La/K8;->R:Z

    .line 13
    .line 14
    return-object v1
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, La/Bz;->onTextChanged(Ljava/lang/CharSequence;III)V

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/button/MaterialButton;->T(II)V

    return-void
.end method

.method public final p()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-boolean v0, v0, La/Dg;->K:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    return v0
.end method

.method public final performClick()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 2
    .line 3
    iget-boolean v0, v0, La/Dg;->R:Z

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->toggle()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-super {p0}, Landroid/widget/Button;->performClick()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0
.end method

.method public final refreshDrawableState()V
    .locals 2

    invoke-super {p0}, Landroid/widget/Button;->refreshDrawableState()V

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_0
    return-void
.end method

.method public final setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final setBackgroundColor(I)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {v0, v1}, La/Dg;->h(Z)La/ex;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    if-eqz v2, :cond_1

    .line 15
    .line 16
    invoke-virtual {v0, v1}, La/Dg;->h(Z)La/ex;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0, p1}, La/ex;->setTint(I)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 25
    .line 26
    .line 27
    :cond_1
    :goto_0
    return-void
.end method

.method public final setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eq p1, v0, :cond_1

    .line 12
    .line 13
    const-string v0, "MaterialButton"

    .line 14
    .line 15
    const-string v1, "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled"

    .line 16
    .line 17
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 22
    .line 23
    iput-boolean v0, v1, La/Dg;->y:Z

    .line 24
    .line 25
    iget-object v0, v1, La/Dg;->V:Landroid/content/res/ColorStateList;

    .line 26
    .line 27
    iget-object v2, v1, La/Dg;->w:Lcom/google/android/material/button/MaterialButton;

    .line 28
    .line 29
    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->V(Landroid/content/res/ColorStateList;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, v1, La/Dg;->O:Landroid/graphics/PorterDuff$Mode;

    .line 33
    .line 34
    invoke-virtual {v2, v0}, Lcom/google/android/material/button/MaterialButton;->I(Landroid/graphics/PorterDuff$Mode;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-super {p0, p1}, La/Bz;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 50
    .line 51
    .line 52
    :goto_0
    return-void
.end method

.method public final setBackgroundResource(I)V
    .locals 1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, La/fe;->q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->V(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public final setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->I(Landroid/graphics/PorterDuff$Mode;)V

    return-void
.end method

.method public final setChecked(Z)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->p()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_4

    .line 12
    .line 13
    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    .line 14
    .line 15
    if-eq v0, p1, :cond_4

    .line 16
    .line 17
    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    .line 18
    .line 19
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->refreshDrawableState()V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    instance-of p1, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    .line 27
    .line 28
    if-eqz p1, :cond_1

    .line 29
    .line 30
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    check-cast p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    .line 35
    .line 36
    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    .line 37
    .line 38
    iget-boolean v1, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:Z

    .line 39
    .line 40
    if-eqz v1, :cond_0

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    invoke-virtual {p1, v1, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h(IZ)V

    .line 48
    .line 49
    .line 50
    :cond_1
    :goto_0
    iget-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->u:Z

    .line 51
    .line 52
    if-eqz p1, :cond_2

    .line 53
    .line 54
    return-void

    .line 55
    :cond_2
    const/4 p1, 0x1

    .line 56
    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->u:Z

    .line 57
    .line 58
    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->f:Ljava/util/LinkedHashSet;

    .line 59
    .line 60
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-nez v0, :cond_3

    .line 69
    .line 70
    const/4 p1, 0x0

    .line 71
    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->u:Z

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_3
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    const/4 p1, 0x0

    .line 82
    throw p1

    .line 83
    :cond_4
    :goto_1
    return-void
.end method

.method public final setElevation(F)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/Button;->setElevation(F)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 12
    .line 13
    invoke-virtual {v1, v0}, La/Dg;->h(Z)La/ex;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0, p1}, La/ex;->y(F)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final setPressed(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->l:La/ze;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, v0, La/ze;->K:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 10
    .line 11
    .line 12
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/Button;->setPressed(Z)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final setTextAlignment(I)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/Button;->setTextAlignment(I)V

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/button/MaterialButton;->T(II)V

    return-void
.end method

.method public final toggle()V
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->D:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    return-void
.end method
