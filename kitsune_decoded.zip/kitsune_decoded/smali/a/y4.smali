.class public abstract La/y4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final w()Z
    .locals 1

    .line 1
    move-object v0, p0

    check-cast v0, La/DF;

    iget v0, v0, La/DF;->p:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
