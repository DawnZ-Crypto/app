.class public final La/lO;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/Wc;


# static fields
.field public static final K:La/LH;


# instance fields
.field public final X:La/eh;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, La/LH;->e:Ljava/util/regex/Pattern;

    .line 2
    .line 3
    const-string v0, "application/json; charset=UTF-8"

    .line 4
    .line 5
    invoke-static {v0}, La/Qr;->F(Ljava/lang/String;)La/LH;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, La/lO;->K:La/LH;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(La/eh;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/lO;->X:La/eh;

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, La/WI;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, La/AN;

    .line 7
    .line 8
    invoke-direct {v1, v0}, La/AN;-><init>(La/WI;)V

    .line 9
    .line 10
    .line 11
    iget-object v2, p0, La/lO;->X:La/eh;

    .line 12
    .line 13
    invoke-virtual {v2, v1, p1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iget-wide v1, v0, La/WI;->K:J

    .line 17
    .line 18
    invoke-virtual {v0, v1, v2}, La/WI;->d(J)La/xi;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    new-instance v0, La/Ua;

    .line 23
    .line 24
    sget-object v1, La/lO;->K:La/LH;

    .line 25
    .line 26
    invoke-direct {v0, v1, p1}, La/Ua;-><init>(La/LH;La/xi;)V

    .line 27
    .line 28
    .line 29
    return-object v0
.end method
