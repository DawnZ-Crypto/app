.class public final La/rA;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "La/rA;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final K:La/Ef;

.field public final L:La/Ef;

.field public final R:La/B3;

.field public final X:La/Ef;

.field public final d:I

.field public final f:I

.field public final l:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/jS;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, La/jS;-><init>(I)V

    sput-object v0, La/rA;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(La/Ef;La/Ef;La/B3;La/Ef;I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La/rA;->X:La/Ef;

    .line 5
    .line 6
    iput-object p2, p0, La/rA;->K:La/Ef;

    .line 7
    .line 8
    iput-object p4, p0, La/rA;->L:La/Ef;

    .line 9
    .line 10
    iput p5, p0, La/rA;->d:I

    .line 11
    .line 12
    iput-object p3, p0, La/rA;->R:La/B3;

    .line 13
    .line 14
    if-eqz p4, :cond_1

    .line 15
    .line 16
    iget-object p3, p1, La/Ef;->X:Ljava/util/Calendar;

    .line 17
    .line 18
    iget-object v0, p4, La/Ef;->X:Ljava/util/Calendar;

    .line 19
    .line 20
    invoke-virtual {p3, v0}, Ljava/util/Calendar;->compareTo(Ljava/util/Calendar;)I

    .line 21
    .line 22
    .line 23
    move-result p3

    .line 24
    if-gtz p3, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 28
    .line 29
    const-string p2, "start Month cannot be after current Month"

    .line 30
    .line 31
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw p1

    .line 35
    :cond_1
    :goto_0
    if-eqz p4, :cond_3

    .line 36
    .line 37
    iget-object p3, p4, La/Ef;->X:Ljava/util/Calendar;

    .line 38
    .line 39
    iget-object p4, p2, La/Ef;->X:Ljava/util/Calendar;

    .line 40
    .line 41
    invoke-virtual {p3, p4}, Ljava/util/Calendar;->compareTo(Ljava/util/Calendar;)I

    .line 42
    .line 43
    .line 44
    move-result p3

    .line 45
    if-gtz p3, :cond_2

    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 49
    .line 50
    const-string p2, "current Month cannot be after end Month"

    .line 51
    .line 52
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    throw p1

    .line 56
    :cond_3
    :goto_1
    if-ltz p5, :cond_4

    .line 57
    .line 58
    const/4 p3, 0x0

    .line 59
    invoke-static {p3}, La/av;->e(Ljava/util/Calendar;)Ljava/util/Calendar;

    .line 60
    .line 61
    .line 62
    move-result-object p3

    .line 63
    const/4 p4, 0x7

    .line 64
    invoke-virtual {p3, p4}, Ljava/util/Calendar;->getMaximum(I)I

    .line 65
    .line 66
    .line 67
    move-result p3

    .line 68
    if-gt p5, p3, :cond_4

    .line 69
    .line 70
    invoke-virtual {p1, p2}, La/Ef;->Q(La/Ef;)I

    .line 71
    .line 72
    .line 73
    move-result p3

    .line 74
    add-int/lit8 p3, p3, 0x1

    .line 75
    .line 76
    iput p3, p0, La/rA;->l:I

    .line 77
    .line 78
    iget p2, p2, La/Ef;->R:I

    .line 79
    .line 80
    iget p1, p1, La/Ef;->R:I

    .line 81
    .line 82
    sub-int/2addr p2, p1

    .line 83
    add-int/lit8 p2, p2, 0x1

    .line 84
    .line 85
    iput p2, p0, La/rA;->f:I

    .line 86
    .line 87
    return-void

    .line 88
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 89
    .line 90
    const-string p2, "firstDayOfWeek is not valid"

    .line 91
    .line 92
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw p1
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, La/rA;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, La/rA;

    .line 12
    .line 13
    iget-object v1, p1, La/rA;->X:La/Ef;

    .line 14
    .line 15
    iget-object v3, p0, La/rA;->X:La/Ef;

    .line 16
    .line 17
    invoke-virtual {v3, v1}, La/Ef;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_2

    .line 22
    .line 23
    iget-object v1, p0, La/rA;->K:La/Ef;

    .line 24
    .line 25
    iget-object v3, p1, La/rA;->K:La/Ef;

    .line 26
    .line 27
    invoke-virtual {v1, v3}, La/Ef;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    iget-object v1, p0, La/rA;->L:La/Ef;

    .line 34
    .line 35
    iget-object v3, p1, La/rA;->L:La/Ef;

    .line 36
    .line 37
    invoke-static {v1, v3}, La/M4;->w(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    iget v1, p0, La/rA;->d:I

    .line 44
    .line 45
    iget v3, p1, La/rA;->d:I

    .line 46
    .line 47
    if-ne v1, v3, :cond_2

    .line 48
    .line 49
    iget-object v1, p0, La/rA;->R:La/B3;

    .line 50
    .line 51
    iget-object p1, p1, La/rA;->R:La/B3;

    .line 52
    .line 53
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    if-eqz p1, :cond_2

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    move v0, v2

    .line 61
    :goto_0
    return v0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    iget-object v2, p0, La/rA;->X:La/Ef;

    aput-object v2, v0, v1

    const/4 v1, 0x1

    iget-object v2, p0, La/rA;->K:La/Ef;

    aput-object v2, v0, v1

    const/4 v1, 0x2

    iget-object v2, p0, La/rA;->L:La/Ef;

    aput-object v2, v0, v1

    iget v1, p0, La/rA;->d:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x3

    aput-object v1, v0, v2

    const/4 v1, 0x4

    iget-object v2, p0, La/rA;->R:La/B3;

    aput-object v2, v0, v1

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    .line 1
    iget-object p2, p0, La/rA;->X:La/Ef;

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object p2, p0, La/rA;->K:La/Ef;

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object p2, p0, La/rA;->L:La/Ef;

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object p2, p0, La/rA;->R:La/B3;

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget p2, p0, La/rA;->d:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
