.class public final La/wr;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final w:La/ym;


# direct methods
.method public constructor <init>(La/ym;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/wr;->w:La/ym;

    return-void
.end method
