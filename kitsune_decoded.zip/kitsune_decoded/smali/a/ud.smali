.class public interface abstract La/ud;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract w(Landroid/content/Context;)V
.end method
