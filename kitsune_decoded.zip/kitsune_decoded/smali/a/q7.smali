.class public final La/q7;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/nY;


# static fields
.field public static final K:La/q7;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/q7;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, La/ig;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, La/q7;->K:La/q7;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final V(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, La/Ze;

    .line 2
    .line 3
    sget-object v0, La/Ze;->X:La/Ze;

    .line 4
    .line 5
    if-ne p1, v0, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 p1, 0x0

    .line 10
    :goto_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method
