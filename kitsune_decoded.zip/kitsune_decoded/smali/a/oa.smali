.class public final synthetic La/oa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/Ya;


# instance fields
.field public final synthetic X:La/cp;


# direct methods
.method public synthetic constructor <init>(La/cp;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/oa;->X:La/cp;

    return-void
.end method


# virtual methods
.method public final w(La/zr;)V
    .locals 3

    .line 1
    iget-object v0, p0, La/oa;->X:La/cp;

    .line 2
    .line 3
    iget-object v1, v0, La/cp;->i:Ljava/util/LinkedHashSet;

    .line 4
    .line 5
    iget-object v2, p1, La/zr;->n:Ljava/lang/String;

    .line 6
    .line 7
    invoke-static {v1}, La/A8;->X(Ljava/util/AbstractCollection;)Ljava/util/Collection;

    .line 8
    .line 9
    .line 10
    invoke-interface {v1, v2}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    iget-object v1, p1, La/zr;->rV:Landroidx/lifecycle/w;

    .line 17
    .line 18
    iget-object v2, v0, La/cp;->Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    .line 19
    .line 20
    invoke-virtual {v1, v2}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    iget-object v0, v0, La/cp;->X:Ljava/util/LinkedHashMap;

    .line 24
    .line 25
    iget-object p1, p1, La/zr;->n:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v0}, La/A8;->O(Ljava/util/LinkedHashMap;)Ljava/util/Map;

    .line 28
    .line 29
    .line 30
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    return-void
.end method
