.class public final La/yC;
.super Ljava/util/AbstractList;
.source "SourceFile"


# static fields
.field public static X:La/yC;


# direct methods
.method public static h()La/yC;
    .locals 1

    .line 1
    sget-object v0, La/yC;->X:La/yC;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, La/yC;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/AbstractList;-><init>()V

    .line 8
    .line 9
    .line 10
    sput-object v0, La/yC;->X:La/yC;

    .line 11
    .line 12
    :cond_0
    sget-object v0, La/yC;->X:La/yC;

    .line 13
    .line 14
    return-object v0
.end method


# virtual methods
.method public final bridge synthetic add(ILjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/String;

    return-void
.end method

.method public final bridge synthetic get(I)Ljava/lang/Object;
    .locals 0

    .line 1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final bridge synthetic remove(I)Ljava/lang/Object;
    .locals 0

    .line 1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final bridge synthetic set(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/String;

    const/4 p1, 0x0

    return-object p1
.end method

.method public final size()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method
