.class public final La/R6;
.super La/dI;
.source "SourceFile"

# interfaces
.implements La/Lk;


# instance fields
.field public final K:Ljava/lang/Object;

.field public final synthetic X:I


# direct methods
.method public constructor <init>(La/OW;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, La/R6;->X:I

    iput-object p1, p0, La/R6;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/R6;->X:I

    new-instance v0, La/Cj;

    invoke-direct {v0, p1, p2, p0, p3}, La/Cj;-><init>(Landroidx/databinding/w;ILa/Lk;Ljava/lang/ref/ReferenceQueue;)V

    iput-object v0, p0, La/R6;->K:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final M(La/RH;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Q(La/OV;II)V
    .locals 2

    .line 1
    iget v0, p0, La/R6;->X:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La/R6;->K:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La/OW;

    .line 9
    .line 10
    invoke-static {v0}, La/OW;->h(La/OW;)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    add-int/lit8 v1, v1, 0x1

    .line 15
    .line 16
    invoke-static {v0, v1}, La/OW;->p(La/OW;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, La/OW;->h(La/OW;)I

    .line 20
    .line 21
    .line 22
    invoke-static {v0, p1, p2}, La/OW;->e(La/OW;Ljava/util/List;I)I

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    iget-object p2, v0, La/OW;->K:La/m4;

    .line 27
    .line 28
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-static {p1, v1, p3}, La/m4;->M(III)La/R7;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    const/4 p3, 0x4

    .line 37
    invoke-virtual {p2, v0, p3, p1}, La/m4;->m(La/OV;ILa/R7;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_0
    invoke-virtual {p0, p1}, La/R6;->w(La/OV;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final e(La/OV;II)V
    .locals 2

    .line 1
    iget v0, p0, La/R6;->X:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La/R6;->K:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La/OW;

    .line 9
    .line 10
    invoke-static {v0}, La/OW;->h(La/OW;)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    add-int/lit8 v1, v1, 0x1

    .line 15
    .line 16
    invoke-static {v0, v1}, La/OW;->p(La/OW;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, La/OW;->h(La/OW;)I

    .line 20
    .line 21
    .line 22
    invoke-static {v0, p1, p2}, La/OW;->e(La/OW;Ljava/util/List;I)I

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    iget-object p2, v0, La/OW;->K:La/m4;

    .line 27
    .line 28
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-static {p1, v1, p3}, La/m4;->M(III)La/R7;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    const/4 p3, 0x2

    .line 37
    invoke-virtual {p2, v0, p3, p1}, La/m4;->m(La/OV;ILa/R7;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_0
    invoke-virtual {p0, p1}, La/R6;->w(La/OV;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final h(La/OV;II)V
    .locals 2

    .line 1
    iget v0, p0, La/R6;->X:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La/R6;->K:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La/OW;

    .line 9
    .line 10
    iget-object v1, v0, La/OW;->K:La/m4;

    .line 11
    .line 12
    invoke-static {v0, p1, p2}, La/OW;->e(La/OW;Ljava/util/List;I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const/4 p2, 0x0

    .line 20
    invoke-static {p1, p2, p3}, La/m4;->M(III)La/R7;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    const/4 p2, 0x1

    .line 25
    invoke-virtual {v1, v0, p2, p1}, La/m4;->m(La/OV;ILa/R7;)V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_0
    invoke-virtual {p0, p1}, La/R6;->w(La/OV;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final i(La/OV;III)V
    .locals 2

    .line 1
    iget v0, p0, La/R6;->X:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La/R6;->K:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, La/OW;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v0, p1, v1}, La/OW;->e(La/OW;Ljava/util/List;I)I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    add-int/2addr p2, p1

    .line 16
    add-int/2addr p1, p3

    .line 17
    iget-object p3, v0, La/OW;->K:La/m4;

    .line 18
    .line 19
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {p2, p1, p4}, La/m4;->M(III)La/R7;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/4 p2, 0x3

    .line 27
    invoke-virtual {p3, v0, p2, p1}, La/m4;->m(La/OV;ILa/R7;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_0
    invoke-virtual {p0, p1}, La/R6;->w(La/OV;)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final m(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La/OV;

    .line 2
    .line 3
    invoke-interface {p1, p0}, La/OV;->w(La/dI;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final p(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, La/OV;

    .line 2
    .line 3
    invoke-interface {p1, p0}, La/OV;->X(La/dI;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(La/OV;)V
    .locals 4

    .line 1
    iget v0, p0, La/R6;->X:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, La/R6;->K:Ljava/lang/Object;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast v2, La/OW;

    .line 10
    .line 11
    invoke-static {v2}, La/OW;->h(La/OW;)I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    add-int/lit8 p1, p1, 0x1

    .line 16
    .line 17
    invoke-static {v2, p1}, La/OW;->p(La/OW;I)V

    .line 18
    .line 19
    .line 20
    invoke-static {v2}, La/OW;->h(La/OW;)I

    .line 21
    .line 22
    .line 23
    const/4 p1, 0x0

    .line 24
    iget-object v0, v2, La/OW;->K:La/m4;

    .line 25
    .line 26
    invoke-virtual {v0, v2, v1, p1}, La/m4;->m(La/OV;ILa/R7;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_0
    check-cast v2, La/Cj;

    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroidx/databinding/w;

    .line 37
    .line 38
    if-nez v0, :cond_0

    .line 39
    .line 40
    invoke-virtual {v2}, La/Cj;->w()Z

    .line 41
    .line 42
    .line 43
    :cond_0
    if-nez v0, :cond_1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    iget-object v3, v2, La/Cj;->p:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v3, La/OV;

    .line 49
    .line 50
    if-eq v3, p1, :cond_2

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_2
    iget-boolean p1, v0, Landroidx/databinding/w;->P:Z

    .line 54
    .line 55
    if-nez p1, :cond_3

    .line 56
    .line 57
    iget p1, v2, La/Cj;->h:I

    .line 58
    .line 59
    invoke-virtual {v0, p1, v1, v3}, Landroidx/databinding/w;->y(IILjava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    if-eqz p1, :cond_3

    .line 64
    .line 65
    invoke-virtual {v0}, Landroidx/databinding/w;->R()V

    .line 66
    .line 67
    .line 68
    :cond_3
    :goto_0
    return-void

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
