.class public final Lcom/topjohnwu/magisk/ui/log/LogFragment;
.super La/zZ;
.source "SourceFile"

# interfaces
.implements La/We;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/UZ;",
        ">;",
        "La/We;"
    }
.end annotation


# static fields
.field public static final synthetic lI:I


# instance fields
.field public Pb:Landroid/view/MenuItem;

.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0037

    iput v0, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x5

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 2

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    invoke-virtual {p0}, La/zZ;->G()La/o5;

    move-result-object v0

    if-eqz v0, :cond_0

    const v1, 0x7f12007f

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(I)V

    :cond_0
    return-void
.end method

.method public final bridge synthetic F9(Landroidx/databinding/w;)V
    .locals 0

    .line 1
    check-cast p1, La/UZ;

    return-void
.end method

.method public final FL()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    :goto_0
    check-cast v0, La/UZ;

    .line 8
    .line 9
    iget-object v0, v0, La/UZ;->x:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 10
    .line 11
    return-object v0
.end method

.method public final synthetic O(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/Ja;

    .line 8
    .line 9
    return-object v0
.end method

.method public final X(Landroid/view/MenuItem;)Z
    .locals 4

    .line 1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f09003a

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->xF:La/Y0;

    .line 9
    .line 10
    if-eq p1, v0, :cond_1

    .line 11
    .line 12
    const v0, 0x7f090051

    .line 13
    .line 14
    .line 15
    if-eq p1, v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    check-cast p1, La/Ja;

    .line 23
    .line 24
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    new-instance v0, La/a8;

    .line 28
    .line 29
    const/4 v1, 0x7

    .line 30
    invoke-direct {v0, p1, v1, p1}, La/a8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    const-string v1, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 34
    .line 35
    invoke-virtual {p1, v1, v0}, La/hb;->K(Ljava/lang/String;La/nY;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/log/LogFragment;->eH()Z

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    const/4 v0, 0x3

    .line 44
    if-nez p1, :cond_2

    .line 45
    .line 46
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, La/Ja;

    .line 51
    .line 52
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    new-instance v1, La/HY;

    .line 56
    .line 57
    const/16 v2, 0x9

    .line 58
    .line 59
    invoke-direct {v1, v2, p1}, La/HY;-><init>(ILjava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iget-object p1, p1, La/Ja;->l:La/qw;

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    const-string p1, "echo -n > /cache/magisk.log"

    .line 68
    .line 69
    filled-new-array {p1}, [Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-static {p1}, La/Id;->w([Ljava/lang/String;)La/x6;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    new-instance v2, La/Mq;

    .line 78
    .line 79
    invoke-direct {v2, v0, v1}, La/Mq;-><init>(ILjava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p1, v2}, La/TZ;->B1(La/Le;)V

    .line 83
    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_2
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    check-cast p1, La/Ja;

    .line 91
    .line 92
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    invoke-static {p1}, La/rE;->mh(La/AZ;)La/wE;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    new-instance v2, La/kX;

    .line 100
    .line 101
    const/4 v3, 0x0

    .line 102
    invoke-direct {v2, p1, v3}, La/kX;-><init>(La/Ja;La/hu;)V

    .line 103
    .line 104
    .line 105
    invoke-static {v1, v3, v2, v0}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 106
    .line 107
    .line 108
    :goto_0
    const/4 p1, 0x0

    .line 109
    return p1
.end method

.method public final synthetic e(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final eH()Z
    .locals 1

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    :goto_0
    check-cast v0, La/UZ;

    .line 8
    .line 9
    iget-object v0, v0, La/UZ;->t:Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    goto :goto_1

    .line 19
    :cond_1
    const/4 v0, 0x0

    .line 20
    :goto_1
    return v0
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, La/zZ;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 5
    .line 6
    const/4 p2, 0x0

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object p1, p2

    .line 11
    :goto_0
    check-cast p1, La/UZ;

    .line 12
    .line 13
    iget-object p1, p1, La/UZ;->x:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 14
    .line 15
    new-instance v0, La/sZ;

    .line 16
    .line 17
    const/4 v1, 0x4

    .line 18
    invoke-direct {v0, v1, p0}, La/sZ;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 22
    .line 23
    .line 24
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 25
    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    move-object p2, p1

    .line 29
    :cond_1
    check-cast p2, La/UZ;

    .line 30
    .line 31
    iget-object p1, p2, La/UZ;->C:La/XF;

    .line 32
    .line 33
    iget-object p1, p1, La/XF;->t:Landroidx/recyclerview/widget/RecyclerView;

    .line 34
    .line 35
    const/4 p2, 0x0

    .line 36
    const/4 v0, 0x7

    .line 37
    invoke-static {p1, p2, v0}, La/rx;->Q(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 38
    .line 39
    .line 40
    invoke-static {p1}, La/rx;->X(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 41
    .line 42
    .line 43
    invoke-static {p1}, La/rx;->S(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final mh(Z)V
    .locals 14

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v2, v0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    move-object v2, v1

    .line 9
    :goto_0
    check-cast v2, La/UZ;

    .line 10
    .line 11
    iget-object v2, v2, La/UZ;->t:Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_1
    move-object v0, v1

    .line 17
    :goto_1
    check-cast v0, La/UZ;

    .line 18
    .line 19
    iget-object v0, v0, La/UZ;->x:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 20
    .line 21
    xor-int/lit8 v3, p1, 0x1

    .line 22
    .line 23
    invoke-static {v2, v3}, La/rx;->l(Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;Z)La/xb;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v2, v4}, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->e(La/xb;)V

    .line 28
    .line 29
    .line 30
    invoke-static {v2, p1}, La/rx;->l(Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;Z)La/xb;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    iget v5, v4, La/xb;->w:F

    .line 35
    .line 36
    iget v6, v4, La/xb;->h:F

    .line 37
    .line 38
    iget v7, v4, La/xb;->p:F

    .line 39
    .line 40
    invoke-static {v2, v5, v6, v7}, La/rE;->z(La/De;FFF)Landroid/animation/AnimatorSet;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    new-instance v6, La/H2;

    .line 45
    .line 46
    const/4 v7, 0x1

    .line 47
    invoke-direct {v6, v4, v2, v2, v7}, La/H2;-><init>(La/xb;Landroid/view/View;Landroid/view/View;I)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v5, v6}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 51
    .line 52
    .line 53
    new-instance v2, Landroid/animation/AnimatorSet;

    .line 54
    .line 55
    invoke-direct {v2}, Landroid/animation/AnimatorSet;-><init>()V

    .line 56
    .line 57
    .line 58
    new-instance v6, La/HR;

    .line 59
    .line 60
    invoke-direct {v6}, La/HR;-><init>()V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v2, v6}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 64
    .line 65
    .line 66
    new-instance v6, La/H2;

    .line 67
    .line 68
    const/4 v8, 0x0

    .line 69
    invoke-direct {v6, v4, v0, v0, v8}, La/H2;-><init>(La/xb;Landroid/view/View;Landroid/view/View;I)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2, v6}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 73
    .line 74
    .line 75
    sget-object v6, La/UD;->w:Ljava/util/Locale;

    .line 76
    .line 77
    invoke-static {v6}, Landroid/text/TextUtils;->getLayoutDirectionFromLocale(Ljava/util/Locale;)I

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    if-ne v6, v7, :cond_2

    .line 82
    .line 83
    const/high16 v6, 0x3f800000    # 1.0f

    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_2
    const/high16 v6, -0x40800000    # -1.0f

    .line 87
    .line 88
    :goto_2
    iget v9, v4, La/xb;->w:F

    .line 89
    .line 90
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 91
    .line 92
    .line 93
    move-result-object v10

    .line 94
    instance-of v11, v10, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 95
    .line 96
    if-eqz v11, :cond_3

    .line 97
    .line 98
    check-cast v10, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 99
    .line 100
    invoke-static {v10}, La/WK;->h(Landroid/view/ViewGroup$MarginLayoutParams;)I

    .line 101
    .line 102
    .line 103
    move-result v10

    .line 104
    goto :goto_3

    .line 105
    :cond_3
    move v10, v8

    .line 106
    :goto_3
    int-to-float v10, v10

    .line 107
    sub-float/2addr v9, v10

    .line 108
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 109
    .line 110
    .line 111
    move-result v10

    .line 112
    int-to-float v10, v10

    .line 113
    const/high16 v11, 0x40000000    # 2.0f

    .line 114
    .line 115
    div-float/2addr v10, v11

    .line 116
    sub-float/2addr v9, v10

    .line 117
    iget v10, v4, La/xb;->p:F

    .line 118
    .line 119
    const/4 v12, 0x0

    .line 120
    cmpg-float v10, v10, v12

    .line 121
    .line 122
    if-nez v10, :cond_4

    .line 123
    .line 124
    move v9, v12

    .line 125
    goto :goto_4

    .line 126
    :cond_4
    mul-float/2addr v9, v6

    .line 127
    :goto_4
    sget-object v6, Landroid/view/View;->TRANSLATION_X:Landroid/util/Property;

    .line 128
    .line 129
    new-array v10, v7, [F

    .line 130
    .line 131
    aput v9, v10, v8

    .line 132
    .line 133
    invoke-static {v0, v6, v10}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 134
    .line 135
    .line 136
    move-result-object v6

    .line 137
    iget v9, v4, La/xb;->h:F

    .line 138
    .line 139
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 140
    .line 141
    .line 142
    move-result-object v10

    .line 143
    instance-of v13, v10, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 144
    .line 145
    if-eqz v13, :cond_5

    .line 146
    .line 147
    check-cast v10, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 148
    .line 149
    goto :goto_5

    .line 150
    :cond_5
    move-object v10, v1

    .line 151
    :goto_5
    if-eqz v10, :cond_6

    .line 152
    .line 153
    iget v10, v10, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 154
    .line 155
    goto :goto_6

    .line 156
    :cond_6
    move v10, v8

    .line 157
    :goto_6
    int-to-float v10, v10

    .line 158
    sub-float/2addr v9, v10

    .line 159
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    .line 160
    .line 161
    .line 162
    move-result v10

    .line 163
    int-to-float v10, v10

    .line 164
    div-float/2addr v10, v11

    .line 165
    sub-float/2addr v9, v10

    .line 166
    iget v4, v4, La/xb;->p:F

    .line 167
    .line 168
    cmpg-float v4, v4, v12

    .line 169
    .line 170
    if-nez v4, :cond_7

    .line 171
    .line 172
    goto :goto_7

    .line 173
    :cond_7
    neg-float v12, v9

    .line 174
    :goto_7
    sget-object v4, Landroid/view/View;->TRANSLATION_Y:Landroid/util/Property;

    .line 175
    .line 176
    new-array v9, v7, [F

    .line 177
    .line 178
    aput v12, v9, v8

    .line 179
    .line 180
    invoke-static {v0, v4, v9}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    const/4 v4, 0x2

    .line 185
    new-array v9, v4, [Landroid/animation/Animator;

    .line 186
    .line 187
    aput-object v6, v9, v8

    .line 188
    .line 189
    aput-object v0, v9, v7

    .line 190
    .line 191
    invoke-virtual {v2, v9}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    .line 192
    .line 193
    .line 194
    new-instance v0, Landroid/animation/AnimatorSet;

    .line 195
    .line 196
    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    .line 197
    .line 198
    .line 199
    if-eqz p1, :cond_8

    .line 200
    .line 201
    invoke-virtual {v0, v5}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    .line 202
    .line 203
    .line 204
    move-result-object v5

    .line 205
    invoke-virtual {v5, v2}, Landroid/animation/AnimatorSet$Builder;->after(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    .line 206
    .line 207
    .line 208
    goto :goto_8

    .line 209
    :cond_8
    invoke-virtual {v0, v2}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    invoke-virtual {v2, v5}, Landroid/animation/AnimatorSet$Builder;->after(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    .line 214
    .line 215
    .line 216
    :goto_8
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 217
    .line 218
    .line 219
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->Pb:Landroid/view/MenuItem;

    .line 220
    .line 221
    if-nez v0, :cond_9

    .line 222
    .line 223
    goto :goto_9

    .line 224
    :cond_9
    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 225
    .line 226
    .line 227
    :goto_9
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    check-cast v0, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 232
    .line 233
    iget-object v2, v0, La/Vo;->J:Landroidx/databinding/w;

    .line 234
    .line 235
    if-eqz v2, :cond_a

    .line 236
    .line 237
    move-object v1, v2

    .line 238
    :cond_a
    check-cast v1, La/TB;

    .line 239
    .line 240
    iget-object v1, v1, La/TB;->n:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 241
    .line 242
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 243
    .line 244
    .line 245
    invoke-static {v0, p1, v8, v4}, Lcom/topjohnwu/magisk/ui/MainActivity;->z(Lcom/topjohnwu/magisk/ui/MainActivity;ZZI)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v0, p1}, Lcom/topjohnwu/magisk/ui/MainActivity;->P(Z)V

    .line 249
    .line 250
    .line 251
    return-void
.end method

.method public final p(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 1

    .line 1
    const v0, 0x7f0e0004

    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const p2, 0x7f090051

    invoke-interface {p1, p2}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/log/LogFragment;->eH()Z

    move-result p2

    xor-int/lit8 p2, p2, 0x1

    invoke-interface {p1, p2}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-object p1, p0, Lcom/topjohnwu/magisk/ui/log/LogFragment;->Pb:Landroid/view/MenuItem;

    return-void
.end method

.method public final rC()Z
    .locals 2

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    :goto_0
    check-cast v0, La/UZ;

    .line 8
    .line 9
    iget-object v0, v0, La/UZ;->t:Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lcom/topjohnwu/magisk/ui/log/LogFragment;->mh(Z)V

    .line 19
    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    return v0

    .line 23
    :cond_1
    return v1
.end method

.method public final rV()Landroid/view/View;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/log/LogFragment;->eH()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    move-object v1, v0

    .line 13
    :cond_0
    check-cast v1, La/UZ;

    .line 14
    .line 15
    iget-object v0, v1, La/UZ;->C:La/XF;

    .line 16
    .line 17
    iget-object v1, v0, La/XF;->n:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 18
    .line 19
    :cond_1
    return-object v1
.end method
