.class public final Lcom/topjohnwu/magisk/ui/install/InstallFragment;
.super La/zZ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/t8;",
        ">;"
    }
.end annotation


# instance fields
.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0036

    iput v0, p0, Lcom/topjohnwu/magisk/ui/install/InstallFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x4

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/install/InstallFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 2

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    invoke-virtual {p0}, La/zr;->c()La/Jf;

    move-result-object v0

    const v1, 0x7f12006e

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(I)V

    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/install/InstallFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/install/InstallFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/kb;

    .line 8
    .line 9
    return-object v0
.end method
