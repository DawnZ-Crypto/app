.class public Landroidx/navigation/fragment/NavHostFragment;
.super La/zr;
.source "SourceFile"


# instance fields
.field public final B1:La/Yi;

.field public Pb:Z

.field public xF:I

.field public y6:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La/zr;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/om;

    .line 5
    .line 6
    const/4 v1, 0x2

    .line 7
    invoke-direct {v0, v1, p0}, La/om;-><init>(ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    new-instance v1, La/Yi;

    .line 11
    .line 12
    invoke-direct {v1, v0}, La/Yi;-><init>(La/Lc;)V

    .line 13
    .line 14
    .line 15
    iput-object v1, p0, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final D(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, La/zr;->D(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, Landroidx/navigation/fragment/NavHostFragment;->Pb:Z

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, La/zr;->d()La/ef;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    new-instance v0, La/D9;

    .line 13
    .line 14
    invoke-direct {v0, p1}, La/D9;-><init>(La/ef;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p0}, La/D9;->O(La/zr;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    invoke-virtual {v0, p1}, La/D9;->e(Z)I

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void
.end method

.method public final U()V
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La/zr;->r:Z

    .line 3
    .line 4
    iget-object v0, p0, Landroidx/navigation/fragment/NavHostFragment;->y6:Landroid/view/View;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    sget-object v2, La/JV;->S:La/JV;

    .line 10
    .line 11
    invoke-static {v0, v2}, La/yZ;->Vm(Ljava/lang/Object;La/nY;)La/WH;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    sget-object v3, La/JV;->H:La/JV;

    .line 16
    .line 17
    new-instance v4, La/tj;

    .line 18
    .line 19
    const/4 v5, 0x2

    .line 20
    invoke-direct {v4, v2, v3, v5}, La/tj;-><init>(La/WH;La/nY;I)V

    .line 21
    .line 22
    .line 23
    sget-object v2, La/jY;->L:La/jY;

    .line 24
    .line 25
    new-instance v3, La/Ff;

    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    invoke-direct {v3, v4, v5, v2}, La/Ff;-><init>(La/WH;ZLa/nY;)V

    .line 29
    .line 30
    .line 31
    new-instance v2, La/bh;

    .line 32
    .line 33
    invoke-direct {v2, v3}, La/bh;-><init>(La/Ff;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2}, La/bh;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    if-nez v3, :cond_0

    .line 41
    .line 42
    move-object v2, v1

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-virtual {v2}, La/bh;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    :goto_0
    check-cast v2, La/r4;

    .line 49
    .line 50
    if-eqz v2, :cond_1

    .line 51
    .line 52
    iget-object v3, p0, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 53
    .line 54
    invoke-virtual {v3}, La/Yi;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    check-cast v3, La/sv;

    .line 59
    .line 60
    if-ne v2, v3, :cond_2

    .line 61
    .line 62
    const v2, 0x7f0901a3

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0, v2, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_1
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 70
    .line 71
    new-instance v2, Ljava/lang/StringBuilder;

    .line 72
    .line 73
    const-string v3, "View "

    .line 74
    .line 75
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    const-string v0, " does not have a NavController set"

    .line 82
    .line 83
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    throw v1

    .line 94
    :cond_2
    :goto_1
    iput-object v1, p0, Landroidx/navigation/fragment/NavHostFragment;->y6:Landroid/view/View;

    .line 95
    .line 96
    return-void
.end method

.method public final Y(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 2
    .line 3
    invoke-virtual {v0}, La/Yi;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/sv;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const-string v0, "android-support-nav:fragment:defaultHost"

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    iput-boolean v0, p0, Landroidx/navigation/fragment/NavHostFragment;->Pb:Z

    .line 22
    .line 23
    invoke-virtual {p0}, La/zr;->d()La/ef;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    new-instance v2, La/D9;

    .line 28
    .line 29
    invoke-direct {v2, v0}, La/D9;-><init>(La/ef;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2, p0}, La/D9;->O(La/zr;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v2, v1}, La/D9;->e(Z)I

    .line 36
    .line 37
    .line 38
    :cond_0
    invoke-super {p0, p1}, La/zr;->Y(Landroid/os/Bundle;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    instance-of p2, p1, Landroid/view/ViewGroup;

    .line 2
    .line 3
    if-eqz p2, :cond_1

    .line 4
    .line 5
    iget-object p2, p0, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 6
    .line 7
    invoke-virtual {p2}, La/Yi;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, La/sv;

    .line 12
    .line 13
    const v1, 0x7f0901a3

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, v1, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, Landroid/view/View;

    .line 30
    .line 31
    iput-object p1, p0, Landroidx/navigation/fragment/NavHostFragment;->y6:Landroid/view/View;

    .line 32
    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    iget v0, p0, La/zr;->j:I

    .line 38
    .line 39
    if-ne p1, v0, :cond_0

    .line 40
    .line 41
    iget-object p1, p0, Landroidx/navigation/fragment/NavHostFragment;->y6:Landroid/view/View;

    .line 42
    .line 43
    invoke-virtual {p2}, La/Yi;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    check-cast p2, La/sv;

    .line 48
    .line 49
    invoke-virtual {p1, v1, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void

    .line 53
    :cond_1
    new-instance p2, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    const-string v0, "created host view "

    .line 56
    .line 57
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string p1, " is not a ViewGroup"

    .line 64
    .line 65
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 73
    .line 74
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw p2
.end method

.method public final n(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/navigation/fragment/NavHostFragment;->Pb:Z

    if-eqz v0, :cond_0

    const-string v0, "android-support-nav:fragment:defaultHost"

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_0
    return-void
.end method

.method public final s(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2, p3}, La/zr;->s(Landroid/content/Context;Landroid/util/AttributeSet;Landroid/os/Bundle;)V

    sget-object p3, La/eW;->h:[I

    invoke-virtual {p1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p3

    const/4 v0, 0x0

    invoke-virtual {p3, v0, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    if-eqz v1, :cond_0

    iput v1, p0, Landroidx/navigation/fragment/NavHostFragment;->xF:I

    :cond_0
    invoke-virtual {p3}, Landroid/content/res/TypedArray;->recycle()V

    sget-object p3, La/Zm;->p:[I

    invoke-virtual {p1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1, v0, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    if-eqz p2, :cond_1

    const/4 p2, 0x1

    iput-boolean p2, p0, Landroidx/navigation/fragment/NavHostFragment;->Pb:Z

    :cond_1
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method public final u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 0

    .line 1
    new-instance p2, Landroidx/fragment/app/FragmentContainerView;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/LayoutInflater;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-direct {p2, p1}, Landroidx/fragment/app/FragmentContainerView;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    iget p1, p0, La/zr;->j:I

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    const/4 p3, -0x1

    .line 15
    if-eq p1, p3, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const p1, 0x7f0901a4

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-virtual {p2, p1}, Landroid/view/View;->setId(I)V

    .line 22
    .line 23
    .line 24
    return-object p2
.end method
