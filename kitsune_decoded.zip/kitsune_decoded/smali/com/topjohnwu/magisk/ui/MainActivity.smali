.class public final Lcom/topjohnwu/magisk/ui/MainActivity;
.super La/K9;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/K9;"
    }
.end annotation


# static fields
.field public static final synthetic mh:I


# instance fields
.field public final F9:I

.field public eH:Z

.field public final p7:La/Y0;

.field public final rC:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La/o5;-><init>()V

    .line 2
    .line 3
    .line 4
    const v0, 0x7f0c001c

    .line 5
    .line 6
    .line 7
    iput v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->rC:I

    .line 8
    .line 9
    new-instance v0, La/Vn;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->p7:La/Y0;

    .line 20
    .line 21
    const v0, 0x7f090151

    .line 22
    .line 23
    .line 24
    iput v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->F9:I

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    iput-boolean v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->eH:Z

    .line 28
    .line 29
    return-void
.end method

.method public static z(Lcom/topjohnwu/magisk/ui/MainActivity;ZZI)V
    .locals 2

    .line 1
    and-int/lit8 v0, p3, 0x1

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move p1, v1

    .line 7
    :cond_0
    and-int/lit8 p3, p3, 0x2

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    move p2, v1

    .line 12
    :cond_1
    iget-object p0, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 13
    .line 14
    if-eqz p0, :cond_2

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_2
    const/4 p0, 0x0

    .line 18
    :goto_0
    check-cast p0, La/TB;

    .line 19
    .line 20
    iget-object p0, p0, La/TB;->t:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 21
    .line 22
    const/4 p3, 0x0

    .line 23
    if-eqz p2, :cond_3

    .line 24
    .line 25
    invoke-virtual {p0, p3}, Landroid/view/View;->setVisibility(I)V

    .line 26
    .line 27
    .line 28
    iget-boolean p2, p0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->W:Z

    .line 29
    .line 30
    if-eq p2, p1, :cond_5

    .line 31
    .line 32
    iput-boolean p1, p0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->W:Z

    .line 33
    .line 34
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_3
    if-eqz p1, :cond_4

    .line 39
    .line 40
    const/16 p3, 0x8

    .line 41
    .line 42
    :cond_4
    invoke-virtual {p0, p3}, Landroid/view/View;->setVisibility(I)V

    .line 43
    .line 44
    .line 45
    :cond_5
    :goto_1
    return-void
.end method


# virtual methods
.method public final F()Landroid/view/View;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/o5;->S()La/zZ;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, La/zZ;->rV()Landroid/view/View;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_1

    invoke-super {p0}, La/Vo;->F()Landroid/view/View;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public final P(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    move-object v0, v1

    .line 8
    :goto_0
    check-cast v0, La/TB;

    .line 9
    .line 10
    iget-object v0, v0, La/TB;->n:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 11
    .line 12
    invoke-static {v0}, La/rx;->au(Landroid/view/ViewGroup;)V

    .line 13
    .line 14
    .line 15
    if-eqz p1, :cond_2

    .line 16
    .line 17
    iget-object p1, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 18
    .line 19
    if-eqz p1, :cond_1

    .line 20
    .line 21
    move-object v1, p1

    .line 22
    :cond_1
    check-cast v1, La/TB;

    .line 23
    .line 24
    iget-object p1, v1, La/TB;->n:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 25
    .line 26
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const v1, 0x7f0800dd

    .line 31
    .line 32
    .line 33
    invoke-static {v0, v1}, La/fe;->q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {p1, v0}, Lcom/google/android/material/appbar/MaterialToolbar;->S(Landroid/graphics/drawable/Drawable;)V

    .line 38
    .line 39
    .line 40
    goto :goto_2

    .line 41
    :cond_2
    iget-object p1, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 42
    .line 43
    if-eqz p1, :cond_3

    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_3
    move-object p1, v1

    .line 47
    :goto_1
    check-cast p1, La/TB;

    .line 48
    .line 49
    iget-object p1, p1, La/TB;->n:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 50
    .line 51
    invoke-virtual {p1, v1}, Lcom/google/android/material/appbar/MaterialToolbar;->S(Landroid/graphics/drawable/Drawable;)V

    .line 52
    .line 53
    .line 54
    :goto_2
    return-void
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->p7:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/KJ;

    .line 8
    .line 9
    return-object v0
.end method

.method public final W()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/MainActivity;->rC:I

    return v0
.end method

.method public final onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x102002c

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, La/o5;->onBackPressed()V

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public final q()Landroid/view/View;
    .locals 3

    .line 1
    invoke-virtual {p0}, La/o5;->S()La/zZ;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, La/zZ;->FL()Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move-object v0, v1

    .line 14
    :goto_0
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_1

    .line 21
    .line 22
    move-object v1, v0

    .line 23
    goto :goto_2

    .line 24
    :cond_1
    iget-object v0, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_2
    move-object v0, v1

    .line 30
    :goto_1
    check-cast v0, La/TB;

    .line 31
    .line 32
    iget-object v0, v0, La/TB;->t:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 33
    .line 34
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_4

    .line 39
    .line 40
    iget-object v0, p0, La/Vo;->J:Landroidx/databinding/w;

    .line 41
    .line 42
    if-eqz v0, :cond_3

    .line 43
    .line 44
    move-object v1, v0

    .line 45
    :cond_3
    check-cast v1, La/TB;

    .line 46
    .line 47
    iget-object v0, v1, La/TB;->t:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 48
    .line 49
    return-object v0

    .line 50
    :cond_4
    :goto_2
    return-object v1
.end method
