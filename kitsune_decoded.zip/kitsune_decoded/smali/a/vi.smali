.class public final La/vi;
.super La/Hb;
.source "SourceFile"


# static fields
.field public static final L:La/vi;

.field public static final d:La/un;

.field public static final f:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/vi;

    .line 2
    .line 3
    invoke-direct {v0}, La/Hb;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/vi;->L:La/vi;

    .line 7
    .line 8
    new-instance v0, La/un;

    .line 9
    .line 10
    const v1, 0x7f120152

    .line 11
    .line 12
    .line 13
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, La/vi;->d:La/un;

    .line 17
    .line 18
    const v0, 0x7f03000d

    .line 19
    .line 20
    .line 21
    sput v0, La/vi;->f:I

    .line 22
    .line 23
    sget-object v0, La/Dp;->w:La/Dp;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final S()I
    .locals 1

    .line 1
    sget v0, La/vi;->f:I

    return v0
.end method

.method public final W(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Ljava/lang/Number;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    sget-object v0, La/Dp;->w:La/Dp;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object v1, La/Dp;->h:[La/KG;

    .line 13
    .line 14
    const/16 v2, 0x15

    .line 15
    .line 16
    aget-object v1, v1, v2

    .line 17
    .line 18
    sget-object v1, La/Dp;->H:La/pj;

    .line 19
    .line 20
    invoke-virtual {v1, v0, p1}, La/pj;->h(La/ac;I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final d()V
    .locals 2

    .line 1
    sget-object v0, La/Mv;->w:La/Mv;

    .line 2
    .line 3
    sget-object v0, La/uv;->w:Landroid/content/Context;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    const-class v1, Landroid/app/KeyguardManager;

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Landroid/app/KeyguardManager;

    .line 16
    .line 17
    invoke-virtual {v0}, Landroid/app/KeyguardManager;->isDeviceSecure()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p0, v0}, La/ET;->f(Z)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final l()Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, La/Dp;->w:La/Dp;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v1, La/Dp;->h:[La/KG;

    .line 7
    .line 8
    const/16 v2, 0x15

    .line 9
    .line 10
    aget-object v1, v1, v2

    .line 11
    .line 12
    sget-object v1, La/Dp;->H:La/pj;

    .line 13
    .line 14
    invoke-virtual {v1, v0}, La/pj;->w(La/ac;)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public final y()La/un;
    .locals 1

    .line 1
    sget-object v0, La/vi;->d:La/un;

    return-object v0
.end method
