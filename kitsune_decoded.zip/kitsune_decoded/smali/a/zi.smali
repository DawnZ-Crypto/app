.class public abstract La/zi;
.super Landroidx/databinding/w;
.source "SourceFile"


# instance fields
.field public final C:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

.field public final n:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

.field public final t:Landroidx/recyclerview/widget/RecyclerView;

.field public x:La/Rp;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    .locals 1

    .line 1
    const/4 v0, 0x3

    invoke-direct {p0, v0, p2, p1}, Landroidx/databinding/w;-><init>(ILandroid/view/View;Ljava/lang/Object;)V

    iput-object p3, p0, La/zi;->t:Landroidx/recyclerview/widget/RecyclerView;

    iput-object p4, p0, La/zi;->n:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    iput-object p5, p0, La/zi;->C:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    return-void
.end method
