.class public final La/D0;
.super La/Yo;
.source "SourceFile"


# instance fields
.field public final K:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 1

    .line 1
    const/16 v0, 0xd

    invoke-direct {p0, v0}, La/Yo;-><init>(I)V

    iput-boolean p1, p0, La/D0;->K:Z

    return-void
.end method


# virtual methods
.method public final p(La/Y8;Ljava/lang/Object;)V
    .locals 2

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    const/4 v0, 0x0

    .line 9
    iget-boolean v1, p0, La/D0;->K:Z

    .line 10
    .line 11
    invoke-virtual {p1, p2, v0, v1}, La/Y8;->e(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
