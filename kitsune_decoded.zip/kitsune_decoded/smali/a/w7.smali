.class public final La/w7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/window/OnBackAnimationCallback;


# instance fields
.field public final synthetic e:La/Lc;

.field public final synthetic h:La/nY;

.field public final synthetic p:La/Lc;

.field public final synthetic w:La/nY;


# direct methods
.method public constructor <init>(La/nY;La/nY;La/Lc;La/Lc;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/w7;->w:La/nY;

    iput-object p2, p0, La/w7;->h:La/nY;

    iput-object p3, p0, La/w7;->p:La/Lc;

    iput-object p4, p0, La/w7;->e:La/Lc;

    return-void
.end method


# virtual methods
.method public final onBackCancelled()V
    .locals 1

    .line 1
    iget-object v0, p0, La/w7;->e:La/Lc;

    invoke-interface {v0}, La/Lc;->w()Ljava/lang/Object;

    return-void
.end method

.method public final onBackInvoked()V
    .locals 1

    .line 1
    iget-object v0, p0, La/w7;->p:La/Lc;

    invoke-interface {v0}, La/Lc;->w()Ljava/lang/Object;

    return-void
.end method

.method public final onBackProgressed(Landroid/window/BackEvent;)V
    .locals 2

    .line 1
    iget-object v0, p0, La/w7;->h:La/nY;

    new-instance v1, La/Ha;

    invoke-direct {v1, p1}, La/Ha;-><init>(Landroid/window/BackEvent;)V

    invoke-interface {v0, v1}, La/nY;->V(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final onBackStarted(Landroid/window/BackEvent;)V
    .locals 2

    .line 1
    iget-object v0, p0, La/w7;->w:La/nY;

    new-instance v1, La/Ha;

    invoke-direct {v1, p1}, La/Ha;-><init>(Landroid/window/BackEvent;)V

    invoke-interface {v0, v1}, La/nY;->V(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
