.class public final La/dg;
.super La/GN;
.source "SourceFile"


# instance fields
.field public final e:La/gp;

.field public final i:La/gp;

.field public final p:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;


# direct methods
.method public constructor <init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V
    .locals 2

    .line 1
    invoke-direct {p0, p1}, La/GN;-><init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V

    iput-object p1, p0, La/dg;->p:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    new-instance v0, La/gp;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, La/gp;-><init>(La/cO;I)V

    iput-object v0, p0, La/dg;->e:La/gp;

    new-instance v0, La/gp;

    const/4 v1, 0x1

    invoke-direct {v0, p1, v1}, La/gp;-><init>(La/cO;I)V

    iput-object v0, p0, La/dg;->i:La/gp;

    return-void
.end method
