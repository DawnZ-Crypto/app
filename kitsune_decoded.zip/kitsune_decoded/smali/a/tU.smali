.class public final La/tU;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/m;
.implements La/J7;


# instance fields
.field public final K:La/v5;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(La/v5;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, La/tU;->X:I

    .line 5
    .line 6
    iput-object p1, p0, La/tU;->K:La/v5;

    .line 7
    .line 8
    return-void
.end method

.method public static w(La/v5;)La/UF;
    .locals 3

    .line 1
    :try_start_0
    new-instance v0, La/UF;

    .line 2
    .line 3
    new-instance v1, La/Dz;

    .line 4
    .line 5
    invoke-virtual {p0}, La/v5;->d()La/y;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-direct {v1, p0}, La/k;-><init>(La/y;)V

    .line 10
    .line 11
    .line 12
    const/4 p0, -0x1

    .line 13
    iput p0, v1, La/Dz;->R:I

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    invoke-direct {v0, v1, p0}, La/UF;-><init>(La/k;I)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :catch_0
    move-exception p0

    .line 21
    new-instance v0, La/L;

    .line 22
    .line 23
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const/4 v2, 0x0

    .line 28
    invoke-direct {v0, v2, v1, p0}, La/L;-><init>(ILjava/lang/String;Ljava/lang/RuntimeException;)V

    .line 29
    .line 30
    .line 31
    throw v0
.end method


# virtual methods
.method public final h()La/Y;
    .locals 4

    .line 1
    iget-object v0, p0, La/tU;->K:La/v5;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget v2, p0, La/tU;->X:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0}, La/v5;->d()La/y;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sget-object v2, La/mJ;->w:La/Dz;

    .line 14
    .line 15
    iget v2, v0, La/y;->h:I

    .line 16
    .line 17
    const/4 v3, 0x1

    .line 18
    if-ge v2, v3, :cond_0

    .line 19
    .line 20
    sget-object v0, La/mJ;->h:La/sA;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    new-instance v2, La/sA;

    .line 24
    .line 25
    invoke-direct {v2, v0, v1}, La/v;-><init>(La/y;Z)V

    .line 26
    .line 27
    .line 28
    const/4 v0, -0x1

    .line 29
    iput v0, v2, La/sA;->L:I

    .line 30
    .line 31
    move-object v0, v2

    .line 32
    :goto_0
    return-object v0

    .line 33
    :pswitch_0
    invoke-virtual {v0}, La/v5;->d()La/y;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {v0}, La/mJ;->w(La/y;)La/Dz;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    return-object v0

    .line 42
    :pswitch_1
    invoke-static {v0}, La/tU;->w(La/v5;)La/UF;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0

    .line 47
    :pswitch_2
    new-instance v2, La/OK;

    .line 48
    .line 49
    invoke-virtual {v0}, La/v5;->d()La/y;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-direct {v2, v0, v1}, La/v;-><init>(La/y;Z)V

    .line 54
    .line 55
    .line 56
    return-object v2

    .line 57
    :pswitch_3
    new-instance v1, La/MG;

    .line 58
    .line 59
    invoke-virtual {v0}, La/v5;->d()La/y;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-direct {v1, v0}, La/k;-><init>(La/y;)V

    .line 64
    .line 65
    .line 66
    return-object v1

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i()La/Y;
    .locals 4

    .line 1
    iget v0, p0, La/tU;->X:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    :try_start_0
    invoke-virtual {p0}, La/tU;->h()La/Y;

    .line 8
    .line 9
    .line 10
    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    return-object v0

    .line 12
    :catch_0
    move-exception v0

    .line 13
    new-instance v2, La/D;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    invoke-direct {v2, v1, v3, v0}, La/D;-><init>(ILjava/lang/String;Ljava/lang/Exception;)V

    .line 20
    .line 21
    .line 22
    throw v2

    .line 23
    :pswitch_0
    :try_start_1
    invoke-virtual {p0}, La/tU;->h()La/Y;

    .line 24
    .line 25
    .line 26
    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    .line 27
    return-object v0

    .line 28
    :catch_1
    move-exception v0

    .line 29
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw v1

    .line 39
    :pswitch_1
    const-string v0, "unable to get DER object"

    .line 40
    .line 41
    :try_start_2
    invoke-virtual {p0}, La/tU;->h()La/Y;

    .line 42
    .line 43
    .line 44
    move-result-object v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    .line 45
    return-object v0

    .line 46
    :catch_2
    move-exception v2

    .line 47
    new-instance v3, La/D;

    .line 48
    .line 49
    invoke-direct {v3, v1, v0, v2}, La/D;-><init>(ILjava/lang/String;Ljava/lang/Exception;)V

    .line 50
    .line 51
    .line 52
    throw v3

    .line 53
    :catch_3
    move-exception v2

    .line 54
    new-instance v3, La/D;

    .line 55
    .line 56
    invoke-direct {v3, v1, v0, v2}, La/D;-><init>(ILjava/lang/String;Ljava/lang/Exception;)V

    .line 57
    .line 58
    .line 59
    throw v3

    .line 60
    :pswitch_2
    :try_start_3
    invoke-virtual {p0}, La/tU;->h()La/Y;

    .line 61
    .line 62
    .line 63
    move-result-object v0
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_4

    .line 64
    return-object v0

    .line 65
    :catch_4
    move-exception v0

    .line 66
    new-instance v2, La/D;

    .line 67
    .line 68
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    invoke-direct {v2, v1, v3, v0}, La/D;-><init>(ILjava/lang/String;Ljava/lang/Exception;)V

    .line 73
    .line 74
    .line 75
    throw v2

    .line 76
    :pswitch_3
    :try_start_4
    invoke-virtual {p0}, La/tU;->h()La/Y;

    .line 77
    .line 78
    .line 79
    move-result-object v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_5

    .line 80
    return-object v0

    .line 81
    :catch_5
    move-exception v0

    .line 82
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 83
    .line 84
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    throw v1

    .line 92
    nop

    .line 93
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
