.class public final Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;
.super La/eh;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/eh;"
    }
.end annotation


# instance fields
.field public final h:La/eh;

.field public final p:La/eh;

.field public final w:La/dh;


# direct methods
.method public constructor <init>(La/Nm;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "zipUrl"

    const-string v1, "changelog"

    const-string v2, "version"

    const-string v3, "versionCode"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, La/dh;->S([Ljava/lang/String;)La/dh;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->w:La/dh;

    sget-object v0, La/UK;->X:La/UK;

    const-class v1, Ljava/lang/String;

    invoke-virtual {p1, v1, v0, v2}, La/Nm;->h(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)La/eh;

    move-result-object v1

    iput-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->h:La/eh;

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-virtual {p1, v1, v0, v3}, La/Nm;->h(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)La/eh;

    move-result-object p1

    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->p:La/eh;

    return-void
.end method


# virtual methods
.method public final p(La/At;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p2, Lcom/topjohnwu/magisk/core/model/ModuleJson;

    .line 2
    .line 3
    if-eqz p2, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, La/At;->h()La/AN;

    .line 6
    .line 7
    .line 8
    const-string v0, "version"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->h:La/eh;

    .line 14
    .line 15
    iget-object v1, p2, Lcom/topjohnwu/magisk/core/model/ModuleJson;->w:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v0, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const-string v1, "versionCode"

    .line 21
    .line 22
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 23
    .line 24
    .line 25
    iget v1, p2, Lcom/topjohnwu/magisk/core/model/ModuleJson;->h:I

    .line 26
    .line 27
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iget-object v2, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->p:La/eh;

    .line 32
    .line 33
    invoke-virtual {v2, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    const-string v1, "zipUrl"

    .line 37
    .line 38
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 39
    .line 40
    .line 41
    iget-object v1, p2, Lcom/topjohnwu/magisk/core/model/ModuleJson;->p:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v0, p1, v1}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    const-string v1, "changelog"

    .line 47
    .line 48
    invoke-virtual {p1, v1}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 49
    .line 50
    .line 51
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/ModuleJson;->e:Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v0, p1, p2}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1}, La/At;->I()La/AN;

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 61
    .line 62
    const-string p2, "value_ was null! Wrap in .nullSafe() to write nullable values."

    .line 63
    .line 64
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "GeneratedJsonAdapter(ModuleJson)"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w(La/SN;)Ljava/lang/Object;
    .locals 10

    .line 1
    invoke-virtual {p1}, La/SN;->h()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move-object v1, v0

    .line 6
    move-object v2, v1

    .line 7
    move-object v3, v2

    .line 8
    :goto_0
    invoke-virtual {p1}, La/SN;->U()Z

    .line 9
    .line 10
    .line 11
    move-result v4

    .line 12
    const-string v5, "version"

    .line 13
    .line 14
    const-string v6, "versionCode"

    .line 15
    .line 16
    const-string v7, "zipUrl"

    .line 17
    .line 18
    const-string v8, "changelog"

    .line 19
    .line 20
    if-eqz v4, :cond_9

    .line 21
    .line 22
    iget-object v4, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->w:La/dh;

    .line 23
    .line 24
    invoke-virtual {p1, v4}, La/SN;->xF(La/dh;)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    const/4 v9, -0x1

    .line 29
    if-eq v4, v9, :cond_8

    .line 30
    .line 31
    iget-object v9, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->h:La/eh;

    .line 32
    .line 33
    if-eqz v4, :cond_6

    .line 34
    .line 35
    const/4 v5, 0x1

    .line 36
    if-eq v4, v5, :cond_4

    .line 37
    .line 38
    const/4 v5, 0x2

    .line 39
    if-eq v4, v5, :cond_2

    .line 40
    .line 41
    const/4 v5, 0x3

    .line 42
    if-eq v4, v5, :cond_0

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-virtual {v9, p1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    check-cast v3, Ljava/lang/String;

    .line 50
    .line 51
    if-eqz v3, :cond_1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_1
    invoke-static {v8, v8, p1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    throw p1

    .line 59
    :cond_2
    invoke-virtual {v9, p1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    check-cast v2, Ljava/lang/String;

    .line 64
    .line 65
    if-eqz v2, :cond_3

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_3
    invoke-static {v7, v7, p1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    throw p1

    .line 73
    :cond_4
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ModuleJsonJsonAdapter;->p:La/eh;

    .line 74
    .line 75
    invoke-virtual {v1, p1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, Ljava/lang/Integer;

    .line 80
    .line 81
    if-eqz v1, :cond_5

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_5
    invoke-static {v6, v6, p1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    throw p1

    .line 89
    :cond_6
    invoke-virtual {v9, p1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Ljava/lang/String;

    .line 94
    .line 95
    if-eqz v0, :cond_7

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_7
    invoke-static {v5, v5, p1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    throw p1

    .line 103
    :cond_8
    invoke-virtual {p1}, La/SN;->Pb()V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p1}, La/SN;->lI()V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_9
    invoke-virtual {p1}, La/SN;->T()V

    .line 111
    .line 112
    .line 113
    new-instance v4, Lcom/topjohnwu/magisk/core/model/ModuleJson;

    .line 114
    .line 115
    if-eqz v0, :cond_d

    .line 116
    .line 117
    if-eqz v1, :cond_c

    .line 118
    .line 119
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v1

    .line 123
    if-eqz v2, :cond_b

    .line 124
    .line 125
    if-eqz v3, :cond_a

    .line 126
    .line 127
    invoke-direct {v4, v0, v1, v2, v3}, Lcom/topjohnwu/magisk/core/model/ModuleJson;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    return-object v4

    .line 131
    :cond_a
    invoke-static {v8, v8, p1}, La/Gh;->i(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    throw p1

    .line 136
    :cond_b
    invoke-static {v7, v7, p1}, La/Gh;->i(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    throw p1

    .line 141
    :cond_c
    invoke-static {v6, v6, p1}, La/Gh;->i(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    throw p1

    .line 146
    :cond_d
    invoke-static {v5, v5, p1}, La/Gh;->i(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    throw p1
.end method
