.class public final La/QU;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/R0;


# instance fields
.field public final synthetic e:Ljava/lang/String;

.field public final synthetic h:Ljava/util/concurrent/CountDownLatch;

.field public final synthetic i:Ljava/util/List;

.field public final synthetic p:La/fv;

.field public final synthetic w:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Ljava/util/concurrent/CountDownLatch;La/fv;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/QU;->w:Ljava/util/List;

    iput-object p2, p0, La/QU;->h:Ljava/util/concurrent/CountDownLatch;

    iput-object p3, p0, La/QU;->p:La/fv;

    iput-object p4, p0, La/QU;->e:Ljava/lang/String;

    iput-object p5, p0, La/QU;->i:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final h(La/vL;)V
    .locals 3

    .line 1
    iget-object v0, p0, La/QU;->p:La/fv;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La/QU;->e:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v1, p0, La/QU;->i:Ljava/util/List;

    .line 9
    .line 10
    iget-object v2, p0, La/QU;->w:Ljava/util/List;

    .line 11
    .line 12
    invoke-static {p1, v0, v1, v2}, La/fv;->p(La/vL;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 13
    .line 14
    .line 15
    iget-object p1, p0, La/QU;->h:Ljava/util/concurrent/CountDownLatch;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final w(Ljava/io/IOException;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/QU;->w:Ljava/util/List;

    monitor-enter v0

    :try_start_0
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    iget-object p1, p0, La/QU;->h:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method
