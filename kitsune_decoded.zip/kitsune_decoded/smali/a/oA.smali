.class public final La/oA;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/yb;


# instance fields
.field public final K:La/yb;

.field public R:I

.field public final X:Landroidx/lifecycle/h;


# direct methods
.method public constructor <init>(La/bc;La/Do;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, La/oA;->R:I

    iput-object p1, p0, La/oA;->X:Landroidx/lifecycle/h;

    iput-object p2, p0, La/oA;->K:La/yb;

    return-void
.end method


# virtual methods
.method public final w(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget v0, p0, La/oA;->R:I

    .line 2
    .line 3
    iget-object v1, p0, La/oA;->X:Landroidx/lifecycle/h;

    .line 4
    .line 5
    iget v1, v1, Landroidx/lifecycle/h;->X:I

    .line 6
    .line 7
    if-eq v0, v1, :cond_0

    .line 8
    .line 9
    iput v1, p0, La/oA;->R:I

    .line 10
    .line 11
    iget-object v0, p0, La/oA;->K:La/yb;

    .line 12
    .line 13
    invoke-interface {v0, p1}, La/yb;->w(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method
