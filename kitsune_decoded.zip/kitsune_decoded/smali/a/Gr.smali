.class public final La/Gr;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public e:Z

.field public h:I

.field public p:I

.field public final w:[La/c;


# direct methods
.method public varargs constructor <init>([La/c;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, La/Gr;->h:I

    .line 6
    .line 7
    iput v0, p0, La/Gr;->p:I

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, La/Gr;->e:Z

    .line 11
    .line 12
    iput-object p1, p0, La/Gr;->w:[La/c;

    .line 13
    .line 14
    return-void
.end method
