.class public abstract La/Z4;
.super La/m1;
.source "SourceFile"


# instance fields
.field public final B:La/Sl;

.field public final N:La/Sl;

.field public Z:La/ty;

.field public final b:La/Y0;

.field public c:La/nY;

.field public final g:La/Sl;

.field public o:La/nY;

.field public final r:La/Sl;

.field public x:La/nY;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 1
    invoke-direct {p0}, La/Jf;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/activity/w;->d:La/fj;

    .line 5
    .line 6
    iget-object v0, v0, La/fj;->h:La/VV;

    .line 7
    .line 8
    new-instance v1, La/My;

    .line 9
    .line 10
    move-object v2, p0

    .line 11
    check-cast v2, La/Vo;

    .line 12
    .line 13
    invoke-direct {v1, v2}, La/My;-><init>(La/Vo;)V

    .line 14
    .line 15
    .line 16
    const-string v3, "androidx:appcompat"

    .line 17
    .line 18
    invoke-virtual {v0, v3, v1}, La/VV;->p(Ljava/lang/String;La/KO;)V

    .line 19
    .line 20
    .line 21
    new-instance v0, La/Aj;

    .line 22
    .line 23
    invoke-direct {v0, v2}, La/Aj;-><init>(La/Vo;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0, v0}, Landroidx/activity/w;->m(La/oh;)V

    .line 27
    .line 28
    .line 29
    new-instance v0, La/WN;

    .line 30
    .line 31
    const/4 v1, 0x1

    .line 32
    invoke-direct {v0, v1}, La/WN;-><init>(I)V

    .line 33
    .line 34
    .line 35
    new-instance v3, La/Gk;

    .line 36
    .line 37
    const/4 v4, 0x0

    .line 38
    invoke-direct {v3, v2, v4}, La/Gk;-><init>(La/Vo;I)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v3, v0}, Landroidx/activity/w;->K(La/Gk;La/WN;)La/Sl;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iput-object v0, p0, La/Z4;->g:La/Sl;

    .line 46
    .line 47
    new-instance v0, La/WN;

    .line 48
    .line 49
    const/4 v3, 0x4

    .line 50
    invoke-direct {v0, v3}, La/WN;-><init>(I)V

    .line 51
    .line 52
    .line 53
    new-instance v3, La/Gk;

    .line 54
    .line 55
    invoke-direct {v3, v2, v1}, La/Gk;-><init>(La/Vo;I)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0, v3, v0}, Landroidx/activity/w;->K(La/Gk;La/WN;)La/Sl;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput-object v0, p0, La/Z4;->r:La/Sl;

    .line 63
    .line 64
    new-instance v0, La/WN;

    .line 65
    .line 66
    const/4 v1, 0x3

    .line 67
    invoke-direct {v0, v1}, La/WN;-><init>(I)V

    .line 68
    .line 69
    .line 70
    new-instance v3, La/Gk;

    .line 71
    .line 72
    const/4 v5, 0x2

    .line 73
    invoke-direct {v3, v2, v5}, La/Gk;-><init>(La/Vo;I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, v3, v0}, Landroidx/activity/w;->K(La/Gk;La/WN;)La/Sl;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    iput-object v0, p0, La/Z4;->B:La/Sl;

    .line 81
    .line 82
    new-instance v0, La/WN;

    .line 83
    .line 84
    invoke-direct {v0, v4}, La/WN;-><init>(I)V

    .line 85
    .line 86
    .line 87
    new-instance v3, La/Gk;

    .line 88
    .line 89
    invoke-direct {v3, v2, v1}, La/Gk;-><init>(La/Vo;I)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p0, v3, v0}, Landroidx/activity/w;->K(La/Gk;La/WN;)La/Sl;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    iput-object v0, p0, La/Z4;->N:La/Sl;

    .line 97
    .line 98
    sget-object v0, La/yu;->K:La/yu;

    .line 99
    .line 100
    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    iput-object v0, p0, La/Z4;->b:La/Y0;

    .line 105
    .line 106
    return-void
.end method


# virtual methods
.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-static {p1}, La/C8;->p(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/aJ;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Landroid/content/ContextWrapper;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    invoke-super {p0, v0}, La/m1;->attachBaseContext(Landroid/content/Context;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final l(Ljava/lang/String;La/nY;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1e

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    const-string v1, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 8
    .line 9
    invoke-static {p1, v1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    :goto_0
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-interface {p2, p1}, La/nY;->V(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    const/16 v1, 0x21

    .line 22
    .line 23
    if-ge v0, v1, :cond_1

    .line 24
    .line 25
    const-string v0, "android.permission.POST_NOTIFICATIONS"

    .line 26
    .line 27
    invoke-static {p1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    .line 35
    .line 36
    invoke-static {p1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    iput-object p2, p0, La/Z4;->o:La/nY;

    .line 43
    .line 44
    sget-object p1, La/rr;->w:La/rr;

    .line 45
    .line 46
    iget-object p2, p0, La/Z4;->r:La/Sl;

    .line 47
    .line 48
    :goto_1
    invoke-virtual {p2, p1}, La/Sl;->xF(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    goto :goto_2

    .line 52
    :cond_2
    iput-object p2, p0, La/Z4;->x:La/nY;

    .line 53
    .line 54
    iget-object p2, p0, La/Z4;->g:La/Sl;

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :goto_2
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 5

    .line 1
    invoke-static {}, La/rx;->Pc()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, La/m1;->L()La/Js;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v2, La/Iw;->w:La/Yi;

    .line 16
    .line 17
    const-string v2, "mActivityHandlesConfigFlagsChecked"

    .line 18
    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v3, 0x1

    .line 24
    invoke-virtual {v2, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 25
    .line 26
    .line 27
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-virtual {v2, v0, v4}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    const-string v2, "mActivityHandlesConfigFlags"

    .line 33
    .line 34
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    invoke-virtual {v1, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 39
    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :cond_0
    if-eqz p1, :cond_1

    .line 50
    .line 51
    const-string v0, "content_callback"

    .line 52
    .line 53
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, La/ty;

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_1
    const/4 v0, 0x0

    .line 61
    :goto_0
    iput-object v0, p0, La/Z4;->Z:La/ty;

    .line 62
    .line 63
    invoke-super {p0, p1}, La/Jf;->onCreate(Landroid/os/Bundle;)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroidx/activity/w;->onSaveInstanceState(Landroid/os/Bundle;)V

    iget-object v0, p0, La/Z4;->Z:La/ty;

    if-eqz v0, :cond_0

    const-string v1, "content_callback"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_0
    return-void
.end method

.method public final recreate()V
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method
