.class public final Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;
.super La/zZ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/ZK;",
        ">;"
    }
.end annotation


# instance fields
.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c003b

    iput v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->y6:I

    new-instance v0, La/Vn;

    const/16 v1, 0xa

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 2

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    invoke-virtual {p0}, La/zZ;->G()La/o5;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const v1, 0x7f120121

    invoke-virtual {p0, v1}, La/zr;->l(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    :goto_0
    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/zD;

    .line 8
    .line 9
    return-object v0
.end method

.method public final u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 8

    .line 1
    invoke-super {p0, p1, p2, p3}, La/zZ;->u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    .line 2
    .line 3
    .line 4
    sget-object p2, La/B4;->L:[La/B4;

    .line 5
    .line 6
    invoke-virtual {p2}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    check-cast p2, [La/B4;

    .line 11
    .line 12
    new-instance p3, La/Oi;

    .line 13
    .line 14
    invoke-direct {p3, p2}, La/Oi;-><init>([Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p3}, La/Oi;->hasNext()Z

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    const/4 v0, 0x0

    .line 22
    if-nez p2, :cond_0

    .line 23
    .line 24
    sget-object p2, La/LL;->X:La/LL;

    .line 25
    .line 26
    goto :goto_2

    .line 27
    :cond_0
    new-instance p2, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 30
    .line 31
    .line 32
    :goto_0
    invoke-virtual {p3}, La/Oi;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    invoke-virtual {p3}, La/Oi;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-virtual {p3}, La/Oi;->hasNext()Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_1

    .line 47
    .line 48
    invoke-virtual {p3}, La/Oi;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    goto :goto_1

    .line 53
    :cond_1
    move-object v2, v0

    .line 54
    :goto_1
    new-instance v3, La/jH;

    .line 55
    .line 56
    invoke-direct {v3, v1, v2}, La/jH;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_2
    :goto_2
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    :goto_3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 68
    .line 69
    .line 70
    move-result p3

    .line 71
    if-eqz p3, :cond_6

    .line 72
    .line 73
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p3

    .line 77
    check-cast p3, La/jH;

    .line 78
    .line 79
    iget-object v1, p3, La/jH;->X:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v1, La/B4;

    .line 82
    .line 83
    iget-object p3, p3, La/jH;->K:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast p3, La/B4;

    .line 86
    .line 87
    const v2, 0x7f0c0054

    .line 88
    .line 89
    .line 90
    const/4 v3, 0x0

    .line 91
    invoke-virtual {p1, v2, v0, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    const v4, 0x7f09013b

    .line 96
    .line 97
    .line 98
    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    check-cast v4, Landroid/widget/FrameLayout;

    .line 103
    .line 104
    const v5, 0x7f0901f2

    .line 105
    .line 106
    .line 107
    invoke-virtual {v2, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    check-cast v5, Landroid/widget/FrameLayout;

    .line 112
    .line 113
    const/4 v6, 0x2

    .line 114
    new-array v6, v6, [La/jH;

    .line 115
    .line 116
    new-instance v7, La/jH;

    .line 117
    .line 118
    invoke-direct {v7, v1, v4}, La/jH;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    aput-object v7, v6, v3

    .line 122
    .line 123
    new-instance v1, La/jH;

    .line 124
    .line 125
    invoke-direct {v1, p3, v5}, La/jH;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    const/4 p3, 0x1

    .line 129
    aput-object v1, v6, p3

    .line 130
    .line 131
    invoke-static {v6}, La/rE;->NE([Ljava/lang/Object;)Ljava/util/List;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 140
    .line 141
    .line 142
    move-result v3

    .line 143
    if-eqz v3, :cond_4

    .line 144
    .line 145
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    check-cast v3, La/jH;

    .line 150
    .line 151
    iget-object v4, v3, La/jH;->X:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v4, La/B4;

    .line 154
    .line 155
    iget-object v3, v3, La/jH;->K:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v3, Landroid/widget/FrameLayout;

    .line 158
    .line 159
    if-nez v4, :cond_3

    .line 160
    .line 161
    goto :goto_4

    .line 162
    :cond_3
    new-instance v5, Landroid/view/ContextThemeWrapper;

    .line 163
    .line 164
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 165
    .line 166
    .line 167
    move-result-object v6

    .line 168
    iget v7, v4, La/B4;->K:I

    .line 169
    .line 170
    invoke-direct {v5, v6, v7}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 171
    .line 172
    .line 173
    invoke-static {v5}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 174
    .line 175
    .line 176
    move-result-object v5

    .line 177
    sget v6, La/S3;->C:I

    .line 178
    .line 179
    const v6, 0x7f0c0053

    .line 180
    .line 181
    .line 182
    invoke-static {v5, v6, v3, p3}, La/SG;->h(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;Z)Landroidx/databinding/w;

    .line 183
    .line 184
    .line 185
    move-result-object v3

    .line 186
    check-cast v3, La/S3;

    .line 187
    .line 188
    iget-object v5, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->xF:La/Y0;

    .line 189
    .line 190
    invoke-interface {v5}, La/Y0;->getValue()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v5

    .line 194
    check-cast v5, La/zD;

    .line 195
    .line 196
    const/16 v6, 0x2b

    .line 197
    .line 198
    invoke-virtual {v3, v6, v5}, Landroidx/databinding/w;->d(ILjava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    const/16 v5, 0x27

    .line 202
    .line 203
    invoke-virtual {v3, v5, v4}, Landroidx/databinding/w;->d(ILjava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    invoke-virtual {p0}, La/zr;->W()La/NT;

    .line 207
    .line 208
    .line 209
    move-result-object v4

    .line 210
    invoke-virtual {v3, v4}, Landroidx/databinding/w;->L(La/RH;)V

    .line 211
    .line 212
    .line 213
    goto :goto_4

    .line 214
    :cond_4
    iget-object p3, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 215
    .line 216
    if-eqz p3, :cond_5

    .line 217
    .line 218
    goto :goto_5

    .line 219
    :cond_5
    move-object p3, v0

    .line 220
    :goto_5
    check-cast p3, La/ZK;

    .line 221
    .line 222
    iget-object p3, p3, La/ZK;->n:Landroid/widget/LinearLayout;

    .line 223
    .line 224
    invoke-virtual {p3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 225
    .line 226
    .line 227
    goto/16 :goto_3

    .line 228
    .line 229
    :cond_6
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 230
    .line 231
    if-eqz p1, :cond_7

    .line 232
    .line 233
    move-object v0, p1

    .line 234
    :cond_7
    check-cast v0, La/ZK;

    .line 235
    .line 236
    iget-object p1, v0, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 237
    .line 238
    return-object p1
.end method
