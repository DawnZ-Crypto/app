.class public final La/wk;
.super La/yG;
.source "SourceFile"

# interfaces
.implements La/Wb;


# instance fields
.field public final synthetic E:La/Wb;

.field public final synthetic F:Ljava/lang/String;

.field public W:Ljava/util/Collection;

.field public d:La/Wb;

.field public f:Ljava/util/Collection;

.field public l:Ljava/util/Iterator;

.field public q:I


# direct methods
.method public constructor <init>(Ljava/lang/String;La/Wb;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/wk;->F:Ljava/lang/String;

    iput-object p2, p0, La/wk;->E:La/Wb;

    invoke-direct {p0, p3}, La/yG;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final I(Ljava/lang/Object;La/hu;)La/hu;
    .locals 2

    .line 1
    new-instance p1, La/wk;

    iget-object v0, p0, La/wk;->F:Ljava/lang/String;

    iget-object v1, p0, La/wk;->E:La/Wb;

    invoke-direct {p1, v0, v1, p2}, La/wk;-><init>(Ljava/lang/String;La/Wb;La/hu;)V

    return-object p1
.end method

.method public final O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La/wE;

    .line 2
    .line 3
    check-cast p2, La/hu;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La/wk;->I(Ljava/lang/Object;La/hu;)La/hu;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La/wk;

    .line 10
    .line 11
    sget-object p2, La/rr;->w:La/rr;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La/wk;->T(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    sget-object v0, La/cj;->X:La/cj;

    .line 2
    .line 3
    iget v1, p0, La/wk;->q:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_2

    .line 8
    .line 9
    if-eq v1, v3, :cond_1

    .line 10
    .line 11
    if-ne v1, v2, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, La/wk;->W:Ljava/util/Collection;

    .line 14
    .line 15
    iget-object v4, p0, La/wk;->l:Ljava/util/Iterator;

    .line 16
    .line 17
    iget-object v5, p0, La/wk;->f:Ljava/util/Collection;

    .line 18
    .line 19
    iget-object v6, p0, La/wk;->d:La/Wb;

    .line 20
    .line 21
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    move-object v7, v6

    .line 25
    move-object v6, v4

    .line 26
    move-object v4, v1

    .line 27
    move-object v1, v0

    .line 28
    move-object v0, p0

    .line 29
    goto/16 :goto_5

    .line 30
    .line 31
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 32
    .line 33
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 34
    .line 35
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw p1

    .line 39
    :cond_1
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_2
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    new-instance p1, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    const-string v1, "magisk --sqlite \'"

    .line 49
    .line 50
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iget-object v1, p0, La/wk;->F:Ljava/lang/String;

    .line 54
    .line 55
    const-string v4, "\'"

    .line 56
    .line 57
    invoke-static {p1, v1, v4}, La/zq;->M(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    filled-new-array {p1}, [Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-static {p1}, La/Id;->w([Ljava/lang/String;)La/x6;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput v3, p0, La/wk;->q:I

    .line 70
    .line 71
    invoke-static {p1, p0}, La/rx;->V(La/iS;La/hu;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    if-ne p1, v0, :cond_3

    .line 76
    .line 77
    return-object v0

    .line 78
    :cond_3
    :goto_0
    check-cast p1, La/y4;

    .line 79
    .line 80
    check-cast p1, La/DF;

    .line 81
    .line 82
    iget-object p1, p1, La/DF;->w:Ljava/util/List;

    .line 83
    .line 84
    if-nez p1, :cond_4

    .line 85
    .line 86
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    :cond_4
    new-instance v1, Ljava/util/ArrayList;

    .line 91
    .line 92
    invoke-static {p1}, La/cl;->DT(Ljava/lang/Iterable;)I

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 97
    .line 98
    .line 99
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iget-object v4, p0, La/wk;->E:La/Wb;

    .line 104
    .line 105
    move-object v6, v4

    .line 106
    move-object v4, p1

    .line 107
    move-object p1, p0

    .line 108
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 109
    .line 110
    .line 111
    move-result v5

    .line 112
    if-eqz v5, :cond_b

    .line 113
    .line 114
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v5

    .line 118
    check-cast v5, Ljava/lang/String;

    .line 119
    .line 120
    new-instance v7, La/FY;

    .line 121
    .line 122
    const-string v8, "\\|"

    .line 123
    .line 124
    invoke-direct {v7, v8}, La/FY;-><init>(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    const/4 v8, 0x0

    .line 128
    invoke-virtual {v7, v8, v5}, La/FY;->w(ILjava/lang/CharSequence;)Ljava/util/List;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    new-instance v7, Ljava/util/ArrayList;

    .line 133
    .line 134
    invoke-static {v5}, La/cl;->DT(Ljava/lang/Iterable;)I

    .line 135
    .line 136
    .line 137
    move-result v9

    .line 138
    invoke-direct {v7, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 139
    .line 140
    .line 141
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 146
    .line 147
    .line 148
    move-result v9

    .line 149
    if-eqz v9, :cond_5

    .line 150
    .line 151
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v9

    .line 155
    check-cast v9, Ljava/lang/String;

    .line 156
    .line 157
    const-string v10, "="

    .line 158
    .line 159
    filled-new-array {v10}, [Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v10

    .line 163
    invoke-static {v9, v10, v2, v2}, La/ge;->cC(Ljava/lang/String;[Ljava/lang/String;II)Ljava/util/List;

    .line 164
    .line 165
    .line 166
    move-result-object v9

    .line 167
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    goto :goto_2

    .line 171
    :cond_5
    new-instance v5, Ljava/util/ArrayList;

    .line 172
    .line 173
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 177
    .line 178
    .line 179
    move-result-object v7

    .line 180
    :cond_6
    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 181
    .line 182
    .line 183
    move-result v9

    .line 184
    if-eqz v9, :cond_7

    .line 185
    .line 186
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v9

    .line 190
    move-object v10, v9

    .line 191
    check-cast v10, Ljava/util/List;

    .line 192
    .line 193
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 194
    .line 195
    .line 196
    move-result v10

    .line 197
    if-ne v10, v2, :cond_6

    .line 198
    .line 199
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    goto :goto_3

    .line 203
    :cond_7
    invoke-static {v5}, La/cl;->DT(Ljava/lang/Iterable;)I

    .line 204
    .line 205
    .line 206
    move-result v7

    .line 207
    invoke-static {v7}, La/A8;->x(I)I

    .line 208
    .line 209
    .line 210
    move-result v7

    .line 211
    const/16 v9, 0x10

    .line 212
    .line 213
    if-ge v7, v9, :cond_8

    .line 214
    .line 215
    move v7, v9

    .line 216
    :cond_8
    new-instance v9, Ljava/util/LinkedHashMap;

    .line 217
    .line 218
    invoke-direct {v9, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 222
    .line 223
    .line 224
    move-result-object v5

    .line 225
    :goto_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 226
    .line 227
    .line 228
    move-result v7

    .line 229
    if-eqz v7, :cond_9

    .line 230
    .line 231
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v7

    .line 235
    check-cast v7, Ljava/util/List;

    .line 236
    .line 237
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v10

    .line 241
    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v7

    .line 245
    invoke-interface {v9, v10, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    goto :goto_4

    .line 249
    :cond_9
    iput-object v6, p1, La/wk;->d:La/Wb;

    .line 250
    .line 251
    iput-object v1, p1, La/wk;->f:Ljava/util/Collection;

    .line 252
    .line 253
    iput-object v4, p1, La/wk;->l:Ljava/util/Iterator;

    .line 254
    .line 255
    iput-object v1, p1, La/wk;->W:Ljava/util/Collection;

    .line 256
    .line 257
    iput v2, p1, La/wk;->q:I

    .line 258
    .line 259
    invoke-interface {v6, v9, p1}, La/Wb;->O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v5

    .line 263
    if-ne v5, v0, :cond_a

    .line 264
    .line 265
    return-object v0

    .line 266
    :cond_a
    move-object v7, v6

    .line 267
    move-object v6, v4

    .line 268
    move-object v4, v1

    .line 269
    move-object v1, v0

    .line 270
    move-object v0, p1

    .line 271
    move-object p1, v5

    .line 272
    move-object v5, v4

    .line 273
    :goto_5
    invoke-interface {v4, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 274
    .line 275
    .line 276
    move-object p1, v0

    .line 277
    move-object v0, v1

    .line 278
    move-object v1, v5

    .line 279
    move-object v4, v6

    .line 280
    move-object v6, v7

    .line 281
    goto/16 :goto_1

    .line 282
    .line 283
    :cond_b
    check-cast v1, Ljava/util/List;

    .line 284
    .line 285
    return-object v1
.end method
