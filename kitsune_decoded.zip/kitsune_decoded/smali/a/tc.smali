.class public final La/tc;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final h:Ljava/util/ArrayList;

.field public final w:La/GK;


# direct methods
.method public constructor <init>(La/GK;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/tc;->w:La/GK;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, La/tc;->h:Ljava/util/ArrayList;

    return-void
.end method
