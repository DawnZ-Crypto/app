.class public final Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;
.super La/zZ;
.source "SourceFile"

# interfaces
.implements La/We;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/fo;",
        ">;",
        "La/We;"
    }
.end annotation


# instance fields
.field public Pb:Landroidx/appcompat/widget/SearchView;

.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0033

    iput v0, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 2

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    .line 2
    .line 3
    .line 4
    sget-object v0, La/Mv;->w:La/Mv;

    .line 5
    .line 6
    sget-boolean v0, La/Mv;->K:Z

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    const v1, 0x7f12015e

    .line 17
    .line 18
    .line 19
    :goto_0
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(I)V

    .line 20
    .line 21
    .line 22
    goto :goto_1

    .line 23
    :cond_0
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    const v1, 0x7f120145

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    :goto_1
    return-void
.end method

.method public final bridge synthetic F9(Landroidx/databinding/w;)V
    .locals 0

    .line 1
    check-cast p1, La/fo;

    return-void
.end method

.method public final synthetic O(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/JI;

    .line 8
    .line 9
    return-object v0
.end method

.method public final X(Landroid/view/MenuItem;)Z
    .locals 4

    .line 1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->xF:La/Y0;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return p1

    .line 13
    :pswitch_0
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    xor-int/2addr v0, v2

    .line 18
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, La/JI;

    .line 23
    .line 24
    iput-boolean v0, v1, La/JI;->l:Z

    .line 25
    .line 26
    iget-object v3, v1, La/JI;->q:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v1, v3}, La/JI;->d(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    .line 32
    .line 33
    .line 34
    return v2

    .line 35
    :pswitch_1
    invoke-interface {p1}, Landroid/view/MenuItem;->isChecked()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    xor-int/2addr v0, v2

    .line 40
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v1, La/JI;

    .line 45
    .line 46
    iput-boolean v0, v1, La/JI;->W:Z

    .line 47
    .line 48
    iget-object v3, v1, La/JI;->q:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {v1, v3}, La/JI;->d(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    .line 54
    .line 55
    .line 56
    return v2

    .line 57
    :pswitch_data_0
    .packed-switch 0x7f090056
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final e(Landroid/view/Menu;)V
    .locals 2

    .line 1
    const v0, 0x7f090057

    invoke-interface {p1, v0}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    const v1, 0x7f090056

    invoke-interface {p1, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    invoke-interface {v0}, Landroid/view/MenuItem;->isChecked()Z

    move-result v0

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    return-void
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, La/zZ;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 5
    .line 6
    const/4 p2, 0x0

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object p1, p2

    .line 11
    :goto_0
    check-cast p1, La/fo;

    .line 12
    .line 13
    iget-object p1, p1, La/fo;->t:Landroidx/recyclerview/widget/RecyclerView;

    .line 14
    .line 15
    new-instance v0, La/vn;

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-direct {v0, v1, p0}, La/vn;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->I(La/Ht;)V

    .line 22
    .line 23
    .line 24
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 25
    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    move-object p2, p1

    .line 29
    :cond_1
    check-cast p2, La/fo;

    .line 30
    .line 31
    iget-object p1, p2, La/fo;->t:Landroidx/recyclerview/widget/RecyclerView;

    .line 32
    .line 33
    const p2, 0x7f0700af

    .line 34
    .line 35
    .line 36
    const/4 v0, 0x5

    .line 37
    invoke-static {p1, p2, v0}, La/rx;->Q(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 38
    .line 39
    .line 40
    invoke-static {p1}, La/rx;->X(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 41
    .line 42
    .line 43
    invoke-static {p1}, La/rx;->S(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final p(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 2

    .line 1
    const v0, 0x7f0e0001

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 5
    .line 6
    .line 7
    const p2, 0x7f090052

    .line 8
    .line 9
    .line 10
    invoke-interface {p1, p2}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-interface {p1}, Landroid/view/MenuItem;->getActionView()Landroid/view/View;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    check-cast p1, Landroidx/appcompat/widget/SearchView;

    .line 19
    .line 20
    iput-object p1, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->Pb:Landroidx/appcompat/widget/SearchView;

    .line 21
    .line 22
    const/4 p2, 0x0

    .line 23
    if-nez p1, :cond_0

    .line 24
    .line 25
    move-object v0, p2

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    move-object v0, p1

    .line 28
    :goto_0
    if-nez p1, :cond_1

    .line 29
    .line 30
    move-object p1, p2

    .line 31
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    const v1, 0x7f120061

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    iput-object p1, v0, Landroidx/appcompat/widget/SearchView;->FL:Ljava/lang/CharSequence;

    .line 43
    .line 44
    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->d()V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->Pb:Landroidx/appcompat/widget/SearchView;

    .line 48
    .line 49
    if-nez p1, :cond_2

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_2
    move-object p2, p1

    .line 53
    :goto_1
    new-instance p1, La/Ku;

    .line 54
    .line 55
    invoke-direct {p1, p0}, La/Ku;-><init>(Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;)V

    .line 56
    .line 57
    .line 58
    iput-object p1, p2, Landroidx/appcompat/widget/SearchView;->J:La/Ku;

    .line 59
    .line 60
    return-void
.end method

.method public final rC()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/deny/DenyListFragment;->Pb:Landroidx/appcompat/widget/SearchView;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    move-object v2, v1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    move-object v2, v0

    .line 9
    :goto_0
    iget-boolean v2, v2, Landroidx/appcompat/widget/SearchView;->G:Z

    .line 10
    .line 11
    if-eqz v2, :cond_3

    .line 12
    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    move-object v2, v1

    .line 16
    goto :goto_1

    .line 17
    :cond_1
    move-object v2, v0

    .line 18
    :goto_1
    iget-boolean v2, v2, Landroidx/appcompat/widget/SearchView;->Pc:Z

    .line 19
    .line 20
    if-nez v2, :cond_3

    .line 21
    .line 22
    if-nez v0, :cond_2

    .line 23
    .line 24
    move-object v0, v1

    .line 25
    :cond_2
    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->y()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x1

    .line 29
    return v0

    .line 30
    :cond_3
    const/4 v0, 0x0

    .line 31
    return v0
.end method
