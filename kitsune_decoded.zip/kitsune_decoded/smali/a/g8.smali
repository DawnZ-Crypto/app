.class public interface abstract La/g8;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final Q:La/H;

.field public static final e:La/H;

.field public static final h:La/H;

.field public static final i:La/H;

.field public static final p:La/H;

.field public static final w:La/H;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, La/H;

    .line 2
    .line 3
    const-string v1, "1.2.643.2.2"

    .line 4
    .line 5
    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v1, La/H;

    .line 9
    .line 10
    const-string v2, "9"

    .line 11
    .line 12
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    sput-object v1, La/g8;->w:La/H;

    .line 16
    .line 17
    new-instance v1, La/H;

    .line 18
    .line 19
    const-string v2, "10"

    .line 20
    .line 21
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    new-instance v1, La/H;

    .line 25
    .line 26
    const-string v2, "13.0"

    .line 27
    .line 28
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    new-instance v1, La/H;

    .line 32
    .line 33
    const-string v2, "13.1"

    .line 34
    .line 35
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    new-instance v1, La/H;

    .line 39
    .line 40
    const-string v2, "21"

    .line 41
    .line 42
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    new-instance v1, La/H;

    .line 46
    .line 47
    const-string v2, "31.0"

    .line 48
    .line 49
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    new-instance v1, La/H;

    .line 53
    .line 54
    const-string v2, "31.1"

    .line 55
    .line 56
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    new-instance v1, La/H;

    .line 60
    .line 61
    const-string v2, "31.2"

    .line 62
    .line 63
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    new-instance v1, La/H;

    .line 67
    .line 68
    const-string v2, "31.3"

    .line 69
    .line 70
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    const-string v1, "31.4"

    .line 74
    .line 75
    const-string v2, "20"

    .line 76
    .line 77
    invoke-static {v0, v1, v0, v2}, La/zq;->p(La/H;Ljava/lang/String;La/H;Ljava/lang/String;)La/H;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    sput-object v1, La/g8;->h:La/H;

    .line 82
    .line 83
    new-instance v1, La/H;

    .line 84
    .line 85
    const-string v2, "19"

    .line 86
    .line 87
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sput-object v1, La/g8;->p:La/H;

    .line 91
    .line 92
    new-instance v1, La/H;

    .line 93
    .line 94
    const-string v2, "4"

    .line 95
    .line 96
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    sput-object v1, La/g8;->e:La/H;

    .line 100
    .line 101
    new-instance v1, La/H;

    .line 102
    .line 103
    const-string v2, "3"

    .line 104
    .line 105
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    sput-object v1, La/g8;->i:La/H;

    .line 109
    .line 110
    new-instance v1, La/H;

    .line 111
    .line 112
    const-string v2, "30.1"

    .line 113
    .line 114
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    new-instance v1, La/H;

    .line 118
    .line 119
    const-string v2, "32.2"

    .line 120
    .line 121
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    new-instance v1, La/H;

    .line 125
    .line 126
    const-string v2, "32.3"

    .line 127
    .line 128
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    new-instance v1, La/H;

    .line 132
    .line 133
    const-string v2, "32.4"

    .line 134
    .line 135
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    new-instance v1, La/H;

    .line 139
    .line 140
    const-string v2, "32.5"

    .line 141
    .line 142
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    new-instance v1, La/H;

    .line 146
    .line 147
    const-string v2, "33.1"

    .line 148
    .line 149
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    new-instance v1, La/H;

    .line 153
    .line 154
    const-string v2, "33.2"

    .line 155
    .line 156
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    new-instance v1, La/H;

    .line 160
    .line 161
    const-string v2, "33.3"

    .line 162
    .line 163
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    new-instance v1, La/H;

    .line 167
    .line 168
    const-string v2, "35.1"

    .line 169
    .line 170
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    new-instance v1, La/H;

    .line 174
    .line 175
    const-string v2, "35.2"

    .line 176
    .line 177
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    new-instance v1, La/H;

    .line 181
    .line 182
    const-string v2, "35.3"

    .line 183
    .line 184
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    new-instance v1, La/H;

    .line 188
    .line 189
    const-string v2, "36.0"

    .line 190
    .line 191
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    const-string v1, "36.1"

    .line 195
    .line 196
    const-string v2, "96"

    .line 197
    .line 198
    invoke-static {v0, v1, v0, v2}, La/zq;->p(La/H;Ljava/lang/String;La/H;Ljava/lang/String;)La/H;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    sput-object v1, La/g8;->Q:La/H;

    .line 203
    .line 204
    new-instance v1, La/H;

    .line 205
    .line 206
    const-string v2, "98"

    .line 207
    .line 208
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    return-void
.end method
