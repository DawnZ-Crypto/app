.class public abstract La/j5;
.super Landroidx/databinding/w;
.source "SourceFile"


# instance fields
.field public t:La/Tj;
