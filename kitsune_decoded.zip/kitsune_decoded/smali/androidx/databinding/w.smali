.class public abstract Landroidx/databinding/w;
.super La/sW;
.source "SourceFile"


# static fields
.field public static final D:I

.field public static final U:La/eI;

.field public static final Y:Z = true

.field public static final j:La/wX;

.field public static final k:La/eI;

.field public static final s:Ljava/lang/ref/ReferenceQueue;

.field public static final u:La/eI;

.field public static final v:La/XO;


# instance fields
.field public final E:Landroid/os/Handler;

.field public final F:La/i9;

.field public H:La/RH;

.field public final K:La/oE;

.field public L:Z

.field public P:Z

.field public R:Z

.field public S:Landroidx/databinding/w;

.field public W:Z

.field public final d:[La/Cj;

.field public final f:Landroid/view/View;

.field public l:La/aY;

.field public final q:Landroid/view/Choreographer;

.field public z:Landroidx/databinding/ViewDataBinding$OnStartListener;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sput v0, Landroidx/databinding/w;->D:I

    new-instance v0, La/eI;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, La/eI;-><init>(I)V

    sput-object v0, Landroidx/databinding/w;->u:La/eI;

    new-instance v0, La/eI;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, La/eI;-><init>(I)V

    sput-object v0, Landroidx/databinding/w;->U:La/eI;

    new-instance v0, La/eI;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, La/eI;-><init>(I)V

    sput-object v0, Landroidx/databinding/w;->k:La/eI;

    new-instance v0, La/XO;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La/XO;-><init>(I)V

    sput-object v0, Landroidx/databinding/w;->v:La/XO;

    new-instance v0, Ljava/lang/ref/ReferenceQueue;

    invoke-direct {v0}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    sput-object v0, Landroidx/databinding/w;->s:Ljava/lang/ref/ReferenceQueue;

    new-instance v0, La/wX;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La/wX;-><init>(I)V

    sput-object v0, Landroidx/databinding/w;->j:La/wX;

    return-void
.end method

.method public constructor <init>(ILandroid/view/View;Ljava/lang/Object;)V
    .locals 1

    .line 1
    if-nez p3, :cond_2

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance p3, La/oE;

    .line 7
    .line 8
    const/4 v0, 0x6

    .line 9
    invoke-direct {p3, v0, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iput-object p3, p0, Landroidx/databinding/w;->K:La/oE;

    .line 13
    .line 14
    const/4 p3, 0x0

    .line 15
    iput-boolean p3, p0, Landroidx/databinding/w;->R:Z

    .line 16
    .line 17
    iput-boolean p3, p0, Landroidx/databinding/w;->L:Z

    .line 18
    .line 19
    new-array p1, p1, [La/Cj;

    .line 20
    .line 21
    iput-object p1, p0, Landroidx/databinding/w;->d:[La/Cj;

    .line 22
    .line 23
    iput-object p2, p0, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 24
    .line 25
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    sget-boolean p1, Landroidx/databinding/w;->Y:Z

    .line 32
    .line 33
    if-eqz p1, :cond_0

    .line 34
    .line 35
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iput-object p1, p0, Landroidx/databinding/w;->q:Landroid/view/Choreographer;

    .line 40
    .line 41
    new-instance p1, La/i9;

    .line 42
    .line 43
    invoke-direct {p1, p0}, La/i9;-><init>(Landroidx/databinding/w;)V

    .line 44
    .line 45
    .line 46
    iput-object p1, p0, Landroidx/databinding/w;->F:La/i9;

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    const/4 p1, 0x0

    .line 50
    iput-object p1, p0, Landroidx/databinding/w;->F:La/i9;

    .line 51
    .line 52
    new-instance p1, Landroid/os/Handler;

    .line 53
    .line 54
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    invoke-direct {p1, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 59
    .line 60
    .line 61
    iput-object p1, p0, Landroidx/databinding/w;->E:Landroid/os/Handler;

    .line 62
    .line 63
    :goto_0
    return-void

    .line 64
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 65
    .line 66
    const-string p2, "DataBinding must be created in view\'s UI Thread"

    .line 67
    .line 68
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw p1

    .line 72
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 73
    .line 74
    const-string p2, "The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent"

    .line 75
    .line 76
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    throw p1
.end method

.method public static T(Landroid/view/View;[Ljava/lang/Object;La/yW;Landroid/util/SparseIntArray;Z)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const v5, 0x7f0900a5

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, v5}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    check-cast v5, Landroidx/databinding/w;

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v5, 0x0

    .line 22
    :goto_0
    if-eqz v5, :cond_1

    .line 23
    .line 24
    return-void

    .line 25
    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    instance-of v6, v5, Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v6, :cond_2

    .line 32
    .line 33
    check-cast v5, Ljava/lang/String;

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_2
    const/4 v5, 0x0

    .line 37
    :goto_1
    const/16 v6, 0x30

    .line 38
    .line 39
    const/4 v8, 0x1

    .line 40
    const-string v9, "layout"

    .line 41
    .line 42
    const/4 v10, -0x1

    .line 43
    if-eqz p4, :cond_8

    .line 44
    .line 45
    if-eqz v5, :cond_8

    .line 46
    .line 47
    invoke-virtual {v5, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 48
    .line 49
    .line 50
    move-result v11

    .line 51
    if-eqz v11, :cond_8

    .line 52
    .line 53
    const/16 v11, 0x5f

    .line 54
    .line 55
    invoke-virtual {v5, v11}, Ljava/lang/String;->lastIndexOf(I)I

    .line 56
    .line 57
    .line 58
    move-result v11

    .line 59
    if-lez v11, :cond_c

    .line 60
    .line 61
    add-int/2addr v11, v8

    .line 62
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 63
    .line 64
    .line 65
    move-result v12

    .line 66
    if-ne v12, v11, :cond_3

    .line 67
    .line 68
    goto :goto_6

    .line 69
    :cond_3
    move v13, v11

    .line 70
    :goto_2
    if-ge v13, v12, :cond_5

    .line 71
    .line 72
    invoke-virtual {v5, v13}, Ljava/lang/String;->charAt(I)C

    .line 73
    .line 74
    .line 75
    move-result v14

    .line 76
    invoke-static {v14}, Ljava/lang/Character;->isDigit(C)Z

    .line 77
    .line 78
    .line 79
    move-result v14

    .line 80
    if-nez v14, :cond_4

    .line 81
    .line 82
    goto :goto_6

    .line 83
    :cond_4
    add-int/lit8 v13, v13, 0x1

    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_5
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 87
    .line 88
    .line 89
    move-result v12

    .line 90
    const/4 v13, 0x0

    .line 91
    :goto_3
    if-ge v11, v12, :cond_6

    .line 92
    .line 93
    mul-int/lit8 v13, v13, 0xa

    .line 94
    .line 95
    invoke-virtual {v5, v11}, Ljava/lang/String;->charAt(I)C

    .line 96
    .line 97
    .line 98
    move-result v14

    .line 99
    sub-int/2addr v14, v6

    .line 100
    add-int/2addr v13, v14

    .line 101
    add-int/lit8 v11, v11, 0x1

    .line 102
    .line 103
    goto :goto_3

    .line 104
    :cond_6
    aget-object v5, v1, v13

    .line 105
    .line 106
    if-nez v5, :cond_7

    .line 107
    .line 108
    aput-object v0, v1, v13

    .line 109
    .line 110
    :cond_7
    if-nez v2, :cond_b

    .line 111
    .line 112
    goto :goto_5

    .line 113
    :cond_8
    if-eqz v5, :cond_c

    .line 114
    .line 115
    const-string v11, "binding_"

    .line 116
    .line 117
    invoke-virtual {v5, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 118
    .line 119
    .line 120
    move-result v11

    .line 121
    if-eqz v11, :cond_c

    .line 122
    .line 123
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 124
    .line 125
    .line 126
    move-result v11

    .line 127
    const/16 v12, 0x8

    .line 128
    .line 129
    const/4 v13, 0x0

    .line 130
    :goto_4
    if-ge v12, v11, :cond_9

    .line 131
    .line 132
    mul-int/lit8 v13, v13, 0xa

    .line 133
    .line 134
    invoke-virtual {v5, v12}, Ljava/lang/String;->charAt(I)C

    .line 135
    .line 136
    .line 137
    move-result v14

    .line 138
    sub-int/2addr v14, v6

    .line 139
    add-int/2addr v13, v14

    .line 140
    add-int/lit8 v12, v12, 0x1

    .line 141
    .line 142
    goto :goto_4

    .line 143
    :cond_9
    aget-object v5, v1, v13

    .line 144
    .line 145
    if-nez v5, :cond_a

    .line 146
    .line 147
    aput-object v0, v1, v13

    .line 148
    .line 149
    :cond_a
    if-nez v2, :cond_b

    .line 150
    .line 151
    :goto_5
    move v13, v10

    .line 152
    :cond_b
    move v5, v8

    .line 153
    goto :goto_7

    .line 154
    :cond_c
    :goto_6
    move v13, v10

    .line 155
    const/4 v5, 0x0

    .line 156
    :goto_7
    if-nez v5, :cond_d

    .line 157
    .line 158
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getId()I

    .line 159
    .line 160
    .line 161
    move-result v5

    .line 162
    if-lez v5, :cond_d

    .line 163
    .line 164
    if-eqz v3, :cond_d

    .line 165
    .line 166
    invoke-virtual {v3, v5, v10}, Landroid/util/SparseIntArray;->get(II)I

    .line 167
    .line 168
    .line 169
    move-result v5

    .line 170
    if-ltz v5, :cond_d

    .line 171
    .line 172
    aget-object v11, v1, v5

    .line 173
    .line 174
    if-nez v11, :cond_d

    .line 175
    .line 176
    aput-object v0, v1, v5

    .line 177
    .line 178
    :cond_d
    instance-of v5, v0, Landroid/view/ViewGroup;

    .line 179
    .line 180
    if-eqz v5, :cond_1d

    .line 181
    .line 182
    check-cast v0, Landroid/view/ViewGroup;

    .line 183
    .line 184
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 185
    .line 186
    .line 187
    move-result v5

    .line 188
    const/4 v11, 0x0

    .line 189
    const/4 v12, 0x0

    .line 190
    :goto_8
    if-ge v11, v5, :cond_1d

    .line 191
    .line 192
    invoke-virtual {v0, v11}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 193
    .line 194
    .line 195
    move-result-object v14

    .line 196
    if-ltz v13, :cond_1b

    .line 197
    .line 198
    invoke-virtual {v14}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v15

    .line 202
    instance-of v15, v15, Ljava/lang/String;

    .line 203
    .line 204
    if-eqz v15, :cond_1b

    .line 205
    .line 206
    invoke-virtual {v14}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v15

    .line 210
    check-cast v15, Ljava/lang/String;

    .line 211
    .line 212
    const-string v4, "_0"

    .line 213
    .line 214
    invoke-virtual {v15, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 215
    .line 216
    .line 217
    move-result v4

    .line 218
    if-eqz v4, :cond_1b

    .line 219
    .line 220
    invoke-virtual {v15, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 221
    .line 222
    .line 223
    move-result v4

    .line 224
    if-eqz v4, :cond_1b

    .line 225
    .line 226
    const/16 v4, 0x2f

    .line 227
    .line 228
    invoke-virtual {v15, v4}, Ljava/lang/String;->indexOf(I)I

    .line 229
    .line 230
    .line 231
    move-result v16

    .line 232
    if-lez v16, :cond_1b

    .line 233
    .line 234
    invoke-virtual {v15, v4}, Ljava/lang/String;->indexOf(I)I

    .line 235
    .line 236
    .line 237
    move-result v4

    .line 238
    add-int/2addr v4, v8

    .line 239
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    .line 240
    .line 241
    .line 242
    move-result v16

    .line 243
    add-int/lit8 v10, v16, -0x2

    .line 244
    .line 245
    invoke-virtual {v15, v4, v10}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 246
    .line 247
    .line 248
    move-result-object v4

    .line 249
    iget-object v10, v2, La/yW;->K:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v10, [[Ljava/lang/String;

    .line 252
    .line 253
    aget-object v10, v10, v13

    .line 254
    .line 255
    array-length v15, v10

    .line 256
    move v6, v12

    .line 257
    :goto_9
    if-ge v6, v15, :cond_f

    .line 258
    .line 259
    aget-object v7, v10, v6

    .line 260
    .line 261
    invoke-static {v4, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 262
    .line 263
    .line 264
    move-result v7

    .line 265
    if-eqz v7, :cond_e

    .line 266
    .line 267
    goto :goto_a

    .line 268
    :cond_e
    add-int/lit8 v6, v6, 0x1

    .line 269
    .line 270
    goto :goto_9

    .line 271
    :cond_f
    const/4 v6, -0x1

    .line 272
    :goto_a
    if-ltz v6, :cond_1a

    .line 273
    .line 274
    add-int/lit8 v12, v6, 0x1

    .line 275
    .line 276
    iget-object v4, v2, La/yW;->R:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast v4, [[I

    .line 279
    .line 280
    aget-object v4, v4, v13

    .line 281
    .line 282
    aget v4, v4, v6

    .line 283
    .line 284
    iget-object v7, v2, La/yW;->L:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast v7, [[I

    .line 287
    .line 288
    aget-object v7, v7, v13

    .line 289
    .line 290
    aget v6, v7, v6

    .line 291
    .line 292
    invoke-virtual {v0, v11}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 293
    .line 294
    .line 295
    move-result-object v7

    .line 296
    invoke-virtual {v7}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v7

    .line 300
    check-cast v7, Ljava/lang/String;

    .line 301
    .line 302
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 303
    .line 304
    .line 305
    move-result v10

    .line 306
    sub-int/2addr v10, v8

    .line 307
    const/4 v15, 0x0

    .line 308
    invoke-virtual {v7, v15, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object v10

    .line 312
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 313
    .line 314
    .line 315
    move-result v15

    .line 316
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 317
    .line 318
    .line 319
    move-result v8

    .line 320
    add-int/lit8 v17, v11, 0x1

    .line 321
    .line 322
    move/from16 p0, v5

    .line 323
    .line 324
    move/from16 v5, v17

    .line 325
    .line 326
    move-object/from16 v17, v9

    .line 327
    .line 328
    move v9, v11

    .line 329
    :goto_b
    if-ge v5, v8, :cond_17

    .line 330
    .line 331
    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 332
    .line 333
    .line 334
    move-result-object v18

    .line 335
    move/from16 p4, v8

    .line 336
    .line 337
    invoke-virtual/range {v18 .. v18}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 338
    .line 339
    .line 340
    move-result-object v8

    .line 341
    instance-of v8, v8, Ljava/lang/String;

    .line 342
    .line 343
    if-eqz v8, :cond_10

    .line 344
    .line 345
    invoke-virtual/range {v18 .. v18}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    move-result-object v8

    .line 349
    check-cast v8, Ljava/lang/String;

    .line 350
    .line 351
    goto :goto_c

    .line 352
    :cond_10
    const/4 v8, 0x0

    .line 353
    :goto_c
    if-eqz v8, :cond_16

    .line 354
    .line 355
    invoke-virtual {v8, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 356
    .line 357
    .line 358
    move-result v18

    .line 359
    if-eqz v18, :cond_16

    .line 360
    .line 361
    move-object/from16 v18, v10

    .line 362
    .line 363
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 364
    .line 365
    .line 366
    move-result v10

    .line 367
    move/from16 v19, v12

    .line 368
    .line 369
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 370
    .line 371
    .line 372
    move-result v12

    .line 373
    if-ne v10, v12, :cond_11

    .line 374
    .line 375
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 376
    .line 377
    .line 378
    move-result v10

    .line 379
    const/4 v12, 0x1

    .line 380
    sub-int/2addr v10, v12

    .line 381
    invoke-virtual {v8, v10}, Ljava/lang/String;->charAt(I)C

    .line 382
    .line 383
    .line 384
    move-result v10

    .line 385
    const/16 v12, 0x30

    .line 386
    .line 387
    if-ne v10, v12, :cond_12

    .line 388
    .line 389
    goto :goto_f

    .line 390
    :cond_11
    const/16 v12, 0x30

    .line 391
    .line 392
    :cond_12
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 393
    .line 394
    .line 395
    move-result v10

    .line 396
    if-ne v10, v15, :cond_13

    .line 397
    .line 398
    goto :goto_e

    .line 399
    :cond_13
    move v12, v15

    .line 400
    :goto_d
    if-ge v12, v10, :cond_15

    .line 401
    .line 402
    invoke-virtual {v8, v12}, Ljava/lang/String;->charAt(I)C

    .line 403
    .line 404
    .line 405
    move-result v20

    .line 406
    invoke-static/range {v20 .. v20}, Ljava/lang/Character;->isDigit(C)Z

    .line 407
    .line 408
    .line 409
    move-result v20

    .line 410
    if-nez v20, :cond_14

    .line 411
    .line 412
    goto :goto_e

    .line 413
    :cond_14
    add-int/lit8 v12, v12, 0x1

    .line 414
    .line 415
    goto :goto_d

    .line 416
    :cond_15
    move v9, v5

    .line 417
    goto :goto_e

    .line 418
    :cond_16
    move-object/from16 v18, v10

    .line 419
    .line 420
    move/from16 v19, v12

    .line 421
    .line 422
    :goto_e
    add-int/lit8 v5, v5, 0x1

    .line 423
    .line 424
    move/from16 v8, p4

    .line 425
    .line 426
    move-object/from16 v10, v18

    .line 427
    .line 428
    move/from16 v12, v19

    .line 429
    .line 430
    goto :goto_b

    .line 431
    :cond_17
    move/from16 v19, v12

    .line 432
    .line 433
    :goto_f
    if-ne v9, v11, :cond_18

    .line 434
    .line 435
    sget-object v5, La/SG;->w:Landroidx/databinding/DataBinderMapperImpl;

    .line 436
    .line 437
    invoke-virtual {v5, v14, v6}, Landroidx/databinding/MergedDataBinderMapper;->h(Landroid/view/View;I)Landroidx/databinding/w;

    .line 438
    .line 439
    .line 440
    move-result-object v5

    .line 441
    aput-object v5, v1, v4

    .line 442
    .line 443
    :goto_10
    move/from16 v12, v19

    .line 444
    .line 445
    const/16 v4, 0x30

    .line 446
    .line 447
    const/4 v15, 0x1

    .line 448
    goto :goto_13

    .line 449
    :cond_18
    sub-int/2addr v9, v11

    .line 450
    add-int/lit8 v5, v9, 0x1

    .line 451
    .line 452
    new-array v7, v5, [Landroid/view/View;

    .line 453
    .line 454
    const/4 v15, 0x0

    .line 455
    :goto_11
    if-ge v15, v5, :cond_19

    .line 456
    .line 457
    add-int v8, v11, v15

    .line 458
    .line 459
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 460
    .line 461
    .line 462
    move-result-object v8

    .line 463
    aput-object v8, v7, v15

    .line 464
    .line 465
    add-int/lit8 v15, v15, 0x1

    .line 466
    .line 467
    goto :goto_11

    .line 468
    :cond_19
    sget-object v5, La/SG;->w:Landroidx/databinding/DataBinderMapperImpl;

    .line 469
    .line 470
    invoke-virtual {v5, v7, v6}, Landroidx/databinding/MergedDataBinderMapper;->p([Landroid/view/View;I)Landroidx/databinding/w;

    .line 471
    .line 472
    .line 473
    move-result-object v5

    .line 474
    aput-object v5, v1, v4

    .line 475
    .line 476
    add-int/2addr v11, v9

    .line 477
    goto :goto_10

    .line 478
    :cond_1a
    move/from16 p0, v5

    .line 479
    .line 480
    move-object/from16 v17, v9

    .line 481
    .line 482
    const/16 v4, 0x30

    .line 483
    .line 484
    goto :goto_12

    .line 485
    :cond_1b
    move/from16 p0, v5

    .line 486
    .line 487
    move v4, v6

    .line 488
    move-object/from16 v17, v9

    .line 489
    .line 490
    :goto_12
    const/4 v15, 0x0

    .line 491
    :goto_13
    const/4 v5, 0x0

    .line 492
    if-nez v15, :cond_1c

    .line 493
    .line 494
    invoke-static {v14, v1, v2, v3, v5}, Landroidx/databinding/w;->T(Landroid/view/View;[Ljava/lang/Object;La/yW;Landroid/util/SparseIntArray;Z)V

    .line 495
    .line 496
    .line 497
    :cond_1c
    const/4 v6, 0x1

    .line 498
    add-int/2addr v11, v6

    .line 499
    move/from16 v5, p0

    .line 500
    .line 501
    move v8, v6

    .line 502
    move-object/from16 v9, v17

    .line 503
    .line 504
    const/4 v10, -0x1

    .line 505
    move v6, v4

    .line 506
    goto/16 :goto_8

    .line 507
    .line 508
    :cond_1d
    return-void
.end method

.method public static m(Landroid/view/View;ILa/yW;Landroid/util/SparseIntArray;)[Ljava/lang/Object;
    .locals 1

    .line 1
    new-array p1, p1, [Ljava/lang/Object;

    const/4 v0, 0x1

    invoke-static {p0, p1, p2, p3, v0}, Landroidx/databinding/w;->T(Landroid/view/View;[Ljava/lang/Object;La/yW;Landroid/util/SparseIntArray;Z)V

    return-object p1
.end method


# virtual methods
.method public abstract I()Z
.end method

.method public final K(ILjava/lang/Object;La/eI;)V
    .locals 2

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    iget-object v0, p0, Landroidx/databinding/w;->d:[La/Cj;

    .line 5
    .line 6
    aget-object v1, v0, p1

    .line 7
    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    sget-object v1, Landroidx/databinding/w;->s:Ljava/lang/ref/ReferenceQueue;

    .line 11
    .line 12
    iget p3, p3, La/eI;->X:I

    .line 13
    .line 14
    packed-switch p3, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    new-instance p3, La/sY;

    .line 18
    .line 19
    invoke-direct {p3, p0, p1, v1}, La/sY;-><init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V

    .line 20
    .line 21
    .line 22
    iget-object p3, p3, La/sY;->X:La/Cj;

    .line 23
    .line 24
    :goto_0
    move-object v1, p3

    .line 25
    goto :goto_1

    .line 26
    :pswitch_0
    new-instance p3, La/ze;

    .line 27
    .line 28
    invoke-direct {p3, p0, p1, v1}, La/ze;-><init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V

    .line 29
    .line 30
    .line 31
    iget-object p3, p3, La/ze;->K:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p3, La/Cj;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :pswitch_1
    new-instance p3, La/R6;

    .line 37
    .line 38
    invoke-direct {p3, p0, p1, v1}, La/R6;-><init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V

    .line 39
    .line 40
    .line 41
    iget-object p3, p3, La/R6;->K:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast p3, La/Cj;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :pswitch_2
    new-instance p3, La/kv;

    .line 47
    .line 48
    invoke-direct {p3, p0, p1, v1}, La/kv;-><init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V

    .line 49
    .line 50
    .line 51
    iget-object p3, p3, La/kv;->X:La/Cj;

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :goto_1
    aput-object v1, v0, p1

    .line 55
    .line 56
    iget-object p1, p0, Landroidx/databinding/w;->H:La/RH;

    .line 57
    .line 58
    if-eqz p1, :cond_1

    .line 59
    .line 60
    iget-object p3, v1, La/Cj;->w:La/Lk;

    .line 61
    .line 62
    invoke-interface {p3, p1}, La/Lk;->M(La/RH;)V

    .line 63
    .line 64
    .line 65
    :cond_1
    invoke-virtual {v1}, La/Cj;->w()Z

    .line 66
    .line 67
    .line 68
    iput-object p2, v1, La/Cj;->p:Ljava/lang/Object;

    .line 69
    .line 70
    iget-object p1, v1, La/Cj;->w:La/Lk;

    .line 71
    .line 72
    invoke-interface {p1, p2}, La/Lk;->p(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    nop

    .line 77
    :pswitch_data_0
    .packed-switch 0xc
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public L(La/RH;)V
    .locals 4

    .line 1
    instance-of v0, p1, La/zr;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const-string v0, "DataBinding"

    .line 6
    .line 7
    const-string v1, "Setting the fragment as the LifecycleOwner might cause memory leaks because views lives shorter than the Fragment. Consider using Fragment\'s view lifecycle"

    .line 8
    .line 9
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Landroidx/databinding/w;->H:La/RH;

    .line 13
    .line 14
    if-ne v0, p1, :cond_1

    .line 15
    .line 16
    return-void

    .line 17
    :cond_1
    if-eqz v0, :cond_2

    .line 18
    .line 19
    invoke-interface {v0}, La/RH;->I()Landroidx/lifecycle/w;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-object v1, p0, Landroidx/databinding/w;->z:Landroidx/databinding/ViewDataBinding$OnStartListener;

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->h(La/IQ;)V

    .line 26
    .line 27
    .line 28
    :cond_2
    iput-object p1, p0, Landroidx/databinding/w;->H:La/RH;

    .line 29
    .line 30
    if-eqz p1, :cond_4

    .line 31
    .line 32
    iget-object v0, p0, Landroidx/databinding/w;->z:Landroidx/databinding/ViewDataBinding$OnStartListener;

    .line 33
    .line 34
    if-nez v0, :cond_3

    .line 35
    .line 36
    new-instance v0, Landroidx/databinding/ViewDataBinding$OnStartListener;

    .line 37
    .line 38
    invoke-direct {v0, p0}, Landroidx/databinding/ViewDataBinding$OnStartListener;-><init>(Landroidx/databinding/w;)V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Landroidx/databinding/w;->z:Landroidx/databinding/ViewDataBinding$OnStartListener;

    .line 42
    .line 43
    :cond_3
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iget-object v1, p0, Landroidx/databinding/w;->z:Landroidx/databinding/ViewDataBinding$OnStartListener;

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 50
    .line 51
    .line 52
    :cond_4
    iget-object v0, p0, Landroidx/databinding/w;->d:[La/Cj;

    .line 53
    .line 54
    array-length v1, v0

    .line 55
    const/4 v2, 0x0

    .line 56
    :goto_0
    if-ge v2, v1, :cond_6

    .line 57
    .line 58
    aget-object v3, v0, v2

    .line 59
    .line 60
    if-eqz v3, :cond_5

    .line 61
    .line 62
    iget-object v3, v3, La/Cj;->w:La/Lk;

    .line 63
    .line 64
    invoke-interface {v3, p1}, La/Lk;->M(La/RH;)V

    .line 65
    .line 66
    .line 67
    :cond_5
    add-int/lit8 v2, v2, 0x1

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_6
    return-void
.end method

.method public abstract M()V
.end method

.method public final R()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/databinding/w;->S:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/databinding/w;->R()V

    .line 6
    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    iget-object v0, p0, Landroidx/databinding/w;->H:La/RH;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-interface {v0}, La/RH;->I()Landroidx/lifecycle/w;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iget-object v0, v0, Landroidx/lifecycle/w;->e:La/m2;

    .line 18
    .line 19
    sget-object v1, La/m2;->L:La/m2;

    .line 20
    .line 21
    invoke-virtual {v0, v1}, La/m2;->w(La/m2;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    monitor-enter p0

    .line 29
    :try_start_0
    iget-boolean v0, p0, Landroidx/databinding/w;->R:Z

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    monitor-exit p0

    .line 34
    return-void

    .line 35
    :catchall_0
    move-exception v0

    .line 36
    goto :goto_1

    .line 37
    :cond_2
    const/4 v0, 0x1

    .line 38
    iput-boolean v0, p0, Landroidx/databinding/w;->R:Z

    .line 39
    .line 40
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    sget-boolean v0, Landroidx/databinding/w;->Y:Z

    .line 42
    .line 43
    if-eqz v0, :cond_3

    .line 44
    .line 45
    iget-object v0, p0, Landroidx/databinding/w;->q:Landroid/view/Choreographer;

    .line 46
    .line 47
    iget-object v1, p0, Landroidx/databinding/w;->F:La/i9;

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_3
    iget-object v0, p0, Landroidx/databinding/w;->E:Landroid/os/Handler;

    .line 54
    .line 55
    iget-object v1, p0, Landroidx/databinding/w;->K:La/oE;

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 58
    .line 59
    .line 60
    :goto_0
    return-void

    .line 61
    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 62
    throw v0
.end method

.method public final V()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/databinding/w;->S:Landroidx/databinding/w;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroidx/databinding/w;->X()V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroidx/databinding/w;->V()V

    :goto_0
    return-void
.end method

.method public final X()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Landroidx/databinding/w;->W:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/databinding/w;->R()V

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/databinding/w;->I()Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/databinding/w;->W:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/databinding/w;->L:Z

    iget-object v2, p0, Landroidx/databinding/w;->l:La/aY;

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    invoke-virtual {v2, p0, v0, v3}, La/aY;->e(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-boolean v0, p0, Landroidx/databinding/w;->L:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/databinding/w;->l:La/aY;

    const/4 v2, 0x2

    invoke-virtual {v0, p0, v2, v3}, La/aY;->e(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_2
    iget-boolean v0, p0, Landroidx/databinding/w;->L:Z

    if-nez v0, :cond_3

    invoke-virtual {p0}, Landroidx/databinding/w;->i()V

    iget-object v0, p0, Landroidx/databinding/w;->l:La/aY;

    if-eqz v0, :cond_3

    const/4 v2, 0x3

    invoke-virtual {v0, p0, v2, v3}, La/aY;->e(Ljava/lang/Object;ILjava/lang/Object;)V

    :cond_3
    iput-boolean v1, p0, Landroidx/databinding/w;->W:Z

    return-void
.end method

.method public abstract d(ILjava/lang/Object;)Z
.end method

.method public final f(ILa/hc;)V
    .locals 1

    .line 1
    sget-object v0, Landroidx/databinding/w;->u:La/eI;

    invoke-virtual {p0, p1, p2, v0}, Landroidx/databinding/w;->l(ILjava/lang/Object;La/eI;)Z

    return-void
.end method

.method public abstract i()V
.end method

.method public final l(ILjava/lang/Object;La/eI;)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p2, :cond_1

    .line 3
    .line 4
    iget-object p2, p0, Landroidx/databinding/w;->d:[La/Cj;

    .line 5
    .line 6
    aget-object p1, p2, p1

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p1}, La/Cj;->w()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    :cond_0
    return v0

    .line 15
    :cond_1
    iget-object v1, p0, Landroidx/databinding/w;->d:[La/Cj;

    .line 16
    .line 17
    aget-object v1, v1, p1

    .line 18
    .line 19
    const/4 v2, 0x1

    .line 20
    if-nez v1, :cond_2

    .line 21
    .line 22
    invoke-virtual {p0, p1, p2, p3}, Landroidx/databinding/w;->K(ILjava/lang/Object;La/eI;)V

    .line 23
    .line 24
    .line 25
    return v2

    .line 26
    :cond_2
    iget-object v3, v1, La/Cj;->p:Ljava/lang/Object;

    .line 27
    .line 28
    if-ne v3, p2, :cond_3

    .line 29
    .line 30
    return v0

    .line 31
    :cond_3
    if-eqz v1, :cond_4

    .line 32
    .line 33
    invoke-virtual {v1}, La/Cj;->w()Z

    .line 34
    .line 35
    .line 36
    :cond_4
    invoke-virtual {p0, p1, p2, p3}, Landroidx/databinding/w;->K(ILjava/lang/Object;La/eI;)V

    .line 37
    .line 38
    .line 39
    return v2
.end method

.method public abstract y(IILjava/lang/Object;)Z
.end method
