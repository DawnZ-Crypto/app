.class public final Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;
.super La/eh;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/eh;"
    }
.end annotation


# instance fields
.field public final h:La/eh;

.field public volatile p:Ljava/lang/reflect/Constructor;

.field public final w:La/dh;


# direct methods
.method public constructor <init>(La/Nm;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "magisk"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, La/dh;->S([Ljava/lang/String;)La/dh;

    move-result-object v1

    iput-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->w:La/dh;

    sget-object v1, La/UK;->X:La/UK;

    const-class v2, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    invoke-virtual {p1, v2, v1, v0}, La/Nm;->h(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)La/eh;

    move-result-object p1

    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->h:La/eh;

    return-void
.end method


# virtual methods
.method public final p(La/At;Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 2
    .line 3
    if-eqz p2, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, La/At;->h()La/AN;

    .line 6
    .line 7
    .line 8
    const-string v0, "magisk"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, La/At;->f(Ljava/lang/String;)La/AN;

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->h:La/eh;

    .line 14
    .line 15
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 16
    .line 17
    invoke-virtual {v0, p1, p2}, La/eh;->p(La/At;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, La/At;->I()La/AN;

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 25
    .line 26
    const-string p2, "value_ was null! Wrap in .nullSafe() to write nullable values."

    .line 27
    .line 28
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "GeneratedJsonAdapter(UpdateInfo)"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final w(La/SN;)Ljava/lang/Object;
    .locals 8

    .line 1
    invoke-virtual {p1}, La/SN;->h()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, -0x1

    .line 6
    move-object v3, v0

    .line 7
    move v2, v1

    .line 8
    :goto_0
    invoke-virtual {p1}, La/SN;->U()Z

    .line 9
    .line 10
    .line 11
    move-result v4

    .line 12
    if-eqz v4, :cond_3

    .line 13
    .line 14
    iget-object v4, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->w:La/dh;

    .line 15
    .line 16
    invoke-virtual {p1, v4}, La/SN;->xF(La/dh;)I

    .line 17
    .line 18
    .line 19
    move-result v4

    .line 20
    if-eq v4, v1, :cond_2

    .line 21
    .line 22
    if-eqz v4, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    iget-object v3, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->h:La/eh;

    .line 26
    .line 27
    invoke-virtual {v3, p1}, La/eh;->w(La/SN;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 32
    .line 33
    if-eqz v3, :cond_1

    .line 34
    .line 35
    and-int/lit8 v2, v2, -0x2

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    const-string v0, "magisk"

    .line 39
    .line 40
    invoke-static {v0, v0, p1}, La/Gh;->I(Ljava/lang/String;Ljava/lang/String;La/SN;)La/P5;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    throw p1

    .line 45
    :cond_2
    invoke-virtual {p1}, La/SN;->Pb()V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, La/SN;->lI()V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_3
    invoke-virtual {p1}, La/SN;->T()V

    .line 53
    .line 54
    .line 55
    const/4 p1, -0x2

    .line 56
    if-ne v2, p1, :cond_4

    .line 57
    .line 58
    new-instance p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 59
    .line 60
    invoke-direct {p1, v3}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Lcom/topjohnwu/magisk/core/model/MagiskJson;)V

    .line 61
    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_4
    iget-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->p:Ljava/lang/reflect/Constructor;

    .line 65
    .line 66
    const/4 v1, 0x2

    .line 67
    const/4 v4, 0x1

    .line 68
    const/4 v5, 0x0

    .line 69
    const/4 v6, 0x3

    .line 70
    if-nez p1, :cond_5

    .line 71
    .line 72
    new-array p1, v6, [Ljava/lang/Class;

    .line 73
    .line 74
    const-class v7, Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 75
    .line 76
    aput-object v7, p1, v5

    .line 77
    .line 78
    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 79
    .line 80
    aput-object v7, p1, v4

    .line 81
    .line 82
    sget-object v7, La/Gh;->p:Ljava/lang/Class;

    .line 83
    .line 84
    aput-object v7, p1, v1

    .line 85
    .line 86
    const-class v7, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 87
    .line 88
    invoke-virtual {v7, p1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->p:Ljava/lang/reflect/Constructor;

    .line 93
    .line 94
    :cond_5
    new-array v6, v6, [Ljava/lang/Object;

    .line 95
    .line 96
    aput-object v3, v6, v5

    .line 97
    .line 98
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    aput-object v2, v6, v4

    .line 103
    .line 104
    aput-object v0, v6, v1

    .line 105
    .line 106
    invoke-virtual {p1, v6}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    check-cast p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 111
    .line 112
    :goto_1
    return-object p1
.end method
