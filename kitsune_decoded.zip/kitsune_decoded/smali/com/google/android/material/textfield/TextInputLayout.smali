.class public Lcom/google/android/material/textfield/TextInputLayout;
.super Landroid/widget/LinearLayout;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# static fields
.field public static final Pi:[[I


# instance fields
.field public final AW:I

.field public B:Ljava/lang/CharSequence;

.field public final B1:I

.field public final B2:Z

.field public final C:La/KF;

.field public final C6:I

.field public final D:La/c8;

.field public final E:La/A7;

.field public final Ey:Z

.field public F:I

.field public final F9:I

.field public FL:La/ex;

.field public G:Landroid/graphics/drawable/StateListDrawable;

.field public final GI:I

.field public Gy:I

.field public H:I

.field public HF:Landroid/graphics/drawable/ColorDrawable;

.field public Hs:Z

.field public final IL:La/W5;

.field public J:La/ex;

.field public final K:Landroid/widget/FrameLayout;

.field public final L:La/h9;

.field public MX:Landroid/graphics/drawable/ColorDrawable;

.field public N:Z

.field public final N3:I

.field public final NE:Ljava/util/LinkedHashSet;

.field public final P:La/TD;

.field public final Pb:Landroid/graphics/Rect;

.field public Pc:Z

.field public Qg:Landroid/graphics/drawable/Drawable;

.field public Qn:Z

.field public final R:La/dX;

.field public final S:Z

.field public Tr:Landroid/content/res/ColorStateList;

.field public final U:I

.field public final VQ:Landroid/graphics/RectF;

.field public final Vm:I

.field public final Vy:Landroid/content/res/ColorStateList;

.field public W:I

.field public ZU:I

.field public final an:I

.field public au:Z

.field public b:La/ex;

.field public final c:Z

.field public final cM:I

.field public cS:I

.field public d:Landroid/widget/EditText;

.field public final eH:I

.field public f:Ljava/lang/CharSequence;

.field public final g:Landroid/content/res/ColorStateList;

.field public final j:Landroid/content/res/ColorStateList;

.field public final k:Ljava/lang/CharSequence;

.field public l:I

.field public final lI:Landroid/graphics/Rect;

.field public mh:I

.field public final n:La/KF;

.field public final nA:I

.field public final o:Landroid/content/res/ColorStateList;

.field public p7:Z

.field public q:I

.field public final r:Landroid/content/res/ColorStateList;

.field public rC:La/c9;

.field public rV:La/ex;

.field public final rZ:I

.field public s:La/c8;

.field public sH:Z

.field public final t:I

.field public final u:I

.field public v:Z

.field public vz:Landroid/animation/ValueAnimator;

.field public final x:Landroid/content/res/ColorStateList;

.field public xF:I

.field public y6:I

.field public final yd:Landroid/content/res/ColorStateList;

.field public z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v0, 0x2

    new-array v0, v0, [[I

    const v1, 0x10100a7

    filled-new-array {v1}, [I

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const/4 v1, 0x1

    new-array v2, v2, [I

    aput-object v2, v0, v1

    sput-object v0, Lcom/google/android/material/textfield/TextInputLayout;->Pi:[[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p2

    .line 4
    .line 5
    const v8, 0x7f040496

    .line 6
    .line 7
    .line 8
    const v9, 0x7f130375

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p1

    .line 12
    .line 13
    invoke-static {v1, v7, v8, v9}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1, v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 18
    .line 19
    .line 20
    const/4 v10, -0x1

    .line 21
    iput v10, v0, Lcom/google/android/material/textfield/TextInputLayout;->l:I

    .line 22
    .line 23
    iput v10, v0, Lcom/google/android/material/textfield/TextInputLayout;->W:I

    .line 24
    .line 25
    iput v10, v0, Lcom/google/android/material/textfield/TextInputLayout;->q:I

    .line 26
    .line 27
    iput v10, v0, Lcom/google/android/material/textfield/TextInputLayout;->F:I

    .line 28
    .line 29
    new-instance v11, La/A7;

    .line 30
    .line 31
    invoke-direct {v11, v0}, La/A7;-><init>(Lcom/google/android/material/textfield/TextInputLayout;)V

    .line 32
    .line 33
    .line 34
    iput-object v11, v0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 35
    .line 36
    new-instance v1, La/TD;

    .line 37
    .line 38
    const/4 v12, 0x1

    .line 39
    invoke-direct {v1, v12}, La/TD;-><init>(I)V

    .line 40
    .line 41
    .line 42
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->P:La/TD;

    .line 43
    .line 44
    new-instance v1, Landroid/graphics/Rect;

    .line 45
    .line 46
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->Pb:Landroid/graphics/Rect;

    .line 50
    .line 51
    new-instance v1, Landroid/graphics/Rect;

    .line 52
    .line 53
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->lI:Landroid/graphics/Rect;

    .line 57
    .line 58
    new-instance v1, Landroid/graphics/RectF;

    .line 59
    .line 60
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 61
    .line 62
    .line 63
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->VQ:Landroid/graphics/RectF;

    .line 64
    .line 65
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 66
    .line 67
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 68
    .line 69
    .line 70
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->NE:Ljava/util/LinkedHashSet;

    .line 71
    .line 72
    new-instance v13, La/W5;

    .line 73
    .line 74
    invoke-direct {v13, v0}, La/W5;-><init>(Landroid/view/View;)V

    .line 75
    .line 76
    .line 77
    iput-object v13, v0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 78
    .line 79
    const/4 v14, 0x0

    .line 80
    iput-boolean v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->Qn:Z

    .line 81
    .line 82
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 83
    .line 84
    .line 85
    move-result-object v15

    .line 86
    invoke-virtual {v0, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, v14}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->setAddStatesFromChildren(Z)V

    .line 93
    .line 94
    .line 95
    new-instance v6, Landroid/widget/FrameLayout;

    .line 96
    .line 97
    invoke-direct {v6, v15}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 98
    .line 99
    .line 100
    iput-object v6, v0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 101
    .line 102
    invoke-virtual {v6, v12}, Landroid/view/ViewGroup;->setAddStatesFromChildren(Z)V

    .line 103
    .line 104
    .line 105
    sget-object v1, La/FP;->w:Landroid/view/animation/LinearInterpolator;

    .line 106
    .line 107
    iput-object v1, v13, La/W5;->r:Landroid/animation/TimeInterpolator;

    .line 108
    .line 109
    invoke-virtual {v13, v14}, La/W5;->O(Z)V

    .line 110
    .line 111
    .line 112
    iput-object v1, v13, La/W5;->o:Landroid/animation/TimeInterpolator;

    .line 113
    .line 114
    invoke-virtual {v13, v14}, La/W5;->O(Z)V

    .line 115
    .line 116
    .line 117
    iget v1, v13, La/W5;->X:I

    .line 118
    .line 119
    const v2, 0x800033

    .line 120
    .line 121
    .line 122
    if-eq v1, v2, :cond_0

    .line 123
    .line 124
    iput v2, v13, La/W5;->X:I

    .line 125
    .line 126
    invoke-virtual {v13, v14}, La/W5;->O(Z)V

    .line 127
    .line 128
    .line 129
    :cond_0
    sget-object v3, La/tS;->n:[I

    .line 130
    .line 131
    const v5, 0x7f130375

    .line 132
    .line 133
    .line 134
    const/16 v4, 0x16

    .line 135
    .line 136
    const/16 v2, 0x14

    .line 137
    .line 138
    const/16 v1, 0x28

    .line 139
    .line 140
    const/16 v14, 0x2d

    .line 141
    .line 142
    const/16 v9, 0x31

    .line 143
    .line 144
    filled-new-array {v4, v2, v1, v14, v9}, [I

    .line 145
    .line 146
    .line 147
    move-result-object v16

    .line 148
    move v14, v1

    .line 149
    move-object v1, v15

    .line 150
    move-object/from16 v2, p2

    .line 151
    .line 152
    move v4, v8

    .line 153
    move-object/from16 v18, v6

    .line 154
    .line 155
    move-object/from16 v6, v16

    .line 156
    .line 157
    invoke-static/range {v1 .. v6}, La/fe;->t(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)La/yW;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    new-instance v2, La/dX;

    .line 162
    .line 163
    invoke-direct {v2, v0, v1}, La/dX;-><init>(Lcom/google/android/material/textfield/TextInputLayout;La/yW;)V

    .line 164
    .line 165
    .line 166
    iput-object v2, v0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 167
    .line 168
    const/16 v3, 0x30

    .line 169
    .line 170
    invoke-virtual {v1, v3, v12}, La/yW;->K(IZ)Z

    .line 171
    .line 172
    .line 173
    move-result v3

    .line 174
    iput-boolean v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 175
    .line 176
    const/4 v3, 0x4

    .line 177
    invoke-virtual {v1, v3}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-virtual {v0, v3}, Lcom/google/android/material/textfield/TextInputLayout;->K(Ljava/lang/CharSequence;)V

    .line 182
    .line 183
    .line 184
    const/16 v3, 0x2f

    .line 185
    .line 186
    invoke-virtual {v1, v3, v12}, La/yW;->K(IZ)Z

    .line 187
    .line 188
    .line 189
    move-result v3

    .line 190
    iput-boolean v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->B2:Z

    .line 191
    .line 192
    const/16 v3, 0x2a

    .line 193
    .line 194
    invoke-virtual {v1, v3, v12}, La/yW;->K(IZ)Z

    .line 195
    .line 196
    .line 197
    move-result v3

    .line 198
    iput-boolean v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Ey:Z

    .line 199
    .line 200
    const/4 v3, 0x6

    .line 201
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    if-eqz v4, :cond_1

    .line 206
    .line 207
    invoke-virtual {v1, v3, v10}, La/yW;->q(II)I

    .line 208
    .line 209
    .line 210
    move-result v3

    .line 211
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->l:I

    .line 212
    .line 213
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 214
    .line 215
    if-eqz v4, :cond_2

    .line 216
    .line 217
    if-eq v3, v10, :cond_2

    .line 218
    .line 219
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setMinEms(I)V

    .line 220
    .line 221
    .line 222
    goto :goto_0

    .line 223
    :cond_1
    const/4 v3, 0x3

    .line 224
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    if-eqz v4, :cond_2

    .line 229
    .line 230
    invoke-virtual {v1, v3, v10}, La/yW;->d(II)I

    .line 231
    .line 232
    .line 233
    move-result v3

    .line 234
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->q:I

    .line 235
    .line 236
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 237
    .line 238
    if-eqz v4, :cond_2

    .line 239
    .line 240
    if-eq v3, v10, :cond_2

    .line 241
    .line 242
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 243
    .line 244
    .line 245
    :cond_2
    :goto_0
    const/4 v3, 0x5

    .line 246
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 247
    .line 248
    .line 249
    move-result v4

    .line 250
    const/4 v5, 0x2

    .line 251
    if-eqz v4, :cond_4

    .line 252
    .line 253
    invoke-virtual {v1, v3, v10}, La/yW;->q(II)I

    .line 254
    .line 255
    .line 256
    move-result v3

    .line 257
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->W:I

    .line 258
    .line 259
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 260
    .line 261
    if-eqz v4, :cond_3

    .line 262
    .line 263
    if-eq v3, v10, :cond_3

    .line 264
    .line 265
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setMaxEms(I)V

    .line 266
    .line 267
    .line 268
    :cond_3
    :goto_1
    const v3, 0x7f130375

    .line 269
    .line 270
    .line 271
    goto :goto_2

    .line 272
    :cond_4
    invoke-virtual {v1, v5}, La/yW;->z(I)Z

    .line 273
    .line 274
    .line 275
    move-result v3

    .line 276
    if-eqz v3, :cond_3

    .line 277
    .line 278
    invoke-virtual {v1, v5, v10}, La/yW;->d(II)I

    .line 279
    .line 280
    .line 281
    move-result v3

    .line 282
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->F:I

    .line 283
    .line 284
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 285
    .line 286
    if-eqz v4, :cond_3

    .line 287
    .line 288
    if-eq v3, v10, :cond_3

    .line 289
    .line 290
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setMaxWidth(I)V

    .line 291
    .line 292
    .line 293
    goto :goto_1

    .line 294
    :goto_2
    invoke-static {v15, v7, v8, v3}, La/c9;->h(Landroid/content/Context;Landroid/util/AttributeSet;II)La/as;

    .line 295
    .line 296
    .line 297
    move-result-object v3

    .line 298
    invoke-virtual {v3}, La/as;->w()La/c9;

    .line 299
    .line 300
    .line 301
    move-result-object v3

    .line 302
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 303
    .line 304
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 305
    .line 306
    .line 307
    move-result-object v3

    .line 308
    const v4, 0x7f07030c

    .line 309
    .line 310
    .line 311
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 312
    .line 313
    .line 314
    move-result v3

    .line 315
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->F9:I

    .line 316
    .line 317
    const/16 v3, 0x9

    .line 318
    .line 319
    const/4 v4, 0x0

    .line 320
    invoke-virtual {v1, v3, v4}, La/yW;->L(II)I

    .line 321
    .line 322
    .line 323
    move-result v3

    .line 324
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->mh:I

    .line 325
    .line 326
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 327
    .line 328
    .line 329
    move-result-object v3

    .line 330
    const v4, 0x7f07030d

    .line 331
    .line 332
    .line 333
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 334
    .line 335
    .line 336
    move-result v3

    .line 337
    const/16 v4, 0x10

    .line 338
    .line 339
    invoke-virtual {v1, v4, v3}, La/yW;->d(II)I

    .line 340
    .line 341
    .line 342
    move-result v3

    .line 343
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->rZ:I

    .line 344
    .line 345
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 346
    .line 347
    .line 348
    move-result-object v4

    .line 349
    const v6, 0x7f07030e

    .line 350
    .line 351
    .line 352
    invoke-virtual {v4, v6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 353
    .line 354
    .line 355
    move-result v4

    .line 356
    const/16 v6, 0x11

    .line 357
    .line 358
    invoke-virtual {v1, v6, v4}, La/yW;->d(II)I

    .line 359
    .line 360
    .line 361
    move-result v4

    .line 362
    iput v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->B1:I

    .line 363
    .line 364
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 365
    .line 366
    iget-object v3, v1, La/yW;->R:Ljava/lang/Object;

    .line 367
    .line 368
    check-cast v3, Landroid/content/res/TypedArray;

    .line 369
    .line 370
    const/16 v4, 0xd

    .line 371
    .line 372
    const/high16 v6, -0x40800000    # -1.0f

    .line 373
    .line 374
    invoke-virtual {v3, v4, v6}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 375
    .line 376
    .line 377
    move-result v3

    .line 378
    iget-object v4, v1, La/yW;->R:Ljava/lang/Object;

    .line 379
    .line 380
    check-cast v4, Landroid/content/res/TypedArray;

    .line 381
    .line 382
    const/16 v7, 0xc

    .line 383
    .line 384
    invoke-virtual {v4, v7, v6}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 385
    .line 386
    .line 387
    move-result v4

    .line 388
    iget-object v7, v1, La/yW;->R:Ljava/lang/Object;

    .line 389
    .line 390
    check-cast v7, Landroid/content/res/TypedArray;

    .line 391
    .line 392
    const/16 v8, 0xa

    .line 393
    .line 394
    invoke-virtual {v7, v8, v6}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 395
    .line 396
    .line 397
    move-result v7

    .line 398
    iget-object v8, v1, La/yW;->R:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v8, Landroid/content/res/TypedArray;

    .line 401
    .line 402
    const/16 v5, 0xb

    .line 403
    .line 404
    invoke-virtual {v8, v5, v6}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 405
    .line 406
    .line 407
    move-result v5

    .line 408
    iget-object v6, v0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 409
    .line 410
    invoke-virtual {v6}, La/c9;->Q()La/as;

    .line 411
    .line 412
    .line 413
    move-result-object v6

    .line 414
    const/4 v8, 0x0

    .line 415
    cmpl-float v16, v3, v8

    .line 416
    .line 417
    if-ltz v16, :cond_5

    .line 418
    .line 419
    new-instance v14, La/r;

    .line 420
    .line 421
    invoke-direct {v14, v3}, La/r;-><init>(F)V

    .line 422
    .line 423
    .line 424
    iput-object v14, v6, La/as;->i:La/cv;

    .line 425
    .line 426
    :cond_5
    cmpl-float v3, v4, v8

    .line 427
    .line 428
    if-ltz v3, :cond_6

    .line 429
    .line 430
    new-instance v3, La/r;

    .line 431
    .line 432
    invoke-direct {v3, v4}, La/r;-><init>(F)V

    .line 433
    .line 434
    .line 435
    iput-object v3, v6, La/as;->Q:La/cv;

    .line 436
    .line 437
    :cond_6
    cmpl-float v3, v7, v8

    .line 438
    .line 439
    if-ltz v3, :cond_7

    .line 440
    .line 441
    new-instance v3, La/r;

    .line 442
    .line 443
    invoke-direct {v3, v7}, La/r;-><init>(F)V

    .line 444
    .line 445
    .line 446
    iput-object v3, v6, La/as;->X:La/cv;

    .line 447
    .line 448
    :cond_7
    cmpl-float v3, v5, v8

    .line 449
    .line 450
    if-ltz v3, :cond_8

    .line 451
    .line 452
    new-instance v3, La/r;

    .line 453
    .line 454
    invoke-direct {v3, v5}, La/r;-><init>(F)V

    .line 455
    .line 456
    .line 457
    iput-object v3, v6, La/as;->O:La/cv;

    .line 458
    .line 459
    :cond_8
    invoke-virtual {v6}, La/as;->w()La/c9;

    .line 460
    .line 461
    .line 462
    move-result-object v3

    .line 463
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 464
    .line 465
    const/4 v3, 0x7

    .line 466
    invoke-static {v15, v1, v3}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 467
    .line 468
    .line 469
    move-result-object v3

    .line 470
    const v4, 0x101009c

    .line 471
    .line 472
    .line 473
    const v5, 0x101009e

    .line 474
    .line 475
    .line 476
    const v6, 0x1010367

    .line 477
    .line 478
    .line 479
    const v7, -0x101009e

    .line 480
    .line 481
    .line 482
    if-eqz v3, :cond_a

    .line 483
    .line 484
    invoke-virtual {v3}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 485
    .line 486
    .line 487
    move-result v14

    .line 488
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->an:I

    .line 489
    .line 490
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 491
    .line 492
    invoke-virtual {v3}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 493
    .line 494
    .line 495
    move-result v19

    .line 496
    if-eqz v19, :cond_9

    .line 497
    .line 498
    filled-new-array {v7}, [I

    .line 499
    .line 500
    .line 501
    move-result-object v14

    .line 502
    invoke-virtual {v3, v14, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 503
    .line 504
    .line 505
    move-result v14

    .line 506
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->cM:I

    .line 507
    .line 508
    filled-new-array {v4, v5}, [I

    .line 509
    .line 510
    .line 511
    move-result-object v14

    .line 512
    invoke-virtual {v3, v14, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 513
    .line 514
    .line 515
    move-result v14

    .line 516
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->N3:I

    .line 517
    .line 518
    filled-new-array {v6, v5}, [I

    .line 519
    .line 520
    .line 521
    move-result-object v14

    .line 522
    invoke-virtual {v3, v14, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 523
    .line 524
    .line 525
    move-result v3

    .line 526
    :goto_3
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->AW:I

    .line 527
    .line 528
    goto :goto_4

    .line 529
    :cond_9
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->N3:I

    .line 530
    .line 531
    const v3, 0x7f0602d6

    .line 532
    .line 533
    .line 534
    invoke-static {v15, v3}, La/hA;->h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 535
    .line 536
    .line 537
    move-result-object v3

    .line 538
    filled-new-array {v7}, [I

    .line 539
    .line 540
    .line 541
    move-result-object v14

    .line 542
    invoke-virtual {v3, v14, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 543
    .line 544
    .line 545
    move-result v14

    .line 546
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->cM:I

    .line 547
    .line 548
    filled-new-array {v6}, [I

    .line 549
    .line 550
    .line 551
    move-result-object v14

    .line 552
    invoke-virtual {v3, v14, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 553
    .line 554
    .line 555
    move-result v3

    .line 556
    goto :goto_3

    .line 557
    :cond_a
    const/4 v3, 0x0

    .line 558
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 559
    .line 560
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->an:I

    .line 561
    .line 562
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->cM:I

    .line 563
    .line 564
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->N3:I

    .line 565
    .line 566
    goto :goto_3

    .line 567
    :goto_4
    invoke-virtual {v1, v12}, La/yW;->z(I)Z

    .line 568
    .line 569
    .line 570
    move-result v3

    .line 571
    if-eqz v3, :cond_b

    .line 572
    .line 573
    invoke-virtual {v1, v12}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 574
    .line 575
    .line 576
    move-result-object v3

    .line 577
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->yd:Landroid/content/res/ColorStateList;

    .line 578
    .line 579
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 580
    .line 581
    :cond_b
    const/16 v3, 0xe

    .line 582
    .line 583
    invoke-static {v15, v1, v3}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 584
    .line 585
    .line 586
    move-result-object v14

    .line 587
    iget-object v12, v1, La/yW;->R:Ljava/lang/Object;

    .line 588
    .line 589
    check-cast v12, Landroid/content/res/TypedArray;

    .line 590
    .line 591
    const/4 v8, 0x0

    .line 592
    invoke-virtual {v12, v3, v8}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 593
    .line 594
    .line 595
    move-result v3

    .line 596
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Vm:I

    .line 597
    .line 598
    sget-object v3, La/hA;->w:Ljava/lang/Object;

    .line 599
    .line 600
    const v3, 0x7f0602f1

    .line 601
    .line 602
    .line 603
    invoke-static {v15, v3}, La/Ex;->w(Landroid/content/Context;I)I

    .line 604
    .line 605
    .line 606
    move-result v3

    .line 607
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->C6:I

    .line 608
    .line 609
    const v3, 0x7f0602f2

    .line 610
    .line 611
    .line 612
    invoke-static {v15, v3}, La/Ex;->w(Landroid/content/Context;I)I

    .line 613
    .line 614
    .line 615
    move-result v3

    .line 616
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->GI:I

    .line 617
    .line 618
    const v3, 0x7f0602f5

    .line 619
    .line 620
    .line 621
    invoke-static {v15, v3}, La/Ex;->w(Landroid/content/Context;I)I

    .line 622
    .line 623
    .line 624
    move-result v3

    .line 625
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->nA:I

    .line 626
    .line 627
    if-eqz v14, :cond_e

    .line 628
    .line 629
    invoke-virtual {v14}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 630
    .line 631
    .line 632
    move-result v3

    .line 633
    if-eqz v3, :cond_c

    .line 634
    .line 635
    invoke-virtual {v14}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 636
    .line 637
    .line 638
    move-result v3

    .line 639
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->C6:I

    .line 640
    .line 641
    filled-new-array {v7}, [I

    .line 642
    .line 643
    .line 644
    move-result-object v3

    .line 645
    invoke-virtual {v14, v3, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 646
    .line 647
    .line 648
    move-result v3

    .line 649
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->GI:I

    .line 650
    .line 651
    filled-new-array {v6, v5}, [I

    .line 652
    .line 653
    .line 654
    move-result-object v3

    .line 655
    invoke-virtual {v14, v3, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 656
    .line 657
    .line 658
    move-result v3

    .line 659
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->nA:I

    .line 660
    .line 661
    filled-new-array {v4, v5}, [I

    .line 662
    .line 663
    .line 664
    move-result-object v3

    .line 665
    invoke-virtual {v14, v3, v10}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 666
    .line 667
    .line 668
    move-result v3

    .line 669
    :goto_5
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Vm:I

    .line 670
    .line 671
    goto :goto_6

    .line 672
    :cond_c
    iget v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Vm:I

    .line 673
    .line 674
    invoke-virtual {v14}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 675
    .line 676
    .line 677
    move-result v4

    .line 678
    if-eq v3, v4, :cond_d

    .line 679
    .line 680
    invoke-virtual {v14}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 681
    .line 682
    .line 683
    move-result v3

    .line 684
    goto :goto_5

    .line 685
    :cond_d
    :goto_6
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 686
    .line 687
    .line 688
    :cond_e
    const/16 v3, 0xf

    .line 689
    .line 690
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 691
    .line 692
    .line 693
    move-result v4

    .line 694
    if-eqz v4, :cond_f

    .line 695
    .line 696
    invoke-static {v15, v1, v3}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 697
    .line 698
    .line 699
    move-result-object v3

    .line 700
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    .line 701
    .line 702
    if-eq v4, v3, :cond_f

    .line 703
    .line 704
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    .line 705
    .line 706
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 707
    .line 708
    .line 709
    :cond_f
    invoke-virtual {v1, v9, v10}, La/yW;->E(II)I

    .line 710
    .line 711
    .line 712
    move-result v3

    .line 713
    if-eq v3, v10, :cond_14

    .line 714
    .line 715
    const/4 v3, 0x0

    .line 716
    invoke-virtual {v1, v9, v3}, La/yW;->E(II)I

    .line 717
    .line 718
    .line 719
    move-result v4

    .line 720
    new-instance v3, La/fy;

    .line 721
    .line 722
    iget-object v5, v13, La/W5;->w:Landroid/view/View;

    .line 723
    .line 724
    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 725
    .line 726
    .line 727
    move-result-object v6

    .line 728
    invoke-direct {v3, v6, v4}, La/fy;-><init>(Landroid/content/Context;I)V

    .line 729
    .line 730
    .line 731
    iget-object v4, v3, La/fy;->I:Landroid/content/res/ColorStateList;

    .line 732
    .line 733
    if-eqz v4, :cond_10

    .line 734
    .line 735
    iput-object v4, v13, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 736
    .line 737
    :cond_10
    iget v4, v3, La/fy;->M:F

    .line 738
    .line 739
    const/4 v6, 0x0

    .line 740
    cmpl-float v6, v4, v6

    .line 741
    .line 742
    if-eqz v6, :cond_11

    .line 743
    .line 744
    iput v4, v13, La/W5;->V:F

    .line 745
    .line 746
    :cond_11
    iget-object v4, v3, La/fy;->w:Landroid/content/res/ColorStateList;

    .line 747
    .line 748
    if-eqz v4, :cond_12

    .line 749
    .line 750
    iput-object v4, v13, La/W5;->N:Landroid/content/res/ColorStateList;

    .line 751
    .line 752
    :cond_12
    iget v4, v3, La/fy;->i:F

    .line 753
    .line 754
    iput v4, v13, La/W5;->B:F

    .line 755
    .line 756
    iget v4, v3, La/fy;->Q:F

    .line 757
    .line 758
    iput v4, v13, La/W5;->Z:F

    .line 759
    .line 760
    iget v4, v3, La/fy;->X:F

    .line 761
    .line 762
    iput v4, v13, La/W5;->c:F

    .line 763
    .line 764
    iget v4, v3, La/fy;->V:F

    .line 765
    .line 766
    iput v4, v13, La/W5;->b:F

    .line 767
    .line 768
    iget-object v4, v13, La/W5;->S:La/qM;

    .line 769
    .line 770
    if-eqz v4, :cond_13

    .line 771
    .line 772
    const/4 v6, 0x1

    .line 773
    iput-boolean v6, v4, La/qM;->L:Z

    .line 774
    .line 775
    :cond_13
    new-instance v4, La/qM;

    .line 776
    .line 777
    new-instance v6, La/ze;

    .line 778
    .line 779
    const/16 v7, 0x1b

    .line 780
    .line 781
    invoke-direct {v6, v7, v13}, La/ze;-><init>(ILjava/lang/Object;)V

    .line 782
    .line 783
    .line 784
    invoke-virtual {v3}, La/fy;->w()V

    .line 785
    .line 786
    .line 787
    iget-object v7, v3, La/fy;->y:Landroid/graphics/Typeface;

    .line 788
    .line 789
    invoke-direct {v4, v6, v7}, La/qM;-><init>(La/ze;Landroid/graphics/Typeface;)V

    .line 790
    .line 791
    .line 792
    iput-object v4, v13, La/W5;->S:La/qM;

    .line 793
    .line 794
    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 795
    .line 796
    .line 797
    move-result-object v4

    .line 798
    iget-object v5, v13, La/W5;->S:La/qM;

    .line 799
    .line 800
    invoke-virtual {v3, v4, v5}, La/fy;->p(Landroid/content/Context;La/Yo;)V

    .line 801
    .line 802
    .line 803
    const/4 v3, 0x0

    .line 804
    invoke-virtual {v13, v3}, La/W5;->O(Z)V

    .line 805
    .line 806
    .line 807
    iget-object v4, v13, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 808
    .line 809
    iput-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->yd:Landroid/content/res/ColorStateList;

    .line 810
    .line 811
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 812
    .line 813
    if-eqz v4, :cond_14

    .line 814
    .line 815
    invoke-virtual {v0, v3, v3}, Lcom/google/android/material/textfield/TextInputLayout;->H(ZZ)V

    .line 816
    .line 817
    .line 818
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->S()V

    .line 819
    .line 820
    .line 821
    :cond_14
    const/16 v3, 0x18

    .line 822
    .line 823
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 824
    .line 825
    .line 826
    move-result-object v3

    .line 827
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->o:Landroid/content/res/ColorStateList;

    .line 828
    .line 829
    const/16 v3, 0x19

    .line 830
    .line 831
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 832
    .line 833
    .line 834
    move-result-object v3

    .line 835
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->r:Landroid/content/res/ColorStateList;

    .line 836
    .line 837
    const/4 v3, 0x0

    .line 838
    const/16 v4, 0x28

    .line 839
    .line 840
    invoke-virtual {v1, v4, v3}, La/yW;->E(II)I

    .line 841
    .line 842
    .line 843
    move-result v4

    .line 844
    const/16 v5, 0x23

    .line 845
    .line 846
    invoke-virtual {v1, v5}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 847
    .line 848
    .line 849
    move-result-object v5

    .line 850
    const/16 v6, 0x22

    .line 851
    .line 852
    const/4 v7, 0x1

    .line 853
    invoke-virtual {v1, v6, v7}, La/yW;->q(II)I

    .line 854
    .line 855
    .line 856
    move-result v6

    .line 857
    const/16 v7, 0x24

    .line 858
    .line 859
    invoke-virtual {v1, v7, v3}, La/yW;->K(IZ)Z

    .line 860
    .line 861
    .line 862
    move-result v7

    .line 863
    const/16 v8, 0x2d

    .line 864
    .line 865
    invoke-virtual {v1, v8, v3}, La/yW;->E(II)I

    .line 866
    .line 867
    .line 868
    move-result v8

    .line 869
    const/16 v9, 0x2c

    .line 870
    .line 871
    invoke-virtual {v1, v9, v3}, La/yW;->K(IZ)Z

    .line 872
    .line 873
    .line 874
    move-result v9

    .line 875
    const/16 v12, 0x2b

    .line 876
    .line 877
    invoke-virtual {v1, v12}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 878
    .line 879
    .line 880
    move-result-object v12

    .line 881
    const/16 v14, 0x39

    .line 882
    .line 883
    invoke-virtual {v1, v14, v3}, La/yW;->E(II)I

    .line 884
    .line 885
    .line 886
    move-result v14

    .line 887
    const/16 v15, 0x38

    .line 888
    .line 889
    invoke-virtual {v1, v15}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 890
    .line 891
    .line 892
    move-result-object v15

    .line 893
    const/16 v10, 0x12

    .line 894
    .line 895
    invoke-virtual {v1, v10, v3}, La/yW;->K(IZ)Z

    .line 896
    .line 897
    .line 898
    move-result v10

    .line 899
    const/16 v3, 0x13

    .line 900
    .line 901
    move-object/from16 p2, v12

    .line 902
    .line 903
    const/4 v12, -0x1

    .line 904
    invoke-virtual {v1, v3, v12}, La/yW;->q(II)I

    .line 905
    .line 906
    .line 907
    move-result v3

    .line 908
    iget v12, v0, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 909
    .line 910
    move/from16 v17, v10

    .line 911
    .line 912
    const/4 v10, 0x0

    .line 913
    if-eq v12, v3, :cond_17

    .line 914
    .line 915
    if-lez v3, :cond_15

    .line 916
    .line 917
    :goto_7
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 918
    .line 919
    goto :goto_8

    .line 920
    :cond_15
    const/4 v3, -0x1

    .line 921
    goto :goto_7

    .line 922
    :goto_8
    iget-boolean v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->S:Z

    .line 923
    .line 924
    if-eqz v3, :cond_17

    .line 925
    .line 926
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 927
    .line 928
    if-eqz v3, :cond_17

    .line 929
    .line 930
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 931
    .line 932
    if-nez v3, :cond_16

    .line 933
    .line 934
    move-object v3, v10

    .line 935
    goto :goto_9

    .line 936
    :cond_16
    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 937
    .line 938
    .line 939
    move-result-object v3

    .line 940
    :goto_9
    invoke-virtual {v0, v3}, Lcom/google/android/material/textfield/TextInputLayout;->f(Landroid/text/Editable;)V

    .line 941
    .line 942
    .line 943
    :cond_17
    const/4 v3, 0x0

    .line 944
    const/16 v12, 0x16

    .line 945
    .line 946
    invoke-virtual {v1, v12, v3}, La/yW;->E(II)I

    .line 947
    .line 948
    .line 949
    move-result v12

    .line 950
    iput v12, v0, Lcom/google/android/material/textfield/TextInputLayout;->U:I

    .line 951
    .line 952
    const/16 v12, 0x14

    .line 953
    .line 954
    invoke-virtual {v1, v12, v3}, La/yW;->E(II)I

    .line 955
    .line 956
    .line 957
    move-result v12

    .line 958
    iput v12, v0, Lcom/google/android/material/textfield/TextInputLayout;->u:I

    .line 959
    .line 960
    const/16 v12, 0x8

    .line 961
    .line 962
    invoke-virtual {v1, v12, v3}, La/yW;->q(II)I

    .line 963
    .line 964
    .line 965
    move-result v12

    .line 966
    iget v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 967
    .line 968
    if-ne v12, v3, :cond_18

    .line 969
    .line 970
    goto :goto_a

    .line 971
    :cond_18
    iput v12, v0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 972
    .line 973
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 974
    .line 975
    if-eqz v3, :cond_19

    .line 976
    .line 977
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->V()V

    .line 978
    .line 979
    .line 980
    :cond_19
    :goto_a
    iput-object v5, v11, La/A7;->f:Ljava/lang/CharSequence;

    .line 981
    .line 982
    iget-object v3, v11, La/A7;->d:La/c8;

    .line 983
    .line 984
    if-eqz v3, :cond_1a

    .line 985
    .line 986
    invoke-virtual {v3, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 987
    .line 988
    .line 989
    :cond_1a
    iput v6, v11, La/A7;->l:I

    .line 990
    .line 991
    iget-object v3, v11, La/A7;->d:La/c8;

    .line 992
    .line 993
    if-eqz v3, :cond_1b

    .line 994
    .line 995
    sget-object v5, La/sI;->w:Ljava/util/WeakHashMap;

    .line 996
    .line 997
    invoke-static {v3, v6}, La/AM;->Q(Landroid/view/View;I)V

    .line 998
    .line 999
    .line 1000
    :cond_1b
    iput v8, v11, La/A7;->H:I

    .line 1001
    .line 1002
    iget-object v3, v11, La/A7;->S:La/c8;

    .line 1003
    .line 1004
    if-eqz v3, :cond_1c

    .line 1005
    .line 1006
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 1007
    .line 1008
    .line 1009
    :cond_1c
    iput v4, v11, La/A7;->W:I

    .line 1010
    .line 1011
    iget-object v3, v11, La/A7;->d:La/c8;

    .line 1012
    .line 1013
    if-eqz v3, :cond_1d

    .line 1014
    .line 1015
    iget-object v5, v11, La/A7;->O:Lcom/google/android/material/textfield/TextInputLayout;

    .line 1016
    .line 1017
    invoke-virtual {v5, v3, v4}, Lcom/google/android/material/textfield/TextInputLayout;->L(Landroid/widget/TextView;I)V

    .line 1018
    .line 1019
    .line 1020
    :cond_1d
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1021
    .line 1022
    if-nez v3, :cond_1e

    .line 1023
    .line 1024
    new-instance v3, La/c8;

    .line 1025
    .line 1026
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1027
    .line 1028
    .line 1029
    move-result-object v4

    .line 1030
    invoke-direct {v3, v4, v10}, La/c8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 1031
    .line 1032
    .line 1033
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1034
    .line 1035
    const v4, 0x7f09025f

    .line 1036
    .line 1037
    .line 1038
    invoke-virtual {v3, v4}, Landroid/view/View;->setId(I)V

    .line 1039
    .line 1040
    .line 1041
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1042
    .line 1043
    const/4 v4, 0x2

    .line 1044
    invoke-static {v3, v4}, La/Tl;->f(Landroid/view/View;I)V

    .line 1045
    .line 1046
    .line 1047
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->e()La/KF;

    .line 1048
    .line 1049
    .line 1050
    move-result-object v3

    .line 1051
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->n:La/KF;

    .line 1052
    .line 1053
    const-wide/16 v4, 0x43

    .line 1054
    .line 1055
    iput-wide v4, v3, La/SB;->K:J

    .line 1056
    .line 1057
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->e()La/KF;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v3

    .line 1061
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->C:La/KF;

    .line 1062
    .line 1063
    iget v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->t:I

    .line 1064
    .line 1065
    iput v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->t:I

    .line 1066
    .line 1067
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1068
    .line 1069
    if-eqz v4, :cond_1e

    .line 1070
    .line 1071
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 1072
    .line 1073
    .line 1074
    :cond_1e
    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1075
    .line 1076
    .line 1077
    move-result v3

    .line 1078
    if-eqz v3, :cond_1f

    .line 1079
    .line 1080
    const/4 v3, 0x0

    .line 1081
    invoke-virtual {v0, v3}, Lcom/google/android/material/textfield/TextInputLayout;->R(Z)V

    .line 1082
    .line 1083
    .line 1084
    goto :goto_b

    .line 1085
    :cond_1f
    iget-boolean v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 1086
    .line 1087
    if-nez v3, :cond_20

    .line 1088
    .line 1089
    const/4 v3, 0x1

    .line 1090
    invoke-virtual {v0, v3}, Lcom/google/android/material/textfield/TextInputLayout;->R(Z)V

    .line 1091
    .line 1092
    .line 1093
    :cond_20
    iput-object v15, v0, Lcom/google/android/material/textfield/TextInputLayout;->k:Ljava/lang/CharSequence;

    .line 1094
    .line 1095
    :goto_b
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 1096
    .line 1097
    if-nez v3, :cond_21

    .line 1098
    .line 1099
    move-object v3, v10

    .line 1100
    goto :goto_c

    .line 1101
    :cond_21
    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 1102
    .line 1103
    .line 1104
    move-result-object v3

    .line 1105
    :goto_c
    invoke-virtual {v0, v3}, Lcom/google/android/material/textfield/TextInputLayout;->z(Landroid/text/Editable;)V

    .line 1106
    .line 1107
    .line 1108
    iput v14, v0, Lcom/google/android/material/textfield/TextInputLayout;->t:I

    .line 1109
    .line 1110
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1111
    .line 1112
    if-eqz v3, :cond_22

    .line 1113
    .line 1114
    invoke-virtual {v3, v14}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 1115
    .line 1116
    .line 1117
    :cond_22
    const/16 v3, 0x29

    .line 1118
    .line 1119
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1120
    .line 1121
    .line 1122
    move-result v4

    .line 1123
    if-eqz v4, :cond_23

    .line 1124
    .line 1125
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1126
    .line 1127
    .line 1128
    move-result-object v3

    .line 1129
    iput-object v3, v11, La/A7;->q:Landroid/content/res/ColorStateList;

    .line 1130
    .line 1131
    iget-object v4, v11, La/A7;->d:La/c8;

    .line 1132
    .line 1133
    if-eqz v4, :cond_23

    .line 1134
    .line 1135
    if-eqz v3, :cond_23

    .line 1136
    .line 1137
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 1138
    .line 1139
    .line 1140
    :cond_23
    const/16 v3, 0x2e

    .line 1141
    .line 1142
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1143
    .line 1144
    .line 1145
    move-result v4

    .line 1146
    if-eqz v4, :cond_24

    .line 1147
    .line 1148
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1149
    .line 1150
    .line 1151
    move-result-object v3

    .line 1152
    iput-object v3, v11, La/A7;->z:Landroid/content/res/ColorStateList;

    .line 1153
    .line 1154
    iget-object v4, v11, La/A7;->S:La/c8;

    .line 1155
    .line 1156
    if-eqz v4, :cond_24

    .line 1157
    .line 1158
    if-eqz v3, :cond_24

    .line 1159
    .line 1160
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 1161
    .line 1162
    .line 1163
    :cond_24
    const/16 v3, 0x32

    .line 1164
    .line 1165
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1166
    .line 1167
    .line 1168
    move-result v4

    .line 1169
    if-eqz v4, :cond_26

    .line 1170
    .line 1171
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1172
    .line 1173
    .line 1174
    move-result-object v3

    .line 1175
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->yd:Landroid/content/res/ColorStateList;

    .line 1176
    .line 1177
    if-eq v4, v3, :cond_26

    .line 1178
    .line 1179
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 1180
    .line 1181
    if-nez v4, :cond_25

    .line 1182
    .line 1183
    iget-object v4, v13, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 1184
    .line 1185
    if-eq v4, v3, :cond_25

    .line 1186
    .line 1187
    iput-object v3, v13, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 1188
    .line 1189
    const/4 v4, 0x0

    .line 1190
    invoke-virtual {v13, v4}, La/W5;->O(Z)V

    .line 1191
    .line 1192
    .line 1193
    goto :goto_d

    .line 1194
    :cond_25
    const/4 v4, 0x0

    .line 1195
    :goto_d
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->yd:Landroid/content/res/ColorStateList;

    .line 1196
    .line 1197
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 1198
    .line 1199
    if-eqz v3, :cond_26

    .line 1200
    .line 1201
    invoke-virtual {v0, v4, v4}, Lcom/google/android/material/textfield/TextInputLayout;->H(ZZ)V

    .line 1202
    .line 1203
    .line 1204
    :cond_26
    const/16 v3, 0x17

    .line 1205
    .line 1206
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1207
    .line 1208
    .line 1209
    move-result v4

    .line 1210
    if-eqz v4, :cond_27

    .line 1211
    .line 1212
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v3

    .line 1216
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->x:Landroid/content/res/ColorStateList;

    .line 1217
    .line 1218
    if-eq v4, v3, :cond_27

    .line 1219
    .line 1220
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->x:Landroid/content/res/ColorStateList;

    .line 1221
    .line 1222
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->l()V

    .line 1223
    .line 1224
    .line 1225
    :cond_27
    const/16 v3, 0x15

    .line 1226
    .line 1227
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1228
    .line 1229
    .line 1230
    move-result v4

    .line 1231
    if-eqz v4, :cond_28

    .line 1232
    .line 1233
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1234
    .line 1235
    .line 1236
    move-result-object v3

    .line 1237
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->g:Landroid/content/res/ColorStateList;

    .line 1238
    .line 1239
    if-eq v4, v3, :cond_28

    .line 1240
    .line 1241
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->g:Landroid/content/res/ColorStateList;

    .line 1242
    .line 1243
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->l()V

    .line 1244
    .line 1245
    .line 1246
    :cond_28
    const/16 v3, 0x3a

    .line 1247
    .line 1248
    invoke-virtual {v1, v3}, La/yW;->z(I)Z

    .line 1249
    .line 1250
    .line 1251
    move-result v4

    .line 1252
    if-eqz v4, :cond_29

    .line 1253
    .line 1254
    invoke-virtual {v1, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 1255
    .line 1256
    .line 1257
    move-result-object v3

    .line 1258
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->j:Landroid/content/res/ColorStateList;

    .line 1259
    .line 1260
    if-eq v4, v3, :cond_29

    .line 1261
    .line 1262
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->j:Landroid/content/res/ColorStateList;

    .line 1263
    .line 1264
    iget-object v4, v0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 1265
    .line 1266
    if-eqz v4, :cond_29

    .line 1267
    .line 1268
    if-eqz v3, :cond_29

    .line 1269
    .line 1270
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 1271
    .line 1272
    .line 1273
    :cond_29
    new-instance v3, La/h9;

    .line 1274
    .line 1275
    invoke-direct {v3, v0, v1}, La/h9;-><init>(Lcom/google/android/material/textfield/TextInputLayout;La/yW;)V

    .line 1276
    .line 1277
    .line 1278
    iput-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 1279
    .line 1280
    const/4 v4, 0x1

    .line 1281
    const/4 v5, 0x0

    .line 1282
    invoke-virtual {v1, v5, v4}, La/yW;->K(IZ)Z

    .line 1283
    .line 1284
    .line 1285
    move-result v6

    .line 1286
    invoke-virtual {v1}, La/yW;->Y()V

    .line 1287
    .line 1288
    .line 1289
    const/4 v1, 0x2

    .line 1290
    invoke-static {v0, v1}, La/Tl;->f(Landroid/view/View;I)V

    .line 1291
    .line 1292
    .line 1293
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1294
    .line 1295
    const/16 v5, 0x1a

    .line 1296
    .line 1297
    if-lt v1, v5, :cond_2a

    .line 1298
    .line 1299
    if-lt v1, v5, :cond_2a

    .line 1300
    .line 1301
    invoke-static {v0, v4}, La/yO;->m(Landroid/view/View;I)V

    .line 1302
    .line 1303
    .line 1304
    :cond_2a
    move-object/from16 v1, v18

    .line 1305
    .line 1306
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1307
    .line 1308
    .line 1309
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1310
    .line 1311
    .line 1312
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1313
    .line 1314
    .line 1315
    invoke-virtual {v0, v6}, Lcom/google/android/material/textfield/TextInputLayout;->setEnabled(Z)V

    .line 1316
    .line 1317
    .line 1318
    invoke-virtual {v0, v9}, Lcom/google/android/material/textfield/TextInputLayout;->y(Z)V

    .line 1319
    .line 1320
    .line 1321
    invoke-virtual {v0, v7}, Lcom/google/android/material/textfield/TextInputLayout;->m(Z)V

    .line 1322
    .line 1323
    .line 1324
    iget-boolean v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->S:Z

    .line 1325
    .line 1326
    move/from16 v2, v17

    .line 1327
    .line 1328
    if-eq v1, v2, :cond_2e

    .line 1329
    .line 1330
    if-eqz v2, :cond_2c

    .line 1331
    .line 1332
    new-instance v1, La/c8;

    .line 1333
    .line 1334
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1335
    .line 1336
    .line 1337
    move-result-object v3

    .line 1338
    invoke-direct {v1, v3, v10}, La/c8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 1339
    .line 1340
    .line 1341
    iput-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1342
    .line 1343
    const v3, 0x7f09025c

    .line 1344
    .line 1345
    .line 1346
    invoke-virtual {v1, v3}, Landroid/view/View;->setId(I)V

    .line 1347
    .line 1348
    .line 1349
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1350
    .line 1351
    const/4 v3, 0x1

    .line 1352
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1353
    .line 1354
    .line 1355
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1356
    .line 1357
    const/4 v3, 0x2

    .line 1358
    invoke-virtual {v11, v1, v3}, La/A7;->w(Landroid/widget/TextView;I)V

    .line 1359
    .line 1360
    .line 1361
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1362
    .line 1363
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1364
    .line 1365
    .line 1366
    move-result-object v1

    .line 1367
    check-cast v1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 1368
    .line 1369
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 1370
    .line 1371
    .line 1372
    move-result-object v3

    .line 1373
    const v4, 0x7f07030f

    .line 1374
    .line 1375
    .line 1376
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 1377
    .line 1378
    .line 1379
    move-result v3

    .line 1380
    invoke-static {v1, v3}, La/WK;->O(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 1381
    .line 1382
    .line 1383
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/textfield/TextInputLayout;->l()V

    .line 1384
    .line 1385
    .line 1386
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1387
    .line 1388
    if-eqz v1, :cond_2d

    .line 1389
    .line 1390
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 1391
    .line 1392
    if-nez v1, :cond_2b

    .line 1393
    .line 1394
    goto :goto_e

    .line 1395
    :cond_2b
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 1396
    .line 1397
    .line 1398
    move-result-object v10

    .line 1399
    :goto_e
    invoke-virtual {v0, v10}, Lcom/google/android/material/textfield/TextInputLayout;->f(Landroid/text/Editable;)V

    .line 1400
    .line 1401
    .line 1402
    goto :goto_f

    .line 1403
    :cond_2c
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1404
    .line 1405
    const/4 v3, 0x2

    .line 1406
    invoke-virtual {v11, v1, v3}, La/A7;->X(Landroid/widget/TextView;I)V

    .line 1407
    .line 1408
    .line 1409
    iput-object v10, v0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 1410
    .line 1411
    :cond_2d
    :goto_f
    iput-boolean v2, v0, Lcom/google/android/material/textfield/TextInputLayout;->S:Z

    .line 1412
    .line 1413
    :cond_2e
    invoke-static/range {p2 .. p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1414
    .line 1415
    .line 1416
    move-result v1

    .line 1417
    if-eqz v1, :cond_2f

    .line 1418
    .line 1419
    iget-boolean v1, v11, La/A7;->E:Z

    .line 1420
    .line 1421
    if-eqz v1, :cond_32

    .line 1422
    .line 1423
    const/4 v1, 0x0

    .line 1424
    invoke-virtual {v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->y(Z)V

    .line 1425
    .line 1426
    .line 1427
    goto :goto_10

    .line 1428
    :cond_2f
    iget-boolean v1, v11, La/A7;->E:Z

    .line 1429
    .line 1430
    if-nez v1, :cond_30

    .line 1431
    .line 1432
    const/4 v1, 0x1

    .line 1433
    invoke-virtual {v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->y(Z)V

    .line 1434
    .line 1435
    .line 1436
    :cond_30
    invoke-virtual {v11}, La/A7;->p()V

    .line 1437
    .line 1438
    .line 1439
    move-object/from16 v1, p2

    .line 1440
    .line 1441
    iput-object v1, v11, La/A7;->F:Ljava/lang/CharSequence;

    .line 1442
    .line 1443
    iget-object v2, v11, La/A7;->S:La/c8;

    .line 1444
    .line 1445
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1446
    .line 1447
    .line 1448
    iget v2, v11, La/A7;->y:I

    .line 1449
    .line 1450
    const/4 v3, 0x2

    .line 1451
    if-eq v2, v3, :cond_31

    .line 1452
    .line 1453
    iput v3, v11, La/A7;->K:I

    .line 1454
    .line 1455
    :cond_31
    iget v3, v11, La/A7;->K:I

    .line 1456
    .line 1457
    iget-object v4, v11, La/A7;->S:La/c8;

    .line 1458
    .line 1459
    invoke-virtual {v11, v4, v1}, La/A7;->O(Landroid/widget/TextView;Ljava/lang/CharSequence;)Z

    .line 1460
    .line 1461
    .line 1462
    move-result v1

    .line 1463
    invoke-virtual {v11, v2, v3, v1}, La/A7;->V(IIZ)V

    .line 1464
    .line 1465
    .line 1466
    :cond_32
    :goto_10
    return-void
.end method

.method public static M(Landroid/view/ViewGroup;Z)V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/view/View;->setEnabled(Z)V

    instance-of v3, v2, Landroid/view/ViewGroup;

    if-eqz v3, :cond_0

    check-cast v2, Landroid/view/ViewGroup;

    invoke-static {v2, p1}, Lcom/google/android/material/textfield/TextInputLayout;->M(Landroid/view/ViewGroup;Z)V

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method


# virtual methods
.method public final D()V
    .locals 8

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 2
    .line 3
    if-eqz v0, :cond_18

    .line 4
    .line 5
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    goto/16 :goto_9

    .line 10
    .line 11
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->isFocused()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x0

    .line 16
    const/4 v2, 0x1

    .line 17
    if-nez v0, :cond_2

    .line 18
    .line 19
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    move v0, v1

    .line 31
    goto :goto_1

    .line 32
    :cond_2
    :goto_0
    move v0, v2

    .line 33
    :goto_1
    invoke-virtual {p0}, Landroid/view/View;->isHovered()Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-nez v3, :cond_3

    .line 38
    .line 39
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 40
    .line 41
    if-eqz v3, :cond_4

    .line 42
    .line 43
    invoke-virtual {v3}, Landroid/view/View;->isHovered()Z

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    if-eqz v3, :cond_4

    .line 48
    .line 49
    :cond_3
    move v1, v2

    .line 50
    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    const/4 v4, -0x1

    .line 55
    if-nez v3, :cond_5

    .line 56
    .line 57
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->GI:I

    .line 58
    .line 59
    iput v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 60
    .line 61
    goto :goto_3

    .line 62
    :cond_5
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    if-eqz v3, :cond_8

    .line 67
    .line 68
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    .line 69
    .line 70
    if-eqz v3, :cond_6

    .line 71
    .line 72
    invoke-virtual {p0, v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->P(ZZ)V

    .line 73
    .line 74
    .line 75
    goto :goto_3

    .line 76
    :cond_6
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 77
    .line 78
    iget-object v3, v3, La/A7;->d:La/c8;

    .line 79
    .line 80
    if-eqz v3, :cond_7

    .line 81
    .line 82
    invoke-virtual {v3}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    goto :goto_2

    .line 87
    :cond_7
    move v3, v4

    .line 88
    :goto_2
    iput v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 89
    .line 90
    goto :goto_3

    .line 91
    :cond_8
    iget-boolean v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 92
    .line 93
    if-eqz v3, :cond_a

    .line 94
    .line 95
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 96
    .line 97
    if-eqz v3, :cond_a

    .line 98
    .line 99
    iget-object v5, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    .line 100
    .line 101
    if-eqz v5, :cond_9

    .line 102
    .line 103
    invoke-virtual {p0, v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->P(ZZ)V

    .line 104
    .line 105
    .line 106
    goto :goto_3

    .line 107
    :cond_9
    invoke-virtual {v3}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    goto :goto_2

    .line 112
    :cond_a
    if-eqz v0, :cond_b

    .line 113
    .line 114
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vm:I

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_b
    if-eqz v1, :cond_c

    .line 118
    .line 119
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->nA:I

    .line 120
    .line 121
    goto :goto_2

    .line 122
    :cond_c
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->C6:I

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :goto_3
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 126
    .line 127
    const/16 v5, 0x1d

    .line 128
    .line 129
    if-lt v3, v5, :cond_d

    .line 130
    .line 131
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->W()V

    .line 132
    .line 133
    .line 134
    :cond_d
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 135
    .line 136
    invoke-virtual {v3}, La/h9;->M()V

    .line 137
    .line 138
    .line 139
    iget-object v5, v3, La/h9;->d:Landroid/content/res/ColorStateList;

    .line 140
    .line 141
    iget-object v6, v3, La/h9;->L:Lcom/google/android/material/internal/CheckableImageButton;

    .line 142
    .line 143
    iget-object v7, v3, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 144
    .line 145
    invoke-static {v7, v6, v5}, La/rx;->NE(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    .line 146
    .line 147
    .line 148
    iget-object v5, v3, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 149
    .line 150
    iget-object v6, v3, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 151
    .line 152
    invoke-static {v7, v6, v5}, La/rx;->NE(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v3}, La/h9;->h()La/sb;

    .line 156
    .line 157
    .line 158
    move-result-object v5

    .line 159
    instance-of v5, v5, La/P0;

    .line 160
    .line 161
    if-eqz v5, :cond_10

    .line 162
    .line 163
    invoke-virtual {v7}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    if-eqz v5, :cond_f

    .line 168
    .line 169
    invoke-virtual {v6}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 170
    .line 171
    .line 172
    move-result-object v5

    .line 173
    if-eqz v5, :cond_f

    .line 174
    .line 175
    invoke-virtual {v6}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    iget-object v5, v7, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 184
    .line 185
    iget-object v5, v5, La/A7;->d:La/c8;

    .line 186
    .line 187
    if-eqz v5, :cond_e

    .line 188
    .line 189
    invoke-virtual {v5}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 190
    .line 191
    .line 192
    move-result v4

    .line 193
    :cond_e
    invoke-static {v3, v4}, La/YU;->X(Landroid/graphics/drawable/Drawable;I)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v6, v3}, La/CN;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 197
    .line 198
    .line 199
    goto :goto_4

    .line 200
    :cond_f
    iget-object v4, v3, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 201
    .line 202
    iget-object v3, v3, La/h9;->S:Landroid/graphics/PorterDuff$Mode;

    .line 203
    .line 204
    invoke-static {v7, v6, v4, v3}, La/rx;->O(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)V

    .line 205
    .line 206
    .line 207
    :cond_10
    :goto_4
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 208
    .line 209
    iget-object v4, v3, La/dX;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 210
    .line 211
    iget-object v5, v3, La/dX;->f:Landroid/content/res/ColorStateList;

    .line 212
    .line 213
    iget-object v3, v3, La/dX;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 214
    .line 215
    invoke-static {v3, v4, v5}, La/rx;->NE(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    .line 216
    .line 217
    .line 218
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 219
    .line 220
    const/4 v4, 0x2

    .line 221
    if-ne v3, v4, :cond_13

    .line 222
    .line 223
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 224
    .line 225
    if-eqz v0, :cond_11

    .line 226
    .line 227
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 228
    .line 229
    .line 230
    move-result v4

    .line 231
    if-eqz v4, :cond_11

    .line 232
    .line 233
    iget v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->B1:I

    .line 234
    .line 235
    :goto_5
    iput v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 236
    .line 237
    goto :goto_6

    .line 238
    :cond_11
    iget v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->rZ:I

    .line 239
    .line 240
    goto :goto_5

    .line 241
    :goto_6
    iget v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 242
    .line 243
    if-eq v4, v3, :cond_13

    .line 244
    .line 245
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 246
    .line 247
    .line 248
    move-result v3

    .line 249
    if-eqz v3, :cond_13

    .line 250
    .line 251
    iget-boolean v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 252
    .line 253
    if-nez v3, :cond_13

    .line 254
    .line 255
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 256
    .line 257
    .line 258
    move-result v3

    .line 259
    if-eqz v3, :cond_12

    .line 260
    .line 261
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 262
    .line 263
    check-cast v3, La/GP;

    .line 264
    .line 265
    const/4 v4, 0x0

    .line 266
    invoke-virtual {v3, v4, v4, v4, v4}, La/GP;->l(FFFF)V

    .line 267
    .line 268
    .line 269
    :cond_12
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->I()V

    .line 270
    .line 271
    .line 272
    :cond_13
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 273
    .line 274
    if-ne v3, v2, :cond_17

    .line 275
    .line 276
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 277
    .line 278
    .line 279
    move-result v2

    .line 280
    if-nez v2, :cond_14

    .line 281
    .line 282
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->cM:I

    .line 283
    .line 284
    :goto_7
    iput v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 285
    .line 286
    goto :goto_8

    .line 287
    :cond_14
    if-eqz v1, :cond_15

    .line 288
    .line 289
    if-nez v0, :cond_15

    .line 290
    .line 291
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->AW:I

    .line 292
    .line 293
    goto :goto_7

    .line 294
    :cond_15
    if-eqz v0, :cond_16

    .line 295
    .line 296
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->N3:I

    .line 297
    .line 298
    goto :goto_7

    .line 299
    :cond_16
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->an:I

    .line 300
    .line 301
    goto :goto_7

    .line 302
    :cond_17
    :goto_8
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->h()V

    .line 303
    .line 304
    .line 305
    :cond_18
    :goto_9
    return-void
.end method

.method public final E()V
    .locals 10

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 6
    .line 7
    if-eqz v1, :cond_7

    .line 8
    .line 9
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Pc:Z

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-nez v0, :cond_7

    .line 18
    .line 19
    :cond_0
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 20
    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    goto/16 :goto_3

    .line 24
    .line 25
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 26
    .line 27
    instance-of v1, v0, Landroid/widget/AutoCompleteTextView;

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_6

    .line 31
    .line 32
    invoke-virtual {v0}, Landroid/widget/TextView;->getInputType()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_2

    .line 37
    .line 38
    goto/16 :goto_1

    .line 39
    .line 40
    :cond_2
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 41
    .line 42
    const v1, 0x7f040101

    .line 43
    .line 44
    .line 45
    invoke-static {v0, v1}, La/rE;->o(Landroid/view/View;I)I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 50
    .line 51
    sget-object v3, Lcom/google/android/material/textfield/TextInputLayout;->Pi:[[I

    .line 52
    .line 53
    const v4, 0x3dcccccd    # 0.1f

    .line 54
    .line 55
    .line 56
    const/4 v5, 0x2

    .line 57
    if-ne v1, v5, :cond_4

    .line 58
    .line 59
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    iget-object v6, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 64
    .line 65
    const v7, 0x7f04012d

    .line 66
    .line 67
    .line 68
    const-string v8, "TextInputLayout"

    .line 69
    .line 70
    invoke-static {v7, v1, v8}, La/rE;->Ey(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    iget v8, v7, Landroid/util/TypedValue;->resourceId:I

    .line 75
    .line 76
    if-eqz v8, :cond_3

    .line 77
    .line 78
    sget-object v7, La/hA;->w:Ljava/lang/Object;

    .line 79
    .line 80
    invoke-static {v1, v8}, La/Ex;->w(Landroid/content/Context;I)I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    iget v1, v7, Landroid/util/TypedValue;->data:I

    .line 86
    .line 87
    :goto_0
    new-instance v7, La/ex;

    .line 88
    .line 89
    iget-object v8, v6, La/ex;->X:La/JP;

    .line 90
    .line 91
    iget-object v8, v8, La/JP;->w:La/c9;

    .line 92
    .line 93
    invoke-direct {v7, v8}, La/ex;-><init>(La/c9;)V

    .line 94
    .line 95
    .line 96
    invoke-static {v0, v1, v4}, La/rE;->Gy(IIF)I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    const/4 v4, 0x0

    .line 101
    filled-new-array {v0, v4}, [I

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    new-instance v9, Landroid/content/res/ColorStateList;

    .line 106
    .line 107
    invoke-direct {v9, v3, v8}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v7, v9}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v7, v1}, La/ex;->setTint(I)V

    .line 114
    .line 115
    .line 116
    filled-new-array {v0, v1}, [I

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    new-instance v1, Landroid/content/res/ColorStateList;

    .line 121
    .line 122
    invoke-direct {v1, v3, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 123
    .line 124
    .line 125
    new-instance v0, La/ex;

    .line 126
    .line 127
    iget-object v3, v6, La/ex;->X:La/JP;

    .line 128
    .line 129
    iget-object v3, v3, La/JP;->w:La/c9;

    .line 130
    .line 131
    invoke-direct {v0, v3}, La/ex;-><init>(La/c9;)V

    .line 132
    .line 133
    .line 134
    const/4 v3, -0x1

    .line 135
    invoke-virtual {v0, v3}, La/ex;->setTint(I)V

    .line 136
    .line 137
    .line 138
    new-instance v3, Landroid/graphics/drawable/RippleDrawable;

    .line 139
    .line 140
    invoke-direct {v3, v1, v7, v0}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 141
    .line 142
    .line 143
    new-array v0, v5, [Landroid/graphics/drawable/Drawable;

    .line 144
    .line 145
    aput-object v3, v0, v4

    .line 146
    .line 147
    aput-object v6, v0, v2

    .line 148
    .line 149
    new-instance v1, Landroid/graphics/drawable/LayerDrawable;

    .line 150
    .line 151
    invoke-direct {v1, v0}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 152
    .line 153
    .line 154
    goto :goto_2

    .line 155
    :cond_4
    if-ne v1, v2, :cond_5

    .line 156
    .line 157
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 158
    .line 159
    iget v5, p0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 160
    .line 161
    invoke-static {v0, v5, v4}, La/rE;->Gy(IIF)I

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    filled-new-array {v0, v5}, [I

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    new-instance v4, Landroid/content/res/ColorStateList;

    .line 170
    .line 171
    invoke-direct {v4, v3, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 172
    .line 173
    .line 174
    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    .line 175
    .line 176
    invoke-direct {v0, v4, v1, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 177
    .line 178
    .line 179
    move-object v1, v0

    .line 180
    goto :goto_2

    .line 181
    :cond_5
    const/4 v1, 0x0

    .line 182
    goto :goto_2

    .line 183
    :cond_6
    :goto_1
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 184
    .line 185
    :goto_2
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 186
    .line 187
    sget-object v3, La/sI;->w:Ljava/util/WeakHashMap;

    .line 188
    .line 189
    invoke-static {v0, v1}, La/Tl;->L(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 190
    .line 191
    .line 192
    iput-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Pc:Z

    .line 193
    .line 194
    :cond_7
    :goto_3
    return-void
.end method

.method public final F()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    goto :goto_1

    .line 10
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    return-void

    .line 17
    :cond_1
    sget-object v1, La/iR;->w:[I

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_3

    .line 28
    .line 29
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 30
    .line 31
    iget-object v1, v1, La/A7;->d:La/c8;

    .line 32
    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    invoke-virtual {v1}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    goto :goto_0

    .line 40
    :cond_2
    const/4 v1, -0x1

    .line 41
    :goto_0
    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 42
    .line 43
    invoke-static {v1, v2}, La/gJ;->p(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 48
    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_3
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 52
    .line 53
    if-eqz v1, :cond_4

    .line 54
    .line 55
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 56
    .line 57
    if-eqz v1, :cond_4

    .line 58
    .line 59
    invoke-virtual {v1}, Landroid/widget/TextView;->getCurrentTextColor()I

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    goto :goto_0

    .line 64
    :cond_4
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    .line 65
    .line 66
    .line 67
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 68
    .line 69
    invoke-virtual {v0}, Landroid/view/View;->refreshDrawableState()V

    .line 70
    .line 71
    .line 72
    :cond_5
    :goto_1
    return-void
.end method

.method public final H(ZZ)V
    .locals 9

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    move v1, v3

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    move v1, v2

    .line 24
    :goto_0
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 25
    .line 26
    if-eqz v4, :cond_1

    .line 27
    .line 28
    invoke-virtual {v4}, Landroid/view/View;->hasFocus()Z

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_1

    .line 33
    .line 34
    move v4, v3

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    move v4, v2

    .line 37
    :goto_1
    iget-object v5, p0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 38
    .line 39
    iget-object v6, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 40
    .line 41
    if-eqz v5, :cond_2

    .line 42
    .line 43
    invoke-virtual {v6, v5}, La/W5;->V(Landroid/content/res/ColorStateList;)V

    .line 44
    .line 45
    .line 46
    :cond_2
    const/4 v5, 0x0

    .line 47
    if-nez v0, :cond_4

    .line 48
    .line 49
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 50
    .line 51
    if-eqz v0, :cond_3

    .line 52
    .line 53
    const v7, -0x101009e

    .line 54
    .line 55
    .line 56
    filled-new-array {v7}, [I

    .line 57
    .line 58
    .line 59
    move-result-object v7

    .line 60
    iget v8, p0, Lcom/google/android/material/textfield/TextInputLayout;->GI:I

    .line 61
    .line 62
    invoke-virtual {v0, v7, v8}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    goto :goto_2

    .line 67
    :cond_3
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->GI:I

    .line 68
    .line 69
    :goto_2
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v6, v0}, La/W5;->V(Landroid/content/res/ColorStateList;)V

    .line 74
    .line 75
    .line 76
    goto :goto_4

    .line 77
    :cond_4
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_6

    .line 82
    .line 83
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 84
    .line 85
    iget-object v0, v0, La/A7;->d:La/c8;

    .line 86
    .line 87
    if-eqz v0, :cond_5

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    goto :goto_3

    .line 94
    :cond_5
    move-object v0, v5

    .line 95
    :goto_3
    invoke-virtual {v6, v0}, La/W5;->V(Landroid/content/res/ColorStateList;)V

    .line 96
    .line 97
    .line 98
    goto :goto_4

    .line 99
    :cond_6
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 100
    .line 101
    if-eqz v0, :cond_7

    .line 102
    .line 103
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 104
    .line 105
    if-eqz v0, :cond_7

    .line 106
    .line 107
    invoke-virtual {v0}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    goto :goto_3

    .line 112
    :cond_7
    if-eqz v4, :cond_8

    .line 113
    .line 114
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->yd:Landroid/content/res/ColorStateList;

    .line 115
    .line 116
    if-eqz v0, :cond_8

    .line 117
    .line 118
    iget-object v7, v6, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 119
    .line 120
    if-eq v7, v0, :cond_8

    .line 121
    .line 122
    iput-object v0, v6, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 123
    .line 124
    invoke-virtual {v6, v2}, La/W5;->O(Z)V

    .line 125
    .line 126
    .line 127
    :cond_8
    :goto_4
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->B2:Z

    .line 128
    .line 129
    iget-object v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 130
    .line 131
    iget-object v8, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 132
    .line 133
    if-nez v1, :cond_f

    .line 134
    .line 135
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Ey:Z

    .line 136
    .line 137
    if-eqz v1, :cond_f

    .line 138
    .line 139
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-eqz v1, :cond_9

    .line 144
    .line 145
    if-eqz v4, :cond_9

    .line 146
    .line 147
    goto :goto_6

    .line 148
    :cond_9
    if-nez p2, :cond_a

    .line 149
    .line 150
    iget-boolean p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 151
    .line 152
    if-nez p2, :cond_15

    .line 153
    .line 154
    :cond_a
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 155
    .line 156
    if-eqz p2, :cond_b

    .line 157
    .line 158
    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->isRunning()Z

    .line 159
    .line 160
    .line 161
    move-result p2

    .line 162
    if-eqz p2, :cond_b

    .line 163
    .line 164
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 165
    .line 166
    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->cancel()V

    .line 167
    .line 168
    .line 169
    :cond_b
    const/4 p2, 0x0

    .line 170
    if-eqz p1, :cond_c

    .line 171
    .line 172
    if-eqz v0, :cond_c

    .line 173
    .line 174
    invoke-virtual {p0, p2}, Lcom/google/android/material/textfield/TextInputLayout;->w(F)V

    .line 175
    .line 176
    .line 177
    goto :goto_5

    .line 178
    :cond_c
    invoke-virtual {v6, p2}, La/W5;->M(F)V

    .line 179
    .line 180
    .line 181
    :goto_5
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 182
    .line 183
    .line 184
    move-result p1

    .line 185
    if-eqz p1, :cond_d

    .line 186
    .line 187
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 188
    .line 189
    check-cast p1, La/GP;

    .line 190
    .line 191
    iget-object p1, p1, La/GP;->n:La/RA;

    .line 192
    .line 193
    iget-object p1, p1, La/RA;->q:Landroid/graphics/RectF;

    .line 194
    .line 195
    invoke-virtual {p1}, Landroid/graphics/RectF;->isEmpty()Z

    .line 196
    .line 197
    .line 198
    move-result p1

    .line 199
    xor-int/2addr p1, v3

    .line 200
    if-eqz p1, :cond_d

    .line 201
    .line 202
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 203
    .line 204
    .line 205
    move-result p1

    .line 206
    if-eqz p1, :cond_d

    .line 207
    .line 208
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 209
    .line 210
    check-cast p1, La/GP;

    .line 211
    .line 212
    invoke-virtual {p1, p2, p2, p2, p2}, La/GP;->l(FFFF)V

    .line 213
    .line 214
    .line 215
    :cond_d
    iput-boolean v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 216
    .line 217
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 218
    .line 219
    if-eqz p1, :cond_e

    .line 220
    .line 221
    iget-boolean p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 222
    .line 223
    if-eqz p2, :cond_e

    .line 224
    .line 225
    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 226
    .line 227
    .line 228
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 229
    .line 230
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->C:La/KF;

    .line 231
    .line 232
    invoke-static {p1, p2}, La/SU;->w(Landroid/view/ViewGroup;La/SB;)V

    .line 233
    .line 234
    .line 235
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 236
    .line 237
    const/4 p2, 0x4

    .line 238
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 239
    .line 240
    .line 241
    :cond_e
    iput-boolean v3, v8, La/dX;->F:Z

    .line 242
    .line 243
    invoke-virtual {v8}, La/dX;->p()V

    .line 244
    .line 245
    .line 246
    iput-boolean v3, v7, La/h9;->u:Z

    .line 247
    .line 248
    invoke-virtual {v7}, La/h9;->m()V

    .line 249
    .line 250
    .line 251
    goto :goto_9

    .line 252
    :cond_f
    :goto_6
    if-nez p2, :cond_10

    .line 253
    .line 254
    iget-boolean p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 255
    .line 256
    if-eqz p2, :cond_15

    .line 257
    .line 258
    :cond_10
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 259
    .line 260
    if-eqz p2, :cond_11

    .line 261
    .line 262
    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->isRunning()Z

    .line 263
    .line 264
    .line 265
    move-result p2

    .line 266
    if-eqz p2, :cond_11

    .line 267
    .line 268
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 269
    .line 270
    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->cancel()V

    .line 271
    .line 272
    .line 273
    :cond_11
    const/high16 p2, 0x3f800000    # 1.0f

    .line 274
    .line 275
    if-eqz p1, :cond_12

    .line 276
    .line 277
    if-eqz v0, :cond_12

    .line 278
    .line 279
    invoke-virtual {p0, p2}, Lcom/google/android/material/textfield/TextInputLayout;->w(F)V

    .line 280
    .line 281
    .line 282
    goto :goto_7

    .line 283
    :cond_12
    invoke-virtual {v6, p2}, La/W5;->M(F)V

    .line 284
    .line 285
    .line 286
    :goto_7
    iput-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 287
    .line 288
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 289
    .line 290
    .line 291
    move-result p1

    .line 292
    if-eqz p1, :cond_13

    .line 293
    .line 294
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->I()V

    .line 295
    .line 296
    .line 297
    :cond_13
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 298
    .line 299
    if-nez p1, :cond_14

    .line 300
    .line 301
    goto :goto_8

    .line 302
    :cond_14
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 303
    .line 304
    .line 305
    move-result-object v5

    .line 306
    :goto_8
    invoke-virtual {p0, v5}, Lcom/google/android/material/textfield/TextInputLayout;->z(Landroid/text/Editable;)V

    .line 307
    .line 308
    .line 309
    iput-boolean v2, v8, La/dX;->F:Z

    .line 310
    .line 311
    invoke-virtual {v8}, La/dX;->p()V

    .line 312
    .line 313
    .line 314
    iput-boolean v2, v7, La/h9;->u:Z

    .line 315
    .line 316
    invoke-virtual {v7}, La/h9;->m()V

    .line 317
    .line 318
    .line 319
    :cond_15
    :goto_9
    return-void
.end method

.method public final I()V
    .locals 12

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 15
    .line 16
    invoke-virtual {v1}, Landroid/widget/TextView;->getGravity()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 21
    .line 22
    iget-object v3, v2, La/W5;->z:Ljava/lang/CharSequence;

    .line 23
    .line 24
    invoke-virtual {v2, v3}, La/W5;->h(Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    iput-boolean v3, v2, La/W5;->D:Z

    .line 29
    .line 30
    const/4 v4, 0x5

    .line 31
    const/high16 v5, 0x40000000    # 2.0f

    .line 32
    .line 33
    const v6, 0x800005

    .line 34
    .line 35
    .line 36
    const/4 v7, 0x1

    .line 37
    const/16 v8, 0x11

    .line 38
    .line 39
    iget-object v9, v2, La/W5;->e:Landroid/graphics/Rect;

    .line 40
    .line 41
    if-eq v1, v8, :cond_6

    .line 42
    .line 43
    and-int/lit8 v10, v1, 0x7

    .line 44
    .line 45
    if-ne v10, v7, :cond_1

    .line 46
    .line 47
    goto :goto_2

    .line 48
    :cond_1
    and-int v10, v1, v6

    .line 49
    .line 50
    if-eq v10, v6, :cond_5

    .line 51
    .line 52
    and-int/lit8 v10, v1, 0x5

    .line 53
    .line 54
    if-ne v10, v4, :cond_2

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_2
    if-eqz v3, :cond_4

    .line 58
    .line 59
    :cond_3
    iget v3, v9, Landroid/graphics/Rect;->right:I

    .line 60
    .line 61
    int-to-float v3, v3

    .line 62
    iget v10, v2, La/W5;->FL:F

    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_4
    :goto_0
    iget v3, v9, Landroid/graphics/Rect;->left:I

    .line 66
    .line 67
    int-to-float v3, v3

    .line 68
    goto :goto_4

    .line 69
    :cond_5
    :goto_1
    if-eqz v3, :cond_3

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_6
    :goto_2
    int-to-float v3, v0

    .line 73
    div-float/2addr v3, v5

    .line 74
    iget v10, v2, La/W5;->FL:F

    .line 75
    .line 76
    div-float/2addr v10, v5

    .line 77
    :goto_3
    sub-float/2addr v3, v10

    .line 78
    :goto_4
    iget v10, v9, Landroid/graphics/Rect;->left:I

    .line 79
    .line 80
    int-to-float v10, v10

    .line 81
    invoke-static {v3, v10}, Ljava/lang/Math;->max(FF)F

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    iget-object v10, p0, Lcom/google/android/material/textfield/TextInputLayout;->VQ:Landroid/graphics/RectF;

    .line 86
    .line 87
    iput v3, v10, Landroid/graphics/RectF;->left:F

    .line 88
    .line 89
    iget v11, v9, Landroid/graphics/Rect;->top:I

    .line 90
    .line 91
    int-to-float v11, v11

    .line 92
    iput v11, v10, Landroid/graphics/RectF;->top:F

    .line 93
    .line 94
    if-eq v1, v8, :cond_c

    .line 95
    .line 96
    and-int/lit8 v8, v1, 0x7

    .line 97
    .line 98
    if-ne v8, v7, :cond_7

    .line 99
    .line 100
    goto :goto_6

    .line 101
    :cond_7
    and-int v0, v1, v6

    .line 102
    .line 103
    if-eq v0, v6, :cond_b

    .line 104
    .line 105
    and-int/lit8 v0, v1, 0x5

    .line 106
    .line 107
    if-ne v0, v4, :cond_8

    .line 108
    .line 109
    goto :goto_5

    .line 110
    :cond_8
    iget-boolean v0, v2, La/W5;->D:Z

    .line 111
    .line 112
    if-eqz v0, :cond_a

    .line 113
    .line 114
    :cond_9
    iget v0, v9, Landroid/graphics/Rect;->right:I

    .line 115
    .line 116
    int-to-float v0, v0

    .line 117
    goto :goto_7

    .line 118
    :cond_a
    iget v0, v2, La/W5;->FL:F

    .line 119
    .line 120
    add-float/2addr v0, v3

    .line 121
    goto :goto_7

    .line 122
    :cond_b
    :goto_5
    iget-boolean v0, v2, La/W5;->D:Z

    .line 123
    .line 124
    if-eqz v0, :cond_9

    .line 125
    .line 126
    iget v0, v2, La/W5;->FL:F

    .line 127
    .line 128
    add-float/2addr v3, v0

    .line 129
    move v0, v3

    .line 130
    goto :goto_7

    .line 131
    :cond_c
    :goto_6
    int-to-float v0, v0

    .line 132
    div-float/2addr v0, v5

    .line 133
    iget v1, v2, La/W5;->FL:F

    .line 134
    .line 135
    div-float/2addr v1, v5

    .line 136
    add-float/2addr v0, v1

    .line 137
    :goto_7
    iget v1, v9, Landroid/graphics/Rect;->right:I

    .line 138
    .line 139
    int-to-float v1, v1

    .line 140
    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    iput v0, v10, Landroid/graphics/RectF;->right:F

    .line 145
    .line 146
    iget v0, v9, Landroid/graphics/Rect;->top:I

    .line 147
    .line 148
    int-to-float v0, v0

    .line 149
    invoke-virtual {v2}, La/W5;->e()F

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    add-float/2addr v1, v0

    .line 154
    iput v1, v10, Landroid/graphics/RectF;->bottom:F

    .line 155
    .line 156
    invoke-virtual {v10}, Landroid/graphics/RectF;->width()F

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    const/4 v1, 0x0

    .line 161
    cmpg-float v0, v0, v1

    .line 162
    .line 163
    if-lez v0, :cond_e

    .line 164
    .line 165
    invoke-virtual {v10}, Landroid/graphics/RectF;->height()F

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    cmpg-float v0, v0, v1

    .line 170
    .line 171
    if-gtz v0, :cond_d

    .line 172
    .line 173
    goto :goto_8

    .line 174
    :cond_d
    iget v0, v10, Landroid/graphics/RectF;->left:F

    .line 175
    .line 176
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->F9:I

    .line 177
    .line 178
    int-to-float v1, v1

    .line 179
    sub-float/2addr v0, v1

    .line 180
    iput v0, v10, Landroid/graphics/RectF;->left:F

    .line 181
    .line 182
    iget v0, v10, Landroid/graphics/RectF;->right:F

    .line 183
    .line 184
    add-float/2addr v0, v1

    .line 185
    iput v0, v10, Landroid/graphics/RectF;->right:F

    .line 186
    .line 187
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 188
    .line 189
    .line 190
    move-result v0

    .line 191
    neg-int v0, v0

    .line 192
    int-to-float v0, v0

    .line 193
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    neg-int v1, v1

    .line 198
    int-to-float v1, v1

    .line 199
    invoke-virtual {v10}, Landroid/graphics/RectF;->height()F

    .line 200
    .line 201
    .line 202
    move-result v2

    .line 203
    div-float/2addr v2, v5

    .line 204
    sub-float/2addr v1, v2

    .line 205
    iget v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 206
    .line 207
    int-to-float v2, v2

    .line 208
    add-float/2addr v1, v2

    .line 209
    invoke-virtual {v10, v0, v1}, Landroid/graphics/RectF;->offset(FF)V

    .line 210
    .line 211
    .line 212
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 213
    .line 214
    check-cast v0, La/GP;

    .line 215
    .line 216
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 217
    .line 218
    .line 219
    iget v1, v10, Landroid/graphics/RectF;->left:F

    .line 220
    .line 221
    iget v2, v10, Landroid/graphics/RectF;->top:F

    .line 222
    .line 223
    iget v3, v10, Landroid/graphics/RectF;->right:F

    .line 224
    .line 225
    iget v4, v10, Landroid/graphics/RectF;->bottom:F

    .line 226
    .line 227
    invoke-virtual {v0, v1, v2, v3, v4}, La/GP;->l(FFFF)V

    .line 228
    .line 229
    .line 230
    :cond_e
    :goto_8
    return-void
.end method

.method public final K(Ljava/lang/CharSequence;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 2
    .line 3
    if-eqz v0, :cond_4

    .line 4
    .line 5
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    .line 6
    .line 7
    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_3

    .line 12
    .line 13
    iput-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 16
    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    iget-object v1, v0, La/W5;->z:Ljava/lang/CharSequence;

    .line 20
    .line 21
    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_2

    .line 26
    .line 27
    :cond_0
    iput-object p1, v0, La/W5;->z:Ljava/lang/CharSequence;

    .line 28
    .line 29
    const/4 p1, 0x0

    .line 30
    iput-object p1, v0, La/W5;->P:Ljava/lang/CharSequence;

    .line 31
    .line 32
    iget-object v1, v0, La/W5;->u:Landroid/graphics/Bitmap;

    .line 33
    .line 34
    if-eqz v1, :cond_1

    .line 35
    .line 36
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 37
    .line 38
    .line 39
    iput-object p1, v0, La/W5;->u:Landroid/graphics/Bitmap;

    .line 40
    .line 41
    :cond_1
    const/4 p1, 0x0

    .line 42
    invoke-virtual {v0, p1}, La/W5;->O(Z)V

    .line 43
    .line 44
    .line 45
    :cond_2
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 46
    .line 47
    if-nez p1, :cond_3

    .line 48
    .line 49
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->I()V

    .line 50
    .line 51
    .line 52
    :cond_3
    const/16 p1, 0x800

    .line 53
    .line 54
    invoke-virtual {p0, p1}, Landroid/view/View;->sendAccessibilityEvent(I)V

    .line 55
    .line 56
    .line 57
    :cond_4
    return-void
.end method

.method public final L(Landroid/widget/TextView;I)V
    .locals 1

    .line 1
    :try_start_0
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    invoke-virtual {p2}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    .line 9
    .line 10
    .line 11
    move-result p2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    const v0, -0xff01

    .line 13
    .line 14
    .line 15
    if-ne p2, v0, :cond_0

    .line 16
    .line 17
    :catch_0
    const p2, 0x7f1301b6

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    sget-object v0, La/hA;->w:Ljava/lang/Object;

    .line 28
    .line 29
    const v0, 0x7f060055

    .line 30
    .line 31
    .line 32
    invoke-static {p2, v0}, La/Ex;->w(Landroid/content/Context;I)I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 37
    .line 38
    .line 39
    :cond_0
    return-void
.end method

.method public final O(IZ)I
    .locals 2

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 4
    .line 5
    iget-object v1, v0, La/h9;->P:Ljava/lang/CharSequence;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, La/h9;->p()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    :goto_0
    sub-int/2addr p1, p2

    .line 14
    return p1

    .line 15
    :cond_0
    if-eqz p2, :cond_1

    .line 16
    .line 17
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 18
    .line 19
    iget-object v0, p2, La/dX;->L:Ljava/lang/CharSequence;

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {p2}, La/dX;->w()I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 29
    .line 30
    invoke-virtual {p2}, Landroid/widget/TextView;->getCompoundPaddingRight()I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    goto :goto_0
.end method

.method public final P(ZZ)V
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    const v2, 0x1010367

    const v3, 0x101009e

    filled-new-array {v2, v3}, [I

    move-result-object v2

    invoke-virtual {v1, v2, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Vy:Landroid/content/res/ColorStateList;

    const v4, 0x10102fe

    filled-new-array {v4, v3}, [I

    move-result-object v3

    invoke-virtual {v2, v3, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v2

    if-eqz p1, :cond_0

    iput v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    goto :goto_0

    :cond_0
    if-eqz p2, :cond_1

    iput v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    goto :goto_0

    :cond_1
    iput v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    :goto_0
    return-void
.end method

.method public final Q(Z)La/ex;
    .locals 14

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const v1, 0x7f0702f3

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    int-to-float v0, v0

    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    move p1, v0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p1, 0x0

    .line 18
    :goto_0
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 19
    .line 20
    instance-of v2, v1, La/UH;

    .line 21
    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    check-cast v1, La/UH;

    .line 25
    .line 26
    iget v1, v1, La/UH;->q:F

    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const v2, 0x7f070163

    .line 34
    .line 35
    .line 36
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    int-to-float v1, v1

    .line 41
    :goto_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    const v3, 0x7f0702b4

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    new-instance v3, La/uA;

    .line 53
    .line 54
    invoke-direct {v3}, La/uA;-><init>()V

    .line 55
    .line 56
    .line 57
    new-instance v4, La/uA;

    .line 58
    .line 59
    invoke-direct {v4}, La/uA;-><init>()V

    .line 60
    .line 61
    .line 62
    new-instance v5, La/uA;

    .line 63
    .line 64
    invoke-direct {v5}, La/uA;-><init>()V

    .line 65
    .line 66
    .line 67
    new-instance v6, La/uA;

    .line 68
    .line 69
    invoke-direct {v6}, La/uA;-><init>()V

    .line 70
    .line 71
    .line 72
    invoke-static {}, La/rx;->f()La/eI;

    .line 73
    .line 74
    .line 75
    move-result-object v7

    .line 76
    invoke-static {}, La/rx;->f()La/eI;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    invoke-static {}, La/rx;->f()La/eI;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    invoke-static {}, La/rx;->f()La/eI;

    .line 85
    .line 86
    .line 87
    move-result-object v10

    .line 88
    new-instance v11, La/r;

    .line 89
    .line 90
    invoke-direct {v11, p1}, La/r;-><init>(F)V

    .line 91
    .line 92
    .line 93
    new-instance v12, La/r;

    .line 94
    .line 95
    invoke-direct {v12, p1}, La/r;-><init>(F)V

    .line 96
    .line 97
    .line 98
    new-instance p1, La/r;

    .line 99
    .line 100
    invoke-direct {p1, v0}, La/r;-><init>(F)V

    .line 101
    .line 102
    .line 103
    new-instance v13, La/r;

    .line 104
    .line 105
    invoke-direct {v13, v0}, La/r;-><init>(F)V

    .line 106
    .line 107
    .line 108
    new-instance v0, La/c9;

    .line 109
    .line 110
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 111
    .line 112
    .line 113
    iput-object v3, v0, La/c9;->w:La/TZ;

    .line 114
    .line 115
    iput-object v4, v0, La/c9;->h:La/TZ;

    .line 116
    .line 117
    iput-object v5, v0, La/c9;->p:La/TZ;

    .line 118
    .line 119
    iput-object v6, v0, La/c9;->e:La/TZ;

    .line 120
    .line 121
    iput-object v11, v0, La/c9;->i:La/cv;

    .line 122
    .line 123
    iput-object v12, v0, La/c9;->Q:La/cv;

    .line 124
    .line 125
    iput-object v13, v0, La/c9;->X:La/cv;

    .line 126
    .line 127
    iput-object p1, v0, La/c9;->O:La/cv;

    .line 128
    .line 129
    iput-object v7, v0, La/c9;->V:La/eI;

    .line 130
    .line 131
    iput-object v8, v0, La/c9;->I:La/eI;

    .line 132
    .line 133
    iput-object v9, v0, La/c9;->M:La/eI;

    .line 134
    .line 135
    iput-object v10, v0, La/c9;->T:La/eI;

    .line 136
    .line 137
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 138
    .line 139
    instance-of v3, p1, La/UH;

    .line 140
    .line 141
    if-eqz v3, :cond_2

    .line 142
    .line 143
    check-cast p1, La/UH;

    .line 144
    .line 145
    iget-object p1, p1, La/UH;->F:Landroid/content/res/ColorStateList;

    .line 146
    .line 147
    goto :goto_2

    .line 148
    :cond_2
    const/4 p1, 0x0

    .line 149
    :goto_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    if-nez p1, :cond_4

    .line 154
    .line 155
    sget-object p1, La/ex;->t:Landroid/graphics/Paint;

    .line 156
    .line 157
    const-class p1, La/ex;

    .line 158
    .line 159
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    const v4, 0x7f04012d

    .line 164
    .line 165
    .line 166
    invoke-static {v4, v3, p1}, La/rE;->Ey(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    .line 167
    .line 168
    .line 169
    move-result-object p1

    .line 170
    iget v4, p1, Landroid/util/TypedValue;->resourceId:I

    .line 171
    .line 172
    if-eqz v4, :cond_3

    .line 173
    .line 174
    sget-object p1, La/hA;->w:Ljava/lang/Object;

    .line 175
    .line 176
    invoke-static {v3, v4}, La/Ex;->w(Landroid/content/Context;I)I

    .line 177
    .line 178
    .line 179
    move-result p1

    .line 180
    goto :goto_3

    .line 181
    :cond_3
    iget p1, p1, Landroid/util/TypedValue;->data:I

    .line 182
    .line 183
    :goto_3
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    :cond_4
    new-instance v4, La/ex;

    .line 188
    .line 189
    invoke-direct {v4}, La/ex;-><init>()V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v4, v3}, La/ex;->T(Landroid/content/Context;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v4, p1}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v4, v1}, La/ex;->y(F)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v4, v0}, La/ex;->h(La/c9;)V

    .line 202
    .line 203
    .line 204
    iget-object p1, v4, La/ex;->X:La/JP;

    .line 205
    .line 206
    iget-object v0, p1, La/JP;->O:Landroid/graphics/Rect;

    .line 207
    .line 208
    if-nez v0, :cond_5

    .line 209
    .line 210
    new-instance v0, Landroid/graphics/Rect;

    .line 211
    .line 212
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 213
    .line 214
    .line 215
    iput-object v0, p1, La/JP;->O:Landroid/graphics/Rect;

    .line 216
    .line 217
    :cond_5
    iget-object p1, v4, La/ex;->X:La/JP;

    .line 218
    .line 219
    iget-object p1, p1, La/JP;->O:Landroid/graphics/Rect;

    .line 220
    .line 221
    const/4 v0, 0x0

    .line 222
    invoke-virtual {p1, v0, v2, v0, v2}, Landroid/graphics/Rect;->set(IIII)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v4}, La/ex;->invalidateSelf()V

    .line 226
    .line 227
    .line 228
    return-object v4
.end method

.method public final R(Z)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    if-eqz p1, :cond_1

    .line 7
    .line 8
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 9
    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 13
    .line 14
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    const/16 v1, 0x8

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 31
    .line 32
    .line 33
    :cond_2
    const/4 v0, 0x0

    .line 34
    iput-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 35
    .line 36
    :cond_3
    :goto_0
    iput-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 37
    .line 38
    return-void
.end method

.method public final S()V
    .locals 4

    .line 1
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->p()I

    move-result v2

    iget v3, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    if-eq v2, v3, :cond_0

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_0
    return-void
.end method

.method public final T(Ljava/lang/CharSequence;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 2
    .line 3
    iget-boolean v1, v0, La/A7;->L:Z

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-nez v1, :cond_1

    .line 7
    .line 8
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->m(Z)V

    .line 16
    .line 17
    .line 18
    :cond_1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-nez v1, :cond_3

    .line 23
    .line 24
    invoke-virtual {v0}, La/A7;->p()V

    .line 25
    .line 26
    .line 27
    iput-object p1, v0, La/A7;->R:Ljava/lang/CharSequence;

    .line 28
    .line 29
    iget-object v1, v0, La/A7;->d:La/c8;

    .line 30
    .line 31
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 32
    .line 33
    .line 34
    iget v1, v0, La/A7;->y:I

    .line 35
    .line 36
    if-eq v1, v2, :cond_2

    .line 37
    .line 38
    iput v2, v0, La/A7;->K:I

    .line 39
    .line 40
    :cond_2
    iget v2, v0, La/A7;->K:I

    .line 41
    .line 42
    iget-object v3, v0, La/A7;->d:La/c8;

    .line 43
    .line 44
    invoke-virtual {v0, v3, p1}, La/A7;->O(Landroid/widget/TextView;Ljava/lang/CharSequence;)Z

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    invoke-virtual {v0, v1, v2, p1}, La/A7;->V(IIZ)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_3
    invoke-virtual {v0}, La/A7;->Q()V

    .line 53
    .line 54
    .line 55
    :goto_0
    return-void
.end method

.method public final V()V
    .locals 8

    .line 1
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x0

    .line 6
    if-eqz v0, :cond_4

    .line 7
    .line 8
    if-eq v0, v1, :cond_3

    .line 9
    .line 10
    if-ne v0, v2, :cond_2

    .line 11
    .line 12
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 17
    .line 18
    instance-of v0, v0, La/GP;

    .line 19
    .line 20
    if-nez v0, :cond_1

    .line 21
    .line 22
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 23
    .line 24
    sget v4, La/GP;->C:I

    .line 25
    .line 26
    new-instance v4, La/RA;

    .line 27
    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance v0, La/c9;

    .line 32
    .line 33
    invoke-direct {v0}, La/c9;-><init>()V

    .line 34
    .line 35
    .line 36
    :goto_0
    new-instance v5, Landroid/graphics/RectF;

    .line 37
    .line 38
    invoke-direct {v5}, Landroid/graphics/RectF;-><init>()V

    .line 39
    .line 40
    .line 41
    invoke-direct {v4, v0, v5}, La/RA;-><init>(La/c9;Landroid/graphics/RectF;)V

    .line 42
    .line 43
    .line 44
    new-instance v0, La/ai;

    .line 45
    .line 46
    invoke-direct {v0, v4}, La/GP;-><init>(La/RA;)V

    .line 47
    .line 48
    .line 49
    :goto_1
    iput-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 50
    .line 51
    goto :goto_2

    .line 52
    :cond_1
    new-instance v0, La/ex;

    .line 53
    .line 54
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 55
    .line 56
    invoke-direct {v0, v4}, La/ex;-><init>(La/c9;)V

    .line 57
    .line 58
    .line 59
    goto :goto_1

    .line 60
    :goto_2
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 61
    .line 62
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 66
    .line 67
    new-instance v1, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 70
    .line 71
    .line 72
    iget v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 73
    .line 74
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    const-string v2, " is illegal; only @BoxBackgroundMode constants are supported."

    .line 78
    .line 79
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    throw v0

    .line 90
    :cond_3
    new-instance v0, La/ex;

    .line 91
    .line 92
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 93
    .line 94
    invoke-direct {v0, v3}, La/ex;-><init>(La/c9;)V

    .line 95
    .line 96
    .line 97
    iput-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 98
    .line 99
    new-instance v0, La/ex;

    .line 100
    .line 101
    invoke-direct {v0}, La/ex;-><init>()V

    .line 102
    .line 103
    .line 104
    iput-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 105
    .line 106
    new-instance v0, La/ex;

    .line 107
    .line 108
    invoke-direct {v0}, La/ex;-><init>()V

    .line 109
    .line 110
    .line 111
    iput-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 112
    .line 113
    goto :goto_3

    .line 114
    :cond_4
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :goto_3
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->E()V

    .line 118
    .line 119
    .line 120
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 121
    .line 122
    .line 123
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 124
    .line 125
    const/high16 v3, 0x40000000    # 2.0f

    .line 126
    .line 127
    if-ne v0, v1, :cond_6

    .line 128
    .line 129
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    iget v0, v0, Landroid/content/res/Configuration;->fontScale:F

    .line 142
    .line 143
    cmpl-float v0, v0, v3

    .line 144
    .line 145
    if-ltz v0, :cond_5

    .line 146
    .line 147
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    const v4, 0x7f07024b

    .line 152
    .line 153
    .line 154
    :goto_4
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    iput v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->mh:I

    .line 159
    .line 160
    goto :goto_5

    .line 161
    :cond_5
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-static {v0}, La/rx;->J(Landroid/content/Context;)Z

    .line 166
    .line 167
    .line 168
    move-result v0

    .line 169
    if-eqz v0, :cond_6

    .line 170
    .line 171
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    const v4, 0x7f07024a

    .line 176
    .line 177
    .line 178
    goto :goto_4

    .line 179
    :cond_6
    :goto_5
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 180
    .line 181
    if-eqz v0, :cond_9

    .line 182
    .line 183
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 184
    .line 185
    if-eq v0, v1, :cond_7

    .line 186
    .line 187
    goto :goto_7

    .line 188
    :cond_7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    iget v0, v0, Landroid/content/res/Configuration;->fontScale:F

    .line 201
    .line 202
    cmpl-float v0, v0, v3

    .line 203
    .line 204
    if-ltz v0, :cond_8

    .line 205
    .line 206
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 207
    .line 208
    sget-object v3, La/sI;->w:Ljava/util/WeakHashMap;

    .line 209
    .line 210
    invoke-static {v0}, La/XC;->Q(Landroid/view/View;)I

    .line 211
    .line 212
    .line 213
    move-result v3

    .line 214
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 215
    .line 216
    .line 217
    move-result-object v4

    .line 218
    const v5, 0x7f070249

    .line 219
    .line 220
    .line 221
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 222
    .line 223
    .line 224
    move-result v4

    .line 225
    iget-object v5, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 226
    .line 227
    invoke-static {v5}, La/XC;->i(Landroid/view/View;)I

    .line 228
    .line 229
    .line 230
    move-result v5

    .line 231
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 232
    .line 233
    .line 234
    move-result-object v6

    .line 235
    const v7, 0x7f070248

    .line 236
    .line 237
    .line 238
    :goto_6
    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 239
    .line 240
    .line 241
    move-result v6

    .line 242
    invoke-static {v0, v3, v4, v5, v6}, La/XC;->M(Landroid/view/View;IIII)V

    .line 243
    .line 244
    .line 245
    goto :goto_7

    .line 246
    :cond_8
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-static {v0}, La/rx;->J(Landroid/content/Context;)Z

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    if-eqz v0, :cond_9

    .line 255
    .line 256
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 257
    .line 258
    sget-object v3, La/sI;->w:Ljava/util/WeakHashMap;

    .line 259
    .line 260
    invoke-static {v0}, La/XC;->Q(Landroid/view/View;)I

    .line 261
    .line 262
    .line 263
    move-result v3

    .line 264
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    const v5, 0x7f070247

    .line 269
    .line 270
    .line 271
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 272
    .line 273
    .line 274
    move-result v4

    .line 275
    iget-object v5, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 276
    .line 277
    invoke-static {v5}, La/XC;->i(Landroid/view/View;)I

    .line 278
    .line 279
    .line 280
    move-result v5

    .line 281
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 282
    .line 283
    .line 284
    move-result-object v6

    .line 285
    const v7, 0x7f070246

    .line 286
    .line 287
    .line 288
    goto :goto_6

    .line 289
    :cond_9
    :goto_7
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 290
    .line 291
    if-eqz v0, :cond_a

    .line 292
    .line 293
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->S()V

    .line 294
    .line 295
    .line 296
    :cond_a
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 297
    .line 298
    instance-of v3, v0, Landroid/widget/AutoCompleteTextView;

    .line 299
    .line 300
    if-nez v3, :cond_b

    .line 301
    .line 302
    goto :goto_8

    .line 303
    :cond_b
    check-cast v0, Landroid/widget/AutoCompleteTextView;

    .line 304
    .line 305
    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->getDropDownBackground()Landroid/graphics/drawable/Drawable;

    .line 306
    .line 307
    .line 308
    move-result-object v3

    .line 309
    if-nez v3, :cond_10

    .line 310
    .line 311
    iget v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 312
    .line 313
    if-ne v3, v2, :cond_d

    .line 314
    .line 315
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 316
    .line 317
    if-nez v2, :cond_c

    .line 318
    .line 319
    invoke-virtual {p0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->Q(Z)La/ex;

    .line 320
    .line 321
    .line 322
    move-result-object v1

    .line 323
    iput-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 324
    .line 325
    :cond_c
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 326
    .line 327
    invoke-virtual {v0, v1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 328
    .line 329
    .line 330
    goto :goto_8

    .line 331
    :cond_d
    if-ne v3, v1, :cond_10

    .line 332
    .line 333
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->G:Landroid/graphics/drawable/StateListDrawable;

    .line 334
    .line 335
    if-nez v2, :cond_f

    .line 336
    .line 337
    new-instance v2, Landroid/graphics/drawable/StateListDrawable;

    .line 338
    .line 339
    invoke-direct {v2}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    .line 340
    .line 341
    .line 342
    iput-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->G:Landroid/graphics/drawable/StateListDrawable;

    .line 343
    .line 344
    const v3, 0x10100aa

    .line 345
    .line 346
    .line 347
    filled-new-array {v3}, [I

    .line 348
    .line 349
    .line 350
    move-result-object v3

    .line 351
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 352
    .line 353
    if-nez v4, :cond_e

    .line 354
    .line 355
    invoke-virtual {p0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->Q(Z)La/ex;

    .line 356
    .line 357
    .line 358
    move-result-object v1

    .line 359
    iput-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 360
    .line 361
    :cond_e
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->J:La/ex;

    .line 362
    .line 363
    invoke-virtual {v2, v3, v1}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 364
    .line 365
    .line 366
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->G:Landroid/graphics/drawable/StateListDrawable;

    .line 367
    .line 368
    const/4 v2, 0x0

    .line 369
    new-array v3, v2, [I

    .line 370
    .line 371
    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->Q(Z)La/ex;

    .line 372
    .line 373
    .line 374
    move-result-object v2

    .line 375
    invoke-virtual {v1, v3, v2}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 376
    .line 377
    .line 378
    :cond_f
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->G:Landroid/graphics/drawable/StateListDrawable;

    .line 379
    .line 380
    invoke-virtual {v0, v1}, Landroid/widget/AutoCompleteTextView;->setDropDownBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 381
    .line 382
    .line 383
    :cond_10
    :goto_8
    return-void
.end method

.method public final W()V
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->o:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const v1, 0x7f040100

    .line 11
    .line 12
    .line 13
    invoke-static {v0, v1}, La/rE;->Hs(Landroid/content/Context;I)Landroid/util/TypedValue;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const/4 v2, 0x0

    .line 18
    if-nez v1, :cond_2

    .line 19
    .line 20
    :cond_1
    move-object v0, v2

    .line 21
    goto :goto_0

    .line 22
    :cond_2
    iget v3, v1, Landroid/util/TypedValue;->resourceId:I

    .line 23
    .line 24
    if-eqz v3, :cond_3

    .line 25
    .line 26
    invoke-static {v0, v3}, La/hA;->h(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    goto :goto_0

    .line 31
    :cond_3
    iget v0, v1, Landroid/util/TypedValue;->data:I

    .line 32
    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :goto_0
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 40
    .line 41
    if-eqz v1, :cond_7

    .line 42
    .line 43
    invoke-static {v1}, La/an;->i(Landroid/widget/EditText;)Landroid/graphics/drawable/Drawable;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    if-nez v1, :cond_4

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_4
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 51
    .line 52
    invoke-static {v1}, La/an;->i(Landroid/widget/EditText;)Landroid/graphics/drawable/Drawable;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-nez v2, :cond_5

    .line 65
    .line 66
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 67
    .line 68
    if-eqz v2, :cond_6

    .line 69
    .line 70
    iget-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 71
    .line 72
    if-eqz v2, :cond_6

    .line 73
    .line 74
    :cond_5
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->r:Landroid/content/res/ColorStateList;

    .line 75
    .line 76
    if-eqz v2, :cond_6

    .line 77
    .line 78
    move-object v0, v2

    .line 79
    :cond_6
    invoke-static {v1, v0}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 80
    .line 81
    .line 82
    :cond_7
    :goto_1
    return-void
.end method

.method public final X(IZ)I
    .locals 2

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 4
    .line 5
    iget-object v1, v0, La/dX;->L:Ljava/lang/CharSequence;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, La/dX;->w()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    :goto_0
    add-int/2addr p2, p1

    .line 14
    return p2

    .line 15
    :cond_0
    if-eqz p2, :cond_1

    .line 16
    .line 17
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 18
    .line 19
    iget-object v0, p2, La/h9;->P:Ljava/lang/CharSequence;

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-virtual {p2}, La/h9;->p()I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 29
    .line 30
    invoke-virtual {p2}, Landroid/widget/TextView;->getCompoundPaddingLeft()I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    goto :goto_0
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 6

    .line 1
    instance-of v0, p1, Landroid/widget/EditText;

    .line 2
    .line 3
    if-eqz v0, :cond_16

    .line 4
    .line 5
    new-instance p2, Landroid/widget/FrameLayout$LayoutParams;

    .line 6
    .line 7
    invoke-direct {p2, p3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 8
    .line 9
    .line 10
    iget v0, p2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 11
    .line 12
    and-int/lit8 v0, v0, -0x71

    .line 13
    .line 14
    or-int/lit8 v0, v0, 0x10

    .line 15
    .line 16
    iput v0, p2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 17
    .line 18
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 19
    .line 20
    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, p3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->S()V

    .line 27
    .line 28
    .line 29
    check-cast p1, Landroid/widget/EditText;

    .line 30
    .line 31
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 32
    .line 33
    if-nez p2, :cond_15

    .line 34
    .line 35
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 36
    .line 37
    iget p3, p2, La/h9;->q:I

    .line 38
    .line 39
    const/4 v0, 0x3

    .line 40
    if-eq p3, v0, :cond_0

    .line 41
    .line 42
    instance-of p3, p1, Lcom/google/android/material/textfield/TextInputEditText;

    .line 43
    .line 44
    if-nez p3, :cond_0

    .line 45
    .line 46
    const-string p3, "TextInputLayout"

    .line 47
    .line 48
    const-string v0, "EditText added is not a TextInputEditText. Please switch to using that class instead."

    .line 49
    .line 50
    invoke-static {p3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 51
    .line 52
    .line 53
    :cond_0
    iput-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 54
    .line 55
    iget p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->l:I

    .line 56
    .line 57
    const/4 v0, -0x1

    .line 58
    if-eq p3, v0, :cond_1

    .line 59
    .line 60
    iput p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->l:I

    .line 61
    .line 62
    if-eqz p1, :cond_2

    .line 63
    .line 64
    if-eq p3, v0, :cond_2

    .line 65
    .line 66
    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setMinEms(I)V

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_1
    iget p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->q:I

    .line 71
    .line 72
    iput p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->q:I

    .line 73
    .line 74
    if-eqz p1, :cond_2

    .line 75
    .line 76
    if-eq p3, v0, :cond_2

    .line 77
    .line 78
    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 79
    .line 80
    .line 81
    :cond_2
    :goto_0
    iget p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->W:I

    .line 82
    .line 83
    if-eq p3, v0, :cond_3

    .line 84
    .line 85
    iput p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->W:I

    .line 86
    .line 87
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 88
    .line 89
    if-eqz v1, :cond_4

    .line 90
    .line 91
    if-eq p3, v0, :cond_4

    .line 92
    .line 93
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setMaxEms(I)V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_3
    iget p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->F:I

    .line 98
    .line 99
    iput p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->F:I

    .line 100
    .line 101
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 102
    .line 103
    if-eqz v1, :cond_4

    .line 104
    .line 105
    if-eq p3, v0, :cond_4

    .line 106
    .line 107
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setMaxWidth(I)V

    .line 108
    .line 109
    .line 110
    :cond_4
    :goto_1
    const/4 p3, 0x0

    .line 111
    iput-boolean p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Pc:Z

    .line 112
    .line 113
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->V()V

    .line 114
    .line 115
    .line 116
    new-instance v0, La/Bc;

    .line 117
    .line 118
    invoke-direct {v0, p0}, La/Bc;-><init>(Lcom/google/android/material/textfield/TextInputLayout;)V

    .line 119
    .line 120
    .line 121
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 122
    .line 123
    if-eqz v1, :cond_5

    .line 124
    .line 125
    invoke-static {v1, v0}, La/sI;->T(Landroid/view/View;La/Qg;)V

    .line 126
    .line 127
    .line 128
    :cond_5
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 129
    .line 130
    invoke-virtual {v0}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 135
    .line 136
    invoke-virtual {v1, v0}, La/W5;->I(Landroid/graphics/Typeface;)Z

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    iget-object v3, v1, La/W5;->F:Landroid/graphics/Typeface;

    .line 141
    .line 142
    const/4 v4, 0x1

    .line 143
    if-eq v3, v0, :cond_7

    .line 144
    .line 145
    iput-object v0, v1, La/W5;->F:Landroid/graphics/Typeface;

    .line 146
    .line 147
    iget-object v3, v1, La/W5;->w:Landroid/view/View;

    .line 148
    .line 149
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    invoke-static {v3, v0}, La/rE;->cS(Landroid/content/res/Configuration;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    iput-object v0, v1, La/W5;->q:Landroid/graphics/Typeface;

    .line 166
    .line 167
    if-nez v0, :cond_6

    .line 168
    .line 169
    iget-object v0, v1, La/W5;->F:Landroid/graphics/Typeface;

    .line 170
    .line 171
    :cond_6
    iput-object v0, v1, La/W5;->W:Landroid/graphics/Typeface;

    .line 172
    .line 173
    move v0, v4

    .line 174
    goto :goto_2

    .line 175
    :cond_7
    move v0, p3

    .line 176
    :goto_2
    if-nez v2, :cond_8

    .line 177
    .line 178
    if-eqz v0, :cond_9

    .line 179
    .line 180
    :cond_8
    invoke-virtual {v1, p3}, La/W5;->O(Z)V

    .line 181
    .line 182
    .line 183
    :cond_9
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 184
    .line 185
    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    iget v2, v1, La/W5;->O:F

    .line 190
    .line 191
    cmpl-float v2, v2, v0

    .line 192
    .line 193
    if-eqz v2, :cond_a

    .line 194
    .line 195
    iput v0, v1, La/W5;->O:F

    .line 196
    .line 197
    invoke-virtual {v1, p3}, La/W5;->O(Z)V

    .line 198
    .line 199
    .line 200
    :cond_a
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 201
    .line 202
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 203
    .line 204
    invoke-virtual {v2}, Landroid/widget/TextView;->getLetterSpacing()F

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    iget v3, v1, La/W5;->J:F

    .line 209
    .line 210
    cmpl-float v3, v3, v2

    .line 211
    .line 212
    if-eqz v3, :cond_b

    .line 213
    .line 214
    iput v2, v1, La/W5;->J:F

    .line 215
    .line 216
    invoke-virtual {v1, p3}, La/W5;->O(Z)V

    .line 217
    .line 218
    .line 219
    :cond_b
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 220
    .line 221
    invoke-virtual {v2}, Landroid/widget/TextView;->getGravity()I

    .line 222
    .line 223
    .line 224
    move-result v2

    .line 225
    and-int/lit8 v3, v2, -0x71

    .line 226
    .line 227
    or-int/lit8 v3, v3, 0x30

    .line 228
    .line 229
    iget v5, v1, La/W5;->X:I

    .line 230
    .line 231
    if-eq v5, v3, :cond_c

    .line 232
    .line 233
    iput v3, v1, La/W5;->X:I

    .line 234
    .line 235
    invoke-virtual {v1, p3}, La/W5;->O(Z)V

    .line 236
    .line 237
    .line 238
    :cond_c
    iget v3, v1, La/W5;->Q:I

    .line 239
    .line 240
    if-eq v3, v2, :cond_d

    .line 241
    .line 242
    iput v2, v1, La/W5;->Q:I

    .line 243
    .line 244
    invoke-virtual {v1, p3}, La/W5;->O(Z)V

    .line 245
    .line 246
    .line 247
    :cond_d
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 248
    .line 249
    new-instance v2, La/mM;

    .line 250
    .line 251
    invoke-direct {v2, p0}, La/mM;-><init>(Lcom/google/android/material/textfield/TextInputLayout;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 255
    .line 256
    .line 257
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 258
    .line 259
    if-nez v1, :cond_e

    .line 260
    .line 261
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 262
    .line 263
    invoke-virtual {v1}, Landroid/widget/TextView;->getHintTextColors()Landroid/content/res/ColorStateList;

    .line 264
    .line 265
    .line 266
    move-result-object v1

    .line 267
    iput-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Tr:Landroid/content/res/ColorStateList;

    .line 268
    .line 269
    :cond_e
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 270
    .line 271
    if-eqz v1, :cond_10

    .line 272
    .line 273
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    .line 274
    .line 275
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 276
    .line 277
    .line 278
    move-result v1

    .line 279
    if-eqz v1, :cond_f

    .line 280
    .line 281
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 282
    .line 283
    invoke-virtual {v1}, Landroid/widget/TextView;->getHint()Ljava/lang/CharSequence;

    .line 284
    .line 285
    .line 286
    move-result-object v1

    .line 287
    iput-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->f:Ljava/lang/CharSequence;

    .line 288
    .line 289
    invoke-virtual {p0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->K(Ljava/lang/CharSequence;)V

    .line 290
    .line 291
    .line 292
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 293
    .line 294
    const/4 v2, 0x0

    .line 295
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 296
    .line 297
    .line 298
    :cond_f
    iput-boolean v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->N:Z

    .line 299
    .line 300
    :cond_10
    const/16 v1, 0x1d

    .line 301
    .line 302
    if-lt v0, v1, :cond_11

    .line 303
    .line 304
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->W()V

    .line 305
    .line 306
    .line 307
    :cond_11
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 308
    .line 309
    if-eqz v0, :cond_12

    .line 310
    .line 311
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 312
    .line 313
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    invoke-virtual {p0, v0}, Lcom/google/android/material/textfield/TextInputLayout;->f(Landroid/text/Editable;)V

    .line 318
    .line 319
    .line 320
    :cond_12
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->F()V

    .line 321
    .line 322
    .line 323
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 324
    .line 325
    invoke-virtual {v0}, La/A7;->h()V

    .line 326
    .line 327
    .line 328
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 329
    .line 330
    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    .line 331
    .line 332
    .line 333
    invoke-virtual {p2}, Landroid/view/View;->bringToFront()V

    .line 334
    .line 335
    .line 336
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->NE:Ljava/util/LinkedHashSet;

    .line 337
    .line 338
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 343
    .line 344
    .line 345
    move-result v1

    .line 346
    if-eqz v1, :cond_13

    .line 347
    .line 348
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object v1

    .line 352
    check-cast v1, La/Wg;

    .line 353
    .line 354
    invoke-virtual {v1, p0}, La/Wg;->w(Lcom/google/android/material/textfield/TextInputLayout;)V

    .line 355
    .line 356
    .line 357
    goto :goto_3

    .line 358
    :cond_13
    invoke-virtual {p2}, La/h9;->T()V

    .line 359
    .line 360
    .line 361
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 362
    .line 363
    .line 364
    move-result p2

    .line 365
    if-nez p2, :cond_14

    .line 366
    .line 367
    invoke-virtual {p1, p3}, Landroid/view/View;->setEnabled(Z)V

    .line 368
    .line 369
    .line 370
    :cond_14
    invoke-virtual {p0, p3, v4}, Lcom/google/android/material/textfield/TextInputLayout;->H(ZZ)V

    .line 371
    .line 372
    .line 373
    goto :goto_4

    .line 374
    :cond_15
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 375
    .line 376
    const-string p2, "We already have an EditText, can only have one"

    .line 377
    .line 378
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 379
    .line 380
    .line 381
    throw p1

    .line 382
    :cond_16
    invoke-super {p0, p1, p2, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 383
    .line 384
    .line 385
    :goto_4
    return-void
.end method

.method public final d()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 2
    .line 3
    iget v1, v0, La/A7;->K:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-ne v1, v2, :cond_0

    .line 7
    .line 8
    iget-object v1, v0, La/A7;->d:La/c8;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, La/A7;->R:Ljava/lang/CharSequence;

    .line 13
    .line 14
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v2, 0x0

    .line 22
    :goto_0
    return v2
.end method

.method public final dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->f:Ljava/lang/CharSequence;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_1

    .line 13
    .line 14
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->N:Z

    .line 15
    .line 16
    iput-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->N:Z

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/widget/TextView;->getHint()Ljava/lang/CharSequence;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 23
    .line 24
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->f:Ljava/lang/CharSequence;

    .line 25
    .line 26
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 27
    .line 28
    .line 29
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 33
    .line 34
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 35
    .line 36
    .line 37
    iput-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->N:Z

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 42
    .line 43
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 44
    .line 45
    .line 46
    iput-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->N:Z

    .line 47
    .line 48
    throw p1

    .line 49
    :cond_1
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getAutofillId()Landroid/view/autofill/AutofillId;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {p1, v0}, Landroid/view/ViewStructure;->setAutofillId(Landroid/view/autofill/AutofillId;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0, p1, p2}, Landroid/widget/LinearLayout;->onProvideAutofillStructure(Landroid/view/ViewStructure;I)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0, p1, p2}, Landroid/widget/LinearLayout;->onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V

    .line 60
    .line 61
    .line 62
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 63
    .line 64
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    invoke-virtual {p1, v1}, Landroid/view/ViewStructure;->setChildCount(I)V

    .line 69
    .line 70
    .line 71
    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    if-ge v2, v1, :cond_4

    .line 76
    .line 77
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-virtual {p1, v2}, Landroid/view/ViewStructure;->newChild(I)Landroid/view/ViewStructure;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-virtual {v1, v3, p2}, Landroid/view/View;->dispatchProvideAutofillStructure(Landroid/view/ViewStructure;I)V

    .line 86
    .line 87
    .line 88
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 89
    .line 90
    if-ne v1, v4, :cond_3

    .line 91
    .line 92
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 93
    .line 94
    if-eqz v1, :cond_2

    .line 95
    .line 96
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_2
    const/4 v1, 0x0

    .line 100
    :goto_1
    invoke-virtual {v3, v1}, Landroid/view/ViewStructure;->setHint(Ljava/lang/CharSequence;)V

    .line 101
    .line 102
    .line 103
    :cond_3
    add-int/lit8 v2, v2, 0x1

    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_4
    :goto_2
    return-void
.end method

.method public final dispatchRestoreInstanceState(Landroid/util/SparseArray;)V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->sH:Z

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->dispatchRestoreInstanceState(Landroid/util/SparseArray;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->sH:Z

    return-void
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v8, p1

    .line 4
    .line 5
    invoke-super/range {p0 .. p1}, Landroid/widget/LinearLayout;->draw(Landroid/graphics/Canvas;)V

    .line 6
    .line 7
    .line 8
    iget-boolean v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 9
    .line 10
    iget-object v9, v0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 11
    .line 12
    if-eqz v1, :cond_7

    .line 13
    .line 14
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 18
    .line 19
    .line 20
    move-result v10

    .line 21
    iget-object v1, v9, La/W5;->P:Ljava/lang/CharSequence;

    .line 22
    .line 23
    if-eqz v1, :cond_7

    .line 24
    .line 25
    iget-object v1, v9, La/W5;->i:Landroid/graphics/RectF;

    .line 26
    .line 27
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    const/4 v3, 0x0

    .line 32
    cmpl-float v2, v2, v3

    .line 33
    .line 34
    if-lez v2, :cond_7

    .line 35
    .line 36
    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    cmpl-float v1, v1, v3

    .line 41
    .line 42
    if-lez v1, :cond_7

    .line 43
    .line 44
    iget-object v11, v9, La/W5;->x:Landroid/text/TextPaint;

    .line 45
    .line 46
    iget v1, v9, La/W5;->k:F

    .line 47
    .line 48
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 49
    .line 50
    .line 51
    iget v1, v9, La/W5;->R:F

    .line 52
    .line 53
    iget v2, v9, La/W5;->L:F

    .line 54
    .line 55
    iget v3, v9, La/W5;->U:F

    .line 56
    .line 57
    const/high16 v4, 0x3f800000    # 1.0f

    .line 58
    .line 59
    cmpl-float v4, v3, v4

    .line 60
    .line 61
    if-eqz v4, :cond_0

    .line 62
    .line 63
    invoke-virtual {v8, v3, v3, v1, v2}, Landroid/graphics/Canvas;->scale(FFFF)V

    .line 64
    .line 65
    .line 66
    :cond_0
    iget v3, v9, La/W5;->F9:I

    .line 67
    .line 68
    const/4 v12, 0x1

    .line 69
    if-le v3, v12, :cond_6

    .line 70
    .line 71
    iget-boolean v3, v9, La/W5;->D:Z

    .line 72
    .line 73
    if-eqz v3, :cond_1

    .line 74
    .line 75
    goto/16 :goto_2

    .line 76
    .line 77
    :cond_1
    iget v1, v9, La/W5;->R:F

    .line 78
    .line 79
    iget-object v3, v9, La/W5;->Pc:Landroid/text/StaticLayout;

    .line 80
    .line 81
    const/4 v13, 0x0

    .line 82
    invoke-virtual {v3, v13}, Landroid/text/StaticLayout;->getLineStart(I)I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    int-to-float v3, v3

    .line 87
    sub-float/2addr v1, v3

    .line 88
    invoke-virtual {v11}, Landroid/graphics/Paint;->getAlpha()I

    .line 89
    .line 90
    .line 91
    move-result v14

    .line 92
    invoke-virtual {v8, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 93
    .line 94
    .line 95
    iget v1, v9, La/W5;->rC:F

    .line 96
    .line 97
    int-to-float v2, v14

    .line 98
    mul-float/2addr v1, v2

    .line 99
    float-to-int v1, v1

    .line 100
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 101
    .line 102
    .line 103
    sget v15, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 104
    .line 105
    const/16 v7, 0x1f

    .line 106
    .line 107
    if-lt v15, v7, :cond_2

    .line 108
    .line 109
    iget v1, v9, La/W5;->v:F

    .line 110
    .line 111
    iget v3, v9, La/W5;->s:F

    .line 112
    .line 113
    iget v4, v9, La/W5;->j:F

    .line 114
    .line 115
    iget v5, v9, La/W5;->t:I

    .line 116
    .line 117
    invoke-virtual {v11}, Landroid/graphics/Paint;->getAlpha()I

    .line 118
    .line 119
    .line 120
    move-result v6

    .line 121
    invoke-static {v5}, Landroid/graphics/Color;->alpha(I)I

    .line 122
    .line 123
    .line 124
    move-result v16

    .line 125
    mul-int v6, v6, v16

    .line 126
    .line 127
    div-int/lit16 v6, v6, 0xff

    .line 128
    .line 129
    invoke-static {v5, v6}, La/zB;->e(II)I

    .line 130
    .line 131
    .line 132
    move-result v5

    .line 133
    invoke-virtual {v11, v1, v3, v4, v5}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 134
    .line 135
    .line 136
    :cond_2
    iget-object v1, v9, La/W5;->Pc:Landroid/text/StaticLayout;

    .line 137
    .line 138
    invoke-virtual {v1, v8}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    .line 139
    .line 140
    .line 141
    iget v1, v9, La/W5;->rV:F

    .line 142
    .line 143
    mul-float/2addr v1, v2

    .line 144
    float-to-int v1, v1

    .line 145
    invoke-virtual {v11, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 146
    .line 147
    .line 148
    if-lt v15, v7, :cond_3

    .line 149
    .line 150
    iget v1, v9, La/W5;->v:F

    .line 151
    .line 152
    iget v2, v9, La/W5;->s:F

    .line 153
    .line 154
    iget v3, v9, La/W5;->j:F

    .line 155
    .line 156
    iget v4, v9, La/W5;->t:I

    .line 157
    .line 158
    invoke-virtual {v11}, Landroid/graphics/Paint;->getAlpha()I

    .line 159
    .line 160
    .line 161
    move-result v5

    .line 162
    invoke-static {v4}, Landroid/graphics/Color;->alpha(I)I

    .line 163
    .line 164
    .line 165
    move-result v6

    .line 166
    mul-int/2addr v6, v5

    .line 167
    div-int/lit16 v6, v6, 0xff

    .line 168
    .line 169
    invoke-static {v4, v6}, La/zB;->e(II)I

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    invoke-virtual {v11, v1, v2, v3, v4}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 174
    .line 175
    .line 176
    :cond_3
    iget-object v1, v9, La/W5;->Pc:Landroid/text/StaticLayout;

    .line 177
    .line 178
    invoke-virtual {v1, v13}, Landroid/text/Layout;->getLineBaseline(I)I

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    iget-object v2, v9, La/W5;->p7:Ljava/lang/CharSequence;

    .line 183
    .line 184
    const/4 v3, 0x0

    .line 185
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 186
    .line 187
    .line 188
    move-result v4

    .line 189
    const/4 v5, 0x0

    .line 190
    int-to-float v6, v1

    .line 191
    move-object/from16 v1, p1

    .line 192
    .line 193
    move/from16 v16, v6

    .line 194
    .line 195
    move v13, v7

    .line 196
    move-object v7, v11

    .line 197
    invoke-virtual/range {v1 .. v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/CharSequence;IIFFLandroid/graphics/Paint;)V

    .line 198
    .line 199
    .line 200
    if-lt v15, v13, :cond_4

    .line 201
    .line 202
    iget v1, v9, La/W5;->v:F

    .line 203
    .line 204
    iget v2, v9, La/W5;->s:F

    .line 205
    .line 206
    iget v3, v9, La/W5;->j:F

    .line 207
    .line 208
    iget v4, v9, La/W5;->t:I

    .line 209
    .line 210
    invoke-virtual {v11, v1, v2, v3, v4}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 211
    .line 212
    .line 213
    :cond_4
    iget-object v1, v9, La/W5;->p7:Ljava/lang/CharSequence;

    .line 214
    .line 215
    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    const-string v2, "\u2026"

    .line 224
    .line 225
    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    if-eqz v2, :cond_5

    .line 230
    .line 231
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 232
    .line 233
    .line 234
    move-result v2

    .line 235
    sub-int/2addr v2, v12

    .line 236
    const/4 v3, 0x0

    .line 237
    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    :goto_0
    move-object v2, v1

    .line 242
    goto :goto_1

    .line 243
    :cond_5
    const/4 v3, 0x0

    .line 244
    goto :goto_0

    .line 245
    :goto_1
    invoke-virtual {v11, v14}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 246
    .line 247
    .line 248
    const/4 v4, 0x0

    .line 249
    iget-object v1, v9, La/W5;->Pc:Landroid/text/StaticLayout;

    .line 250
    .line 251
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineEnd(I)I

    .line 252
    .line 253
    .line 254
    move-result v1

    .line 255
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 256
    .line 257
    .line 258
    move-result v3

    .line 259
    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    .line 260
    .line 261
    .line 262
    move-result v5

    .line 263
    const/4 v6, 0x0

    .line 264
    move-object/from16 v1, p1

    .line 265
    .line 266
    move v3, v4

    .line 267
    move v4, v5

    .line 268
    move v5, v6

    .line 269
    move/from16 v6, v16

    .line 270
    .line 271
    move-object v7, v11

    .line 272
    invoke-virtual/range {v1 .. v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;IIFFLandroid/graphics/Paint;)V

    .line 273
    .line 274
    .line 275
    goto :goto_3

    .line 276
    :cond_6
    :goto_2
    invoke-virtual {v8, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 277
    .line 278
    .line 279
    iget-object v1, v9, La/W5;->Pc:Landroid/text/StaticLayout;

    .line 280
    .line 281
    invoke-virtual {v1, v8}, Landroid/text/Layout;->draw(Landroid/graphics/Canvas;)V

    .line 282
    .line 283
    .line 284
    :goto_3
    invoke-virtual {v8, v10}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 285
    .line 286
    .line 287
    :cond_7
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 288
    .line 289
    if-eqz v1, :cond_8

    .line 290
    .line 291
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 292
    .line 293
    if-eqz v1, :cond_8

    .line 294
    .line 295
    invoke-virtual {v1, v8}, La/ex;->draw(Landroid/graphics/Canvas;)V

    .line 296
    .line 297
    .line 298
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 299
    .line 300
    invoke-virtual {v1}, Landroid/view/View;->isFocused()Z

    .line 301
    .line 302
    .line 303
    move-result v1

    .line 304
    if-eqz v1, :cond_8

    .line 305
    .line 306
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 307
    .line 308
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 309
    .line 310
    .line 311
    move-result-object v1

    .line 312
    iget-object v2, v0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 313
    .line 314
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 315
    .line 316
    .line 317
    move-result-object v2

    .line 318
    iget v3, v9, La/W5;->h:F

    .line 319
    .line 320
    invoke-virtual {v2}, Landroid/graphics/Rect;->centerX()I

    .line 321
    .line 322
    .line 323
    move-result v4

    .line 324
    iget v5, v2, Landroid/graphics/Rect;->left:I

    .line 325
    .line 326
    invoke-static {v4, v5, v3}, La/FP;->p(IIF)I

    .line 327
    .line 328
    .line 329
    move-result v5

    .line 330
    iput v5, v1, Landroid/graphics/Rect;->left:I

    .line 331
    .line 332
    iget v2, v2, Landroid/graphics/Rect;->right:I

    .line 333
    .line 334
    invoke-static {v4, v2, v3}, La/FP;->p(IIF)I

    .line 335
    .line 336
    .line 337
    move-result v2

    .line 338
    iput v2, v1, Landroid/graphics/Rect;->right:I

    .line 339
    .line 340
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 341
    .line 342
    invoke-virtual {v1, v8}, La/ex;->draw(Landroid/graphics/Canvas;)V

    .line 343
    .line 344
    .line 345
    :cond_8
    return-void
.end method

.method public final drawableStateChanged()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->au:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->au:Z

    .line 8
    .line 9
    invoke-super {p0}, Landroid/widget/LinearLayout;->drawableStateChanged()V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const/4 v2, 0x0

    .line 17
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 18
    .line 19
    if-eqz v3, :cond_3

    .line 20
    .line 21
    iput-object v1, v3, La/W5;->n:[I

    .line 22
    .line 23
    iget-object v1, v3, La/W5;->M:Landroid/content/res/ColorStateList;

    .line 24
    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_2

    .line 32
    .line 33
    :cond_1
    iget-object v1, v3, La/W5;->I:Landroid/content/res/ColorStateList;

    .line 34
    .line 35
    if-eqz v1, :cond_3

    .line 36
    .line 37
    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->isStateful()Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_3

    .line 42
    .line 43
    :cond_2
    invoke-virtual {v3, v2}, La/W5;->O(Z)V

    .line 44
    .line 45
    .line 46
    move v1, v0

    .line 47
    goto :goto_0

    .line 48
    :cond_3
    move v1, v2

    .line 49
    :goto_0
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 50
    .line 51
    if-eqz v3, :cond_5

    .line 52
    .line 53
    sget-object v3, La/sI;->w:Ljava/util/WeakHashMap;

    .line 54
    .line 55
    invoke-static {p0}, La/AM;->p(Landroid/view/View;)Z

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    if-eqz v3, :cond_4

    .line 60
    .line 61
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    if-eqz v3, :cond_4

    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_4
    move v0, v2

    .line 69
    :goto_1
    invoke-virtual {p0, v0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->H(ZZ)V

    .line 70
    .line 71
    .line 72
    :cond_5
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->F()V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 76
    .line 77
    .line 78
    if-eqz v1, :cond_6

    .line 79
    .line 80
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 81
    .line 82
    .line 83
    :cond_6
    iput-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->au:Z

    .line 84
    .line 85
    return-void
.end method

.method public final e()La/KF;
    .locals 4

    .line 1
    new-instance v0, La/KF;

    .line 2
    .line 3
    invoke-direct {v0}, La/SB;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x3

    .line 7
    iput v1, v0, La/KF;->n:I

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const v2, 0x7f040347

    .line 14
    .line 15
    .line 16
    const/16 v3, 0x57

    .line 17
    .line 18
    invoke-static {v1, v2, v3}, La/rx;->MX(Landroid/content/Context;II)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    int-to-long v1, v1

    .line 23
    iput-wide v1, v0, La/SB;->R:J

    .line 24
    .line 25
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    sget-object v2, La/FP;->w:Landroid/view/animation/LinearInterpolator;

    .line 30
    .line 31
    const v3, 0x7f040351

    .line 32
    .line 33
    .line 34
    invoke-static {v1, v3, v2}, La/rx;->cS(Landroid/content/Context;ILandroid/view/animation/Interpolator;)Landroid/animation/TimeInterpolator;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iput-object v1, v0, La/SB;->L:Landroid/animation/TimeInterpolator;

    .line 39
    .line 40
    return-object v0
.end method

.method public final f(Landroid/text/Editable;)V
    .locals 13

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->P:La/TD;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move p1, v0

    .line 15
    :goto_0
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 16
    .line 17
    iget v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    const/4 v4, -0x1

    .line 21
    if-ne v2, v4, :cond_1

    .line 22
    .line 23
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 24
    .line 25
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 33
    .line 34
    invoke-virtual {p1, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 35
    .line 36
    .line 37
    iput-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 38
    .line 39
    goto/16 :goto_b

    .line 40
    .line 41
    :cond_1
    const/4 v5, 0x1

    .line 42
    if-le p1, v2, :cond_2

    .line 43
    .line 44
    move v2, v5

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    move v2, v0

    .line 47
    :goto_1
    iput-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 48
    .line 49
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    iget-object v6, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 54
    .line 55
    iget v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 56
    .line 57
    iget-boolean v8, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 58
    .line 59
    if-eqz v8, :cond_3

    .line 60
    .line 61
    const v8, 0x7f120031

    .line 62
    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_3
    const v8, 0x7f120030

    .line 66
    .line 67
    .line 68
    :goto_2
    const/4 v9, 0x2

    .line 69
    new-array v10, v9, [Ljava/lang/Object;

    .line 70
    .line 71
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 72
    .line 73
    .line 74
    move-result-object v11

    .line 75
    aput-object v11, v10, v0

    .line 76
    .line 77
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    aput-object v7, v10, v5

    .line 82
    .line 83
    invoke-virtual {v2, v8, v10}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {v6, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 88
    .line 89
    .line 90
    iget-boolean v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 91
    .line 92
    if-eq v1, v2, :cond_4

    .line 93
    .line 94
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->l()V

    .line 95
    .line 96
    .line 97
    :cond_4
    sget-object v2, La/rj;->e:Ljava/lang/String;

    .line 98
    .line 99
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    sget v6, La/Ac;->w:I

    .line 104
    .line 105
    invoke-static {v2}, La/vE;->w(Ljava/util/Locale;)I

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    if-ne v2, v5, :cond_5

    .line 110
    .line 111
    sget-object v2, La/rj;->X:La/rj;

    .line 112
    .line 113
    goto :goto_3

    .line 114
    :cond_5
    sget-object v2, La/rj;->Q:La/rj;

    .line 115
    .line 116
    :goto_3
    iget-object v6, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    .line 117
    .line 118
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    new-array v8, v9, [Ljava/lang/Object;

    .line 123
    .line 124
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    aput-object p1, v8, v0

    .line 129
    .line 130
    iget p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->H:I

    .line 131
    .line 132
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    aput-object p1, v8, v5

    .line 137
    .line 138
    const p1, 0x7f120032

    .line 139
    .line 140
    .line 141
    invoke-virtual {v7, p1, v8}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    if-nez p1, :cond_6

    .line 149
    .line 150
    goto/16 :goto_a

    .line 151
    .line 152
    :cond_6
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 153
    .line 154
    .line 155
    move-result v3

    .line 156
    iget-object v7, v2, La/rj;->p:La/Jw;

    .line 157
    .line 158
    invoke-virtual {v7, p1, v3}, La/Jw;->h(Ljava/lang/CharSequence;I)Z

    .line 159
    .line 160
    .line 161
    move-result v3

    .line 162
    new-instance v7, Landroid/text/SpannableStringBuilder;

    .line 163
    .line 164
    invoke-direct {v7}, Landroid/text/SpannableStringBuilder;-><init>()V

    .line 165
    .line 166
    .line 167
    iget v8, v2, La/rj;->h:I

    .line 168
    .line 169
    and-int/2addr v8, v9

    .line 170
    sget-object v9, La/rj;->i:Ljava/lang/String;

    .line 171
    .line 172
    sget-object v10, La/rj;->e:Ljava/lang/String;

    .line 173
    .line 174
    const-string v11, ""

    .line 175
    .line 176
    iget-boolean v2, v2, La/rj;->w:Z

    .line 177
    .line 178
    if-eqz v8, :cond_c

    .line 179
    .line 180
    if-eqz v3, :cond_7

    .line 181
    .line 182
    sget-object v8, La/o2;->h:La/wh;

    .line 183
    .line 184
    goto :goto_4

    .line 185
    :cond_7
    sget-object v8, La/o2;->w:La/wh;

    .line 186
    .line 187
    :goto_4
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 188
    .line 189
    .line 190
    move-result v12

    .line 191
    invoke-virtual {v8, p1, v12}, La/Jw;->h(Ljava/lang/CharSequence;I)Z

    .line 192
    .line 193
    .line 194
    move-result v8

    .line 195
    if-nez v2, :cond_9

    .line 196
    .line 197
    if-nez v8, :cond_8

    .line 198
    .line 199
    invoke-static {p1}, La/rj;->w(Ljava/lang/String;)I

    .line 200
    .line 201
    .line 202
    move-result v12

    .line 203
    if-ne v12, v5, :cond_9

    .line 204
    .line 205
    :cond_8
    move-object v8, v10

    .line 206
    goto :goto_5

    .line 207
    :cond_9
    if-eqz v2, :cond_b

    .line 208
    .line 209
    if-eqz v8, :cond_a

    .line 210
    .line 211
    invoke-static {p1}, La/rj;->w(Ljava/lang/String;)I

    .line 212
    .line 213
    .line 214
    move-result v8

    .line 215
    if-ne v8, v4, :cond_b

    .line 216
    .line 217
    :cond_a
    move-object v8, v9

    .line 218
    goto :goto_5

    .line 219
    :cond_b
    move-object v8, v11

    .line 220
    :goto_5
    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 221
    .line 222
    .line 223
    :cond_c
    if-eq v3, v2, :cond_e

    .line 224
    .line 225
    if-eqz v3, :cond_d

    .line 226
    .line 227
    const/16 v8, 0x202b

    .line 228
    .line 229
    goto :goto_6

    .line 230
    :cond_d
    const/16 v8, 0x202a

    .line 231
    .line 232
    :goto_6
    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    .line 233
    .line 234
    .line 235
    invoke-virtual {v7, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 236
    .line 237
    .line 238
    const/16 v8, 0x202c

    .line 239
    .line 240
    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(C)Landroid/text/SpannableStringBuilder;

    .line 241
    .line 242
    .line 243
    goto :goto_7

    .line 244
    :cond_e
    invoke-virtual {v7, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 245
    .line 246
    .line 247
    :goto_7
    if-eqz v3, :cond_f

    .line 248
    .line 249
    sget-object v3, La/o2;->h:La/wh;

    .line 250
    .line 251
    goto :goto_8

    .line 252
    :cond_f
    sget-object v3, La/o2;->w:La/wh;

    .line 253
    .line 254
    :goto_8
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 255
    .line 256
    .line 257
    move-result v8

    .line 258
    invoke-virtual {v3, p1, v8}, La/Jw;->h(Ljava/lang/CharSequence;I)Z

    .line 259
    .line 260
    .line 261
    move-result v3

    .line 262
    if-nez v2, :cond_11

    .line 263
    .line 264
    if-nez v3, :cond_10

    .line 265
    .line 266
    invoke-static {p1}, La/rj;->h(Ljava/lang/String;)I

    .line 267
    .line 268
    .line 269
    move-result v8

    .line 270
    if-ne v8, v5, :cond_11

    .line 271
    .line 272
    :cond_10
    move-object v9, v10

    .line 273
    goto :goto_9

    .line 274
    :cond_11
    if-eqz v2, :cond_12

    .line 275
    .line 276
    if-eqz v3, :cond_13

    .line 277
    .line 278
    invoke-static {p1}, La/rj;->h(Ljava/lang/String;)I

    .line 279
    .line 280
    .line 281
    move-result p1

    .line 282
    if-ne p1, v4, :cond_12

    .line 283
    .line 284
    goto :goto_9

    .line 285
    :cond_12
    move-object v9, v11

    .line 286
    :cond_13
    :goto_9
    invoke-virtual {v7, v9}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 287
    .line 288
    .line 289
    invoke-virtual {v7}, Landroid/text/SpannableStringBuilder;->toString()Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v3

    .line 293
    :goto_a
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 294
    .line 295
    .line 296
    :goto_b
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 297
    .line 298
    if-eqz p1, :cond_14

    .line 299
    .line 300
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    .line 301
    .line 302
    if-eq v1, p1, :cond_14

    .line 303
    .line 304
    invoke-virtual {p0, v0, v0}, Lcom/google/android/material/textfield/TextInputLayout;->H(ZZ)V

    .line 305
    .line 306
    .line 307
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 308
    .line 309
    .line 310
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->F()V

    .line 311
    .line 312
    .line 313
    :cond_14
    return-void
.end method

.method public final getBaseline()I
    .locals 2

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getBaseline()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->p()I

    move-result v0

    add-int/2addr v0, v1

    return v0

    :cond_0
    invoke-super {p0}, Landroid/widget/LinearLayout;->getBaseline()I

    move-result v0

    return v0
.end method

.method public final h()V
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v1, v0, La/ex;->X:La/JP;

    .line 7
    .line 8
    iget-object v1, v1, La/JP;->w:La/c9;

    .line 9
    .line 10
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 11
    .line 12
    if-eq v1, v2, :cond_1

    .line 13
    .line 14
    invoke-virtual {v0, v2}, La/ex;->h(La/c9;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    const/4 v2, -0x1

    .line 21
    if-ne v0, v1, :cond_2

    .line 22
    .line 23
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 24
    .line 25
    if-le v0, v2, :cond_2

    .line 26
    .line 27
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 28
    .line 29
    if-eqz v1, :cond_2

    .line 30
    .line 31
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 32
    .line 33
    int-to-float v0, v0

    .line 34
    iget-object v4, v3, La/ex;->X:La/JP;

    .line 35
    .line 36
    iput v0, v4, La/JP;->M:F

    .line 37
    .line 38
    invoke-virtual {v3}, La/ex;->invalidateSelf()V

    .line 39
    .line 40
    .line 41
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iget-object v1, v3, La/ex;->X:La/JP;

    .line 46
    .line 47
    iget-object v4, v1, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 48
    .line 49
    if-eq v4, v0, :cond_2

    .line 50
    .line 51
    iput-object v0, v1, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 52
    .line 53
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v3, v0}, La/ex;->onStateChange([I)Z

    .line 58
    .line 59
    .line 60
    :cond_2
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 61
    .line 62
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 63
    .line 64
    const/4 v3, 0x1

    .line 65
    if-ne v1, v3, :cond_3

    .line 66
    .line 67
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    const v1, 0x7f04012d

    .line 72
    .line 73
    .line 74
    const/4 v3, 0x0

    .line 75
    invoke-static {v0, v1, v3}, La/rE;->g(Landroid/content/Context;II)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 80
    .line 81
    invoke-static {v1, v0}, La/zB;->h(II)I

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    :cond_3
    iput v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->xF:I

    .line 86
    .line 87
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 88
    .line 89
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-virtual {v1, v0}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 94
    .line 95
    .line 96
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 97
    .line 98
    if-eqz v0, :cond_7

    .line 99
    .line 100
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 101
    .line 102
    if-nez v1, :cond_4

    .line 103
    .line 104
    goto :goto_2

    .line 105
    :cond_4
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->ZU:I

    .line 106
    .line 107
    if-le v1, v2, :cond_6

    .line 108
    .line 109
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 110
    .line 111
    if-eqz v1, :cond_6

    .line 112
    .line 113
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 114
    .line 115
    invoke-virtual {v1}, Landroid/view/View;->isFocused()Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-eqz v1, :cond_5

    .line 120
    .line 121
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->C6:I

    .line 122
    .line 123
    :goto_0
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    goto :goto_1

    .line 128
    :cond_5
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 129
    .line 130
    goto :goto_0

    .line 131
    :goto_1
    invoke-virtual {v0, v1}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 132
    .line 133
    .line 134
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 135
    .line 136
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->y6:I

    .line 137
    .line 138
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 139
    .line 140
    .line 141
    move-result-object v1

    .line 142
    invoke-virtual {v0, v1}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 143
    .line 144
    .line 145
    :cond_6
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 146
    .line 147
    .line 148
    :cond_7
    :goto_2
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->E()V

    .line 149
    .line 150
    .line 151
    return-void
.end method

.method public final i()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->B:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    instance-of v0, v0, La/GP;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final l()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    if-eqz v0, :cond_2

    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    if-eqz v1, :cond_0

    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->u:I

    goto :goto_0

    :cond_0
    iget v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->U:I

    :goto_0
    invoke-virtual {p0, v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->L(Landroid/widget/TextView;I)V

    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->x:Landroid/content/res/ColorStateList;

    if-eqz v0, :cond_1

    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->z:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->g:Landroid/content/res/ColorStateList;

    if-eqz v0, :cond_2

    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->D:La/c8;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_2
    return-void
.end method

.method public final m(Z)V
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 2
    .line 3
    iget-boolean v1, v0, La/A7;->L:Z

    .line 4
    .line 5
    if-ne v1, p1, :cond_0

    .line 6
    .line 7
    goto :goto_1

    .line 8
    :cond_0
    invoke-virtual {v0}, La/A7;->p()V

    .line 9
    .line 10
    .line 11
    iget-object v1, v0, La/A7;->O:Lcom/google/android/material/textfield/TextInputLayout;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz p1, :cond_5

    .line 16
    .line 17
    new-instance v4, La/c8;

    .line 18
    .line 19
    iget-object v5, v0, La/A7;->X:Landroid/content/Context;

    .line 20
    .line 21
    invoke-direct {v4, v5, v3}, La/c8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 22
    .line 23
    .line 24
    iput-object v4, v0, La/A7;->d:La/c8;

    .line 25
    .line 26
    const v3, 0x7f09025d

    .line 27
    .line 28
    .line 29
    invoke-virtual {v4, v3}, Landroid/view/View;->setId(I)V

    .line 30
    .line 31
    .line 32
    iget-object v3, v0, La/A7;->d:La/c8;

    .line 33
    .line 34
    const/4 v4, 0x5

    .line 35
    invoke-virtual {v3, v4}, Landroid/view/View;->setTextAlignment(I)V

    .line 36
    .line 37
    .line 38
    iget v3, v0, La/A7;->W:I

    .line 39
    .line 40
    iput v3, v0, La/A7;->W:I

    .line 41
    .line 42
    iget-object v4, v0, La/A7;->d:La/c8;

    .line 43
    .line 44
    if-eqz v4, :cond_1

    .line 45
    .line 46
    invoke-virtual {v1, v4, v3}, Lcom/google/android/material/textfield/TextInputLayout;->L(Landroid/widget/TextView;I)V

    .line 47
    .line 48
    .line 49
    :cond_1
    iget-object v1, v0, La/A7;->q:Landroid/content/res/ColorStateList;

    .line 50
    .line 51
    iput-object v1, v0, La/A7;->q:Landroid/content/res/ColorStateList;

    .line 52
    .line 53
    iget-object v3, v0, La/A7;->d:La/c8;

    .line 54
    .line 55
    if-eqz v3, :cond_2

    .line 56
    .line 57
    if-eqz v1, :cond_2

    .line 58
    .line 59
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 60
    .line 61
    .line 62
    :cond_2
    iget-object v1, v0, La/A7;->f:Ljava/lang/CharSequence;

    .line 63
    .line 64
    iput-object v1, v0, La/A7;->f:Ljava/lang/CharSequence;

    .line 65
    .line 66
    iget-object v3, v0, La/A7;->d:La/c8;

    .line 67
    .line 68
    if-eqz v3, :cond_3

    .line 69
    .line 70
    invoke-virtual {v3, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 71
    .line 72
    .line 73
    :cond_3
    iget v1, v0, La/A7;->l:I

    .line 74
    .line 75
    iput v1, v0, La/A7;->l:I

    .line 76
    .line 77
    iget-object v3, v0, La/A7;->d:La/c8;

    .line 78
    .line 79
    if-eqz v3, :cond_4

    .line 80
    .line 81
    sget-object v4, La/sI;->w:Ljava/util/WeakHashMap;

    .line 82
    .line 83
    invoke-static {v3, v1}, La/AM;->Q(Landroid/view/View;I)V

    .line 84
    .line 85
    .line 86
    :cond_4
    iget-object v1, v0, La/A7;->d:La/c8;

    .line 87
    .line 88
    const/4 v3, 0x4

    .line 89
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 90
    .line 91
    .line 92
    iget-object v1, v0, La/A7;->d:La/c8;

    .line 93
    .line 94
    invoke-virtual {v0, v1, v2}, La/A7;->w(Landroid/widget/TextView;I)V

    .line 95
    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_5
    invoke-virtual {v0}, La/A7;->Q()V

    .line 99
    .line 100
    .line 101
    iget-object v4, v0, La/A7;->d:La/c8;

    .line 102
    .line 103
    invoke-virtual {v0, v4, v2}, La/A7;->X(Landroid/widget/TextView;I)V

    .line 104
    .line 105
    .line 106
    iput-object v3, v0, La/A7;->d:La/c8;

    .line 107
    .line 108
    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputLayout;->F()V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 112
    .line 113
    .line 114
    :goto_0
    iput-boolean p1, v0, La/A7;->L:Z

    .line 115
    .line 116
    :goto_1
    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    invoke-virtual {v0, p1}, La/W5;->X(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public final onGlobalLayout()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Qn:Z

    .line 12
    .line 13
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 14
    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 23
    .line 24
    invoke-virtual {v2}, Landroid/view/View;->getMeasuredHeight()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 33
    .line 34
    invoke-virtual {v2}, Landroid/view/View;->getMeasuredHeight()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-ge v2, v0, :cond_1

    .line 39
    .line 40
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 41
    .line 42
    invoke-virtual {v1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    .line 43
    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    :cond_1
    :goto_0
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->q()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v1, :cond_2

    .line 51
    .line 52
    if-eqz v0, :cond_3

    .line 53
    .line 54
    :cond_2
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 55
    .line 56
    new-instance v1, La/xp;

    .line 57
    .line 58
    const/16 v2, 0x10

    .line 59
    .line 60
    invoke-direct {v1, v2, p0}, La/xp;-><init>(ILjava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 64
    .line 65
    .line 66
    :cond_3
    return-void
.end method

.method public final onLayout(ZIIII)V
    .locals 6

    .line 1
    invoke-super/range {p0 .. p5}, Landroid/widget/LinearLayout;->onLayout(ZIIII)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 5
    .line 6
    if-eqz p1, :cond_d

    .line 7
    .line 8
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Pb:Landroid/graphics/Rect;

    .line 9
    .line 10
    invoke-static {p0, p1, p2}, La/Bn;->w(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->FL:La/ex;

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    iget p3, p2, Landroid/graphics/Rect;->bottom:I

    .line 18
    .line 19
    iget p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->rZ:I

    .line 20
    .line 21
    sub-int p4, p3, p4

    .line 22
    .line 23
    iget p5, p2, Landroid/graphics/Rect;->left:I

    .line 24
    .line 25
    iget v0, p2, Landroid/graphics/Rect;->right:I

    .line 26
    .line 27
    invoke-virtual {p1, p5, p4, v0, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 28
    .line 29
    .line 30
    :cond_0
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->rV:La/ex;

    .line 31
    .line 32
    if-eqz p1, :cond_1

    .line 33
    .line 34
    iget p3, p2, Landroid/graphics/Rect;->bottom:I

    .line 35
    .line 36
    iget p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->B1:I

    .line 37
    .line 38
    sub-int p4, p3, p4

    .line 39
    .line 40
    iget p5, p2, Landroid/graphics/Rect;->left:I

    .line 41
    .line 42
    iget v0, p2, Landroid/graphics/Rect;->right:I

    .line 43
    .line 44
    invoke-virtual {p1, p5, p4, v0, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 45
    .line 46
    .line 47
    :cond_1
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    .line 48
    .line 49
    if-eqz p1, :cond_d

    .line 50
    .line 51
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 52
    .line 53
    invoke-virtual {p1}, Landroid/widget/TextView;->getTextSize()F

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    iget-object p3, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 58
    .line 59
    iget p4, p3, La/W5;->O:F

    .line 60
    .line 61
    cmpl-float p4, p4, p1

    .line 62
    .line 63
    const/4 p5, 0x0

    .line 64
    if-eqz p4, :cond_2

    .line 65
    .line 66
    iput p1, p3, La/W5;->O:F

    .line 67
    .line 68
    invoke-virtual {p3, p5}, La/W5;->O(Z)V

    .line 69
    .line 70
    .line 71
    :cond_2
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 72
    .line 73
    invoke-virtual {p1}, Landroid/widget/TextView;->getGravity()I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    and-int/lit8 p4, p1, -0x71

    .line 78
    .line 79
    or-int/lit8 p4, p4, 0x30

    .line 80
    .line 81
    iget v0, p3, La/W5;->X:I

    .line 82
    .line 83
    if-eq v0, p4, :cond_3

    .line 84
    .line 85
    iput p4, p3, La/W5;->X:I

    .line 86
    .line 87
    invoke-virtual {p3, p5}, La/W5;->O(Z)V

    .line 88
    .line 89
    .line 90
    :cond_3
    iget p4, p3, La/W5;->Q:I

    .line 91
    .line 92
    if-eq p4, p1, :cond_4

    .line 93
    .line 94
    iput p1, p3, La/W5;->Q:I

    .line 95
    .line 96
    invoke-virtual {p3, p5}, La/W5;->O(Z)V

    .line 97
    .line 98
    .line 99
    :cond_4
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 100
    .line 101
    if-eqz p1, :cond_c

    .line 102
    .line 103
    invoke-static {p0}, La/rE;->lI(Landroid/view/View;)Z

    .line 104
    .line 105
    .line 106
    move-result p1

    .line 107
    iget p4, p2, Landroid/graphics/Rect;->bottom:I

    .line 108
    .line 109
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->lI:Landroid/graphics/Rect;

    .line 110
    .line 111
    iput p4, v0, Landroid/graphics/Rect;->bottom:I

    .line 112
    .line 113
    iget p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 114
    .line 115
    const/4 v1, 0x1

    .line 116
    if-eq p4, v1, :cond_6

    .line 117
    .line 118
    const/4 v2, 0x2

    .line 119
    if-eq p4, v2, :cond_5

    .line 120
    .line 121
    iget p4, p2, Landroid/graphics/Rect;->left:I

    .line 122
    .line 123
    invoke-virtual {p0, p4, p1}, Lcom/google/android/material/textfield/TextInputLayout;->X(IZ)I

    .line 124
    .line 125
    .line 126
    move-result p4

    .line 127
    iput p4, v0, Landroid/graphics/Rect;->left:I

    .line 128
    .line 129
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 130
    .line 131
    .line 132
    move-result p4

    .line 133
    :goto_0
    iput p4, v0, Landroid/graphics/Rect;->top:I

    .line 134
    .line 135
    iget p4, p2, Landroid/graphics/Rect;->right:I

    .line 136
    .line 137
    invoke-virtual {p0, p4, p1}, Lcom/google/android/material/textfield/TextInputLayout;->O(IZ)I

    .line 138
    .line 139
    .line 140
    move-result p1

    .line 141
    :goto_1
    iput p1, v0, Landroid/graphics/Rect;->right:I

    .line 142
    .line 143
    goto :goto_2

    .line 144
    :cond_5
    iget p1, p2, Landroid/graphics/Rect;->left:I

    .line 145
    .line 146
    iget-object p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 147
    .line 148
    invoke-virtual {p4}, Landroid/view/View;->getPaddingLeft()I

    .line 149
    .line 150
    .line 151
    move-result p4

    .line 152
    add-int/2addr p4, p1

    .line 153
    iput p4, v0, Landroid/graphics/Rect;->left:I

    .line 154
    .line 155
    iget p1, p2, Landroid/graphics/Rect;->top:I

    .line 156
    .line 157
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->p()I

    .line 158
    .line 159
    .line 160
    move-result p4

    .line 161
    sub-int/2addr p1, p4

    .line 162
    iput p1, v0, Landroid/graphics/Rect;->top:I

    .line 163
    .line 164
    iget p1, p2, Landroid/graphics/Rect;->right:I

    .line 165
    .line 166
    iget-object p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 167
    .line 168
    invoke-virtual {p4}, Landroid/view/View;->getPaddingRight()I

    .line 169
    .line 170
    .line 171
    move-result p4

    .line 172
    sub-int/2addr p1, p4

    .line 173
    goto :goto_1

    .line 174
    :cond_6
    iget p4, p2, Landroid/graphics/Rect;->left:I

    .line 175
    .line 176
    invoke-virtual {p0, p4, p1}, Lcom/google/android/material/textfield/TextInputLayout;->X(IZ)I

    .line 177
    .line 178
    .line 179
    move-result p4

    .line 180
    iput p4, v0, Landroid/graphics/Rect;->left:I

    .line 181
    .line 182
    iget p4, p2, Landroid/graphics/Rect;->top:I

    .line 183
    .line 184
    iget v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->mh:I

    .line 185
    .line 186
    add-int/2addr p4, v2

    .line 187
    goto :goto_0

    .line 188
    :goto_2
    iget p1, v0, Landroid/graphics/Rect;->left:I

    .line 189
    .line 190
    iget p4, v0, Landroid/graphics/Rect;->top:I

    .line 191
    .line 192
    iget v2, v0, Landroid/graphics/Rect;->right:I

    .line 193
    .line 194
    iget v3, v0, Landroid/graphics/Rect;->bottom:I

    .line 195
    .line 196
    iget-object v4, p3, La/W5;->e:Landroid/graphics/Rect;

    .line 197
    .line 198
    iget v5, v4, Landroid/graphics/Rect;->left:I

    .line 199
    .line 200
    if-ne v5, p1, :cond_7

    .line 201
    .line 202
    iget v5, v4, Landroid/graphics/Rect;->top:I

    .line 203
    .line 204
    if-ne v5, p4, :cond_7

    .line 205
    .line 206
    iget v5, v4, Landroid/graphics/Rect;->right:I

    .line 207
    .line 208
    if-ne v5, v2, :cond_7

    .line 209
    .line 210
    iget v5, v4, Landroid/graphics/Rect;->bottom:I

    .line 211
    .line 212
    if-ne v5, v3, :cond_7

    .line 213
    .line 214
    goto :goto_3

    .line 215
    :cond_7
    invoke-virtual {v4, p1, p4, v2, v3}, Landroid/graphics/Rect;->set(IIII)V

    .line 216
    .line 217
    .line 218
    iput-boolean v1, p3, La/W5;->C:Z

    .line 219
    .line 220
    :goto_3
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 221
    .line 222
    if-eqz p1, :cond_b

    .line 223
    .line 224
    iget-object p1, p3, La/W5;->g:Landroid/text/TextPaint;

    .line 225
    .line 226
    iget p4, p3, La/W5;->O:F

    .line 227
    .line 228
    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 229
    .line 230
    .line 231
    iget-object p4, p3, La/W5;->W:Landroid/graphics/Typeface;

    .line 232
    .line 233
    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 234
    .line 235
    .line 236
    iget p4, p3, La/W5;->J:F

    .line 237
    .line 238
    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {p1}, Landroid/graphics/Paint;->ascent()F

    .line 242
    .line 243
    .line 244
    move-result p1

    .line 245
    neg-float p1, p1

    .line 246
    iget p4, p2, Landroid/graphics/Rect;->left:I

    .line 247
    .line 248
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 249
    .line 250
    invoke-virtual {v2}, Landroid/widget/TextView;->getCompoundPaddingLeft()I

    .line 251
    .line 252
    .line 253
    move-result v2

    .line 254
    add-int/2addr v2, p4

    .line 255
    iput v2, v0, Landroid/graphics/Rect;->left:I

    .line 256
    .line 257
    iget p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 258
    .line 259
    if-ne p4, v1, :cond_8

    .line 260
    .line 261
    iget-object p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 262
    .line 263
    invoke-virtual {p4}, Landroid/widget/TextView;->getMinLines()I

    .line 264
    .line 265
    .line 266
    move-result p4

    .line 267
    if-gt p4, v1, :cond_8

    .line 268
    .line 269
    invoke-virtual {p2}, Landroid/graphics/Rect;->centerY()I

    .line 270
    .line 271
    .line 272
    move-result p4

    .line 273
    int-to-float p4, p4

    .line 274
    const/high16 v2, 0x40000000    # 2.0f

    .line 275
    .line 276
    div-float v2, p1, v2

    .line 277
    .line 278
    sub-float/2addr p4, v2

    .line 279
    float-to-int p4, p4

    .line 280
    goto :goto_4

    .line 281
    :cond_8
    iget p4, p2, Landroid/graphics/Rect;->top:I

    .line 282
    .line 283
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 284
    .line 285
    invoke-virtual {v2}, Landroid/widget/TextView;->getCompoundPaddingTop()I

    .line 286
    .line 287
    .line 288
    move-result v2

    .line 289
    add-int/2addr p4, v2

    .line 290
    :goto_4
    iput p4, v0, Landroid/graphics/Rect;->top:I

    .line 291
    .line 292
    iget p4, p2, Landroid/graphics/Rect;->right:I

    .line 293
    .line 294
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 295
    .line 296
    invoke-virtual {v2}, Landroid/widget/TextView;->getCompoundPaddingRight()I

    .line 297
    .line 298
    .line 299
    move-result v2

    .line 300
    sub-int/2addr p4, v2

    .line 301
    iput p4, v0, Landroid/graphics/Rect;->right:I

    .line 302
    .line 303
    iget p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 304
    .line 305
    if-ne p4, v1, :cond_9

    .line 306
    .line 307
    iget-object p4, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 308
    .line 309
    invoke-virtual {p4}, Landroid/widget/TextView;->getMinLines()I

    .line 310
    .line 311
    .line 312
    move-result p4

    .line 313
    if-gt p4, v1, :cond_9

    .line 314
    .line 315
    iget p2, v0, Landroid/graphics/Rect;->top:I

    .line 316
    .line 317
    int-to-float p2, p2

    .line 318
    add-float/2addr p2, p1

    .line 319
    float-to-int p1, p2

    .line 320
    goto :goto_5

    .line 321
    :cond_9
    iget p1, p2, Landroid/graphics/Rect;->bottom:I

    .line 322
    .line 323
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 324
    .line 325
    invoke-virtual {p2}, Landroid/widget/TextView;->getCompoundPaddingBottom()I

    .line 326
    .line 327
    .line 328
    move-result p2

    .line 329
    sub-int/2addr p1, p2

    .line 330
    :goto_5
    iput p1, v0, Landroid/graphics/Rect;->bottom:I

    .line 331
    .line 332
    iget p2, v0, Landroid/graphics/Rect;->left:I

    .line 333
    .line 334
    iget p4, v0, Landroid/graphics/Rect;->top:I

    .line 335
    .line 336
    iget v0, v0, Landroid/graphics/Rect;->right:I

    .line 337
    .line 338
    iget-object v2, p3, La/W5;->p:Landroid/graphics/Rect;

    .line 339
    .line 340
    iget v3, v2, Landroid/graphics/Rect;->left:I

    .line 341
    .line 342
    if-ne v3, p2, :cond_a

    .line 343
    .line 344
    iget v3, v2, Landroid/graphics/Rect;->top:I

    .line 345
    .line 346
    if-ne v3, p4, :cond_a

    .line 347
    .line 348
    iget v3, v2, Landroid/graphics/Rect;->right:I

    .line 349
    .line 350
    if-ne v3, v0, :cond_a

    .line 351
    .line 352
    iget v3, v2, Landroid/graphics/Rect;->bottom:I

    .line 353
    .line 354
    if-ne v3, p1, :cond_a

    .line 355
    .line 356
    goto :goto_6

    .line 357
    :cond_a
    invoke-virtual {v2, p2, p4, v0, p1}, Landroid/graphics/Rect;->set(IIII)V

    .line 358
    .line 359
    .line 360
    iput-boolean v1, p3, La/W5;->C:Z

    .line 361
    .line 362
    :goto_6
    invoke-virtual {p3, p5}, La/W5;->O(Z)V

    .line 363
    .line 364
    .line 365
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->i()Z

    .line 366
    .line 367
    .line 368
    move-result p1

    .line 369
    if-eqz p1, :cond_d

    .line 370
    .line 371
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 372
    .line 373
    if-nez p1, :cond_d

    .line 374
    .line 375
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->I()V

    .line 376
    .line 377
    .line 378
    goto :goto_7

    .line 379
    :cond_b
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 380
    .line 381
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 382
    .line 383
    .line 384
    throw p1

    .line 385
    :cond_c
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 386
    .line 387
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 388
    .line 389
    .line 390
    throw p1

    .line 391
    :cond_d
    :goto_7
    return-void
.end method

.method public final onMeasure(II)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Qn:Z

    .line 5
    .line 6
    iget-object p2, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 7
    .line 8
    if-nez p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p2}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 15
    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    iput-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Qn:Z

    .line 19
    .line 20
    :cond_0
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 21
    .line 22
    if-eqz p1, :cond_1

    .line 23
    .line 24
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 25
    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p1}, Landroid/widget/TextView;->getGravity()I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 33
    .line 34
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setGravity(I)V

    .line 35
    .line 36
    .line 37
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 38
    .line 39
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 40
    .line 41
    invoke-virtual {v0}, Landroid/widget/TextView;->getCompoundPaddingLeft()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 46
    .line 47
    invoke-virtual {v1}, Landroid/widget/TextView;->getCompoundPaddingTop()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 52
    .line 53
    invoke-virtual {v2}, Landroid/widget/TextView;->getCompoundPaddingRight()I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 58
    .line 59
    invoke-virtual {v3}, Landroid/widget/TextView;->getCompoundPaddingBottom()I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 64
    .line 65
    .line 66
    :cond_1
    invoke-virtual {p2}, La/h9;->T()V

    .line 67
    .line 68
    .line 69
    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    .line 1
    instance-of v0, p1, La/qp;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, La/qp;

    .line 10
    .line 11
    iget-object v0, p1, La/o;->X:Landroid/os/Parcelable;

    .line 12
    .line 13
    invoke-super {p0, v0}, Landroid/widget/LinearLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p1, La/qp;->R:Ljava/lang/CharSequence;

    .line 17
    .line 18
    invoke-virtual {p0, v0}, Lcom/google/android/material/textfield/TextInputLayout;->T(Ljava/lang/CharSequence;)V

    .line 19
    .line 20
    .line 21
    iget-boolean p1, p1, La/qp;->L:Z

    .line 22
    .line 23
    if-eqz p1, :cond_1

    .line 24
    .line 25
    new-instance p1, La/oE;

    .line 26
    .line 27
    const/16 v0, 0xc

    .line 28
    .line 29
    invoke-direct {p1, v0, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 33
    .line 34
    .line 35
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final onRtlPropertiesChanged(I)V
    .locals 13

    .line 1
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onRtlPropertiesChanged(I)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    if-ne p1, v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->p7:Z

    .line 10
    .line 11
    if-eq v0, p1, :cond_1

    .line 12
    .line 13
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 14
    .line 15
    iget-object p1, p1, La/c9;->i:La/cv;

    .line 16
    .line 17
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->VQ:Landroid/graphics/RectF;

    .line 18
    .line 19
    invoke-interface {p1, v1}, La/cv;->w(Landroid/graphics/RectF;)F

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 24
    .line 25
    iget-object v2, v2, La/c9;->Q:La/cv;

    .line 26
    .line 27
    invoke-interface {v2, v1}, La/cv;->w(Landroid/graphics/RectF;)F

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 32
    .line 33
    iget-object v3, v3, La/c9;->O:La/cv;

    .line 34
    .line 35
    invoke-interface {v3, v1}, La/cv;->w(Landroid/graphics/RectF;)F

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 40
    .line 41
    iget-object v4, v4, La/c9;->X:La/cv;

    .line 42
    .line 43
    invoke-interface {v4, v1}, La/cv;->w(Landroid/graphics/RectF;)F

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 48
    .line 49
    iget-object v5, v4, La/c9;->w:La/TZ;

    .line 50
    .line 51
    iget-object v6, v4, La/c9;->h:La/TZ;

    .line 52
    .line 53
    iget-object v7, v4, La/c9;->e:La/TZ;

    .line 54
    .line 55
    iget-object v4, v4, La/c9;->p:La/TZ;

    .line 56
    .line 57
    invoke-static {}, La/rx;->f()La/eI;

    .line 58
    .line 59
    .line 60
    move-result-object v8

    .line 61
    invoke-static {}, La/rx;->f()La/eI;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    invoke-static {}, La/rx;->f()La/eI;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    invoke-static {}, La/rx;->f()La/eI;

    .line 70
    .line 71
    .line 72
    move-result-object v11

    .line 73
    invoke-static {v6}, La/as;->h(La/TZ;)V

    .line 74
    .line 75
    .line 76
    invoke-static {v5}, La/as;->h(La/TZ;)V

    .line 77
    .line 78
    .line 79
    invoke-static {v4}, La/as;->h(La/TZ;)V

    .line 80
    .line 81
    .line 82
    invoke-static {v7}, La/as;->h(La/TZ;)V

    .line 83
    .line 84
    .line 85
    new-instance v12, La/r;

    .line 86
    .line 87
    invoke-direct {v12, v2}, La/r;-><init>(F)V

    .line 88
    .line 89
    .line 90
    new-instance v2, La/r;

    .line 91
    .line 92
    invoke-direct {v2, p1}, La/r;-><init>(F)V

    .line 93
    .line 94
    .line 95
    new-instance p1, La/r;

    .line 96
    .line 97
    invoke-direct {p1, v1}, La/r;-><init>(F)V

    .line 98
    .line 99
    .line 100
    new-instance v1, La/r;

    .line 101
    .line 102
    invoke-direct {v1, v3}, La/r;-><init>(F)V

    .line 103
    .line 104
    .line 105
    new-instance v3, La/c9;

    .line 106
    .line 107
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 108
    .line 109
    .line 110
    iput-object v6, v3, La/c9;->w:La/TZ;

    .line 111
    .line 112
    iput-object v5, v3, La/c9;->h:La/TZ;

    .line 113
    .line 114
    iput-object v7, v3, La/c9;->p:La/TZ;

    .line 115
    .line 116
    iput-object v4, v3, La/c9;->e:La/TZ;

    .line 117
    .line 118
    iput-object v12, v3, La/c9;->i:La/cv;

    .line 119
    .line 120
    iput-object v2, v3, La/c9;->Q:La/cv;

    .line 121
    .line 122
    iput-object v1, v3, La/c9;->X:La/cv;

    .line 123
    .line 124
    iput-object p1, v3, La/c9;->O:La/cv;

    .line 125
    .line 126
    iput-object v8, v3, La/c9;->V:La/eI;

    .line 127
    .line 128
    iput-object v9, v3, La/c9;->I:La/eI;

    .line 129
    .line 130
    iput-object v10, v3, La/c9;->M:La/eI;

    .line 131
    .line 132
    iput-object v11, v3, La/c9;->T:La/eI;

    .line 133
    .line 134
    iput-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->p7:Z

    .line 135
    .line 136
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->b:La/ex;

    .line 137
    .line 138
    if-eqz p1, :cond_1

    .line 139
    .line 140
    iget-object p1, p1, La/ex;->X:La/JP;

    .line 141
    .line 142
    iget-object p1, p1, La/JP;->w:La/c9;

    .line 143
    .line 144
    if-eq p1, v3, :cond_1

    .line 145
    .line 146
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->rC:La/c9;

    .line 147
    .line 148
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->h()V

    .line 149
    .line 150
    .line 151
    :cond_1
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/widget/LinearLayout;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, La/qp;

    .line 6
    .line 7
    invoke-direct {v1, v0}, La/o;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 17
    .line 18
    iget-boolean v2, v0, La/A7;->L:Z

    .line 19
    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    iget-object v0, v0, La/A7;->R:Ljava/lang/CharSequence;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v0, 0x0

    .line 26
    :goto_0
    iput-object v0, v1, La/qp;->R:Ljava/lang/CharSequence;

    .line 27
    .line 28
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 29
    .line 30
    iget v2, v0, La/h9;->q:I

    .line 31
    .line 32
    if-eqz v2, :cond_2

    .line 33
    .line 34
    iget-object v0, v0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    goto :goto_1

    .line 44
    :cond_2
    const/4 v0, 0x0

    .line 45
    :goto_1
    iput-boolean v0, v1, La/qp;->L:Z

    .line 46
    .line 47
    return-object v1
.end method

.method public final p()I
    .locals 4

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->c:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    if-eq v0, v3, :cond_1

    return v1

    :cond_1
    invoke-virtual {v2}, La/W5;->e()F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    :goto_0
    float-to-int v0, v0

    return v0

    :cond_2
    invoke-virtual {v2}, La/W5;->e()F

    move-result v0

    goto :goto_0
.end method

.method public final q()Z
    .locals 10

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->R:La/dX;

    .line 8
    .line 9
    iget-object v2, v0, La/dX;->d:Lcom/google/android/material/internal/CheckableImageButton;

    .line 10
    .line 11
    invoke-virtual {v2}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const/4 v3, 0x0

    .line 16
    const/4 v4, 0x2

    .line 17
    const/4 v5, 0x3

    .line 18
    const/4 v6, 0x1

    .line 19
    if-nez v2, :cond_1

    .line 20
    .line 21
    iget-object v2, v0, La/dX;->L:Ljava/lang/CharSequence;

    .line 22
    .line 23
    if-eqz v2, :cond_4

    .line 24
    .line 25
    iget-object v2, v0, La/dX;->R:La/c8;

    .line 26
    .line 27
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_4

    .line 32
    .line 33
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-lez v2, :cond_4

    .line 38
    .line 39
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 44
    .line 45
    invoke-virtual {v2}, Landroid/view/View;->getPaddingLeft()I

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    sub-int/2addr v0, v2

    .line 50
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->HF:Landroid/graphics/drawable/ColorDrawable;

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    iget v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->Gy:I

    .line 55
    .line 56
    if-eq v2, v0, :cond_3

    .line 57
    .line 58
    :cond_2
    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    .line 59
    .line 60
    invoke-direct {v2}, Landroid/graphics/drawable/ColorDrawable;-><init>()V

    .line 61
    .line 62
    .line 63
    iput-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->HF:Landroid/graphics/drawable/ColorDrawable;

    .line 64
    .line 65
    iput v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->Gy:I

    .line 66
    .line 67
    invoke-virtual {v2, v1, v1, v0, v6}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 68
    .line 69
    .line 70
    :cond_3
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 71
    .line 72
    invoke-static {v0}, La/aK;->w(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    aget-object v2, v0, v1

    .line 77
    .line 78
    iget-object v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->HF:Landroid/graphics/drawable/ColorDrawable;

    .line 79
    .line 80
    if-eq v2, v7, :cond_5

    .line 81
    .line 82
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 83
    .line 84
    aget-object v8, v0, v6

    .line 85
    .line 86
    aget-object v9, v0, v4

    .line 87
    .line 88
    aget-object v0, v0, v5

    .line 89
    .line 90
    invoke-static {v2, v7, v8, v9, v0}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 91
    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_4
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->HF:Landroid/graphics/drawable/ColorDrawable;

    .line 95
    .line 96
    if-eqz v0, :cond_5

    .line 97
    .line 98
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 99
    .line 100
    invoke-static {v0}, La/aK;->w(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 105
    .line 106
    aget-object v7, v0, v6

    .line 107
    .line 108
    aget-object v8, v0, v4

    .line 109
    .line 110
    aget-object v0, v0, v5

    .line 111
    .line 112
    invoke-static {v2, v3, v7, v8, v0}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 113
    .line 114
    .line 115
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->HF:Landroid/graphics/drawable/ColorDrawable;

    .line 116
    .line 117
    :goto_0
    move v0, v6

    .line 118
    goto :goto_1

    .line 119
    :cond_5
    move v0, v1

    .line 120
    :goto_1
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 121
    .line 122
    invoke-virtual {v2}, La/h9;->i()Z

    .line 123
    .line 124
    .line 125
    move-result v7

    .line 126
    if-nez v7, :cond_7

    .line 127
    .line 128
    iget v7, v2, La/h9;->q:I

    .line 129
    .line 130
    if-eqz v7, :cond_6

    .line 131
    .line 132
    invoke-virtual {v2}, La/h9;->e()Z

    .line 133
    .line 134
    .line 135
    move-result v7

    .line 136
    if-nez v7, :cond_7

    .line 137
    .line 138
    :cond_6
    iget-object v7, v2, La/h9;->P:Ljava/lang/CharSequence;

    .line 139
    .line 140
    if-eqz v7, :cond_e

    .line 141
    .line 142
    :cond_7
    invoke-virtual {v2}, Landroid/view/View;->getMeasuredWidth()I

    .line 143
    .line 144
    .line 145
    move-result v7

    .line 146
    if-lez v7, :cond_e

    .line 147
    .line 148
    iget-object v7, v2, La/h9;->D:La/c8;

    .line 149
    .line 150
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    .line 151
    .line 152
    .line 153
    move-result v7

    .line 154
    iget-object v8, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 155
    .line 156
    invoke-virtual {v8}, Landroid/view/View;->getPaddingRight()I

    .line 157
    .line 158
    .line 159
    move-result v8

    .line 160
    sub-int/2addr v7, v8

    .line 161
    invoke-virtual {v2}, La/h9;->i()Z

    .line 162
    .line 163
    .line 164
    move-result v8

    .line 165
    if-eqz v8, :cond_8

    .line 166
    .line 167
    iget-object v3, v2, La/h9;->L:Lcom/google/android/material/internal/CheckableImageButton;

    .line 168
    .line 169
    goto :goto_2

    .line 170
    :cond_8
    iget v8, v2, La/h9;->q:I

    .line 171
    .line 172
    if-eqz v8, :cond_9

    .line 173
    .line 174
    invoke-virtual {v2}, La/h9;->e()Z

    .line 175
    .line 176
    .line 177
    move-result v8

    .line 178
    if-eqz v8, :cond_9

    .line 179
    .line 180
    iget-object v3, v2, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 181
    .line 182
    :cond_9
    :goto_2
    if-eqz v3, :cond_a

    .line 183
    .line 184
    invoke-virtual {v3}, Landroid/view/View;->getMeasuredWidth()I

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    add-int/2addr v2, v7

    .line 189
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    check-cast v3, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 194
    .line 195
    invoke-static {v3}, La/WK;->p(Landroid/view/ViewGroup$MarginLayoutParams;)I

    .line 196
    .line 197
    .line 198
    move-result v3

    .line 199
    add-int v7, v3, v2

    .line 200
    .line 201
    :cond_a
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 202
    .line 203
    invoke-static {v2}, La/aK;->w(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 204
    .line 205
    .line 206
    move-result-object v2

    .line 207
    iget-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 208
    .line 209
    if-eqz v3, :cond_b

    .line 210
    .line 211
    iget v8, p0, Lcom/google/android/material/textfield/TextInputLayout;->cS:I

    .line 212
    .line 213
    if-eq v8, v7, :cond_b

    .line 214
    .line 215
    iput v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->cS:I

    .line 216
    .line 217
    invoke-virtual {v3, v1, v1, v7, v6}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 218
    .line 219
    .line 220
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 221
    .line 222
    aget-object v1, v2, v1

    .line 223
    .line 224
    aget-object v3, v2, v6

    .line 225
    .line 226
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 227
    .line 228
    aget-object v2, v2, v5

    .line 229
    .line 230
    :goto_3
    invoke-static {v0, v1, v3, v4, v2}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 231
    .line 232
    .line 233
    goto :goto_4

    .line 234
    :cond_b
    if-nez v3, :cond_c

    .line 235
    .line 236
    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    .line 237
    .line 238
    invoke-direct {v3}, Landroid/graphics/drawable/ColorDrawable;-><init>()V

    .line 239
    .line 240
    .line 241
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 242
    .line 243
    iput v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->cS:I

    .line 244
    .line 245
    invoke-virtual {v3, v1, v1, v7, v6}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 246
    .line 247
    .line 248
    :cond_c
    aget-object v3, v2, v4

    .line 249
    .line 250
    iget-object v4, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 251
    .line 252
    if-eq v3, v4, :cond_d

    .line 253
    .line 254
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->Qg:Landroid/graphics/drawable/Drawable;

    .line 255
    .line 256
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 257
    .line 258
    aget-object v1, v2, v1

    .line 259
    .line 260
    aget-object v3, v2, v6

    .line 261
    .line 262
    aget-object v2, v2, v5

    .line 263
    .line 264
    goto :goto_3

    .line 265
    :cond_d
    move v6, v0

    .line 266
    :goto_4
    move v0, v6

    .line 267
    goto :goto_6

    .line 268
    :cond_e
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 269
    .line 270
    if-eqz v2, :cond_10

    .line 271
    .line 272
    iget-object v2, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 273
    .line 274
    invoke-static {v2}, La/aK;->w(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 275
    .line 276
    .line 277
    move-result-object v2

    .line 278
    aget-object v4, v2, v4

    .line 279
    .line 280
    iget-object v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 281
    .line 282
    if-ne v4, v7, :cond_f

    .line 283
    .line 284
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 285
    .line 286
    aget-object v1, v2, v1

    .line 287
    .line 288
    aget-object v4, v2, v6

    .line 289
    .line 290
    iget-object v7, p0, Lcom/google/android/material/textfield/TextInputLayout;->Qg:Landroid/graphics/drawable/Drawable;

    .line 291
    .line 292
    aget-object v2, v2, v5

    .line 293
    .line 294
    invoke-static {v0, v1, v4, v7, v2}, La/aK;->i(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 295
    .line 296
    .line 297
    goto :goto_5

    .line 298
    :cond_f
    move v6, v0

    .line 299
    :goto_5
    iput-object v3, p0, Lcom/google/android/material/textfield/TextInputLayout;->MX:Landroid/graphics/drawable/ColorDrawable;

    .line 300
    .line 301
    goto :goto_4

    .line 302
    :cond_10
    :goto_6
    return v0
.end method

.method public final setEnabled(Z)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/material/textfield/TextInputLayout;->M(Landroid/view/ViewGroup;Z)V

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setEnabled(Z)V

    return-void
.end method

.method public final w(F)V
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->IL:La/W5;

    .line 2
    .line 3
    iget v1, v0, La/W5;->h:F

    .line 4
    .line 5
    cmpl-float v1, v1, p1

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    if-nez v1, :cond_1

    .line 14
    .line 15
    new-instance v1, Landroid/animation/ValueAnimator;

    .line 16
    .line 17
    invoke-direct {v1}, Landroid/animation/ValueAnimator;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 21
    .line 22
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    sget-object v4, La/FP;->h:La/HR;

    .line 27
    .line 28
    const v5, 0x7f04034f

    .line 29
    .line 30
    .line 31
    invoke-static {v3, v5, v4}, La/rx;->cS(Landroid/content/Context;ILandroid/view/animation/Interpolator;)Landroid/animation/TimeInterpolator;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 36
    .line 37
    .line 38
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 39
    .line 40
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    const v4, 0x7f040345

    .line 45
    .line 46
    .line 47
    const/16 v5, 0xa7

    .line 48
    .line 49
    invoke-static {v3, v4, v5}, La/rx;->MX(Landroid/content/Context;II)I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    int-to-long v3, v3

    .line 54
    invoke-virtual {v1, v3, v4}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 55
    .line 56
    .line 57
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 58
    .line 59
    new-instance v3, La/MF;

    .line 60
    .line 61
    invoke-direct {v3, v2, p0}, La/MF;-><init>(ILjava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 65
    .line 66
    .line 67
    :cond_1
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 68
    .line 69
    const/4 v3, 0x2

    .line 70
    new-array v3, v3, [F

    .line 71
    .line 72
    iget v0, v0, La/W5;->h:F

    .line 73
    .line 74
    const/4 v4, 0x0

    .line 75
    aput v0, v3, v4

    .line 76
    .line 77
    aput p1, v3, v2

    .line 78
    .line 79
    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->vz:Landroid/animation/ValueAnimator;

    .line 83
    .line 84
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    .line 85
    .line 86
    .line 87
    return-void
.end method

.method public final y(Z)V
    .locals 7

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 2
    .line 3
    iget-boolean v1, v0, La/A7;->E:Z

    .line 4
    .line 5
    if-ne v1, p1, :cond_0

    .line 6
    .line 7
    goto/16 :goto_1

    .line 8
    .line 9
    :cond_0
    invoke-virtual {v0}, La/A7;->p()V

    .line 10
    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    const/4 v2, 0x1

    .line 14
    if-eqz p1, :cond_3

    .line 15
    .line 16
    new-instance v3, La/c8;

    .line 17
    .line 18
    iget-object v4, v0, La/A7;->X:Landroid/content/Context;

    .line 19
    .line 20
    invoke-direct {v3, v4, v1}, La/c8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 21
    .line 22
    .line 23
    iput-object v3, v0, La/A7;->S:La/c8;

    .line 24
    .line 25
    const v1, 0x7f09025e

    .line 26
    .line 27
    .line 28
    invoke-virtual {v3, v1}, Landroid/view/View;->setId(I)V

    .line 29
    .line 30
    .line 31
    iget-object v1, v0, La/A7;->S:La/c8;

    .line 32
    .line 33
    const/4 v3, 0x5

    .line 34
    invoke-virtual {v1, v3}, Landroid/view/View;->setTextAlignment(I)V

    .line 35
    .line 36
    .line 37
    iget-object v1, v0, La/A7;->S:La/c8;

    .line 38
    .line 39
    const/4 v3, 0x4

    .line 40
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 41
    .line 42
    .line 43
    iget-object v1, v0, La/A7;->S:La/c8;

    .line 44
    .line 45
    invoke-static {v1, v2}, La/AM;->Q(Landroid/view/View;I)V

    .line 46
    .line 47
    .line 48
    iget v1, v0, La/A7;->H:I

    .line 49
    .line 50
    iput v1, v0, La/A7;->H:I

    .line 51
    .line 52
    iget-object v3, v0, La/A7;->S:La/c8;

    .line 53
    .line 54
    if-eqz v3, :cond_1

    .line 55
    .line 56
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 57
    .line 58
    .line 59
    :cond_1
    iget-object v1, v0, La/A7;->z:Landroid/content/res/ColorStateList;

    .line 60
    .line 61
    iput-object v1, v0, La/A7;->z:Landroid/content/res/ColorStateList;

    .line 62
    .line 63
    iget-object v3, v0, La/A7;->S:La/c8;

    .line 64
    .line 65
    if-eqz v3, :cond_2

    .line 66
    .line 67
    if-eqz v1, :cond_2

    .line 68
    .line 69
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    iget-object v1, v0, La/A7;->S:La/c8;

    .line 73
    .line 74
    invoke-virtual {v0, v1, v2}, La/A7;->w(Landroid/widget/TextView;I)V

    .line 75
    .line 76
    .line 77
    iget-object v1, v0, La/A7;->S:La/c8;

    .line 78
    .line 79
    new-instance v2, La/Dx;

    .line 80
    .line 81
    invoke-direct {v2, v0}, La/Dx;-><init>(La/A7;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v1, v2}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_3
    invoke-virtual {v0}, La/A7;->p()V

    .line 89
    .line 90
    .line 91
    iget v3, v0, La/A7;->y:I

    .line 92
    .line 93
    const/4 v4, 0x2

    .line 94
    if-ne v3, v4, :cond_4

    .line 95
    .line 96
    const/4 v4, 0x0

    .line 97
    iput v4, v0, La/A7;->K:I

    .line 98
    .line 99
    :cond_4
    iget v4, v0, La/A7;->K:I

    .line 100
    .line 101
    iget-object v5, v0, La/A7;->S:La/c8;

    .line 102
    .line 103
    const-string v6, ""

    .line 104
    .line 105
    invoke-virtual {v0, v5, v6}, La/A7;->O(Landroid/widget/TextView;Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v5

    .line 109
    invoke-virtual {v0, v3, v4, v5}, La/A7;->V(IIZ)V

    .line 110
    .line 111
    .line 112
    iget-object v3, v0, La/A7;->S:La/c8;

    .line 113
    .line 114
    invoke-virtual {v0, v3, v2}, La/A7;->X(Landroid/widget/TextView;I)V

    .line 115
    .line 116
    .line 117
    iput-object v1, v0, La/A7;->S:La/c8;

    .line 118
    .line 119
    iget-object v1, v0, La/A7;->O:Lcom/google/android/material/textfield/TextInputLayout;

    .line 120
    .line 121
    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputLayout;->F()V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputLayout;->D()V

    .line 125
    .line 126
    .line 127
    :goto_0
    iput-boolean p1, v0, La/A7;->E:Z

    .line 128
    .line 129
    :goto_1
    return-void
.end method

.method public final z(Landroid/text/Editable;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->P:La/TD;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/google/android/material/textfield/TextInputLayout;->K:Landroid/widget/FrameLayout;

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-nez p1, :cond_1

    .line 15
    .line 16
    :cond_0
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->Hs:Z

    .line 17
    .line 18
    if-nez p1, :cond_1

    .line 19
    .line 20
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 21
    .line 22
    if-eqz p1, :cond_2

    .line 23
    .line 24
    iget-boolean p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 25
    .line 26
    if-eqz p1, :cond_2

    .line 27
    .line 28
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->k:Ljava/lang/CharSequence;

    .line 29
    .line 30
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-nez p1, :cond_2

    .line 35
    .line 36
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 37
    .line 38
    iget-object v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->k:Ljava/lang/CharSequence;

    .line 39
    .line 40
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 41
    .line 42
    .line 43
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->n:La/KF;

    .line 44
    .line 45
    invoke-static {v0, p1}, La/SU;->w(Landroid/view/ViewGroup;La/SB;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 49
    .line 50
    const/4 v0, 0x0

    .line 51
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 52
    .line 53
    .line 54
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 55
    .line 56
    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    .line 57
    .line 58
    .line 59
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->k:Ljava/lang/CharSequence;

    .line 60
    .line 61
    invoke-virtual {p0, p1}, Landroid/view/View;->announceForAccessibility(Ljava/lang/CharSequence;)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_1
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 66
    .line 67
    if-eqz p1, :cond_2

    .line 68
    .line 69
    iget-boolean v1, p0, Lcom/google/android/material/textfield/TextInputLayout;->v:Z

    .line 70
    .line 71
    if-eqz v1, :cond_2

    .line 72
    .line 73
    const/4 v1, 0x0

    .line 74
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 75
    .line 76
    .line 77
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->C:La/KF;

    .line 78
    .line 79
    invoke-static {v0, p1}, La/SU;->w(Landroid/view/ViewGroup;La/SB;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lcom/google/android/material/textfield/TextInputLayout;->s:La/c8;

    .line 83
    .line 84
    const/4 v0, 0x4

    .line 85
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 86
    .line 87
    .line 88
    :cond_2
    :goto_0
    return-void
.end method
