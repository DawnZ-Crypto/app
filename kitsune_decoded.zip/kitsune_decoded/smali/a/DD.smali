.class public interface abstract La/DD;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/FH;
