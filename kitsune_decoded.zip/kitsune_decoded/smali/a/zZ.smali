.class public abstract La/zZ;
.super La/zr;
.source "SourceFile"

# interfaces
.implements La/yN;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<Binding:",
        "Landroidx/databinding/w;",
        ">",
        "La/zr;",
        "La/yN;"
    }
.end annotation


# instance fields
.field public B1:Landroidx/databinding/w;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, La/zr;-><init>()V

    return-void
.end method


# virtual methods
.method public C()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La/zr;->r:Z

    .line 3
    .line 4
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, La/m1;->d()La/Yo;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move-object v0, v1

    .line 17
    :goto_0
    if-nez v0, :cond_1

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    invoke-virtual {v0, v1}, La/Yo;->n(Ljava/lang/CharSequence;)V

    .line 21
    .line 22
    .line 23
    :goto_1
    return-void
.end method

.method public F9(Landroidx/databinding/w;)V
    .locals 1

    .line 1
    iget-object p1, p1, Landroidx/databinding/w;->f:Landroid/view/View;

    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    check-cast p1, Landroid/view/ViewGroup;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    if-eqz p1, :cond_1

    invoke-static {p1}, La/rx;->au(Landroid/view/ViewGroup;)V

    :cond_1
    return-void
.end method

.method public FL()Landroid/view/View;
    .locals 1

    .line 1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final G()La/o5;
    .locals 2

    .line 1
    invoke-virtual {p0}, La/zr;->y()La/Jf;

    move-result-object v0

    instance-of v1, v0, La/o5;

    if-eqz v1, :cond_0

    check-cast v0, La/o5;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public abstract Pc()I
.end method

.method public final Q(La/I2;)V
    .locals 1

    .line 1
    instance-of v0, p1, La/ud;

    if-eqz v0, :cond_0

    check-cast p1, La/ud;

    invoke-virtual {p0}, La/zr;->B()Landroid/content/Context;

    move-result-object v0

    invoke-interface {p1, v0}, La/ud;->w(Landroid/content/Context;)V

    goto :goto_0

    :cond_0
    instance-of v0, p1, La/Bv;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, La/zZ;->G()La/o5;

    move-result-object v0

    if-eqz v0, :cond_1

    check-cast p1, La/Bv;

    invoke-interface {p1, v0}, La/Bv;->h(La/Vo;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public Y(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, La/zr;->Y(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, La/rE;->Ek(La/yN;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 1
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 p1, 0x0

    .line 7
    :goto_0
    new-instance p2, La/vF;

    .line 8
    .line 9
    invoke-direct {p2, p0}, La/vF;-><init>(La/zZ;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p1, Landroidx/databinding/w;->l:La/aY;

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    new-instance v0, La/aY;

    .line 17
    .line 18
    sget-object v1, Landroidx/databinding/w;->v:La/XO;

    .line 19
    .line 20
    invoke-direct {v0, v1}, La/aY;-><init>(La/XO;)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p1, Landroidx/databinding/w;->l:La/aY;

    .line 24
    .line 25
    :cond_1
    iget-object p1, p1, Landroidx/databinding/w;->l:La/aY;

    .line 26
    .line 27
    invoke-virtual {p1, p2}, La/aY;->w(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final n(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-interface {p0}, La/yN;->V()La/hb;

    move-result-object v0

    invoke-virtual {v0, p1}, La/hb;->T(Landroid/os/Bundle;)V

    return-void
.end method

.method public p7(Landroid/view/KeyEvent;)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public rC()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public rV()Landroid/view/View;
    .locals 1

    .line 1
    const/4 v0, 0x0

    return-object v0
.end method

.method public t()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La/zr;->r:Z

    .line 3
    .line 4
    invoke-interface {p0}, La/yN;->V()La/hb;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    instance-of v1, v0, La/aV;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    check-cast v0, La/aV;

    .line 13
    .line 14
    invoke-virtual {v0}, La/aV;->L()V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 5

    .line 1
    invoke-virtual {p0}, La/zZ;->Pc()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {p1, v0, p2, v1}, La/SG;->h(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;Z)Landroidx/databinding/w;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const/16 p2, 0x2b

    .line 11
    .line 12
    invoke-interface {p0}, La/yN;->V()La/hb;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {p1, p2, v0}, Landroidx/databinding/w;->d(ILjava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, La/zr;->W()La/NT;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    invoke-virtual {p1, p2}, Landroidx/databinding/w;->L(La/RH;)V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 27
    .line 28
    instance-of p1, p0, La/We;

    .line 29
    .line 30
    const/4 p2, 0x0

    .line 31
    if-eqz p1, :cond_1

    .line 32
    .line 33
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    move-object v0, p0

    .line 40
    check-cast v0, La/We;

    .line 41
    .line 42
    invoke-virtual {p0}, La/zr;->W()La/NT;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iget-object p1, p1, Landroidx/activity/w;->R:La/yW;

    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v1}, La/NT;->e()V

    .line 52
    .line 53
    .line 54
    iget-object v1, v1, La/NT;->d:Landroidx/lifecycle/w;

    .line 55
    .line 56
    iget-object v2, p1, La/yW;->L:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v2, Ljava/util/Map;

    .line 59
    .line 60
    invoke-interface {v2, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    check-cast v2, La/OL;

    .line 65
    .line 66
    if-eqz v2, :cond_0

    .line 67
    .line 68
    iget-object v3, v2, La/OL;->w:La/GK;

    .line 69
    .line 70
    iget-object v4, v2, La/OL;->h:La/dr;

    .line 71
    .line 72
    invoke-virtual {v3, v4}, La/GK;->h(La/IQ;)V

    .line 73
    .line 74
    .line 75
    iput-object p2, v2, La/OL;->h:La/dr;

    .line 76
    .line 77
    :cond_0
    new-instance v2, La/gY;

    .line 78
    .line 79
    invoke-direct {v2, p1, v0}, La/gY;-><init>(La/yW;La/We;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p1, La/yW;->L:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast p1, Ljava/util/Map;

    .line 85
    .line 86
    new-instance v3, La/OL;

    .line 87
    .line 88
    invoke-direct {v3, v1, v2}, La/OL;-><init>(La/GK;La/gY;)V

    .line 89
    .line 90
    .line 91
    invoke-interface {p1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    :cond_1
    if-eqz p3, :cond_2

    .line 95
    .line 96
    invoke-interface {p0}, La/yN;->V()La/hb;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {p1, p3}, La/hb;->M(Landroid/os/Bundle;)V

    .line 101
    .line 102
    .line 103
    :cond_2
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 104
    .line 105
    if-eqz p1, :cond_3

    .line 106
    .line 107
    move-object p2, p1

    .line 108
    :cond_3
    iget-object p1, p2, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 109
    .line 110
    return-object p1
.end method
