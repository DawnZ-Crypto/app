.class public final La/Rt;
.super La/Zv;
.source "SourceFile"

# interfaces
.implements La/mt;


# instance fields
.field public final L:La/pY;

.field public final R:Landroid/content/Context;

.field public d:La/Lw;

.field public f:Ljava/lang/ref/WeakReference;

.field public final synthetic l:La/EF;


# direct methods
.method public constructor <init>(La/EF;Landroid/content/Context;La/HB;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/Rt;->l:La/EF;

    iput-object p2, p0, La/Rt;->R:Landroid/content/Context;

    iput-object p3, p0, La/Rt;->d:La/Lw;

    new-instance p1, La/pY;

    invoke-direct {p1, p2}, La/pY;-><init>(Landroid/content/Context;)V

    const/4 p2, 0x1

    iput p2, p1, La/pY;->T:I

    iput-object p1, p0, La/Rt;->L:La/pY;

    iput-object p0, p1, La/pY;->i:La/mt;

    return-void
.end method


# virtual methods
.method public final I(La/pY;)V
    .locals 0

    .line 1
    iget-object p1, p0, La/Rt;->d:La/Lw;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, La/Rt;->O()V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, La/Rt;->l:La/EF;

    .line 10
    .line 11
    iget-object p1, p1, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 12
    .line 13
    iget-object p1, p1, Landroidx/appcompat/widget/ActionBarContextView;->d:La/uP;

    .line 14
    .line 15
    if-eqz p1, :cond_1

    .line 16
    .line 17
    invoke-virtual {p1}, La/uP;->K()Z

    .line 18
    .line 19
    .line 20
    :cond_1
    return-void
.end method

.method public final K(Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 4
    .line 5
    iput-object p1, v0, Landroidx/appcompat/widget/ActionBarContextView;->F:Ljava/lang/CharSequence;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->e()V

    .line 8
    .line 9
    .line 10
    invoke-static {v0, p1}, La/sI;->m(Landroid/view/View;Ljava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final M(Landroid/view/View;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->M(Landroid/view/View;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, La/Rt;->f:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public final O()V
    .locals 2

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    iget-object v0, v0, La/EF;->F:La/Rt;

    if-eq v0, p0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, La/Rt;->L:La/pY;

    invoke-virtual {v0}, La/pY;->F()V

    :try_start_0
    iget-object v1, p0, La/Rt;->d:La/Lw;

    invoke-interface {v1, p0, v0}, La/Lw;->w(La/Zv;La/pY;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, La/pY;->q()V

    return-void

    :catchall_0
    move-exception v1

    invoke-virtual {v0}, La/pY;->q()V

    throw v1
.end method

.method public final Q()Ljava/lang/CharSequence;
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 4
    .line 5
    iget-object v0, v0, Landroidx/appcompat/widget/ActionBarContextView;->E:Ljava/lang/CharSequence;

    .line 6
    .line 7
    return-object v0
.end method

.method public final R(Z)V
    .locals 2

    .line 1
    iput-boolean p1, p0, La/Zv;->K:Z

    .line 2
    .line 3
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 4
    .line 5
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 6
    .line 7
    iget-boolean v1, v0, Landroidx/appcompat/widget/ActionBarContextView;->v:Z

    .line 8
    .line 9
    if-eq p1, v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 12
    .line 13
    .line 14
    :cond_0
    iput-boolean p1, v0, Landroidx/appcompat/widget/ActionBarContextView;->v:Z

    .line 15
    .line 16
    return-void
.end method

.method public final T(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    iget-object v0, v0, La/EF;->K:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La/Rt;->m(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final V()Z
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 4
    .line 5
    iget-boolean v0, v0, Landroidx/appcompat/widget/ActionBarContextView;->v:Z

    .line 6
    .line 7
    return v0
.end method

.method public final X()Ljava/lang/CharSequence;
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 4
    .line 5
    iget-object v0, v0, Landroidx/appcompat/widget/ActionBarContextView;->F:Ljava/lang/CharSequence;

    .line 6
    .line 7
    return-object v0
.end method

.method public final e()Landroid/view/MenuInflater;
    .locals 2

    .line 1
    new-instance v0, La/HC;

    iget-object v1, p0, La/Rt;->R:Landroid/content/Context;

    invoke-direct {v0, v1}, La/HC;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public final h()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final i(La/pY;Landroid/view/MenuItem;)Z
    .locals 0

    .line 1
    iget-object p1, p0, La/Rt;->d:La/Lw;

    if-eqz p1, :cond_0

    invoke-interface {p1, p0, p2}, La/Lw;->p(La/Zv;Landroid/view/MenuItem;)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final m(Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v0, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 4
    .line 5
    iput-object p1, v0, Landroidx/appcompat/widget/ActionBarContextView;->E:Ljava/lang/CharSequence;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionBarContextView;->e()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final p()La/pY;
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->L:La/pY;

    return-object v0
.end method

.method public final w()V
    .locals 4

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    .line 2
    .line 3
    iget-object v1, v0, La/EF;->F:La/Rt;

    .line 4
    .line 5
    if-eq v1, p0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget-boolean v1, v0, La/EF;->Y:Z

    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    iput-object p0, v0, La/EF;->E:La/Rt;

    .line 13
    .line 14
    iget-object v1, p0, La/Rt;->d:La/Lw;

    .line 15
    .line 16
    iput-object v1, v0, La/EF;->S:La/Lw;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    iget-object v1, p0, La/Rt;->d:La/Lw;

    .line 20
    .line 21
    invoke-interface {v1, p0}, La/Lw;->h(La/Zv;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    const/4 v1, 0x0

    .line 25
    iput-object v1, p0, La/Rt;->d:La/Lw;

    .line 26
    .line 27
    const/4 v2, 0x0

    .line 28
    invoke-virtual {v0, v2}, La/EF;->r(Z)V

    .line 29
    .line 30
    .line 31
    iget-object v2, v0, La/EF;->l:Landroidx/appcompat/widget/ActionBarContextView;

    .line 32
    .line 33
    iget-object v3, v2, Landroidx/appcompat/widget/ActionBarContextView;->S:Landroid/view/View;

    .line 34
    .line 35
    if-nez v3, :cond_2

    .line 36
    .line 37
    invoke-virtual {v2}, Landroidx/appcompat/widget/ActionBarContextView;->i()V

    .line 38
    .line 39
    .line 40
    :cond_2
    iget-object v2, v0, La/EF;->L:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    .line 41
    .line 42
    iget-boolean v3, v0, La/EF;->s:Z

    .line 43
    .line 44
    invoke-virtual {v2, v3}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->T(Z)V

    .line 45
    .line 46
    .line 47
    iput-object v1, v0, La/EF;->F:La/Rt;

    .line 48
    .line 49
    return-void
.end method

.method public final y(I)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Rt;->l:La/EF;

    iget-object v0, v0, La/EF;->K:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, La/Rt;->K(Ljava/lang/CharSequence;)V

    return-void
.end method
