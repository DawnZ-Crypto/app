.class public final Landroidx/lifecycle/w;
.super La/GK;
.source "SourceFile"


# instance fields
.field public O:Z

.field public Q:I

.field public final V:Ljava/util/ArrayList;

.field public X:Z

.field public e:La/m2;

.field public final h:Z

.field public final i:Ljava/lang/ref/WeakReference;

.field public p:La/aG;


# direct methods
.method public constructor <init>(La/RH;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La/GK;->w:Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    iput-boolean v0, p0, Landroidx/lifecycle/w;->h:Z

    .line 13
    .line 14
    new-instance v0, La/aG;

    .line 15
    .line 16
    invoke-direct {v0}, La/aG;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 20
    .line 21
    sget-object v0, La/m2;->K:La/m2;

    .line 22
    .line 23
    iput-object v0, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 24
    .line 25
    new-instance v0, Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object v0, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 31
    .line 32
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 33
    .line 34
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iput-object v0, p0, Landroidx/lifecycle/w;->i:Ljava/lang/ref/WeakReference;

    .line 38
    .line 39
    return-void
.end method


# virtual methods
.method public final O()V
    .locals 11

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/w;->i:Ljava/lang/ref/WeakReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/RH;

    .line 8
    .line 9
    if-eqz v0, :cond_e

    .line 10
    .line 11
    :cond_0
    iget-object v1, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 12
    .line 13
    iget v2, v1, La/U6;->L:I

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    if-nez v2, :cond_1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    iget-object v2, v1, La/U6;->X:La/dA;

    .line 20
    .line 21
    iget-object v2, v2, La/dA;->K:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v2, La/jl;

    .line 24
    .line 25
    iget-object v2, v2, La/jl;->w:La/m2;

    .line 26
    .line 27
    iget-object v1, v1, La/U6;->K:La/dA;

    .line 28
    .line 29
    iget-object v1, v1, La/dA;->K:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v1, La/jl;

    .line 32
    .line 33
    iget-object v1, v1, La/jl;->w:La/m2;

    .line 34
    .line 35
    if-ne v2, v1, :cond_2

    .line 36
    .line 37
    iget-object v4, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 38
    .line 39
    if-ne v4, v1, :cond_2

    .line 40
    .line 41
    :goto_0
    iput-boolean v3, p0, Landroidx/lifecycle/w;->O:Z

    .line 42
    .line 43
    return-void

    .line 44
    :cond_2
    iput-boolean v3, p0, Landroidx/lifecycle/w;->O:Z

    .line 45
    .line 46
    iget-object v1, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 47
    .line 48
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    const/4 v2, 0x0

    .line 53
    const/4 v3, 0x3

    .line 54
    const/4 v4, 0x2

    .line 55
    const/4 v5, 0x1

    .line 56
    if-gez v1, :cond_8

    .line 57
    .line 58
    iget-object v1, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 59
    .line 60
    new-instance v6, La/al;

    .line 61
    .line 62
    iget-object v7, v1, La/U6;->K:La/dA;

    .line 63
    .line 64
    iget-object v8, v1, La/U6;->X:La/dA;

    .line 65
    .line 66
    invoke-direct {v6, v7, v8, v5}, La/al;-><init>(La/dA;La/dA;I)V

    .line 67
    .line 68
    .line 69
    iget-object v1, v1, La/U6;->R:Ljava/util/WeakHashMap;

    .line 70
    .line 71
    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 72
    .line 73
    invoke-virtual {v1, v6, v7}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    :cond_3
    invoke-virtual {v6}, La/Tp;->hasNext()Z

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    if-eqz v1, :cond_8

    .line 81
    .line 82
    iget-boolean v1, p0, Landroidx/lifecycle/w;->O:Z

    .line 83
    .line 84
    if-nez v1, :cond_8

    .line 85
    .line 86
    invoke-virtual {v6}, La/Tp;->next()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    check-cast v1, Ljava/util/Map$Entry;

    .line 91
    .line 92
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v7

    .line 96
    check-cast v7, La/IQ;

    .line 97
    .line 98
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    check-cast v1, La/jl;

    .line 103
    .line 104
    :goto_1
    iget-object v8, v1, La/jl;->w:La/m2;

    .line 105
    .line 106
    iget-object v9, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 107
    .line 108
    invoke-virtual {v8, v9}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 109
    .line 110
    .line 111
    move-result v8

    .line 112
    if-lez v8, :cond_3

    .line 113
    .line 114
    iget-boolean v8, p0, Landroidx/lifecycle/w;->O:Z

    .line 115
    .line 116
    if-nez v8, :cond_3

    .line 117
    .line 118
    iget-object v8, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 119
    .line 120
    iget-object v8, v8, La/aG;->d:Ljava/util/HashMap;

    .line 121
    .line 122
    invoke-virtual {v8, v7}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v8

    .line 126
    if-eqz v8, :cond_3

    .line 127
    .line 128
    sget-object v8, La/cw;->Companion:La/K2;

    .line 129
    .line 130
    iget-object v9, v1, La/jl;->w:La/m2;

    .line 131
    .line 132
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 136
    .line 137
    .line 138
    move-result v8

    .line 139
    if-eq v8, v4, :cond_6

    .line 140
    .line 141
    if-eq v8, v3, :cond_5

    .line 142
    .line 143
    const/4 v9, 0x4

    .line 144
    if-eq v8, v9, :cond_4

    .line 145
    .line 146
    move-object v8, v2

    .line 147
    goto :goto_2

    .line 148
    :cond_4
    sget-object v8, La/cw;->ON_PAUSE:La/cw;

    .line 149
    .line 150
    goto :goto_2

    .line 151
    :cond_5
    sget-object v8, La/cw;->ON_STOP:La/cw;

    .line 152
    .line 153
    goto :goto_2

    .line 154
    :cond_6
    sget-object v8, La/cw;->ON_DESTROY:La/cw;

    .line 155
    .line 156
    :goto_2
    if-eqz v8, :cond_7

    .line 157
    .line 158
    invoke-virtual {v8}, La/cw;->w()La/m2;

    .line 159
    .line 160
    .line 161
    move-result-object v9

    .line 162
    iget-object v10, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 163
    .line 164
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    invoke-virtual {v1, v0, v8}, La/jl;->w(La/RH;La/cw;)V

    .line 168
    .line 169
    .line 170
    iget-object v8, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 171
    .line 172
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 173
    .line 174
    .line 175
    move-result v9

    .line 176
    sub-int/2addr v9, v5

    .line 177
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    goto :goto_1

    .line 181
    :cond_7
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 182
    .line 183
    new-instance v2, Ljava/lang/StringBuilder;

    .line 184
    .line 185
    const-string v3, "no event down from "

    .line 186
    .line 187
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    iget-object v1, v1, La/jl;->w:La/m2;

    .line 191
    .line 192
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    throw v0

    .line 203
    :cond_8
    iget-object v1, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 204
    .line 205
    iget-object v1, v1, La/U6;->K:La/dA;

    .line 206
    .line 207
    iget-boolean v6, p0, Landroidx/lifecycle/w;->O:Z

    .line 208
    .line 209
    if-nez v6, :cond_0

    .line 210
    .line 211
    if-eqz v1, :cond_0

    .line 212
    .line 213
    iget-object v6, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 214
    .line 215
    iget-object v1, v1, La/dA;->K:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v1, La/jl;

    .line 218
    .line 219
    iget-object v1, v1, La/jl;->w:La/m2;

    .line 220
    .line 221
    invoke-virtual {v6, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 222
    .line 223
    .line 224
    move-result v1

    .line 225
    if-lez v1, :cond_0

    .line 226
    .line 227
    iget-object v1, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 228
    .line 229
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 230
    .line 231
    .line 232
    new-instance v6, La/Mo;

    .line 233
    .line 234
    invoke-direct {v6, v1}, La/Mo;-><init>(La/U6;)V

    .line 235
    .line 236
    .line 237
    iget-object v1, v1, La/U6;->R:Ljava/util/WeakHashMap;

    .line 238
    .line 239
    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 240
    .line 241
    invoke-virtual {v1, v6, v7}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    :cond_9
    invoke-virtual {v6}, La/Mo;->hasNext()Z

    .line 245
    .line 246
    .line 247
    move-result v1

    .line 248
    if-eqz v1, :cond_0

    .line 249
    .line 250
    iget-boolean v1, p0, Landroidx/lifecycle/w;->O:Z

    .line 251
    .line 252
    if-nez v1, :cond_0

    .line 253
    .line 254
    invoke-virtual {v6}, La/Mo;->next()Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    check-cast v1, Ljava/util/Map$Entry;

    .line 259
    .line 260
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v7

    .line 264
    check-cast v7, La/IQ;

    .line 265
    .line 266
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    check-cast v1, La/jl;

    .line 271
    .line 272
    :goto_3
    iget-object v8, v1, La/jl;->w:La/m2;

    .line 273
    .line 274
    iget-object v9, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 275
    .line 276
    invoke-virtual {v8, v9}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 277
    .line 278
    .line 279
    move-result v8

    .line 280
    if-gez v8, :cond_9

    .line 281
    .line 282
    iget-boolean v8, p0, Landroidx/lifecycle/w;->O:Z

    .line 283
    .line 284
    if-nez v8, :cond_9

    .line 285
    .line 286
    iget-object v8, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 287
    .line 288
    iget-object v8, v8, La/aG;->d:Ljava/util/HashMap;

    .line 289
    .line 290
    invoke-virtual {v8, v7}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 291
    .line 292
    .line 293
    move-result v8

    .line 294
    if-eqz v8, :cond_9

    .line 295
    .line 296
    iget-object v8, v1, La/jl;->w:La/m2;

    .line 297
    .line 298
    iget-object v9, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 299
    .line 300
    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    sget-object v8, La/cw;->Companion:La/K2;

    .line 304
    .line 305
    iget-object v9, v1, La/jl;->w:La/m2;

    .line 306
    .line 307
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 308
    .line 309
    .line 310
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 311
    .line 312
    .line 313
    move-result v8

    .line 314
    if-eq v8, v5, :cond_c

    .line 315
    .line 316
    if-eq v8, v4, :cond_b

    .line 317
    .line 318
    if-eq v8, v3, :cond_a

    .line 319
    .line 320
    move-object v8, v2

    .line 321
    goto :goto_4

    .line 322
    :cond_a
    sget-object v8, La/cw;->ON_RESUME:La/cw;

    .line 323
    .line 324
    goto :goto_4

    .line 325
    :cond_b
    sget-object v8, La/cw;->ON_START:La/cw;

    .line 326
    .line 327
    goto :goto_4

    .line 328
    :cond_c
    sget-object v8, La/cw;->ON_CREATE:La/cw;

    .line 329
    .line 330
    :goto_4
    if-eqz v8, :cond_d

    .line 331
    .line 332
    invoke-virtual {v1, v0, v8}, La/jl;->w(La/RH;La/cw;)V

    .line 333
    .line 334
    .line 335
    iget-object v8, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 336
    .line 337
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 338
    .line 339
    .line 340
    move-result v9

    .line 341
    sub-int/2addr v9, v5

    .line 342
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    goto :goto_3

    .line 346
    :cond_d
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 347
    .line 348
    new-instance v2, Ljava/lang/StringBuilder;

    .line 349
    .line 350
    const-string v3, "no event up from "

    .line 351
    .line 352
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 353
    .line 354
    .line 355
    iget-object v1, v1, La/jl;->w:La/m2;

    .line 356
    .line 357
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 358
    .line 359
    .line 360
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 365
    .line 366
    .line 367
    throw v0

    .line 368
    :cond_e
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 369
    .line 370
    const-string v1, "LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state."

    .line 371
    .line 372
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    throw v0
.end method

.method public final Q(La/m2;)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/w;->e:La/m2;

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    sget-object v1, La/m2;->K:La/m2;

    sget-object v2, La/m2;->X:La/m2;

    if-ne v0, v1, :cond_2

    if-eq p1, v2, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "no event down from "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/lifecycle/w;->e:La/m2;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " in component "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Landroidx/lifecycle/w;->i:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    :goto_0
    iput-object p1, p0, Landroidx/lifecycle/w;->e:La/m2;

    iget-boolean p1, p0, Landroidx/lifecycle/w;->X:Z

    const/4 v0, 0x1

    if-nez p1, :cond_5

    iget p1, p0, Landroidx/lifecycle/w;->Q:I

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    iput-boolean v0, p0, Landroidx/lifecycle/w;->X:Z

    invoke-virtual {p0}, Landroidx/lifecycle/w;->O()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/lifecycle/w;->X:Z

    iget-object p1, p0, Landroidx/lifecycle/w;->e:La/m2;

    if-ne p1, v2, :cond_4

    new-instance p1, La/aG;

    invoke-direct {p1}, La/aG;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/w;->p:La/aG;

    :cond_4
    return-void

    :cond_5
    :goto_1
    iput-boolean v0, p0, Landroidx/lifecycle/w;->O:Z

    return-void
.end method

.method public final X(La/m2;)V
    .locals 1

    .line 1
    const-string v0, "setCurrentState"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/w;->e(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Landroidx/lifecycle/w;->Q(La/m2;)V

    return-void
.end method

.method public final e(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/lifecycle/w;->h:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-static {}, La/t5;->Pb()La/t5;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v0, v0, La/t5;->K:La/RM;

    .line 10
    .line 11
    invoke-virtual {v0}, La/RM;->lI()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string v0, "Method "

    .line 19
    .line 20
    const-string v1, " must be called on the main thread"

    .line 21
    .line 22
    invoke-static {v0, p1, v1}, La/zq;->I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 27
    .line 28
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v0

    .line 36
    :cond_1
    :goto_0
    return-void
.end method

.method public final h(La/IQ;)V
    .locals 1

    .line 1
    const-string v0, "removeObserver"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/w;->e(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/lifecycle/w;->p:La/aG;

    invoke-virtual {v0, p1}, La/aG;->e(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final i(La/cw;)V
    .locals 1

    .line 1
    const-string v0, "handleLifecycleEvent"

    invoke-virtual {p0, v0}, Landroidx/lifecycle/w;->e(Ljava/lang/String;)V

    invoke-virtual {p1}, La/cw;->w()La/m2;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/lifecycle/w;->Q(La/m2;)V

    return-void
.end method

.method public final p(La/IQ;)La/m2;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 2
    .line 3
    iget-object v0, v0, La/aG;->d:Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, La/dA;

    .line 17
    .line 18
    iget-object p1, p1, La/dA;->L:La/dA;

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    move-object p1, v2

    .line 22
    :goto_0
    if-eqz p1, :cond_1

    .line 23
    .line 24
    iget-object p1, p1, La/dA;->K:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, La/jl;

    .line 27
    .line 28
    if-eqz p1, :cond_1

    .line 29
    .line 30
    iget-object p1, p1, La/jl;->w:La/m2;

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_1
    move-object p1, v2

    .line 34
    :goto_1
    iget-object v0, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    xor-int/lit8 v1, v1, 0x1

    .line 41
    .line 42
    if-eqz v1, :cond_2

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    add-int/lit8 v1, v1, -0x1

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    move-object v2, v0

    .line 55
    check-cast v2, La/m2;

    .line 56
    .line 57
    :cond_2
    iget-object v0, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 58
    .line 59
    if-eqz p1, :cond_3

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-gez v1, :cond_3

    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_3
    move-object p1, v0

    .line 69
    :goto_2
    if-eqz v2, :cond_4

    .line 70
    .line 71
    invoke-virtual {v2, p1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-gez v0, :cond_4

    .line 76
    .line 77
    goto :goto_3

    .line 78
    :cond_4
    move-object v2, p1

    .line 79
    :goto_3
    return-object v2
.end method

.method public final w(La/IQ;)V
    .locals 9

    .line 1
    const-string v0, "addObserver"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroidx/lifecycle/w;->e(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/lifecycle/w;->e:La/m2;

    .line 7
    .line 8
    sget-object v1, La/m2;->X:La/m2;

    .line 9
    .line 10
    if-ne v0, v1, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    sget-object v1, La/m2;->K:La/m2;

    .line 14
    .line 15
    :goto_0
    new-instance v0, La/jl;

    .line 16
    .line 17
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    sget-object v2, La/TW;->w:Ljava/util/HashMap;

    .line 21
    .line 22
    instance-of v2, p1, La/dr;

    .line 23
    .line 24
    instance-of v3, p1, La/no;

    .line 25
    .line 26
    const/4 v4, 0x2

    .line 27
    const/4 v5, 0x1

    .line 28
    const/4 v6, 0x0

    .line 29
    const/4 v7, 0x0

    .line 30
    if-eqz v2, :cond_1

    .line 31
    .line 32
    if-eqz v3, :cond_1

    .line 33
    .line 34
    new-instance v2, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;

    .line 35
    .line 36
    move-object v3, p1

    .line 37
    check-cast v3, La/no;

    .line 38
    .line 39
    move-object v8, p1

    .line 40
    check-cast v8, La/dr;

    .line 41
    .line 42
    invoke-direct {v2, v3, v8}, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;-><init>(La/no;La/dr;)V

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_1
    if-eqz v3, :cond_2

    .line 47
    .line 48
    new-instance v2, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;

    .line 49
    .line 50
    move-object v3, p1

    .line 51
    check-cast v3, La/no;

    .line 52
    .line 53
    invoke-direct {v2, v3, v6}, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;-><init>(La/no;La/dr;)V

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_2
    if-eqz v2, :cond_3

    .line 58
    .line 59
    move-object v2, p1

    .line 60
    check-cast v2, La/dr;

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-static {v2}, La/TW;->h(Ljava/lang/Class;)I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    if-ne v3, v4, :cond_6

    .line 72
    .line 73
    sget-object v3, La/TW;->h:Ljava/util/HashMap;

    .line 74
    .line 75
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    check-cast v2, Ljava/util/List;

    .line 80
    .line 81
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    if-eq v3, v5, :cond_5

    .line 86
    .line 87
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    new-array v8, v3, [La/Tw;

    .line 92
    .line 93
    if-gtz v3, :cond_4

    .line 94
    .line 95
    new-instance v2, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;

    .line 96
    .line 97
    invoke-direct {v2, v8}, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;-><init>([La/Tw;)V

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_4
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    check-cast v0, Ljava/lang/reflect/Constructor;

    .line 106
    .line 107
    invoke-static {v0, p1}, La/TW;->w(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    throw v6

    .line 111
    :cond_5
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Ljava/lang/reflect/Constructor;

    .line 116
    .line 117
    invoke-static {v0, p1}, La/TW;->w(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    throw v6

    .line 121
    :cond_6
    new-instance v2, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;

    .line 122
    .line 123
    invoke-direct {v2, p1}, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;-><init>(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :goto_1
    iput-object v2, v0, La/jl;->h:La/dr;

    .line 127
    .line 128
    iput-object v1, v0, La/jl;->w:La/m2;

    .line 129
    .line 130
    iget-object v1, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 131
    .line 132
    invoke-virtual {v1, p1, v0}, La/aG;->p(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    check-cast v1, La/jl;

    .line 137
    .line 138
    if-eqz v1, :cond_7

    .line 139
    .line 140
    return-void

    .line 141
    :cond_7
    iget-object v1, p0, Landroidx/lifecycle/w;->i:Ljava/lang/ref/WeakReference;

    .line 142
    .line 143
    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    check-cast v1, La/RH;

    .line 148
    .line 149
    if-nez v1, :cond_8

    .line 150
    .line 151
    return-void

    .line 152
    :cond_8
    iget v2, p0, Landroidx/lifecycle/w;->Q:I

    .line 153
    .line 154
    if-nez v2, :cond_9

    .line 155
    .line 156
    iget-boolean v2, p0, Landroidx/lifecycle/w;->X:Z

    .line 157
    .line 158
    if-eqz v2, :cond_a

    .line 159
    .line 160
    :cond_9
    move v7, v5

    .line 161
    :cond_a
    invoke-virtual {p0, p1}, Landroidx/lifecycle/w;->p(La/IQ;)La/m2;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    iget v3, p0, Landroidx/lifecycle/w;->Q:I

    .line 166
    .line 167
    add-int/2addr v3, v5

    .line 168
    iput v3, p0, Landroidx/lifecycle/w;->Q:I

    .line 169
    .line 170
    :goto_2
    iget-object v3, v0, La/jl;->w:La/m2;

    .line 171
    .line 172
    invoke-virtual {v3, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 173
    .line 174
    .line 175
    move-result v2

    .line 176
    if-gez v2, :cond_f

    .line 177
    .line 178
    iget-object v2, p0, Landroidx/lifecycle/w;->p:La/aG;

    .line 179
    .line 180
    iget-object v2, v2, La/aG;->d:Ljava/util/HashMap;

    .line 181
    .line 182
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    move-result v2

    .line 186
    if-eqz v2, :cond_f

    .line 187
    .line 188
    iget-object v2, v0, La/jl;->w:La/m2;

    .line 189
    .line 190
    iget-object v3, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 191
    .line 192
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    sget-object v2, La/cw;->Companion:La/K2;

    .line 196
    .line 197
    iget-object v3, v0, La/jl;->w:La/m2;

    .line 198
    .line 199
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    if-eq v2, v5, :cond_d

    .line 207
    .line 208
    if-eq v2, v4, :cond_c

    .line 209
    .line 210
    const/4 v3, 0x3

    .line 211
    if-eq v2, v3, :cond_b

    .line 212
    .line 213
    move-object v2, v6

    .line 214
    goto :goto_3

    .line 215
    :cond_b
    sget-object v2, La/cw;->ON_RESUME:La/cw;

    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_c
    sget-object v2, La/cw;->ON_START:La/cw;

    .line 219
    .line 220
    goto :goto_3

    .line 221
    :cond_d
    sget-object v2, La/cw;->ON_CREATE:La/cw;

    .line 222
    .line 223
    :goto_3
    if-eqz v2, :cond_e

    .line 224
    .line 225
    invoke-virtual {v0, v1, v2}, La/jl;->w(La/RH;La/cw;)V

    .line 226
    .line 227
    .line 228
    iget-object v2, p0, Landroidx/lifecycle/w;->V:Ljava/util/ArrayList;

    .line 229
    .line 230
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 231
    .line 232
    .line 233
    move-result v3

    .line 234
    sub-int/2addr v3, v5

    .line 235
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    invoke-virtual {p0, p1}, Landroidx/lifecycle/w;->p(La/IQ;)La/m2;

    .line 239
    .line 240
    .line 241
    move-result-object v2

    .line 242
    goto :goto_2

    .line 243
    :cond_e
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 244
    .line 245
    new-instance v1, Ljava/lang/StringBuilder;

    .line 246
    .line 247
    const-string v2, "no event up from "

    .line 248
    .line 249
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    iget-object v0, v0, La/jl;->w:La/m2;

    .line 253
    .line 254
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 255
    .line 256
    .line 257
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v0

    .line 261
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    throw p1

    .line 265
    :cond_f
    if-nez v7, :cond_10

    .line 266
    .line 267
    invoke-virtual {p0}, Landroidx/lifecycle/w;->O()V

    .line 268
    .line 269
    .line 270
    :cond_10
    iget p1, p0, Landroidx/lifecycle/w;->Q:I

    .line 271
    .line 272
    add-int/lit8 p1, p1, -0x1

    .line 273
    .line 274
    iput p1, p0, Landroidx/lifecycle/w;->Q:I

    .line 275
    .line 276
    return-void
.end method
