.class public final La/PX;
.super Landroid/text/SpannableStringBuilder;
.source "SourceFile"
