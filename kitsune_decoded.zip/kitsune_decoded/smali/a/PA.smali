.class public final La/PA;
.super La/yG;
.source "SourceFile"

# interfaces
.implements La/Wb;


# instance fields
.field public d:I

.field public final synthetic f:La/yC;


# direct methods
.method public constructor <init>(La/yC;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/PA;->f:La/yC;

    invoke-direct {p0, p2}, La/yG;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final I(Ljava/lang/Object;La/hu;)La/hu;
    .locals 1

    .line 1
    new-instance p1, La/PA;

    iget-object v0, p0, La/PA;->f:La/yC;

    invoke-direct {p1, v0, p2}, La/PA;-><init>(La/yC;La/hu;)V

    return-object p1
.end method

.method public final O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La/wE;

    .line 2
    .line 3
    check-cast p2, La/hu;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La/PA;->I(Ljava/lang/Object;La/hu;)La/hu;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La/PA;

    .line 10
    .line 11
    sget-object p2, La/rr;->w:La/rr;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La/PA;->T(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, La/cj;->X:La/cj;

    .line 2
    .line 3
    iget v1, p0, La/PA;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    new-instance p1, La/Hf;

    .line 26
    .line 27
    iget-object v1, p0, La/PA;->f:La/yC;

    .line 28
    .line 29
    const/4 v3, 0x2

    .line 30
    invoke-direct {p1, v1, v1, v3}, La/Hf;-><init>(Ljava/util/AbstractList;Ljava/util/List;I)V

    .line 31
    .line 32
    .line 33
    iput v2, p0, La/PA;->d:I

    .line 34
    .line 35
    invoke-static {p1, p0}, La/Q6;->R(La/Q6;La/hu;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    if-ne p1, v0, :cond_2

    .line 40
    .line 41
    return-object v0

    .line 42
    :cond_2
    :goto_0
    return-object p1
.end method
