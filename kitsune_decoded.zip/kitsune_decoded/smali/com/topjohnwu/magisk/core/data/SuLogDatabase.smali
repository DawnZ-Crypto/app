.class public abstract Lcom/topjohnwu/magisk/core/data/SuLogDatabase;
.super La/cO;
.source "SourceFile"


# static fields
.field public static final m:La/U0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/U0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->m:La/U0;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, La/cO;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract T()La/GN;
.end method
