.class public final La/PR;
.super La/Y;
.source "SourceFile"

# interfaces
.implements La/s;


# instance fields
.field public final X:[B


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/q5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput v1, v0, La/q5;->w:I

    .line 8
    .line 9
    const/16 v1, 0x15

    .line 10
    .line 11
    iput v1, v0, La/q5;->h:I

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>([B)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La/PR;->X:[B

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final K(Z)I
    .locals 1

    .line 1
    iget-object v0, p0, La/PR;->X:[B

    .line 2
    .line 3
    array-length v0, v0

    .line 4
    invoke-static {v0, p1}, La/sR;->X(IZ)I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    return p1
.end method

.method public final Q()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, La/PR;->X:[B

    .line 2
    .line 3
    invoke-static {v0}, La/mb;->w([B)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final T(La/Y;)Z
    .locals 1

    .line 1
    instance-of v0, p1, La/PR;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    check-cast p1, La/PR;

    .line 8
    .line 9
    iget-object p1, p1, La/PR;->X:[B

    .line 10
    .line 11
    iget-object v0, p0, La/PR;->X:[B

    .line 12
    .line 13
    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    :goto_0
    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, La/PR;->X:[B

    .line 2
    .line 3
    invoke-static {v0}, La/rx;->Z([B)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final m(La/sR;Z)V
    .locals 2

    .line 1
    const/16 v0, 0x15

    .line 2
    .line 3
    iget-object v1, p0, La/PR;->X:[B

    .line 4
    .line 5
    invoke-virtual {p1, v0, p2, v1}, La/sR;->y(IZ[B)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final bridge synthetic y()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method
