.class public final La/tQ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/hC;


# instance fields
.field public h:I

.field public final p:Ljava/util/LinkedList;

.field public final w:C


# direct methods
.method public constructor <init>(C)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, La/tQ;->h:I

    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, La/tQ;->p:Ljava/util/LinkedList;

    iput-char p1, p0, La/tQ;->w:C

    return-void
.end method


# virtual methods
.method public final Q(La/hC;)V
    .locals 4

    .line 1
    invoke-interface {p1}, La/hC;->p()I

    move-result v0

    iget-object v1, p0, La/tQ;->p:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/AbstractList;->listIterator()Ljava/util/ListIterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/ListIterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, La/hC;

    invoke-interface {v3}, La/hC;->p()I

    move-result v3

    if-le v0, v3, :cond_0

    invoke-interface {v2}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    invoke-interface {v2, p1}, Ljava/util/ListIterator;->add(Ljava/lang/Object;)V

    goto :goto_1

    :cond_0
    if-eq v0, v3, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Cannot add two delimiter processors for char \'"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-char v2, p0, La/tQ;->w:C

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, "\' and minimum length "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    invoke-virtual {v1, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    iput v0, p0, La/tQ;->h:I

    :goto_1
    return-void
.end method

.method public final e(La/aa;La/aa;I)V
    .locals 4

    .line 1
    iget-object v0, p0, La/tQ;->p:Ljava/util/LinkedList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_1

    .line 12
    .line 13
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, La/hC;

    .line 18
    .line 19
    invoke-interface {v2}, La/hC;->p()I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-gt v3, p3, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {v0}, Ljava/util/LinkedList;->getFirst()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    move-object v2, v0

    .line 31
    check-cast v2, La/hC;

    .line 32
    .line 33
    :goto_0
    invoke-interface {v2, p1, p2, p3}, La/hC;->e(La/aa;La/aa;I)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final h(La/iE;La/iE;)I
    .locals 5

    .line 1
    iget v0, p1, La/iE;->X:I

    .line 2
    .line 3
    iget-object v1, p0, La/tQ;->p:Ljava/util/LinkedList;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    if-eqz v3, :cond_1

    .line 14
    .line 15
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    check-cast v3, La/hC;

    .line 20
    .line 21
    invoke-interface {v3}, La/hC;->p()I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    if-gt v4, v0, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    invoke-virtual {v1}, Ljava/util/LinkedList;->getFirst()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    move-object v3, v0

    .line 33
    check-cast v3, La/hC;

    .line 34
    .line 35
    :goto_0
    invoke-interface {v3, p1, p2}, La/hC;->h(La/iE;La/iE;)I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    return p1
.end method

.method public final i()C
    .locals 1

    .line 1
    iget-char v0, p0, La/tQ;->w:C

    return v0
.end method

.method public final p()I
    .locals 1

    .line 1
    iget v0, p0, La/tQ;->h:I

    return v0
.end method

.method public final w()C
    .locals 1

    .line 1
    iget-char v0, p0, La/tQ;->w:C

    return v0
.end method
