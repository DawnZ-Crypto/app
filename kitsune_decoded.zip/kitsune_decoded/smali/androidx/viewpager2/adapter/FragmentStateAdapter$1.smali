.class Landroidx/viewpager2/adapter/FragmentStateAdapter$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    throw p1
.end method
