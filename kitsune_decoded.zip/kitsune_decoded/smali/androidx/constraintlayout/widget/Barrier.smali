.class public Landroidx/constraintlayout/widget/Barrier;
.super La/Sc;
.source "SourceFile"


# instance fields
.field public E:La/SD;

.field public F:I

.field public q:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, La/Sc;->K:[I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La/Sc;->W:Ljava/util/HashMap;

    iput-object p1, p0, La/Sc;->L:Landroid/content/Context;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/Barrier;->X(Landroid/util/AttributeSet;)V

    const/16 p1, 0x8

    .line 2
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1, p2}, La/Sc;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/16 p1, 0x8

    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method public final O(La/c6;Z)V
    .locals 5

    .line 1
    iget v0, p0, Landroidx/constraintlayout/widget/Barrier;->q:I

    .line 2
    .line 3
    iput v0, p0, Landroidx/constraintlayout/widget/Barrier;->F:I

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x6

    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x5

    .line 9
    if-eqz p2, :cond_1

    .line 10
    .line 11
    if-ne v0, v4, :cond_0

    .line 12
    .line 13
    :goto_0
    iput v3, p0, Landroidx/constraintlayout/widget/Barrier;->F:I

    .line 14
    .line 15
    goto :goto_2

    .line 16
    :cond_0
    if-ne v0, v2, :cond_3

    .line 17
    .line 18
    :goto_1
    iput v1, p0, Landroidx/constraintlayout/widget/Barrier;->F:I

    .line 19
    .line 20
    goto :goto_2

    .line 21
    :cond_1
    if-ne v0, v4, :cond_2

    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_2
    if-ne v0, v2, :cond_3

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_3
    :goto_2
    instance-of p2, p1, La/SD;

    .line 28
    .line 29
    if-eqz p2, :cond_4

    .line 30
    .line 31
    check-cast p1, La/SD;

    .line 32
    .line 33
    iget p2, p0, Landroidx/constraintlayout/widget/Barrier;->F:I

    .line 34
    .line 35
    iput p2, p1, La/SD;->MX:I

    .line 36
    .line 37
    :cond_4
    return-void
.end method

.method public final X(Landroid/util/AttributeSet;)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, La/Sc;->X(Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/SD;

    .line 5
    .line 6
    invoke-direct {v0}, La/vZ;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    iput v1, v0, La/SD;->MX:I

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    iput-boolean v2, v0, La/SD;->cS:Z

    .line 14
    .line 15
    iput v1, v0, La/SD;->Qg:I

    .line 16
    .line 17
    iput-boolean v1, v0, La/SD;->Tr:Z

    .line 18
    .line 19
    iput-object v0, p0, Landroidx/constraintlayout/widget/Barrier;->E:La/SD;

    .line 20
    .line 21
    if-eqz p1, :cond_4

    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sget-object v3, La/dp;->h:[I

    .line 28
    .line 29
    invoke-virtual {v0, p1, v3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    move v3, v1

    .line 38
    :goto_0
    if-ge v3, v0, :cond_3

    .line 39
    .line 40
    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    const/16 v5, 0x1a

    .line 45
    .line 46
    if-ne v4, v5, :cond_0

    .line 47
    .line 48
    invoke-virtual {p1, v4, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    iput v4, p0, Landroidx/constraintlayout/widget/Barrier;->q:I

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_0
    const/16 v5, 0x19

    .line 56
    .line 57
    if-ne v4, v5, :cond_1

    .line 58
    .line 59
    iget-object v5, p0, Landroidx/constraintlayout/widget/Barrier;->E:La/SD;

    .line 60
    .line 61
    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    iput-boolean v4, v5, La/SD;->cS:Z

    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_1
    const/16 v5, 0x1b

    .line 69
    .line 70
    if-ne v4, v5, :cond_2

    .line 71
    .line 72
    invoke-virtual {p1, v4, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 73
    .line 74
    .line 75
    move-result v4

    .line 76
    iget-object v5, p0, Landroidx/constraintlayout/widget/Barrier;->E:La/SD;

    .line 77
    .line 78
    iput v4, v5, La/SD;->Qg:I

    .line 79
    .line 80
    :cond_2
    :goto_1
    add-int/lit8 v3, v3, 0x1

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 84
    .line 85
    .line 86
    :cond_4
    iget-object p1, p0, Landroidx/constraintlayout/widget/Barrier;->E:La/SD;

    .line 87
    .line 88
    iput-object p1, p0, La/Sc;->d:La/vZ;

    .line 89
    .line 90
    invoke-virtual {p0}, La/Sc;->T()V

    .line 91
    .line 92
    .line 93
    return-void
.end method
