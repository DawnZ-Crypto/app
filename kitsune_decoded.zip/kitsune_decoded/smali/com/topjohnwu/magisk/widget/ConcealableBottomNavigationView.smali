.class public Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;
.super La/c5;
.source "SourceFile"


# static fields
.field public static final q:[I


# instance fields
.field public W:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const v0, 0x7f040420

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->q:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 6

    .line 1
    const v3, 0x7f04007f

    .line 2
    .line 3
    .line 4
    const v4, 0x7f13036c

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, p1, p2}, La/eg;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget-object v2, La/tS;->e:[I

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    new-array v5, p1, [I

    .line 18
    .line 19
    move-object v1, p2

    .line 20
    invoke-static/range {v0 .. v5}, La/fe;->t(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)La/yW;

    .line 21
    .line 22
    .line 23
    move-result-object p2

    .line 24
    const/4 v0, 0x2

    .line 25
    const/4 v1, 0x1

    .line 26
    invoke-virtual {p2, v0, v1}, La/yW;->K(IZ)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iget-object v2, p0, La/eg;->R:La/eO;

    .line 31
    .line 32
    iget-boolean v3, v2, La/eO;->FL:Z

    .line 33
    .line 34
    if-eq v3, v0, :cond_0

    .line 35
    .line 36
    iput-boolean v0, v2, La/eO;->FL:Z

    .line 37
    .line 38
    iget-object v0, p0, La/eg;->L:La/t9;

    .line 39
    .line 40
    invoke-virtual {v0, p1}, La/t9;->m(Z)V

    .line 41
    .line 42
    .line 43
    :cond_0
    invoke-virtual {p2, p1}, La/yW;->z(I)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_1

    .line 48
    .line 49
    invoke-virtual {p2, p1, p1}, La/yW;->d(II)I

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    invoke-virtual {p0, p1}, Landroid/view/View;->setMinimumHeight(I)V

    .line 54
    .line 55
    .line 56
    :cond_1
    invoke-virtual {p2, v1, v1}, La/yW;->K(IZ)Z

    .line 57
    .line 58
    .line 59
    invoke-virtual {p2}, La/yW;->Y()V

    .line 60
    .line 61
    .line 62
    new-instance p1, La/ze;

    .line 63
    .line 64
    const/16 p2, 0x16

    .line 65
    .line 66
    invoke-direct {p1, p2, p0}, La/ze;-><init>(ILjava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    invoke-static {p0, p1}, La/rE;->U(Landroid/view/View;La/JJ;)V

    .line 70
    .line 71
    .line 72
    return-void
.end method


# virtual methods
.method public final onCreateDrawableState(I)[I
    .locals 1

    .line 1
    add-int/lit8 p1, p1, 0x1

    .line 2
    .line 3
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onCreateDrawableState(I)[I

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-boolean v0, p0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->W:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    sget-object v0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->q:[I

    .line 12
    .line 13
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 14
    .line 15
    .line 16
    :cond_0
    return-object p1
.end method

.method public final onMeasure(II)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, La/c5;->onMeasure(II)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    const/4 p2, 0x1

    .line 9
    new-array v0, p2, [F

    .line 10
    .line 11
    int-to-float p1, p1

    .line 12
    const/4 v1, 0x0

    .line 13
    aput p1, v0, v1

    .line 14
    .line 15
    const-string p1, "translationY"

    .line 16
    .line 17
    invoke-static {p0, p1, v0}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const-wide/16 v2, 0xaf

    .line 22
    .line 23
    invoke-virtual {v0, v2, v3}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 24
    .line 25
    .line 26
    new-instance v2, La/qf;

    .line 27
    .line 28
    invoke-direct {v2}, La/qf;-><init>()V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v2}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 32
    .line 33
    .line 34
    new-array p2, p2, [F

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    aput v2, p2, v1

    .line 38
    .line 39
    invoke-static {p0, p1, p2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    const-wide/16 v2, 0xe1

    .line 44
    .line 45
    invoke-virtual {p1, v2, v3}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 46
    .line 47
    .line 48
    new-instance p2, La/qf;

    .line 49
    .line 50
    invoke-direct {p2}, La/qf;-><init>()V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1, p2}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 54
    .line 55
    .line 56
    new-instance p2, Landroid/animation/StateListAnimator;

    .line 57
    .line 58
    invoke-direct {p2}, Landroid/animation/StateListAnimator;-><init>()V

    .line 59
    .line 60
    .line 61
    sget-object v2, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->q:[I

    .line 62
    .line 63
    invoke-virtual {p2, v2, v0}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    .line 64
    .line 65
    .line 66
    new-array v0, v1, [I

    .line 67
    .line 68
    invoke-virtual {p2, v0, p1}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0, p2}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 0

    .line 1
    check-cast p1, La/F6;

    .line 2
    .line 3
    iget-object p1, p1, La/o;->X:Landroid/os/Parcelable;

    .line 4
    .line 5
    invoke-super {p0, p1}, La/eg;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    new-instance v0, La/F6;

    .line 2
    .line 3
    invoke-super {p0}, La/eg;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, La/o;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    iget-boolean v1, p0, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;->W:Z

    .line 11
    .line 12
    iput-boolean v1, v0, La/F6;->R:Z

    .line 13
    .line 14
    return-object v0
.end method
