.class public final La/Lh;
.super La/qB;
.source "SourceFile"


# virtual methods
.method public final w(La/Cz;)V
    .locals 0

    .line 1
    check-cast p1, La/gS;

    .line 2
    .line 3
    invoke-virtual {p1, p0}, La/gS;->Q(La/QW;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
