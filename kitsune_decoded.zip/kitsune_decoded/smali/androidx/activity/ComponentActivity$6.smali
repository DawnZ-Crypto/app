.class Landroidx/activity/ComponentActivity$6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic X:Landroidx/activity/w;


# direct methods
.method public constructor <init>(Landroidx/activity/w;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/ComponentActivity$6;->X:Landroidx/activity/w;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 1

    .line 1
    sget-object v0, La/cw;->ON_CREATE:La/cw;

    .line 2
    .line 3
    if-ne p2, v0, :cond_0

    .line 4
    .line 5
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v0, 0x21

    .line 8
    .line 9
    if-lt p2, v0, :cond_0

    .line 10
    .line 11
    iget-object p2, p0, Landroidx/activity/ComponentActivity$6;->X:Landroidx/activity/w;

    .line 12
    .line 13
    iget-object p2, p2, Landroidx/activity/w;->W:Landroidx/activity/h;

    .line 14
    .line 15
    check-cast p1, Landroidx/activity/w;

    .line 16
    .line 17
    invoke-static {p1}, La/UX;->w(Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p2, Landroidx/activity/h;->i:Landroid/window/OnBackInvokedDispatcher;

    .line 22
    .line 23
    iget-boolean p1, p2, Landroidx/activity/h;->X:Z

    .line 24
    .line 25
    invoke-virtual {p2, p1}, Landroidx/activity/h;->p(Z)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void
.end method
