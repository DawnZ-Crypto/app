.class public final La/MH;
.super La/Hb;
.source "SourceFile"


# static fields
.field public static final L:La/MH;

.field public static final d:La/un;

.field public static final f:I

.field public static final l:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/MH;

    .line 2
    .line 3
    invoke-direct {v0}, La/Hb;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/MH;->L:La/MH;

    .line 7
    .line 8
    new-instance v0, La/un;

    .line 9
    .line 10
    const v1, 0x7f1200b2

    .line 11
    .line 12
    .line 13
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, La/MH;->d:La/un;

    .line 17
    .line 18
    const v0, 0x7f030009

    .line 19
    .line 20
    .line 21
    sput v0, La/MH;->f:I

    .line 22
    .line 23
    const v0, 0x7f03000a

    .line 24
    .line 25
    .line 26
    sput v0, La/MH;->l:I

    .line 27
    .line 28
    sget-object v0, La/Dp;->w:La/Dp;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final E()I
    .locals 1

    .line 1
    sget v0, La/MH;->l:I

    return v0
.end method

.method public final S()I
    .locals 1

    .line 1
    sget v0, La/MH;->f:I

    return v0
.end method

.method public final W(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Ljava/lang/Number;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    sget-object v0, La/Dp;->w:La/Dp;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object v1, La/Dp;->h:[La/KG;

    .line 13
    .line 14
    const/16 v2, 0x13

    .line 15
    .line 16
    aget-object v1, v1, v2

    .line 17
    .line 18
    sget-object v1, La/Dp;->E:La/pj;

    .line 19
    .line 20
    invoke-virtual {v1, v0, p1}, La/pj;->h(La/ac;I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final l()Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, La/Dp;->w:La/Dp;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v1, La/Dp;->h:[La/KG;

    .line 7
    .line 8
    const/16 v2, 0x13

    .line 9
    .line 10
    aget-object v1, v1, v2

    .line 11
    .line 12
    sget-object v1, La/Dp;->E:La/pj;

    .line 13
    .line 14
    invoke-virtual {v1, v0}, La/pj;->w(La/ac;)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    return-object v0
.end method

.method public final y()La/un;
    .locals 1

    .line 1
    sget-object v0, La/MH;->d:La/un;

    return-object v0
.end method
