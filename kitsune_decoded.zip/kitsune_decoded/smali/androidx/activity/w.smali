.class public abstract Landroidx/activity/w;
.super La/l6;
.source "SourceFile"

# interfaces
.implements La/CG;
.implements La/kO;
.implements La/vd;
.implements La/LS;
.implements La/rq;
.implements La/b6;
.implements La/cf;
.implements La/V8;
.implements La/x9;
.implements La/r7;


# instance fields
.field public final D:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final E:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final F:La/Jc;

.field public final H:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final K:La/yg;

.field public final L:Landroidx/lifecycle/w;

.field public final P:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final R:La/yW;

.field public final S:La/Y6;

.field public U:Z

.field public W:Landroidx/activity/h;

.field public final Y:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public final d:La/fj;

.field public f:La/Sx;

.field public l:La/qN;

.field public final q:La/HQ;

.field public u:Z

.field public final z:Ljava/util/concurrent/CopyOnWriteArrayList;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/lifecycle/w;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Landroidx/lifecycle/w;-><init>(La/RH;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La/l6;->X:Landroidx/lifecycle/w;

    .line 10
    .line 11
    new-instance v0, La/yg;

    .line 12
    .line 13
    invoke-direct {v0}, La/yg;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Landroidx/activity/w;->K:La/yg;

    .line 17
    .line 18
    new-instance v0, La/yW;

    .line 19
    .line 20
    new-instance v1, La/xp;

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-direct {v1, v2, p0}, La/xp;-><init>(ILjava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {v0, v1}, La/yW;-><init>(Ljava/lang/Runnable;)V

    .line 27
    .line 28
    .line 29
    iput-object v0, p0, Landroidx/activity/w;->R:La/yW;

    .line 30
    .line 31
    new-instance v0, Landroidx/lifecycle/w;

    .line 32
    .line 33
    invoke-direct {v0, p0}, Landroidx/lifecycle/w;-><init>(La/RH;)V

    .line 34
    .line 35
    .line 36
    iput-object v0, p0, Landroidx/activity/w;->L:Landroidx/lifecycle/w;

    .line 37
    .line 38
    new-instance v1, La/fj;

    .line 39
    .line 40
    invoke-direct {v1, p0}, La/fj;-><init>(La/vd;)V

    .line 41
    .line 42
    .line 43
    iput-object v1, p0, Landroidx/activity/w;->d:La/fj;

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    iput-object v3, p0, Landroidx/activity/w;->W:Landroidx/activity/h;

    .line 47
    .line 48
    new-instance v3, La/HQ;

    .line 49
    .line 50
    move-object v4, p0

    .line 51
    check-cast v4, La/Jf;

    .line 52
    .line 53
    invoke-direct {v3, v4}, La/HQ;-><init>(La/Jf;)V

    .line 54
    .line 55
    .line 56
    iput-object v3, p0, Landroidx/activity/w;->q:La/HQ;

    .line 57
    .line 58
    new-instance v3, La/Jc;

    .line 59
    .line 60
    new-instance v5, La/XN;

    .line 61
    .line 62
    invoke-direct {v5, v4}, La/XN;-><init>(La/Jf;)V

    .line 63
    .line 64
    .line 65
    invoke-direct {v3, v5}, La/Jc;-><init>(La/XN;)V

    .line 66
    .line 67
    .line 68
    iput-object v3, p0, Landroidx/activity/w;->F:La/Jc;

    .line 69
    .line 70
    new-instance v3, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 71
    .line 72
    invoke-direct {v3}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    .line 73
    .line 74
    .line 75
    iput-object v3, p0, Landroidx/activity/w;->E:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 76
    .line 77
    new-instance v3, La/Y6;

    .line 78
    .line 79
    invoke-direct {v3, v4}, La/Y6;-><init>(La/Jf;)V

    .line 80
    .line 81
    .line 82
    iput-object v3, p0, Landroidx/activity/w;->S:La/Y6;

    .line 83
    .line 84
    new-instance v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 85
    .line 86
    invoke-direct {v3}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 87
    .line 88
    .line 89
    iput-object v3, p0, Landroidx/activity/w;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 90
    .line 91
    new-instance v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 92
    .line 93
    invoke-direct {v3}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 94
    .line 95
    .line 96
    iput-object v3, p0, Landroidx/activity/w;->z:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 97
    .line 98
    new-instance v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 99
    .line 100
    invoke-direct {v3}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 101
    .line 102
    .line 103
    iput-object v3, p0, Landroidx/activity/w;->P:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 104
    .line 105
    new-instance v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 106
    .line 107
    invoke-direct {v3}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 108
    .line 109
    .line 110
    iput-object v3, p0, Landroidx/activity/w;->D:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 111
    .line 112
    new-instance v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 113
    .line 114
    invoke-direct {v3}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 115
    .line 116
    .line 117
    iput-object v3, p0, Landroidx/activity/w;->Y:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 118
    .line 119
    iput-boolean v2, p0, Landroidx/activity/w;->u:Z

    .line 120
    .line 121
    iput-boolean v2, p0, Landroidx/activity/w;->U:Z

    .line 122
    .line 123
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 124
    .line 125
    new-instance v5, Landroidx/activity/ComponentActivity$2;

    .line 126
    .line 127
    invoke-direct {v5, v4}, Landroidx/activity/ComponentActivity$2;-><init>(La/Jf;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0, v5}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 131
    .line 132
    .line 133
    new-instance v5, Landroidx/activity/ComponentActivity$3;

    .line 134
    .line 135
    invoke-direct {v5, v4}, Landroidx/activity/ComponentActivity$3;-><init>(La/Jf;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v0, v5}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 139
    .line 140
    .line 141
    new-instance v5, Landroidx/activity/ComponentActivity$4;

    .line 142
    .line 143
    invoke-direct {v5, v4}, Landroidx/activity/ComponentActivity$4;-><init>(La/Jf;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v0, v5}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v1}, La/fj;->w()V

    .line 150
    .line 151
    .line 152
    invoke-static {p0}, La/fe;->L(La/vd;)V

    .line 153
    .line 154
    .line 155
    const/16 v5, 0x17

    .line 156
    .line 157
    if-gt v3, v5, :cond_0

    .line 158
    .line 159
    new-instance v3, Landroidx/activity/ImmLeaksCleaner;

    .line 160
    .line 161
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 162
    .line 163
    .line 164
    iput-object p0, v3, Landroidx/activity/ImmLeaksCleaner;->X:Landroid/app/Activity;

    .line 165
    .line 166
    invoke-virtual {v0, v3}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 167
    .line 168
    .line 169
    :cond_0
    new-instance v0, La/V0;

    .line 170
    .line 171
    invoke-direct {v0, v2, p0}, La/V0;-><init>(ILjava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    iget-object v1, v1, La/fj;->h:La/VV;

    .line 175
    .line 176
    const-string v3, "android:support:activity-result"

    .line 177
    .line 178
    invoke-virtual {v1, v3, v0}, La/VV;->p(Ljava/lang/String;La/KO;)V

    .line 179
    .line 180
    .line 181
    new-instance v0, La/PT;

    .line 182
    .line 183
    invoke-direct {v0, v4, v2}, La/PT;-><init>(La/Jf;I)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {p0, v0}, Landroidx/activity/w;->m(La/oh;)V

    .line 187
    .line 188
    .line 189
    return-void
.end method

.method public static synthetic T(Landroidx/activity/w;)V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    return-void
.end method


# virtual methods
.method public final I()Landroidx/lifecycle/w;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->L:Landroidx/lifecycle/w;

    return-object v0
.end method

.method public final K(La/Gk;La/WN;)La/Sl;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "activity_rq#"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Landroidx/activity/w;->E:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v1, p0, Landroidx/activity/w;->S:La/Y6;

    .line 22
    .line 23
    invoke-virtual {v1, v0, p0, p2, p1}, Landroidx/activity/result/w;->e(Ljava/lang/String;La/RH;La/WN;La/Gk;)La/Sl;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    return-object p1
.end method

.method public final M()La/o7;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->l:La/qN;

    if-nez v0, :cond_1

    new-instance v0, La/qN;

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    invoke-direct {v0, v1, p0, v2}, La/qN;-><init>(Landroid/app/Application;La/vd;Landroid/os/Bundle;)V

    iput-object v0, p0, Landroidx/activity/w;->l:La/qN;

    :cond_1
    iget-object v0, p0, Landroidx/activity/w;->l:La/qN;

    return-object v0
.end method

.method public final h()La/VV;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->d:La/fj;

    .line 2
    .line 3
    iget-object v0, v0, La/fj;->h:La/VV;

    .line 4
    .line 5
    return-object v0
.end method

.method public final i()La/Sx;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    iget-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 8
    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, La/d2;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, v0, La/d2;->w:La/Sx;

    .line 20
    .line 21
    iput-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 22
    .line 23
    :cond_0
    iget-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    new-instance v0, La/Sx;

    .line 28
    .line 29
    invoke-direct {v0}, La/Sx;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 33
    .line 34
    :cond_1
    iget-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 35
    .line 36
    return-object v0

    .line 37
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 38
    .line 39
    const-string v1, "Your activity is not yet attached to the Application instance. You can\'t request ViewModel before onCreate call."

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0
.end method

.method public final m(La/oh;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->K:La/yg;

    .line 2
    .line 3
    iget-object v1, v0, La/yg;->h:Landroid/content/Context;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-interface {p1}, La/oh;->w()V

    .line 8
    .line 9
    .line 10
    :cond_0
    iget-object v0, v0, La/yg;->w:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    iget-object v0, p0, Landroidx/activity/w;->S:La/Y6;

    invoke-virtual {v0, p1, p2, p3}, Landroidx/activity/result/w;->w(IILandroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    :cond_0
    return-void
.end method

.method public onBackPressed()V
    .locals 1

    invoke-virtual {p0}, Landroidx/activity/w;->y()Landroidx/activity/h;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/activity/h;->h()V

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object v0, p0, Landroidx/activity/w;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    invoke-interface {v1, p1}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->d:La/fj;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La/fj;->h(Landroid/os/Bundle;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/w;->K:La/yg;

    .line 7
    .line 8
    iput-object p0, v0, La/yg;->h:Landroid/content/Context;

    .line 9
    .line 10
    iget-object v0, v0, La/yg;->w:Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, La/oh;

    .line 27
    .line 28
    invoke-interface {v1}, La/oh;->w()V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    invoke-super {p0, p1}, La/l6;->onCreate(Landroid/os/Bundle;)V

    .line 33
    .line 34
    .line 35
    invoke-static {p0}, La/eI;->L(Landroid/app/Activity;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/app/Activity;->getMenuInflater()Landroid/view/MenuInflater;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    iget-object v0, p0, Landroidx/activity/w;->R:La/yW;

    .line 11
    .line 12
    iget-object v0, v0, La/yW;->R:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, La/We;

    .line 31
    .line 32
    invoke-interface {v1, p2, p1}, La/We;->p(Landroid/view/Menu;Landroid/view/MenuInflater;)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 p1, 0x1

    .line 37
    return p1
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 3

    .line 1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    if-nez p1, :cond_3

    .line 11
    .line 12
    iget-object p1, p0, Landroidx/activity/w;->R:La/yW;

    .line 13
    .line 14
    iget-object p1, p1, La/yW;->R:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_2

    .line 27
    .line 28
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, La/We;

    .line 33
    .line 34
    invoke-interface {v2, p2}, La/We;->X(Landroid/view/MenuItem;)Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_2
    move v1, v0

    .line 42
    :goto_0
    return v1

    .line 43
    :cond_3
    return v0
.end method

.method public final onMultiWindowModeChanged(Z)V
    .locals 3

    .line 1
    iget-boolean v0, p0, Landroidx/activity/w;->u:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/activity/w;->D:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    new-instance v2, La/VD;

    invoke-direct {v2, p1}, La/VD;-><init>(Z)V

    invoke-interface {v1, v2}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final onMultiWindowModeChanged(ZLandroid/content/res/Configuration;)V
    .locals 3

    .line 2
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/activity/w;->u:Z

    const/4 v0, 0x0

    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMultiWindowModeChanged(ZLandroid/content/res/Configuration;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v0, p0, Landroidx/activity/w;->u:Z

    iget-object p2, p0, Landroidx/activity/w;->D:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    new-instance v2, La/VD;

    invoke-direct {v2, p1, v0}, La/VD;-><init>(ZI)V

    invoke-interface {v1, v2}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    return-void

    :catchall_0
    move-exception p1

    iput-boolean v0, p0, Landroidx/activity/w;->u:Z

    throw p1
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    iget-object v0, p0, Landroidx/activity/w;->P:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    invoke-interface {v1, p1}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public onPanelClosed(ILandroid/view/Menu;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->R:La/yW;

    .line 2
    .line 3
    iget-object v0, v0, La/yW;->R:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, La/We;

    .line 22
    .line 23
    invoke-interface {v1, p2}, La/We;->O(Landroid/view/Menu;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onPanelClosed(ILandroid/view/Menu;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final onPictureInPictureModeChanged(Z)V
    .locals 3

    .line 1
    iget-boolean v0, p0, Landroidx/activity/w;->U:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Landroidx/activity/w;->Y:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    new-instance v2, La/MJ;

    invoke-direct {v2, p1}, La/MJ;-><init>(Z)V

    invoke-interface {v1, v2}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V
    .locals 3

    .line 2
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/activity/w;->U:Z

    const/4 v0, 0x0

    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-boolean v0, p0, Landroidx/activity/w;->U:Z

    iget-object p2, p0, Landroidx/activity/w;->Y:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    new-instance v2, La/MJ;

    invoke-direct {v2, p1, v0}, La/MJ;-><init>(ZI)V

    invoke-interface {v1, v2}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    return-void

    :catchall_0
    move-exception p1

    iput-boolean v0, p0, Landroidx/activity/w;->U:Z

    throw p1
.end method

.method public final onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .locals 0

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Landroidx/activity/w;->R:La/yW;

    .line 7
    .line 8
    iget-object p1, p1, La/yW;->R:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result p2

    .line 20
    if-eqz p2, :cond_0

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p2

    .line 26
    check-cast p2, La/We;

    .line 27
    .line 28
    invoke-interface {p2, p3}, La/We;->e(Landroid/view/Menu;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    const/4 p1, 0x1

    .line 33
    return p1
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 3

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const-string v1, "androidx.activity.result.contract.extra.PERMISSIONS"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS"

    invoke-virtual {v0, v1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    move-result-object v0

    const/4 v1, -0x1

    iget-object v2, p0, Landroidx/activity/w;->S:La/Y6;

    invoke-virtual {v2, p1, v1, v0}, Landroidx/activity/result/w;->w(IILandroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    :cond_0
    return-void
.end method

.method public final onRetainNonConfigurationInstance()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->f:La/Sx;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, La/d2;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    iget-object v0, v1, La/d2;->w:La/Sx;

    .line 14
    .line 15
    :cond_0
    if-nez v0, :cond_1

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    return-object v0

    .line 19
    :cond_1
    new-instance v1, La/d2;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v0, v1, La/d2;->w:La/Sx;

    .line 25
    .line 26
    return-object v1
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    iget-object v0, p0, Landroidx/activity/w;->L:Landroidx/lifecycle/w;

    instance-of v1, v0, Landroidx/lifecycle/w;

    if-eqz v1, :cond_0

    sget-object v1, La/m2;->R:La/m2;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->X(La/m2;)V

    :cond_0
    invoke-super {p0, p1}, La/l6;->onSaveInstanceState(Landroid/os/Bundle;)V

    iget-object v0, p0, Landroidx/activity/w;->d:La/fj;

    invoke-virtual {v0, p1}, La/fj;->p(Landroid/os/Bundle;)V

    return-void
.end method

.method public final onTrimMemory(I)V
    .locals 3

    invoke-super {p0, p1}, Landroid/app/Activity;->onTrimMemory(I)V

    iget-object v0, p0, Landroidx/activity/w;->z:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, La/ir;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, La/ir;->w(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final reportFullyDrawn()V
    .locals 1

    .line 1
    :try_start_0
    invoke-static {}, La/rE;->Pb()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const-string v0, "reportFullyDrawn() for ComponentActivity"

    .line 8
    .line 9
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    goto :goto_0

    .line 13
    :catchall_0
    move-exception v0

    .line 14
    goto :goto_1

    .line 15
    :cond_0
    :goto_0
    invoke-super {p0}, Landroid/app/Activity;->reportFullyDrawn()V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Landroidx/activity/w;->F:La/Jc;

    .line 19
    .line 20
    invoke-virtual {v0}, La/Jc;->w()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    .line 23
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :goto_1
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 28
    .line 29
    .line 30
    throw v0
.end method

.method public final startActivityForResult(Landroid/content/Intent;I)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method public final startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V
    .locals 0

    .line 2
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    return-void
.end method

.method public final startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    .locals 0

    .line 1
    invoke-super/range {p0 .. p6}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V

    return-void
.end method

.method public final startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    .locals 0

    .line 2
    invoke-super/range {p0 .. p7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V

    return-void
.end method

.method public final w()La/NM;
    .locals 3

    .line 1
    new-instance v0, La/NM;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, La/NM;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    sget-object v1, La/Qr;->F:La/Qr;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v0, v1, v2}, La/NM;->w(La/e6;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    sget-object v1, La/fe;->D:La/Qr;

    .line 23
    .line 24
    invoke-virtual {v0, v1, p0}, La/NM;->w(La/e6;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    sget-object v1, La/fe;->Y:La/Qr;

    .line 28
    .line 29
    invoke-virtual {v0, v1, p0}, La/NM;->w(La/e6;Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-virtual {v1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    sget-object v1, La/fe;->u:La/Qr;

    .line 49
    .line 50
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    invoke-virtual {v0, v1, v2}, La/NM;->w(La/e6;Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :cond_1
    return-object v0
.end method

.method public final y()Landroidx/activity/h;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/activity/w;->W:Landroidx/activity/h;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/activity/h;

    new-instance v1, La/oE;

    const/4 v2, 0x0

    invoke-direct {v1, v2, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    invoke-direct {v0, v1}, Landroidx/activity/h;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Landroidx/activity/w;->W:Landroidx/activity/h;

    new-instance v0, Landroidx/activity/ComponentActivity$6;

    invoke-direct {v0, p0}, Landroidx/activity/ComponentActivity$6;-><init>(Landroidx/activity/w;)V

    iget-object v1, p0, Landroidx/activity/w;->L:Landroidx/lifecycle/w;

    invoke-virtual {v1, v0}, Landroidx/lifecycle/w;->w(La/IQ;)V

    :cond_0
    iget-object v0, p0, Landroidx/activity/w;->W:Landroidx/activity/h;

    return-object v0
.end method
