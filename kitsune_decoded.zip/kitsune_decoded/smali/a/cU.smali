.class public final La/cU;
.super La/oW;
.source "SourceFile"


# static fields
.field public static final R:La/cU;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/cU;

    .line 2
    .line 3
    invoke-direct {v0}, La/ET;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/cU;->R:La/cU;

    .line 7
    .line 8
    const-string v0, "magisk magiskhide sulist"

    .line 9
    .line 10
    filled-new-array {v0}, [Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, La/Id;->w([Ljava/lang/String;)La/x6;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, La/x6;->f()La/y4;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final M()La/wl;
    .locals 2

    .line 1
    sget-object v0, La/Mv;->w:La/Mv;

    .line 2
    .line 3
    sget-boolean v0, La/Mv;->K:Z

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    new-instance v0, La/un;

    .line 8
    .line 9
    const v1, 0x7f12015f

    .line 10
    .line 11
    .line 12
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance v0, La/un;

    .line 17
    .line 18
    const v1, 0x7f12013f

    .line 19
    .line 20
    .line 21
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 22
    .line 23
    .line 24
    :goto_0
    return-object v0
.end method

.method public final d()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, La/ET;->f(Z)V

    return-void
.end method

.method public final y()La/un;
    .locals 2

    .line 1
    sget-boolean v0, La/Mv;->K:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, La/un;

    .line 6
    .line 7
    const v1, 0x7f120160

    .line 8
    .line 9
    .line 10
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance v0, La/un;

    .line 15
    .line 16
    const v1, 0x7f120140

    .line 17
    .line 18
    .line 19
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 20
    .line 21
    .line 22
    :goto_0
    return-object v0
.end method
