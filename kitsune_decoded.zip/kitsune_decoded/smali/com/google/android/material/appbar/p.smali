.class public final Lcom/google/android/material/appbar/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/Fl;


# instance fields
.field public final synthetic K:Lcom/google/android/material/appbar/AppBarLayout;

.field public final synthetic L:I

.field public final synthetic R:Landroid/view/View;

.field public final synthetic X:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

.field public final synthetic d:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/material/appbar/p;->d:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    iput-object p2, p0, Lcom/google/android/material/appbar/p;->X:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    iput-object p3, p0, Lcom/google/android/material/appbar/p;->K:Lcom/google/android/material/appbar/AppBarLayout;

    iput-object p4, p0, Lcom/google/android/material/appbar/p;->R:Landroid/view/View;

    iput p5, p0, Lcom/google/android/material/appbar/p;->L:I

    return-void
.end method


# virtual methods
.method public final h(Landroid/view/View;)Z
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/google/android/material/appbar/p;->d:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    iget-object v1, p0, Lcom/google/android/material/appbar/p;->X:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    iget-object v2, p0, Lcom/google/android/material/appbar/p;->K:Lcom/google/android/material/appbar/AppBarLayout;

    iget-object v3, p0, Lcom/google/android/material/appbar/p;->R:Landroid/view/View;

    iget v4, p0, Lcom/google/android/material/appbar/p;->L:I

    const/4 p1, 0x0

    filled-new-array {p1, p1}, [I

    move-result-object v5

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->H(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I[I)V

    const/4 p1, 0x1

    return p1
.end method
