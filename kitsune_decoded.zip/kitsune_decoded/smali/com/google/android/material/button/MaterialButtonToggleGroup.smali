.class public Lcom/google/android/material/button/MaterialButtonToggleGroup;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# static fields
.field public static final synthetic S:I


# instance fields
.field public E:Ljava/util/HashSet;

.field public final F:I

.field public final K:Ljava/util/ArrayList;

.field public final L:Ljava/util/LinkedHashSet;

.field public final R:La/ze;

.field public final W:Z

.field public final d:La/Ce;

.field public f:[Ljava/lang/Integer;

.field public l:Z

.field public final q:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 7

    .line 1
    const v3, 0x7f0402f7

    .line 2
    .line 3
    .line 4
    const v0, 0x7f13044f

    .line 5
    .line 6
    .line 7
    invoke-static {p1, p2, v3, v0}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {p0, p1, p2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 12
    .line 13
    .line 14
    new-instance p1, Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->K:Ljava/util/ArrayList;

    .line 20
    .line 21
    new-instance p1, La/ze;

    .line 22
    .line 23
    invoke-direct {p1, p0}, La/ze;-><init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;)V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->R:La/ze;

    .line 27
    .line 28
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 29
    .line 30
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->L:Ljava/util/LinkedHashSet;

    .line 34
    .line 35
    new-instance p1, La/Ce;

    .line 36
    .line 37
    const/4 v6, 0x1

    .line 38
    invoke-direct {p1, v6, p0}, La/Ce;-><init>(ILjava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->d:La/Ce;

    .line 42
    .line 43
    const/4 p1, 0x0

    .line 44
    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:Z

    .line 45
    .line 46
    new-instance v0, Ljava/util/HashSet;

    .line 47
    .line 48
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 49
    .line 50
    .line 51
    iput-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->E:Ljava/util/HashSet;

    .line 52
    .line 53
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    sget-object v2, La/tS;->d:[I

    .line 58
    .line 59
    const v4, 0x7f13044f

    .line 60
    .line 61
    .line 62
    new-array v5, p1, [I

    .line 63
    .line 64
    move-object v1, p2

    .line 65
    invoke-static/range {v0 .. v5}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    const/4 v0, 0x3

    .line 70
    invoke-virtual {p2, v0, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    iget-boolean v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->W:Z

    .line 75
    .line 76
    if-eq v1, v0, :cond_0

    .line 77
    .line 78
    iput-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->W:Z

    .line 79
    .line 80
    new-instance v0, Ljava/util/HashSet;

    .line 81
    .line 82
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->e(Ljava/util/Set;)V

    .line 86
    .line 87
    .line 88
    :cond_0
    move v0, p1

    .line 89
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    if-ge v0, v1, :cond_2

    .line 94
    .line 95
    iget-boolean v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->W:Z

    .line 96
    .line 97
    if-eqz v1, :cond_1

    .line 98
    .line 99
    const-class v1, Landroid/widget/RadioButton;

    .line 100
    .line 101
    :goto_1
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    goto :goto_2

    .line 106
    :cond_1
    const-class v1, Landroid/widget/ToggleButton;

    .line 107
    .line 108
    goto :goto_1

    .line 109
    :goto_2
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    check-cast v2, Lcom/google/android/material/button/MaterialButton;

    .line 114
    .line 115
    iput-object v1, v2, Lcom/google/android/material/button/MaterialButton;->E:Ljava/lang/String;

    .line 116
    .line 117
    add-int/lit8 v0, v0, 0x1

    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    const/4 v0, -0x1

    .line 121
    invoke-virtual {p2, v6, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    iput v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->F:I

    .line 126
    .line 127
    const/4 v0, 0x2

    .line 128
    invoke-virtual {p2, v0, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    iput-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->q:Z

    .line 133
    .line 134
    invoke-virtual {p0, v6}, Landroid/view/ViewGroup;->setChildrenDrawingOrderEnabled(Z)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {p2, p1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 138
    .line 139
    .line 140
    move-result p1

    .line 141
    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->setEnabled(Z)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    .line 145
    .line 146
    .line 147
    sget-object p1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 148
    .line 149
    invoke-static {p0, v6}, La/Tl;->f(Landroid/view/View;I)V

    .line 150
    .line 151
    .line 152
    return-void
.end method


# virtual methods
.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    .line 1
    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-string p1, "MButtonToggleGroup"

    .line 6
    .line 7
    const-string p2, "Child views must be of type MaterialButton."

    .line 8
    .line 9
    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 14
    .line 15
    .line 16
    check-cast p1, Lcom/google/android/material/button/MaterialButton;

    .line 17
    .line 18
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    const/4 p3, -0x1

    .line 23
    if-ne p2, p3, :cond_1

    .line 24
    .line 25
    sget-object p2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 26
    .line 27
    invoke-static {}, La/XC;->w()I

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    invoke-virtual {p1, p2}, Landroid/view/View;->setId(I)V

    .line 32
    .line 33
    .line 34
    :cond_1
    const/4 p2, 0x1

    .line 35
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 36
    .line 37
    .line 38
    sget-object p3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 39
    .line 40
    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 44
    .line 45
    .line 46
    move-result p3

    .line 47
    iget-object v0, p1, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 48
    .line 49
    if-eqz p3, :cond_2

    .line 50
    .line 51
    iput-boolean p2, v0, La/Dg;->K:Z

    .line 52
    .line 53
    :cond_2
    iget-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->R:La/ze;

    .line 54
    .line 55
    iput-object p3, p1, Lcom/google/android/material/button/MaterialButton;->l:La/ze;

    .line 56
    .line 57
    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 58
    .line 59
    .line 60
    move-result p3

    .line 61
    const/4 v1, 0x0

    .line 62
    if-eqz p3, :cond_5

    .line 63
    .line 64
    iput-boolean p2, v0, La/Dg;->m:Z

    .line 65
    .line 66
    invoke-virtual {v0, v1}, La/Dg;->h(Z)La/ex;

    .line 67
    .line 68
    .line 69
    move-result-object p3

    .line 70
    invoke-virtual {v0, p2}, La/Dg;->h(Z)La/ex;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    if-eqz p3, :cond_5

    .line 75
    .line 76
    iget v2, v0, La/Dg;->X:I

    .line 77
    .line 78
    int-to-float v2, v2

    .line 79
    iget-object v3, v0, La/Dg;->I:Landroid/content/res/ColorStateList;

    .line 80
    .line 81
    iget-object v4, p3, La/ex;->X:La/JP;

    .line 82
    .line 83
    iput v2, v4, La/JP;->M:F

    .line 84
    .line 85
    invoke-virtual {p3}, La/ex;->invalidateSelf()V

    .line 86
    .line 87
    .line 88
    iget-object v2, p3, La/ex;->X:La/JP;

    .line 89
    .line 90
    iget-object v4, v2, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 91
    .line 92
    if-eq v4, v3, :cond_3

    .line 93
    .line 94
    iput-object v3, v2, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 95
    .line 96
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {p3, v2}, La/ex;->onStateChange([I)Z

    .line 101
    .line 102
    .line 103
    :cond_3
    if-eqz p2, :cond_5

    .line 104
    .line 105
    iget p3, v0, La/Dg;->X:I

    .line 106
    .line 107
    int-to-float p3, p3

    .line 108
    iget-boolean v2, v0, La/Dg;->m:Z

    .line 109
    .line 110
    if-eqz v2, :cond_4

    .line 111
    .line 112
    iget-object v2, v0, La/Dg;->w:Lcom/google/android/material/button/MaterialButton;

    .line 113
    .line 114
    const v3, 0x7f04012d

    .line 115
    .line 116
    .line 117
    invoke-static {v2, v3}, La/rE;->o(Landroid/view/View;I)I

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    goto :goto_0

    .line 122
    :cond_4
    move v2, v1

    .line 123
    :goto_0
    iget-object v3, p2, La/ex;->X:La/JP;

    .line 124
    .line 125
    iput p3, v3, La/JP;->M:F

    .line 126
    .line 127
    invoke-virtual {p2}, La/ex;->invalidateSelf()V

    .line 128
    .line 129
    .line 130
    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 131
    .line 132
    .line 133
    move-result-object p3

    .line 134
    iget-object v2, p2, La/ex;->X:La/JP;

    .line 135
    .line 136
    iget-object v3, v2, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 137
    .line 138
    if-eq v3, p3, :cond_5

    .line 139
    .line 140
    iput-object p3, v2, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 141
    .line 142
    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 143
    .line 144
    .line 145
    move-result-object p3

    .line 146
    invoke-virtual {p2, p3}, La/ex;->onStateChange([I)Z

    .line 147
    .line 148
    .line 149
    :cond_5
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 150
    .line 151
    .line 152
    move-result p2

    .line 153
    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    .line 154
    .line 155
    .line 156
    move-result p3

    .line 157
    invoke-virtual {p0, p2, p3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h(IZ)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 161
    .line 162
    .line 163
    move-result p2

    .line 164
    if-eqz p2, :cond_6

    .line 165
    .line 166
    iget-object p2, v0, La/Dg;->h:La/c9;

    .line 167
    .line 168
    iget-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->K:Ljava/util/ArrayList;

    .line 169
    .line 170
    new-instance v0, La/b3;

    .line 171
    .line 172
    iget-object v2, p2, La/c9;->i:La/cv;

    .line 173
    .line 174
    iget-object v3, p2, La/c9;->O:La/cv;

    .line 175
    .line 176
    iget-object v4, p2, La/c9;->Q:La/cv;

    .line 177
    .line 178
    iget-object p2, p2, La/c9;->X:La/cv;

    .line 179
    .line 180
    invoke-direct {v0, v2, v3, v4, p2}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 187
    .line 188
    .line 189
    move-result p2

    .line 190
    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    .line 191
    .line 192
    .line 193
    new-instance p2, La/Bc;

    .line 194
    .line 195
    invoke-direct {p2, v1, p0}, La/Bc;-><init>(ILjava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    invoke-static {p1, p2}, La/sI;->T(Landroid/view/View;La/Qg;)V

    .line 199
    .line 200
    .line 201
    return-void

    .line 202
    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 203
    .line 204
    const-string p2, "Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background."

    .line 205
    .line 206
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    throw p1
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 6

    .line 1
    new-instance v0, Ljava/util/TreeMap;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->d:La/Ce;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/util/TreeMap;-><init>(Ljava/util/Comparator;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v2, 0x0

    .line 13
    move v3, v2

    .line 14
    :goto_0
    if-ge v3, v1, :cond_0

    .line 15
    .line 16
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    check-cast v4, Lcom/google/android/material/button/MaterialButton;

    .line 21
    .line 22
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    invoke-virtual {v0, v4, v5}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    add-int/lit8 v3, v3, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    invoke-virtual {v0}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    new-array v1, v2, [Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-interface {v0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, [Ljava/lang/Integer;

    .line 43
    .line 44
    iput-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:[Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final e(Ljava/util/Set;)V
    .locals 7

    .line 1
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->E:Ljava/util/HashSet;

    .line 2
    .line 3
    new-instance v1, Ljava/util/HashSet;

    .line 4
    .line 5
    invoke-direct {v1, p1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 6
    .line 7
    .line 8
    iput-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->E:Ljava/util/HashSet;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    move v2, v1

    .line 12
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-ge v2, v3, :cond_2

    .line 17
    .line 18
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    check-cast v3, Lcom/google/android/material/button/MaterialButton;

    .line 23
    .line 24
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    invoke-interface {p1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    instance-of v6, v5, Lcom/google/android/material/button/MaterialButton;

    .line 41
    .line 42
    if-eqz v6, :cond_0

    .line 43
    .line 44
    const/4 v6, 0x1

    .line 45
    iput-boolean v6, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:Z

    .line 46
    .line 47
    check-cast v5, Lcom/google/android/material/button/MaterialButton;

    .line 48
    .line 49
    invoke-virtual {v5, v4}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    .line 50
    .line 51
    .line 52
    iput-boolean v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:Z

    .line 53
    .line 54
    :cond_0
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-virtual {v0, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    invoke-interface {p1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    if-eq v4, v5, :cond_1

    .line 71
    .line 72
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    invoke-interface {p1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    iget-object v3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->L:Ljava/util/LinkedHashSet;

    .line 80
    .line 81
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    if-eqz v4, :cond_1

    .line 90
    .line 91
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    check-cast v4, Lcom/google/android/material/timepicker/e;

    .line 96
    .line 97
    invoke-virtual {v4}, Lcom/google/android/material/timepicker/e;->w()V

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 102
    .line 103
    goto :goto_0

    .line 104
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 105
    .line 106
    .line 107
    return-void
.end method

.method public final getChildDrawingOrder(II)I
    .locals 1

    iget-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:[Ljava/lang/Integer;

    if-eqz p1, :cond_1

    array-length v0, p1

    if-lt p2, v0, :cond_0

    goto :goto_0

    :cond_0
    aget-object p1, p1, p2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    return p1

    :cond_1
    :goto_0
    const-string p1, "MButtonToggleGroup"

    const-string v0, "Child order wasn\'t updated"

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return p2
.end method

.method public final h(IZ)V
    .locals 2

    .line 1
    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Button ID is not valid: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "MButtonToggleGroup"

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    new-instance v0, Ljava/util/HashSet;

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->E:Ljava/util/HashSet;

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    if-eqz p2, :cond_2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    iget-boolean p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->W:Z

    if-eqz p2, :cond_1

    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_1

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    :cond_1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    if-nez p2, :cond_5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_5

    iget-boolean p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->q:Z

    if-eqz p2, :cond_3

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result p2

    const/4 v1, 0x1

    if-le p2, v1, :cond_4

    :cond_3
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    :cond_4
    :goto_0
    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->e(Ljava/util/Set;)V

    :cond_5
    return-void
.end method

.method public final i()V
    .locals 12

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v2

    .line 11
    :goto_0
    const/4 v4, -0x1

    .line 12
    if-ge v3, v1, :cond_1

    .line 13
    .line 14
    invoke-virtual {p0, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(I)Z

    .line 15
    .line 16
    .line 17
    move-result v5

    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    goto :goto_1

    .line 21
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    move v3, v4

    .line 25
    :goto_1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    const/4 v5, 0x1

    .line 30
    sub-int/2addr v1, v5

    .line 31
    :goto_2
    if-ltz v1, :cond_3

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(I)Z

    .line 34
    .line 35
    .line 36
    move-result v6

    .line 37
    if-eqz v6, :cond_2

    .line 38
    .line 39
    move v4, v1

    .line 40
    goto :goto_3

    .line 41
    :cond_2
    add-int/lit8 v1, v1, -0x1

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :cond_3
    :goto_3
    move v1, v2

    .line 45
    :goto_4
    if-ge v1, v0, :cond_f

    .line 46
    .line 47
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    check-cast v6, Lcom/google/android/material/button/MaterialButton;

    .line 52
    .line 53
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    .line 54
    .line 55
    .line 56
    move-result v7

    .line 57
    const/16 v8, 0x8

    .line 58
    .line 59
    if-ne v7, v8, :cond_4

    .line 60
    .line 61
    goto/16 :goto_9

    .line 62
    .line 63
    :cond_4
    invoke-virtual {v6}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    if-eqz v7, :cond_e

    .line 68
    .line 69
    iget-object v7, v6, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 70
    .line 71
    iget-object v7, v7, La/Dg;->h:La/c9;

    .line 72
    .line 73
    invoke-virtual {v7}, La/c9;->Q()La/as;

    .line 74
    .line 75
    .line 76
    move-result-object v7

    .line 77
    iget-object v8, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->K:Ljava/util/ArrayList;

    .line 78
    .line 79
    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    check-cast v8, La/b3;

    .line 84
    .line 85
    if-ne v3, v4, :cond_5

    .line 86
    .line 87
    goto :goto_7

    .line 88
    :cond_5
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    .line 89
    .line 90
    .line 91
    move-result v9

    .line 92
    if-nez v9, :cond_6

    .line 93
    .line 94
    move v9, v5

    .line 95
    goto :goto_5

    .line 96
    :cond_6
    move v9, v2

    .line 97
    :goto_5
    sget-object v10, La/b3;->i:La/r;

    .line 98
    .line 99
    if-ne v1, v3, :cond_9

    .line 100
    .line 101
    if-eqz v9, :cond_8

    .line 102
    .line 103
    invoke-static {p0}, La/rE;->lI(Landroid/view/View;)Z

    .line 104
    .line 105
    .line 106
    move-result v9

    .line 107
    if-eqz v9, :cond_7

    .line 108
    .line 109
    new-instance v9, La/b3;

    .line 110
    .line 111
    iget-object v11, v8, La/b3;->h:La/cv;

    .line 112
    .line 113
    iget-object v8, v8, La/b3;->p:La/cv;

    .line 114
    .line 115
    invoke-direct {v9, v10, v10, v11, v8}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 116
    .line 117
    .line 118
    goto :goto_6

    .line 119
    :cond_7
    new-instance v9, La/b3;

    .line 120
    .line 121
    iget-object v11, v8, La/b3;->w:La/cv;

    .line 122
    .line 123
    iget-object v8, v8, La/b3;->e:La/cv;

    .line 124
    .line 125
    invoke-direct {v9, v11, v8, v10, v10}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 126
    .line 127
    .line 128
    :goto_6
    move-object v8, v9

    .line 129
    goto :goto_7

    .line 130
    :cond_8
    new-instance v9, La/b3;

    .line 131
    .line 132
    iget-object v11, v8, La/b3;->w:La/cv;

    .line 133
    .line 134
    iget-object v8, v8, La/b3;->h:La/cv;

    .line 135
    .line 136
    invoke-direct {v9, v11, v10, v8, v10}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 137
    .line 138
    .line 139
    goto :goto_6

    .line 140
    :cond_9
    if-ne v1, v4, :cond_c

    .line 141
    .line 142
    if-eqz v9, :cond_b

    .line 143
    .line 144
    invoke-static {p0}, La/rE;->lI(Landroid/view/View;)Z

    .line 145
    .line 146
    .line 147
    move-result v9

    .line 148
    if-eqz v9, :cond_a

    .line 149
    .line 150
    new-instance v9, La/b3;

    .line 151
    .line 152
    iget-object v11, v8, La/b3;->w:La/cv;

    .line 153
    .line 154
    iget-object v8, v8, La/b3;->e:La/cv;

    .line 155
    .line 156
    invoke-direct {v9, v11, v8, v10, v10}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 157
    .line 158
    .line 159
    goto :goto_6

    .line 160
    :cond_a
    new-instance v9, La/b3;

    .line 161
    .line 162
    iget-object v11, v8, La/b3;->h:La/cv;

    .line 163
    .line 164
    iget-object v8, v8, La/b3;->p:La/cv;

    .line 165
    .line 166
    invoke-direct {v9, v10, v10, v11, v8}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 167
    .line 168
    .line 169
    goto :goto_6

    .line 170
    :cond_b
    new-instance v9, La/b3;

    .line 171
    .line 172
    iget-object v11, v8, La/b3;->e:La/cv;

    .line 173
    .line 174
    iget-object v8, v8, La/b3;->p:La/cv;

    .line 175
    .line 176
    invoke-direct {v9, v10, v11, v10, v8}, La/b3;-><init>(La/cv;La/cv;La/cv;La/cv;)V

    .line 177
    .line 178
    .line 179
    goto :goto_6

    .line 180
    :cond_c
    const/4 v8, 0x0

    .line 181
    :goto_7
    if-nez v8, :cond_d

    .line 182
    .line 183
    new-instance v8, La/r;

    .line 184
    .line 185
    const/4 v9, 0x0

    .line 186
    invoke-direct {v8, v9}, La/r;-><init>(F)V

    .line 187
    .line 188
    .line 189
    iput-object v8, v7, La/as;->i:La/cv;

    .line 190
    .line 191
    new-instance v8, La/r;

    .line 192
    .line 193
    invoke-direct {v8, v9}, La/r;-><init>(F)V

    .line 194
    .line 195
    .line 196
    iput-object v8, v7, La/as;->Q:La/cv;

    .line 197
    .line 198
    new-instance v8, La/r;

    .line 199
    .line 200
    invoke-direct {v8, v9}, La/r;-><init>(F)V

    .line 201
    .line 202
    .line 203
    iput-object v8, v7, La/as;->X:La/cv;

    .line 204
    .line 205
    new-instance v8, La/r;

    .line 206
    .line 207
    invoke-direct {v8, v9}, La/r;-><init>(F)V

    .line 208
    .line 209
    .line 210
    iput-object v8, v7, La/as;->O:La/cv;

    .line 211
    .line 212
    goto :goto_8

    .line 213
    :cond_d
    iget-object v9, v8, La/b3;->w:La/cv;

    .line 214
    .line 215
    iput-object v9, v7, La/as;->i:La/cv;

    .line 216
    .line 217
    iget-object v9, v8, La/b3;->e:La/cv;

    .line 218
    .line 219
    iput-object v9, v7, La/as;->O:La/cv;

    .line 220
    .line 221
    iget-object v9, v8, La/b3;->h:La/cv;

    .line 222
    .line 223
    iput-object v9, v7, La/as;->Q:La/cv;

    .line 224
    .line 225
    iget-object v8, v8, La/b3;->p:La/cv;

    .line 226
    .line 227
    iput-object v8, v7, La/as;->X:La/cv;

    .line 228
    .line 229
    :goto_8
    invoke-virtual {v7}, La/as;->w()La/c9;

    .line 230
    .line 231
    .line 232
    move-result-object v7

    .line 233
    invoke-virtual {v6, v7}, Lcom/google/android/material/button/MaterialButton;->h(La/c9;)V

    .line 234
    .line 235
    .line 236
    :goto_9
    add-int/lit8 v1, v1, 0x1

    .line 237
    .line 238
    goto/16 :goto_4

    .line 239
    .line 240
    :cond_e
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 241
    .line 242
    const-string v1, "Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background."

    .line 243
    .line 244
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    throw v0

    .line 248
    :cond_f
    return-void
.end method

.method public final onFinishInflate()V
    .locals 2

    invoke-super {p0}, Landroid/widget/LinearLayout;->onFinishInflate()V

    const/4 v0, -0x1

    iget v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->F:I

    if-eq v1, v0, :cond_0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->e(Ljava/util/Set;)V

    :cond_0
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move v1, v0

    .line 6
    move v2, v1

    .line 7
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-ge v1, v3, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    instance-of v3, v3, Lcom/google/android/material/button/MaterialButton;

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    invoke-virtual {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(I)Z

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    if-eqz v3, :cond_0

    .line 26
    .line 27
    add-int/lit8 v2, v2, 0x1

    .line 28
    .line 29
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    iget-boolean v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->W:Z

    .line 33
    .line 34
    const/4 v3, 0x1

    .line 35
    if-eqz v1, :cond_2

    .line 36
    .line 37
    move v1, v3

    .line 38
    goto :goto_1

    .line 39
    :cond_2
    const/4 v1, 0x2

    .line 40
    :goto_1
    invoke-static {v3, v2, v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;->obtain(IIZI)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCollectionInfo(Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final onMeasure(II)V
    .locals 0

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->i()V

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->w()V

    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    return-void
.end method

.method public final onViewRemoved(Landroid/view/View;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onViewRemoved(Landroid/view/View;)V

    .line 2
    .line 3
    .line 4
    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    iput-object v1, v0, Lcom/google/android/material/button/MaterialButton;->l:La/ze;

    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    if-ltz p1, :cond_1

    .line 19
    .line 20
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->K:Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    :cond_1
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->i()V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->w()V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final p(I)Z
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/16 v0, 0x8

    if-eq p1, v0, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final setEnabled(Z)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setEnabled(Z)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-ge v0, v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lcom/google/android/material/button/MaterialButton;

    .line 16
    .line 17
    invoke-virtual {v1, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 18
    .line 19
    .line 20
    add-int/lit8 v0, v0, 0x1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    return-void
.end method

.method public final w()V
    .locals 9

    .line 1
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    move v2, v1

    .line 7
    :goto_0
    const/4 v3, -0x1

    .line 8
    if-ge v2, v0, :cond_1

    .line 9
    .line 10
    invoke-virtual {p0, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(I)Z

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    if-eqz v4, :cond_0

    .line 15
    .line 16
    goto :goto_1

    .line 17
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_1
    move v2, v3

    .line 21
    :goto_1
    if-ne v2, v3, :cond_2

    .line 22
    .line 23
    return-void

    .line 24
    :cond_2
    add-int/lit8 v0, v2, 0x1

    .line 25
    .line 26
    :goto_2
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ge v0, v4, :cond_7

    .line 31
    .line 32
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    check-cast v4, Lcom/google/android/material/button/MaterialButton;

    .line 37
    .line 38
    add-int/lit8 v5, v0, -0x1

    .line 39
    .line 40
    invoke-virtual {p0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Lcom/google/android/material/button/MaterialButton;

    .line 45
    .line 46
    invoke-virtual {v4}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 47
    .line 48
    .line 49
    move-result v6

    .line 50
    if-eqz v6, :cond_3

    .line 51
    .line 52
    iget-object v6, v4, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 53
    .line 54
    iget v6, v6, La/Dg;->X:I

    .line 55
    .line 56
    goto :goto_3

    .line 57
    :cond_3
    move v6, v1

    .line 58
    :goto_3
    invoke-virtual {v5}, Lcom/google/android/material/button/MaterialButton;->e()Z

    .line 59
    .line 60
    .line 61
    move-result v7

    .line 62
    if-eqz v7, :cond_4

    .line 63
    .line 64
    iget-object v5, v5, Lcom/google/android/material/button/MaterialButton;->d:La/Dg;

    .line 65
    .line 66
    iget v5, v5, La/Dg;->X:I

    .line 67
    .line 68
    goto :goto_4

    .line 69
    :cond_4
    move v5, v1

    .line 70
    :goto_4
    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    instance-of v7, v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 79
    .line 80
    if-eqz v7, :cond_5

    .line 81
    .line 82
    check-cast v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 83
    .line 84
    goto :goto_5

    .line 85
    :cond_5
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 86
    .line 87
    iget v8, v6, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 88
    .line 89
    iget v6, v6, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 90
    .line 91
    invoke-direct {v7, v8, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 92
    .line 93
    .line 94
    move-object v6, v7

    .line 95
    :goto_5
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    .line 96
    .line 97
    .line 98
    move-result v7

    .line 99
    if-nez v7, :cond_6

    .line 100
    .line 101
    invoke-static {v6, v1}, La/WK;->X(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 102
    .line 103
    .line 104
    neg-int v5, v5

    .line 105
    invoke-static {v6, v5}, La/WK;->O(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 106
    .line 107
    .line 108
    iput v1, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 109
    .line 110
    goto :goto_6

    .line 111
    :cond_6
    iput v1, v6, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 112
    .line 113
    neg-int v5, v5

    .line 114
    iput v5, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 115
    .line 116
    invoke-static {v6, v1}, La/WK;->O(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 117
    .line 118
    .line 119
    :goto_6
    invoke-virtual {v4, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 120
    .line 121
    .line 122
    add-int/lit8 v0, v0, 0x1

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_7
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_a

    .line 130
    .line 131
    if-ne v2, v3, :cond_8

    .line 132
    .line 133
    goto :goto_7

    .line 134
    :cond_8
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    .line 139
    .line 140
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 145
    .line 146
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    .line 147
    .line 148
    .line 149
    move-result v2

    .line 150
    const/4 v3, 0x1

    .line 151
    if-ne v2, v3, :cond_9

    .line 152
    .line 153
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 154
    .line 155
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 156
    .line 157
    goto :goto_7

    .line 158
    :cond_9
    invoke-static {v0, v1}, La/WK;->X(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 159
    .line 160
    .line 161
    invoke-static {v0, v1}, La/WK;->O(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 162
    .line 163
    .line 164
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 165
    .line 166
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 167
    .line 168
    :cond_a
    :goto_7
    return-void
.end method
