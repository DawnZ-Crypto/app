.class final Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 0

    .line 1
    sget-object p1, La/cw;->ON_DESTROY:La/cw;

    if-eq p2, p1, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x0

    throw p1
.end method
