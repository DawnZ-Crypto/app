.class public final Landroidx/activity/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public Q:Z

.field public X:Z

.field public final e:Landroid/window/OnBackInvokedCallback;

.field public final h:La/qP;

.field public i:Landroid/window/OnBackInvokedDispatcher;

.field public p:La/AJ;

.field public final w:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/activity/h;->w:Ljava/lang/Runnable;

    .line 5
    .line 6
    new-instance p1, La/qP;

    .line 7
    .line 8
    invoke-direct {p1}, La/qP;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Landroidx/activity/h;->h:La/qP;

    .line 12
    .line 13
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/16 v0, 0x21

    .line 16
    .line 17
    if-lt p1, v0, :cond_1

    .line 18
    .line 19
    const/16 v0, 0x22

    .line 20
    .line 21
    if-lt p1, v0, :cond_0

    .line 22
    .line 23
    sget-object p1, La/Ut;->w:La/Ut;

    .line 24
    .line 25
    new-instance v0, La/mz;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-direct {v0, p0, v1}, La/mz;-><init>(Landroidx/activity/h;I)V

    .line 29
    .line 30
    .line 31
    new-instance v2, La/mz;

    .line 32
    .line 33
    const/4 v3, 0x1

    .line 34
    invoke-direct {v2, p0, v3}, La/mz;-><init>(Landroidx/activity/h;I)V

    .line 35
    .line 36
    .line 37
    new-instance v4, La/dC;

    .line 38
    .line 39
    invoke-direct {v4, p0, v1}, La/dC;-><init>(Landroidx/activity/h;I)V

    .line 40
    .line 41
    .line 42
    new-instance v1, La/dC;

    .line 43
    .line 44
    invoke-direct {v1, p0, v3}, La/dC;-><init>(Landroidx/activity/h;I)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1, v0, v2, v4, v1}, La/Ut;->w(La/nY;La/nY;La/Lc;La/Lc;)Landroid/window/OnBackInvokedCallback;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    sget-object p1, La/D8;->w:La/D8;

    .line 53
    .line 54
    new-instance v0, La/dC;

    .line 55
    .line 56
    const/4 v1, 0x2

    .line 57
    invoke-direct {v0, p0, v1}, La/dC;-><init>(Landroidx/activity/h;I)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p1, v0}, La/D8;->w(La/Lc;)Landroid/window/OnBackInvokedCallback;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    :goto_0
    iput-object p1, p0, Landroidx/activity/h;->e:Landroid/window/OnBackInvokedCallback;

    .line 65
    .line 66
    :cond_1
    return-void
.end method


# virtual methods
.method public final e()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Landroidx/activity/h;->X:Z

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/activity/h;->h:La/qP;

    .line 4
    .line 5
    instance-of v2, v1, Ljava/util/Collection;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v2, :cond_0

    .line 9
    .line 10
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :cond_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, La/AJ;

    .line 32
    .line 33
    iget-boolean v2, v2, La/AJ;->w:Z

    .line 34
    .line 35
    if-eqz v2, :cond_1

    .line 36
    .line 37
    const/4 v3, 0x1

    .line 38
    :cond_2
    :goto_0
    iput-boolean v3, p0, Landroidx/activity/h;->X:Z

    .line 39
    .line 40
    if-eq v3, v0, :cond_3

    .line 41
    .line 42
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 43
    .line 44
    const/16 v1, 0x21

    .line 45
    .line 46
    if-lt v0, v1, :cond_3

    .line 47
    .line 48
    invoke-virtual {p0, v3}, Landroidx/activity/h;->p(Z)V

    .line 49
    .line 50
    .line 51
    :cond_3
    return-void
.end method

.method public final h()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/activity/h;->h:La/qP;

    .line 2
    .line 3
    invoke-virtual {v0}, La/qP;->h()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    :cond_0
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v2, 0x0

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v3, v1

    .line 23
    check-cast v3, La/AJ;

    .line 24
    .line 25
    iget-boolean v3, v3, La/AJ;->w:Z

    .line 26
    .line 27
    if-eqz v3, :cond_0

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    move-object v1, v2

    .line 31
    :goto_0
    check-cast v1, La/AJ;

    .line 32
    .line 33
    iput-object v2, p0, Landroidx/activity/h;->p:La/AJ;

    .line 34
    .line 35
    if-eqz v1, :cond_5

    .line 36
    .line 37
    check-cast v1, La/rN;

    .line 38
    .line 39
    const/4 v0, 0x1

    .line 40
    iget v2, v1, La/rN;->e:I

    .line 41
    .line 42
    iget-object v1, v1, La/rN;->i:Ljava/lang/Object;

    .line 43
    .line 44
    packed-switch v2, :pswitch_data_0

    .line 45
    .line 46
    .line 47
    check-cast v1, La/r4;

    .line 48
    .line 49
    iget-object v2, v1, La/r4;->X:La/qP;

    .line 50
    .line 51
    invoke-virtual {v2}, La/qP;->isEmpty()Z

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    if-eqz v2, :cond_2

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_2
    invoke-virtual {v1}, La/r4;->Q()La/VT;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    iget v2, v2, La/VT;->W:I

    .line 63
    .line 64
    const/4 v3, 0x0

    .line 65
    invoke-virtual {v1, v2, v0, v3}, La/r4;->M(IZZ)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-eqz v0, :cond_4

    .line 70
    .line 71
    invoke-virtual {v1}, La/r4;->h()Z

    .line 72
    .line 73
    .line 74
    goto :goto_1

    .line 75
    :pswitch_0
    check-cast v1, La/ef;

    .line 76
    .line 77
    invoke-virtual {v1, v0}, La/ef;->E(Z)Z

    .line 78
    .line 79
    .line 80
    iget-object v0, v1, La/ef;->O:La/rN;

    .line 81
    .line 82
    iget-boolean v0, v0, La/AJ;->w:Z

    .line 83
    .line 84
    if-eqz v0, :cond_3

    .line 85
    .line 86
    invoke-virtual {v1}, La/ef;->r()Z

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_3
    iget-object v0, v1, La/ef;->X:Landroidx/activity/h;

    .line 91
    .line 92
    invoke-virtual {v0}, Landroidx/activity/h;->h()V

    .line 93
    .line 94
    .line 95
    :cond_4
    :goto_1
    return-void

    .line 96
    :cond_5
    iget-object v0, p0, Landroidx/activity/h;->w:Ljava/lang/Runnable;

    .line 97
    .line 98
    if-eqz v0, :cond_6

    .line 99
    .line 100
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 101
    .line 102
    .line 103
    :cond_6
    return-void

    .line 104
    nop

    .line 105
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final p(Z)V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/activity/h;->i:Landroid/window/OnBackInvokedDispatcher;

    if-eqz v0, :cond_1

    iget-object v1, p0, Landroidx/activity/h;->e:Landroid/window/OnBackInvokedCallback;

    if-eqz v1, :cond_1

    const/4 v2, 0x0

    sget-object v3, La/D8;->w:La/D8;

    if-eqz p1, :cond_0

    iget-boolean v4, p0, Landroidx/activity/h;->Q:Z

    if-nez v4, :cond_0

    invoke-virtual {v3, v0, v2, v1}, La/D8;->h(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/activity/h;->Q:Z

    goto :goto_0

    :cond_0
    if-nez p1, :cond_1

    iget-boolean p1, p0, Landroidx/activity/h;->Q:Z

    if-eqz p1, :cond_1

    invoke-virtual {v3, v0, v1}, La/D8;->p(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-boolean v2, p0, Landroidx/activity/h;->Q:Z

    :cond_1
    :goto_0
    return-void
.end method

.method public final w(La/RH;La/rN;)V
    .locals 2

    .line 1
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p1, Landroidx/lifecycle/w;->e:La/m2;

    .line 6
    .line 7
    sget-object v1, La/m2;->X:La/m2;

    .line 8
    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    new-instance v0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;

    .line 13
    .line 14
    invoke-direct {v0, p0, p1, p2}, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;-><init>(Landroidx/activity/h;La/GK;La/rN;)V

    .line 15
    .line 16
    .line 17
    iget-object p1, p2, La/AJ;->h:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 18
    .line 19
    invoke-virtual {p1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, Landroidx/activity/h;->e()V

    .line 23
    .line 24
    .line 25
    new-instance p1, La/aq;

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-direct {p1, v0, p0}, La/aq;-><init>(ILandroidx/activity/h;)V

    .line 29
    .line 30
    .line 31
    iput-object p1, p2, La/AJ;->p:La/Lc;

    .line 32
    .line 33
    return-void
.end method
