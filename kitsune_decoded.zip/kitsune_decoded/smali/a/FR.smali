.class public final La/FR;
.super La/tT;
.source "SourceFile"


# instance fields
.field public final w:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const/16 v0, 0x9

    invoke-direct {p0, v0}, La/FR;-><init>(I)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    sub-int/2addr p1, v0

    shl-int p1, v0, p1

    iput p1, p0, La/FR;->w:I

    return-void
.end method


# virtual methods
.method public final w([B[B)I
    .locals 25

    .line 1
    move-object/from16 v8, p1

    .line 2
    .line 3
    const/4 v9, 0x0

    .line 4
    const/16 v0, 0x14

    .line 5
    .line 6
    invoke-static {v8, v9, v0}, La/wg;->w([BII)V

    .line 7
    .line 8
    .line 9
    const/16 v0, 0x24

    .line 10
    .line 11
    move-object/from16 v10, p2

    .line 12
    .line 13
    invoke-static {v10, v9, v0}, La/wg;->w([BII)V

    .line 14
    .line 15
    .line 16
    const/16 v12, 0xf

    .line 17
    .line 18
    new-instance v13, La/KT;

    .line 19
    .line 20
    move-object/from16 v14, p0

    .line 21
    .line 22
    invoke-direct {v13, v14}, La/KT;-><init>(La/FR;)V

    .line 23
    .line 24
    .line 25
    new-instance v15, La/eF;

    .line 26
    .line 27
    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    new-instance v7, La/eF;

    .line 31
    .line 32
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    const/4 v0, 0x1

    .line 36
    move v1, v9

    .line 37
    move v2, v1

    .line 38
    move v4, v2

    .line 39
    :goto_0
    const/16 v6, 0x8

    .line 40
    .line 41
    if-ge v0, v6, :cond_1a

    .line 42
    .line 43
    invoke-virtual {v13, v0, v8}, La/KT;->w(I[B)V

    .line 44
    .line 45
    .line 46
    invoke-static {v0, v8}, La/wg;->h(I[B)I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    const v5, -0x61c8864f

    .line 51
    .line 52
    .line 53
    mul-int/2addr v3, v5

    .line 54
    ushr-int/lit8 v3, v3, 0x11

    .line 55
    .line 56
    iget-object v9, v13, La/KT;->p:[I

    .line 57
    .line 58
    aget v3, v9, v3

    .line 59
    .line 60
    add-int/lit8 v11, v0, -0x4

    .line 61
    .line 62
    const v16, 0xffff

    .line 63
    .line 64
    .line 65
    move/from16 v17, v4

    .line 66
    .line 67
    const/4 v4, 0x4

    .line 68
    iget-object v6, v13, La/KT;->e:[S

    .line 69
    .line 70
    iget v5, v13, La/KT;->h:I

    .line 71
    .line 72
    if-lt v3, v11, :cond_1

    .line 73
    .line 74
    if-gt v3, v0, :cond_1

    .line 75
    .line 76
    if-lt v3, v5, :cond_1

    .line 77
    .line 78
    invoke-static {v8, v3, v0}, La/kW;->i([BII)Z

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    if-eqz v11, :cond_0

    .line 83
    .line 84
    sub-int v2, v0, v3

    .line 85
    .line 86
    add-int/lit8 v11, v3, 0x4

    .line 87
    .line 88
    move/from16 v20, v2

    .line 89
    .line 90
    add-int/lit8 v2, v0, 0x4

    .line 91
    .line 92
    invoke-static {v11, v2, v12, v8}, La/kW;->w(III[B)I

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    add-int/2addr v2, v4

    .line 97
    move v11, v2

    .line 98
    move/from16 v21, v3

    .line 99
    .line 100
    move/from16 v2, v20

    .line 101
    .line 102
    move/from16 v20, v11

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_0
    move/from16 v21, v2

    .line 106
    .line 107
    const/4 v2, 0x0

    .line 108
    const/4 v11, 0x0

    .line 109
    const/16 v20, 0x0

    .line 110
    .line 111
    :goto_1
    and-int v22, v3, v16

    .line 112
    .line 113
    aget-short v22, v6, v22

    .line 114
    .line 115
    and-int v22, v22, v16

    .line 116
    .line 117
    sub-int v3, v3, v22

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_1
    move/from16 v21, v2

    .line 121
    .line 122
    const/4 v2, 0x0

    .line 123
    const/4 v11, 0x0

    .line 124
    const/16 v20, 0x0

    .line 125
    .line 126
    :goto_2
    move/from16 v23, v20

    .line 127
    .line 128
    const/4 v4, 0x0

    .line 129
    :goto_3
    iget-object v12, v13, La/KT;->i:La/FR;

    .line 130
    .line 131
    iget v12, v12, La/FR;->w:I

    .line 132
    .line 133
    if-ge v4, v12, :cond_2

    .line 134
    .line 135
    sub-int v12, v0, v16

    .line 136
    .line 137
    invoke-static {v5, v12}, Ljava/lang/Math;->max(II)I

    .line 138
    .line 139
    .line 140
    move-result v12

    .line 141
    if-lt v3, v12, :cond_2

    .line 142
    .line 143
    if-le v3, v0, :cond_3

    .line 144
    .line 145
    :cond_2
    move/from16 v12, v23

    .line 146
    .line 147
    const/4 v10, 0x4

    .line 148
    goto :goto_5

    .line 149
    :cond_3
    invoke-static {v8, v3, v0}, La/kW;->i([BII)Z

    .line 150
    .line 151
    .line 152
    move-result v12

    .line 153
    if-eqz v12, :cond_5

    .line 154
    .line 155
    add-int/lit8 v12, v3, 0x4

    .line 156
    .line 157
    move/from16 v24, v5

    .line 158
    .line 159
    add-int/lit8 v5, v0, 0x4

    .line 160
    .line 161
    const/16 v10, 0xf

    .line 162
    .line 163
    invoke-static {v12, v5, v10, v8}, La/kW;->w(III[B)I

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    const/4 v10, 0x4

    .line 168
    add-int/2addr v5, v10

    .line 169
    move/from16 v12, v23

    .line 170
    .line 171
    if-le v5, v12, :cond_4

    .line 172
    .line 173
    move/from16 v21, v3

    .line 174
    .line 175
    move/from16 v23, v5

    .line 176
    .line 177
    goto :goto_4

    .line 178
    :cond_4
    move/from16 v23, v12

    .line 179
    .line 180
    goto :goto_4

    .line 181
    :cond_5
    move/from16 v24, v5

    .line 182
    .line 183
    move/from16 v12, v23

    .line 184
    .line 185
    const/4 v10, 0x4

    .line 186
    :goto_4
    and-int v5, v3, v16

    .line 187
    .line 188
    aget-short v5, v6, v5

    .line 189
    .line 190
    and-int v5, v5, v16

    .line 191
    .line 192
    sub-int/2addr v3, v5

    .line 193
    add-int/lit8 v4, v4, 0x1

    .line 194
    .line 195
    move-object/from16 v10, p2

    .line 196
    .line 197
    move/from16 v5, v24

    .line 198
    .line 199
    goto :goto_3

    .line 200
    :goto_5
    const/4 v5, 0x3

    .line 201
    if-eqz v11, :cond_7

    .line 202
    .line 203
    add-int/2addr v11, v0

    .line 204
    sub-int/2addr v11, v5

    .line 205
    move v3, v0

    .line 206
    :goto_6
    sub-int v4, v11, v2

    .line 207
    .line 208
    if-ge v3, v4, :cond_6

    .line 209
    .line 210
    and-int v4, v3, v16

    .line 211
    .line 212
    int-to-short v5, v2

    .line 213
    aput-short v5, v6, v4

    .line 214
    .line 215
    add-int/lit8 v3, v3, 0x1

    .line 216
    .line 217
    const/4 v5, 0x3

    .line 218
    goto :goto_6

    .line 219
    :cond_6
    and-int v4, v3, v16

    .line 220
    .line 221
    int-to-short v5, v2

    .line 222
    aput-short v5, v6, v4

    .line 223
    .line 224
    invoke-static {v3, v8}, La/wg;->h(I[B)I

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    const v5, -0x61c8864f

    .line 229
    .line 230
    .line 231
    mul-int/2addr v4, v5

    .line 232
    ushr-int/lit8 v4, v4, 0x11

    .line 233
    .line 234
    aput v3, v9, v4

    .line 235
    .line 236
    add-int/lit8 v3, v3, 0x1

    .line 237
    .line 238
    if-lt v3, v11, :cond_6

    .line 239
    .line 240
    iput v11, v13, La/KT;->w:I

    .line 241
    .line 242
    :cond_7
    if-eqz v12, :cond_19

    .line 243
    .line 244
    move v9, v0

    .line 245
    move v11, v1

    .line 246
    move/from16 v16, v12

    .line 247
    .line 248
    move/from16 v23, v16

    .line 249
    .line 250
    move/from16 v19, v21

    .line 251
    .line 252
    move v12, v9

    .line 253
    :goto_7
    add-int v6, v12, v16

    .line 254
    .line 255
    const/16 v5, 0x8

    .line 256
    .line 257
    if-ge v6, v5, :cond_18

    .line 258
    .line 259
    add-int/lit8 v2, v6, -0x2

    .line 260
    .line 261
    add-int/lit8 v3, v12, 0x1

    .line 262
    .line 263
    move-object v0, v13

    .line 264
    move-object/from16 v1, p1

    .line 265
    .line 266
    move v8, v10

    .line 267
    const/16 v10, 0xf

    .line 268
    .line 269
    move v4, v10

    .line 270
    const/4 v10, 0x3

    .line 271
    move/from16 v5, v16

    .line 272
    .line 273
    move/from16 v18, v6

    .line 274
    .line 275
    move-object v6, v15

    .line 276
    invoke-virtual/range {v0 .. v6}, La/KT;->h([BIIIILa/eF;)Z

    .line 277
    .line 278
    .line 279
    move-result v0

    .line 280
    if-nez v0, :cond_8

    .line 281
    .line 282
    :goto_8
    move-object v10, v7

    .line 283
    const/16 v19, 0xf

    .line 284
    .line 285
    goto/16 :goto_f

    .line 286
    .line 287
    :cond_8
    if-ge v9, v12, :cond_9

    .line 288
    .line 289
    iget v0, v15, La/eF;->w:I

    .line 290
    .line 291
    add-int v1, v12, v23

    .line 292
    .line 293
    if-ge v0, v1, :cond_9

    .line 294
    .line 295
    move v12, v9

    .line 296
    move/from16 v21, v19

    .line 297
    .line 298
    move/from16 v16, v23

    .line 299
    .line 300
    :cond_9
    iget v0, v15, La/eF;->w:I

    .line 301
    .line 302
    sub-int v1, v0, v12

    .line 303
    .line 304
    if-ge v1, v10, :cond_a

    .line 305
    .line 306
    iget v1, v15, La/eF;->p:I

    .line 307
    .line 308
    iget v2, v15, La/eF;->h:I

    .line 309
    .line 310
    move v12, v0

    .line 311
    move/from16 v16, v1

    .line 312
    .line 313
    move/from16 v21, v2

    .line 314
    .line 315
    :goto_9
    move v10, v8

    .line 316
    move-object/from16 v8, p1

    .line 317
    .line 318
    goto :goto_7

    .line 319
    :cond_a
    move/from16 v9, v16

    .line 320
    .line 321
    :goto_a
    iget v0, v15, La/eF;->w:I

    .line 322
    .line 323
    sub-int v1, v0, v12

    .line 324
    .line 325
    const/16 v6, 0x12

    .line 326
    .line 327
    if-ge v1, v6, :cond_d

    .line 328
    .line 329
    if-le v9, v6, :cond_b

    .line 330
    .line 331
    move v1, v6

    .line 332
    goto :goto_b

    .line 333
    :cond_b
    move v1, v9

    .line 334
    :goto_b
    add-int v2, v12, v1

    .line 335
    .line 336
    iget v3, v15, La/eF;->p:I

    .line 337
    .line 338
    add-int v4, v0, v3

    .line 339
    .line 340
    sub-int/2addr v4, v8

    .line 341
    if-le v2, v4, :cond_c

    .line 342
    .line 343
    sub-int v1, v0, v12

    .line 344
    .line 345
    add-int/2addr v1, v3

    .line 346
    sub-int/2addr v1, v8

    .line 347
    :cond_c
    sub-int/2addr v0, v12

    .line 348
    sub-int/2addr v1, v0

    .line 349
    if-lez v1, :cond_d

    .line 350
    .line 351
    invoke-virtual {v15, v1}, La/eF;->w(I)V

    .line 352
    .line 353
    .line 354
    :cond_d
    iget v3, v15, La/eF;->w:I

    .line 355
    .line 356
    iget v5, v15, La/eF;->p:I

    .line 357
    .line 358
    add-int v0, v3, v5

    .line 359
    .line 360
    const/16 v4, 0x8

    .line 361
    .line 362
    if-ge v0, v4, :cond_16

    .line 363
    .line 364
    add-int v0, v3, v5

    .line 365
    .line 366
    add-int/lit8 v2, v0, -0x3

    .line 367
    .line 368
    move-object v0, v13

    .line 369
    move-object/from16 v1, p1

    .line 370
    .line 371
    move/from16 v16, v4

    .line 372
    .line 373
    const/16 v19, 0xf

    .line 374
    .line 375
    move/from16 v4, v19

    .line 376
    .line 377
    move v10, v6

    .line 378
    move-object v6, v7

    .line 379
    invoke-virtual/range {v0 .. v6}, La/KT;->h([BIIIILa/eF;)Z

    .line 380
    .line 381
    .line 382
    move-result v0

    .line 383
    if-nez v0, :cond_e

    .line 384
    .line 385
    move-object v10, v7

    .line 386
    goto/16 :goto_d

    .line 387
    .line 388
    :cond_e
    iget v0, v7, La/eF;->w:I

    .line 389
    .line 390
    add-int v6, v12, v9

    .line 391
    .line 392
    add-int/lit8 v1, v6, 0x3

    .line 393
    .line 394
    if-ge v0, v1, :cond_11

    .line 395
    .line 396
    if-lt v0, v6, :cond_10

    .line 397
    .line 398
    iget v0, v15, La/eF;->w:I

    .line 399
    .line 400
    if-ge v0, v6, :cond_f

    .line 401
    .line 402
    sub-int v0, v6, v0

    .line 403
    .line 404
    invoke-virtual {v15, v0}, La/eF;->w(I)V

    .line 405
    .line 406
    .line 407
    iget v0, v15, La/eF;->p:I

    .line 408
    .line 409
    if-ge v0, v8, :cond_f

    .line 410
    .line 411
    iget v0, v7, La/eF;->p:I

    .line 412
    .line 413
    iput v0, v15, La/eF;->p:I

    .line 414
    .line 415
    iget v0, v7, La/eF;->w:I

    .line 416
    .line 417
    iput v0, v15, La/eF;->w:I

    .line 418
    .line 419
    iget v0, v7, La/eF;->h:I

    .line 420
    .line 421
    iput v0, v15, La/eF;->h:I

    .line 422
    .line 423
    :cond_f
    move-object/from16 v0, p1

    .line 424
    .line 425
    move v1, v11

    .line 426
    move v2, v12

    .line 427
    move/from16 v3, v21

    .line 428
    .line 429
    move v4, v9

    .line 430
    move-object/from16 v5, p2

    .line 431
    .line 432
    move v10, v6

    .line 433
    move/from16 v6, v17

    .line 434
    .line 435
    move-object v11, v7

    .line 436
    const/16 v9, 0x24

    .line 437
    .line 438
    move v7, v9

    .line 439
    invoke-static/range {v0 .. v7}, La/kW;->p([BIIII[BII)I

    .line 440
    .line 441
    .line 442
    move-result v17

    .line 443
    iget v0, v11, La/eF;->p:I

    .line 444
    .line 445
    iget v12, v11, La/eF;->w:I

    .line 446
    .line 447
    iget v1, v11, La/eF;->h:I

    .line 448
    .line 449
    iget v2, v15, La/eF;->p:I

    .line 450
    .line 451
    iget v9, v15, La/eF;->w:I

    .line 452
    .line 453
    iget v3, v15, La/eF;->h:I

    .line 454
    .line 455
    move/from16 v16, v0

    .line 456
    .line 457
    move/from16 v21, v1

    .line 458
    .line 459
    move/from16 v23, v2

    .line 460
    .line 461
    move/from16 v19, v3

    .line 462
    .line 463
    move-object v7, v11

    .line 464
    move v11, v10

    .line 465
    goto/16 :goto_9

    .line 466
    .line 467
    :cond_10
    iget v1, v7, La/eF;->p:I

    .line 468
    .line 469
    iput v1, v15, La/eF;->p:I

    .line 470
    .line 471
    iput v0, v15, La/eF;->w:I

    .line 472
    .line 473
    iget v0, v7, La/eF;->h:I

    .line 474
    .line 475
    iput v0, v15, La/eF;->h:I

    .line 476
    .line 477
    const/4 v10, 0x3

    .line 478
    goto/16 :goto_a

    .line 479
    .line 480
    :cond_11
    move v0, v6

    .line 481
    iget v1, v15, La/eF;->w:I

    .line 482
    .line 483
    if-ge v1, v0, :cond_15

    .line 484
    .line 485
    sub-int v0, v1, v12

    .line 486
    .line 487
    const/16 v2, 0xf

    .line 488
    .line 489
    if-ge v0, v2, :cond_14

    .line 490
    .line 491
    if-le v9, v10, :cond_12

    .line 492
    .line 493
    move v9, v10

    .line 494
    :cond_12
    add-int v0, v12, v9

    .line 495
    .line 496
    iget v2, v15, La/eF;->p:I

    .line 497
    .line 498
    add-int v3, v1, v2

    .line 499
    .line 500
    sub-int/2addr v3, v8

    .line 501
    if-le v0, v3, :cond_13

    .line 502
    .line 503
    add-int/2addr v2, v1

    .line 504
    sub-int/2addr v2, v12

    .line 505
    sub-int/2addr v2, v8

    .line 506
    move v9, v2

    .line 507
    :cond_13
    add-int v0, v12, v9

    .line 508
    .line 509
    sub-int/2addr v0, v1

    .line 510
    invoke-virtual {v15, v0}, La/eF;->w(I)V

    .line 511
    .line 512
    .line 513
    goto :goto_c

    .line 514
    :cond_14
    move v9, v0

    .line 515
    :cond_15
    :goto_c
    move-object/from16 v0, p1

    .line 516
    .line 517
    move v1, v11

    .line 518
    move v2, v12

    .line 519
    move/from16 v3, v21

    .line 520
    .line 521
    move v4, v9

    .line 522
    move-object/from16 v5, p2

    .line 523
    .line 524
    move/from16 v6, v17

    .line 525
    .line 526
    move-object v11, v7

    .line 527
    const/16 v10, 0x24

    .line 528
    .line 529
    move v7, v10

    .line 530
    invoke-static/range {v0 .. v7}, La/kW;->p([BIIII[BII)I

    .line 531
    .line 532
    .line 533
    move-result v17

    .line 534
    add-int v0, v12, v9

    .line 535
    .line 536
    iget v9, v15, La/eF;->p:I

    .line 537
    .line 538
    iget v12, v15, La/eF;->w:I

    .line 539
    .line 540
    iget v1, v15, La/eF;->h:I

    .line 541
    .line 542
    iget v2, v11, La/eF;->p:I

    .line 543
    .line 544
    iput v2, v15, La/eF;->p:I

    .line 545
    .line 546
    iget v2, v11, La/eF;->w:I

    .line 547
    .line 548
    iput v2, v15, La/eF;->w:I

    .line 549
    .line 550
    iget v2, v11, La/eF;->h:I

    .line 551
    .line 552
    iput v2, v15, La/eF;->h:I

    .line 553
    .line 554
    move/from16 v21, v1

    .line 555
    .line 556
    move-object v7, v11

    .line 557
    const/4 v10, 0x3

    .line 558
    move v11, v0

    .line 559
    goto/16 :goto_a

    .line 560
    .line 561
    :cond_16
    move-object v10, v7

    .line 562
    const/16 v19, 0xf

    .line 563
    .line 564
    :goto_d
    iget v0, v15, La/eF;->w:I

    .line 565
    .line 566
    add-int v1, v12, v9

    .line 567
    .line 568
    if-ge v0, v1, :cond_17

    .line 569
    .line 570
    sub-int v9, v0, v12

    .line 571
    .line 572
    :cond_17
    move-object/from16 v0, p1

    .line 573
    .line 574
    move v1, v11

    .line 575
    move v2, v12

    .line 576
    move/from16 v3, v21

    .line 577
    .line 578
    move v4, v9

    .line 579
    move-object/from16 v5, p2

    .line 580
    .line 581
    move/from16 v6, v17

    .line 582
    .line 583
    const/16 v8, 0x24

    .line 584
    .line 585
    move v7, v8

    .line 586
    invoke-static/range {v0 .. v7}, La/kW;->p([BIIII[BII)I

    .line 587
    .line 588
    .line 589
    move-result v6

    .line 590
    add-int v1, v12, v9

    .line 591
    .line 592
    iget v2, v15, La/eF;->w:I

    .line 593
    .line 594
    iget v3, v15, La/eF;->h:I

    .line 595
    .line 596
    iget v4, v15, La/eF;->p:I

    .line 597
    .line 598
    move-object/from16 v0, p1

    .line 599
    .line 600
    move-object/from16 v5, p2

    .line 601
    .line 602
    const/16 v8, 0x24

    .line 603
    .line 604
    move v7, v8

    .line 605
    invoke-static/range {v0 .. v7}, La/kW;->p([BIIII[BII)I

    .line 606
    .line 607
    .line 608
    move-result v4

    .line 609
    iget v0, v15, La/eF;->w:I

    .line 610
    .line 611
    iget v1, v15, La/eF;->p:I

    .line 612
    .line 613
    add-int/2addr v1, v0

    .line 614
    move-object/from16 v8, p1

    .line 615
    .line 616
    move v0, v1

    .line 617
    move-object v7, v10

    .line 618
    :goto_e
    move/from16 v12, v19

    .line 619
    .line 620
    move/from16 v2, v21

    .line 621
    .line 622
    const/4 v9, 0x0

    .line 623
    move-object/from16 v10, p2

    .line 624
    .line 625
    goto/16 :goto_0

    .line 626
    .line 627
    :cond_18
    move/from16 v18, v6

    .line 628
    .line 629
    goto/16 :goto_8

    .line 630
    .line 631
    :goto_f
    move-object/from16 v0, p1

    .line 632
    .line 633
    move v1, v11

    .line 634
    move v2, v12

    .line 635
    move/from16 v3, v21

    .line 636
    .line 637
    move/from16 v4, v16

    .line 638
    .line 639
    move-object/from16 v5, p2

    .line 640
    .line 641
    move/from16 v6, v17

    .line 642
    .line 643
    const/16 v8, 0x24

    .line 644
    .line 645
    move v7, v8

    .line 646
    invoke-static/range {v0 .. v7}, La/kW;->p([BIIII[BII)I

    .line 647
    .line 648
    .line 649
    move-result v4

    .line 650
    move-object/from16 v8, p1

    .line 651
    .line 652
    move-object v7, v10

    .line 653
    move/from16 v0, v18

    .line 654
    .line 655
    move v1, v0

    .line 656
    goto :goto_e

    .line 657
    :cond_19
    move-object v10, v7

    .line 658
    const/16 v19, 0xf

    .line 659
    .line 660
    add-int/lit8 v0, v0, 0x1

    .line 661
    .line 662
    move-object/from16 v8, p1

    .line 663
    .line 664
    move/from16 v4, v17

    .line 665
    .line 666
    goto :goto_e

    .line 667
    :cond_1a
    move/from16 v17, v4

    .line 668
    .line 669
    rsub-int/lit8 v2, v1, 0x14

    .line 670
    .line 671
    move-object/from16 v0, p1

    .line 672
    .line 673
    move-object/from16 v3, p2

    .line 674
    .line 675
    const/16 v5, 0x24

    .line 676
    .line 677
    invoke-static/range {v0 .. v5}, La/kW;->e([BII[BII)I

    .line 678
    .line 679
    .line 680
    move-result v0

    .line 681
    return v0
.end method
