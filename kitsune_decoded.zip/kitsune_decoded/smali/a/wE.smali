.class public interface abstract La/wE;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract U()La/oj;
.end method
