.class public interface abstract La/Io;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract h(La/c9;)V
.end method
