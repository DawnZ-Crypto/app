.class public final La/cp;
.super La/Z5;
.source "SourceFile"


# annotations
.annotation runtime La/BV;
    value = "dialog"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/Z5;"
    }
.end annotation


# instance fields
.field public final Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

.field public final X:Ljava/util/LinkedHashMap;

.field public final e:La/ef;

.field public final i:Ljava/util/LinkedHashSet;

.field public final p:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;La/ef;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/cp;->p:Landroid/content/Context;

    iput-object p2, p0, La/cp;->e:La/ef;

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, La/cp;->i:Ljava/util/LinkedHashSet;

    new-instance p1, Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    invoke-direct {p1, p0}, Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;-><init>(La/cp;)V

    iput-object p1, p0, La/cp;->Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, La/cp;->X:Ljava/util/LinkedHashMap;

    return-void
.end method


# virtual methods
.method public final M(La/GA;)La/XM;
    .locals 6

    .line 1
    iget-object v0, p1, La/GA;->K:La/VT;

    .line 2
    .line 3
    check-cast v0, La/Wd;

    .line 4
    .line 5
    iget-object v1, v0, La/Wd;->E:Ljava/lang/String;

    .line 6
    .line 7
    const-string v2, "DialogFragment class was not set"

    .line 8
    .line 9
    if-eqz v1, :cond_3

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/16 v4, 0x2e

    .line 17
    .line 18
    iget-object v5, p0, La/cp;->p:Landroid/content/Context;

    .line 19
    .line 20
    if-ne v3, v4, :cond_0

    .line 21
    .line 22
    new-instance v3, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    :cond_0
    iget-object v3, p0, La/cp;->e:La/ef;

    .line 42
    .line 43
    invoke-virtual {v3}, La/ef;->U()La/r8;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-virtual {v5}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 48
    .line 49
    .line 50
    invoke-virtual {v3, v1}, La/r8;->w(Ljava/lang/String;)La/zr;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    const-class v4, La/XM;

    .line 59
    .line 60
    invoke-virtual {v4, v3}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    if-eqz v3, :cond_1

    .line 65
    .line 66
    check-cast v1, La/XM;

    .line 67
    .line 68
    invoke-virtual {p1}, La/GA;->p()Landroid/os/Bundle;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-virtual {v1, v0}, La/zr;->J(Landroid/os/Bundle;)V

    .line 73
    .line 74
    .line 75
    iget-object v0, v1, La/zr;->rV:Landroidx/lifecycle/w;

    .line 76
    .line 77
    iget-object v2, p0, La/cp;->Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    .line 78
    .line 79
    invoke-virtual {v0, v2}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 80
    .line 81
    .line 82
    iget-object v0, p0, La/cp;->X:Ljava/util/LinkedHashMap;

    .line 83
    .line 84
    iget-object p1, p1, La/GA;->f:Ljava/lang/String;

    .line 85
    .line 86
    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    return-object v1

    .line 90
    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 91
    .line 92
    const-string v1, "Dialog destination "

    .line 93
    .line 94
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    iget-object v0, v0, La/Wd;->E:Ljava/lang/String;

    .line 98
    .line 99
    if-eqz v0, :cond_2

    .line 100
    .line 101
    const-string v1, " is not an instance of DialogFragment"

    .line 102
    .line 103
    invoke-static {p1, v0, v1}, La/zq;->M(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 108
    .line 109
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    throw v0

    .line 117
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 118
    .line 119
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    throw p1

    .line 127
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 128
    .line 129
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    throw p1
.end method

.method public final Q(La/GA;)V
    .locals 5

    .line 1
    iget-object v0, p0, La/cp;->e:La/ef;

    .line 2
    .line 3
    invoke-virtual {v0}, La/ef;->C()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    const-string p1, "DialogFragmentNavigator"

    .line 10
    .line 11
    const-string v0, "Ignoring onLaunchSingleTop() call: FragmentManager has already saved its state"

    .line 12
    .line 13
    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iget-object v1, p0, La/cp;->X:Ljava/util/LinkedHashMap;

    .line 18
    .line 19
    iget-object v2, p1, La/GA;->f:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    check-cast v1, La/XM;

    .line 26
    .line 27
    if-nez v1, :cond_2

    .line 28
    .line 29
    invoke-virtual {v0, v2}, La/ef;->D(Ljava/lang/String;)La/zr;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    instance-of v3, v1, La/XM;

    .line 34
    .line 35
    if-eqz v3, :cond_1

    .line 36
    .line 37
    check-cast v1, La/XM;

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const/4 v1, 0x0

    .line 41
    :cond_2
    :goto_0
    if-eqz v1, :cond_3

    .line 42
    .line 43
    iget-object v3, v1, La/zr;->rV:Landroidx/lifecycle/w;

    .line 44
    .line 45
    iget-object v4, p0, La/cp;->Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    .line 46
    .line 47
    invoke-virtual {v3, v4}, Landroidx/lifecycle/w;->h(La/IQ;)V

    .line 48
    .line 49
    .line 50
    const/4 v3, 0x0

    .line 51
    invoke-virtual {v1, v3, v3}, La/XM;->G(ZZ)V

    .line 52
    .line 53
    .line 54
    :cond_3
    invoke-virtual {p0, p1}, La/cp;->M(La/GA;)La/XM;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-virtual {v1, v0, v2}, La/XM;->rV(La/ef;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    iget-object v1, v0, La/Ws;->i:La/Zz;

    .line 66
    .line 67
    iget-object v1, v1, La/Zz;->X:La/Jk;

    .line 68
    .line 69
    invoke-interface {v1}, La/Jk;->getValue()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    check-cast v1, Ljava/util/List;

    .line 74
    .line 75
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    invoke-interface {v1, v3}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    :cond_4
    invoke-interface {v1}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 84
    .line 85
    .line 86
    move-result v3

    .line 87
    if-eqz v3, :cond_5

    .line 88
    .line 89
    invoke-interface {v1}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    check-cast v3, La/GA;

    .line 94
    .line 95
    iget-object v4, v3, La/GA;->f:Ljava/lang/String;

    .line 96
    .line 97
    invoke-static {v4, v2}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    if-eqz v4, :cond_4

    .line 102
    .line 103
    iget-object v1, v0, La/Ws;->p:La/p8;

    .line 104
    .line 105
    invoke-virtual {v1}, La/p8;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    check-cast v2, Ljava/util/Set;

    .line 110
    .line 111
    invoke-static {v2, v3}, La/cl;->bG(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-static {v2, p1}, La/cl;->bG(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    invoke-virtual {v1, v2}, La/p8;->X(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, p1}, La/Ws;->p(La/GA;)V

    .line 123
    .line 124
    .line 125
    return-void

    .line 126
    :cond_5
    new-instance p1, Ljava/util/NoSuchElementException;

    .line 127
    .line 128
    const-string v0, "List contains no element matching the predicate."

    .line 129
    .line 130
    invoke-direct {p1, v0}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    throw p1
.end method

.method public final T(ILa/GA;Z)V
    .locals 2

    .line 1
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, La/Ws;->i:La/Zz;

    .line 6
    .line 7
    iget-object v0, v0, La/Zz;->X:La/Jk;

    .line 8
    .line 9
    invoke-interface {v0}, La/Jk;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Ljava/util/List;

    .line 14
    .line 15
    add-int/lit8 p1, p1, -0x1

    .line 16
    .line 17
    invoke-static {p1, v0}, La/ar;->yV(ILjava/util/List;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    check-cast p1, La/GA;

    .line 22
    .line 23
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iget-object v0, v0, La/Ws;->Q:La/Zz;

    .line 28
    .line 29
    iget-object v0, v0, La/Zz;->X:La/Jk;

    .line 30
    .line 31
    invoke-interface {v0}, La/Jk;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Ljava/lang/Iterable;

    .line 36
    .line 37
    invoke-static {v0, p1}, La/ar;->jR(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v1, p2, p3}, La/Ws;->Q(La/GA;Z)V

    .line 46
    .line 47
    .line 48
    if-eqz p1, :cond_0

    .line 49
    .line 50
    if-nez v0, :cond_0

    .line 51
    .line 52
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 53
    .line 54
    .line 55
    move-result-object p2

    .line 56
    invoke-virtual {p2, p1}, La/Ws;->h(La/GA;)V

    .line 57
    .line 58
    .line 59
    :cond_0
    return-void
.end method

.method public final V(La/GA;Z)V
    .locals 5

    .line 1
    iget-object v0, p0, La/cp;->e:La/ef;

    .line 2
    .line 3
    invoke-virtual {v0}, La/ef;->C()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    const-string p1, "DialogFragmentNavigator"

    .line 10
    .line 11
    const-string p2, "Ignoring popBackStack() call: FragmentManager has already saved its state"

    .line 12
    .line 13
    invoke-static {p1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v1, v1, La/Ws;->i:La/Zz;

    .line 22
    .line 23
    iget-object v1, v1, La/Zz;->X:La/Jk;

    .line 24
    .line 25
    invoke-interface {v1}, La/Jk;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    check-cast v1, Ljava/util/List;

    .line 30
    .line 31
    invoke-interface {v1, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    invoke-interface {v1, v2, v3}, Ljava/util/List;->subList(II)Ljava/util/List;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-static {v1}, La/ar;->yv(Ljava/util/List;)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-eqz v3, :cond_2

    .line 56
    .line 57
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    check-cast v3, La/GA;

    .line 62
    .line 63
    iget-object v3, v3, La/GA;->f:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v0, v3}, La/ef;->D(Ljava/lang/String;)La/zr;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    if-eqz v3, :cond_1

    .line 70
    .line 71
    check-cast v3, La/XM;

    .line 72
    .line 73
    const/4 v4, 0x0

    .line 74
    invoke-virtual {v3, v4, v4}, La/XM;->G(ZZ)V

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_2
    invoke-virtual {p0, v2, p1, p2}, La/cp;->T(ILa/GA;Z)V

    .line 79
    .line 80
    .line 81
    return-void
.end method

.method public final e(Ljava/util/List;La/i1;)V
    .locals 4

    .line 1
    iget-object p2, p0, La/cp;->e:La/ef;

    .line 2
    .line 3
    invoke-virtual {p2}, La/ef;->C()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const-string p1, "DialogFragmentNavigator"

    .line 10
    .line 11
    const-string p2, "Ignoring navigate() call: FragmentManager has already saved its state"

    .line 12
    .line 13
    invoke-static {p1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    :cond_1
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, La/GA;

    .line 32
    .line 33
    invoke-virtual {p0, v0}, La/cp;->M(La/GA;)La/XM;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    iget-object v2, v0, La/GA;->f:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {v1, p2, v2}, La/XM;->rV(La/ef;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iget-object v1, v1, La/Ws;->i:La/Zz;

    .line 47
    .line 48
    iget-object v1, v1, La/Zz;->X:La/Jk;

    .line 49
    .line 50
    invoke-interface {v1}, La/Jk;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    check-cast v1, Ljava/util/List;

    .line 55
    .line 56
    invoke-static {v1}, La/ar;->Hy(Ljava/util/List;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    check-cast v1, La/GA;

    .line 61
    .line 62
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    iget-object v2, v2, La/Ws;->Q:La/Zz;

    .line 67
    .line 68
    iget-object v2, v2, La/Zz;->X:La/Jk;

    .line 69
    .line 70
    invoke-interface {v2}, La/Jk;->getValue()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    check-cast v2, Ljava/lang/Iterable;

    .line 75
    .line 76
    invoke-static {v2, v1}, La/ar;->jR(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    invoke-virtual {v3, v0}, La/Ws;->O(La/GA;)V

    .line 85
    .line 86
    .line 87
    if-eqz v1, :cond_1

    .line 88
    .line 89
    if-nez v2, :cond_1

    .line 90
    .line 91
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-virtual {v0, v1}, La/Ws;->h(La/GA;)V

    .line 96
    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_2
    return-void
.end method

.method public final i(La/Ws;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, La/Z5;->i(La/Ws;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p1, La/Ws;->i:La/Zz;

    .line 5
    .line 6
    iget-object p1, p1, La/Zz;->X:La/Jk;

    .line 7
    .line 8
    invoke-interface {p1}, La/Jk;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v1, p0, La/cp;->e:La/ef;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, La/GA;

    .line 31
    .line 32
    iget-object v2, v0, La/GA;->f:Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {v1, v2}, La/ef;->D(Ljava/lang/String;)La/zr;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    check-cast v1, La/XM;

    .line 39
    .line 40
    if-eqz v1, :cond_0

    .line 41
    .line 42
    iget-object v1, v1, La/zr;->rV:Landroidx/lifecycle/w;

    .line 43
    .line 44
    if-eqz v1, :cond_0

    .line 45
    .line 46
    iget-object v0, p0, La/cp;->Q:Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;

    .line 47
    .line 48
    invoke-virtual {v1, v0}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_0
    iget-object v1, p0, La/cp;->i:Ljava/util/LinkedHashSet;

    .line 53
    .line 54
    iget-object v0, v0, La/GA;->f:Ljava/lang/String;

    .line 55
    .line 56
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_1
    new-instance p1, La/oa;

    .line 61
    .line 62
    invoke-direct {p1, p0}, La/oa;-><init>(La/cp;)V

    .line 63
    .line 64
    .line 65
    iget-object v0, v1, La/ef;->y:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 66
    .line 67
    invoke-virtual {v0, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final w()La/VT;
    .locals 1

    .line 1
    new-instance v0, La/Wd;

    .line 2
    .line 3
    invoke-direct {v0, p0}, La/VT;-><init>(La/Z5;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
