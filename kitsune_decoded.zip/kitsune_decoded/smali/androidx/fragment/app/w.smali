.class public final Landroidx/fragment/app/w;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public e:Z

.field public final h:La/kQ;

.field public i:I

.field public final p:La/zr;

.field public final w:La/dh;


# direct methods
.method public constructor <init>(La/dh;La/kQ;La/zr;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/w;->e:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/w;->i:I

    iput-object p1, p0, Landroidx/fragment/app/w;->w:La/dh;

    iput-object p2, p0, Landroidx/fragment/app/w;->h:La/kQ;

    iput-object p3, p0, Landroidx/fragment/app/w;->p:La/zr;

    return-void
.end method

.method public constructor <init>(La/dh;La/kQ;La/zr;Landroid/os/Bundle;)V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/w;->e:Z

    const/4 v1, -0x1

    iput v1, p0, Landroidx/fragment/app/w;->i:I

    iput-object p1, p0, Landroidx/fragment/app/w;->w:La/dh;

    iput-object p2, p0, Landroidx/fragment/app/w;->h:La/kQ;

    iput-object p3, p0, Landroidx/fragment/app/w;->p:La/zr;

    const/4 p1, 0x0

    iput-object p1, p3, La/zr;->R:Landroid/util/SparseArray;

    iput-object p1, p3, La/zr;->L:Landroid/os/Bundle;

    iput v0, p3, La/zr;->u:I

    iput-boolean v0, p3, La/zr;->P:Z

    iput-boolean v0, p3, La/zr;->E:Z

    iget-object p2, p3, La/zr;->l:La/zr;

    if-eqz p2, :cond_0

    iget-object p2, p2, La/zr;->d:Ljava/lang/String;

    goto :goto_0

    :cond_0
    move-object p2, p1

    :goto_0
    iput-object p2, p3, La/zr;->W:Ljava/lang/String;

    iput-object p1, p3, La/zr;->l:La/zr;

    iput-object p4, p3, La/zr;->K:Landroid/os/Bundle;

    const-string p1, "arguments"

    invoke-virtual {p4, p1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    iput-object p1, p3, La/zr;->f:Landroid/os/Bundle;

    return-void
.end method

.method public constructor <init>(La/dh;La/kQ;Ljava/lang/ClassLoader;La/r8;Landroid/os/Bundle;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/w;->e:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/w;->i:I

    iput-object p1, p0, Landroidx/fragment/app/w;->w:La/dh;

    iput-object p2, p0, Landroidx/fragment/app/w;->h:La/kQ;

    const-string p1, "state"

    invoke-virtual {p5, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, La/Db;

    invoke-virtual {p1, p4}, La/Db;->h(La/r8;)La/zr;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/w;->p:La/zr;

    iput-object p5, p1, La/zr;->K:Landroid/os/Bundle;

    const-string p2, "arguments"

    invoke-virtual {p5, p2}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p2

    if-eqz p2, :cond_0

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    :cond_0
    invoke-virtual {p1, p2}, La/zr;->J(Landroid/os/Bundle;)V

    const/4 p2, 0x2

    const-string p3, "FragmentManager"

    .line 3
    invoke-static {p3, p2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p2

    if-eqz p2, :cond_1

    .line 4
    new-instance p2, Ljava/lang/StringBuilder;

    const-string p4, "Instantiated fragment "

    invoke-direct {p2, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p3, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-void
.end method


# virtual methods
.method public final I()V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 2
    .line 3
    iget-boolean v1, v0, La/zr;->z:Z

    .line 4
    .line 5
    if-eqz v1, :cond_4

    .line 6
    .line 7
    iget-boolean v1, v0, La/zr;->P:Z

    .line 8
    .line 9
    if-eqz v1, :cond_4

    .line 10
    .line 11
    iget-boolean v1, v0, La/zr;->Y:Z

    .line 12
    .line 13
    if-nez v1, :cond_4

    .line 14
    .line 15
    const/4 v1, 0x3

    .line 16
    const-string v2, "FragmentManager"

    .line 17
    .line 18
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    new-instance v1, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v3, "moveto CREATE_VIEW: "

    .line 27
    .line 28
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    :cond_0
    iget-object v1, v0, La/zr;->K:Landroid/os/Bundle;

    .line 42
    .line 43
    const-string v2, "savedInstanceState"

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    goto :goto_0

    .line 53
    :cond_1
    move-object v1, v3

    .line 54
    :goto_0
    invoke-virtual {v0, v1}, La/zr;->v(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-virtual {v0, v4, v3, v1}, La/zr;->r(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    .line 59
    .line 60
    .line 61
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 62
    .line 63
    if-eqz v1, :cond_4

    .line 64
    .line 65
    const/4 v4, 0x0

    .line 66
    invoke-virtual {v1, v4}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    .line 67
    .line 68
    .line 69
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 70
    .line 71
    const v5, 0x7f0900f8

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1, v5, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    iget-boolean v1, v0, La/zr;->C:Z

    .line 78
    .line 79
    if-eqz v1, :cond_2

    .line 80
    .line 81
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 82
    .line 83
    const/16 v5, 0x8

    .line 84
    .line 85
    invoke-virtual {v1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 86
    .line 87
    .line 88
    :cond_2
    iget-object v1, v0, La/zr;->K:Landroid/os/Bundle;

    .line 89
    .line 90
    if-eqz v1, :cond_3

    .line 91
    .line 92
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    :cond_3
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 97
    .line 98
    invoke-virtual {v0, v1, v3}, La/zr;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 99
    .line 100
    .line 101
    iget-object v1, v0, La/zr;->v:La/ef;

    .line 102
    .line 103
    const/4 v2, 0x2

    .line 104
    invoke-virtual {v1, v2}, La/ef;->l(I)V

    .line 105
    .line 106
    .line 107
    iget-object v1, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 108
    .line 109
    invoke-virtual {v1, v4}, La/dh;->f(Z)V

    .line 110
    .line 111
    .line 112
    iput v2, v0, La/zr;->X:I

    .line 113
    .line 114
    :cond_4
    return-void
.end method

.method public final K()Landroid/os/Bundle;
    .locals 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 7
    .line 8
    iget v2, v1, La/zr;->X:I

    .line 9
    .line 10
    const/4 v3, -0x1

    .line 11
    if-ne v2, v3, :cond_0

    .line 12
    .line 13
    iget-object v2, v1, La/zr;->K:Landroid/os/Bundle;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    new-instance v2, La/Db;

    .line 21
    .line 22
    invoke-direct {v2, v1}, La/Db;-><init>(La/zr;)V

    .line 23
    .line 24
    .line 25
    const-string v4, "state"

    .line 26
    .line 27
    invoke-virtual {v0, v4, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 28
    .line 29
    .line 30
    iget v2, v1, La/zr;->X:I

    .line 31
    .line 32
    if-le v2, v3, :cond_6

    .line 33
    .line 34
    new-instance v2, Landroid/os/Bundle;

    .line 35
    .line 36
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1, v2}, La/zr;->n(Landroid/os/Bundle;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v2}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    if-nez v3, :cond_1

    .line 47
    .line 48
    const-string v3, "savedInstanceState"

    .line 49
    .line 50
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    iget-object v2, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 54
    .line 55
    const/4 v3, 0x0

    .line 56
    invoke-virtual {v2, v3}, La/dh;->R(Z)V

    .line 57
    .line 58
    .line 59
    new-instance v2, Landroid/os/Bundle;

    .line 60
    .line 61
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 62
    .line 63
    .line 64
    iget-object v3, v1, La/zr;->eH:La/fj;

    .line 65
    .line 66
    invoke-virtual {v3, v2}, La/fj;->p(Landroid/os/Bundle;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    if-nez v3, :cond_2

    .line 74
    .line 75
    const-string v3, "registryState"

    .line 76
    .line 77
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 78
    .line 79
    .line 80
    :cond_2
    iget-object v2, v1, La/zr;->v:La/ef;

    .line 81
    .line 82
    invoke-virtual {v2}, La/ef;->b()Landroid/os/Bundle;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    invoke-virtual {v2}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    if-nez v3, :cond_3

    .line 91
    .line 92
    const-string v3, "childFragmentManager"

    .line 93
    .line 94
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 95
    .line 96
    .line 97
    :cond_3
    iget-object v2, v1, La/zr;->B:Landroid/view/View;

    .line 98
    .line 99
    if-eqz v2, :cond_4

    .line 100
    .line 101
    invoke-virtual {p0}, Landroidx/fragment/app/w;->R()V

    .line 102
    .line 103
    .line 104
    :cond_4
    iget-object v2, v1, La/zr;->R:Landroid/util/SparseArray;

    .line 105
    .line 106
    if-eqz v2, :cond_5

    .line 107
    .line 108
    const-string v3, "viewState"

    .line 109
    .line 110
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    .line 111
    .line 112
    .line 113
    :cond_5
    iget-object v2, v1, La/zr;->L:Landroid/os/Bundle;

    .line 114
    .line 115
    if-eqz v2, :cond_6

    .line 116
    .line 117
    const-string v3, "viewRegistryState"

    .line 118
    .line 119
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 120
    .line 121
    .line 122
    :cond_6
    iget-object v1, v1, La/zr;->f:Landroid/os/Bundle;

    .line 123
    .line 124
    if-eqz v1, :cond_7

    .line 125
    .line 126
    const-string v2, "arguments"

    .line 127
    .line 128
    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 129
    .line 130
    .line 131
    :cond_7
    return-object v0
.end method

.method public final L()V
    .locals 5

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "moveto STARTED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 30
    .line 31
    invoke-virtual {v0}, La/ef;->g()V

    .line 32
    .line 33
    .line 34
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 35
    .line 36
    const/4 v1, 0x1

    .line 37
    invoke-virtual {v0, v1}, La/ef;->E(Z)Z

    .line 38
    .line 39
    .line 40
    const/4 v0, 0x5

    .line 41
    iput v0, v2, La/zr;->X:I

    .line 42
    .line 43
    const/4 v1, 0x0

    .line 44
    iput-boolean v1, v2, La/zr;->r:Z

    .line 45
    .line 46
    invoke-virtual {v2}, La/zr;->C()V

    .line 47
    .line 48
    .line 49
    iget-boolean v3, v2, La/zr;->r:Z

    .line 50
    .line 51
    if-eqz v3, :cond_2

    .line 52
    .line 53
    iget-object v3, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 54
    .line 55
    sget-object v4, La/cw;->ON_START:La/cw;

    .line 56
    .line 57
    invoke-virtual {v3, v4}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 58
    .line 59
    .line 60
    iget-object v3, v2, La/zr;->B:Landroid/view/View;

    .line 61
    .line 62
    if-eqz v3, :cond_1

    .line 63
    .line 64
    iget-object v3, v2, La/zr;->rC:La/NT;

    .line 65
    .line 66
    invoke-virtual {v3, v4}, La/NT;->p(La/cw;)V

    .line 67
    .line 68
    .line 69
    :cond_1
    iget-object v2, v2, La/zr;->v:La/ef;

    .line 70
    .line 71
    iput-boolean v1, v2, La/ef;->U:Z

    .line 72
    .line 73
    iput-boolean v1, v2, La/ef;->k:Z

    .line 74
    .line 75
    iget-object v3, v2, La/ef;->C:La/d5;

    .line 76
    .line 77
    iput-boolean v1, v3, La/d5;->q:Z

    .line 78
    .line 79
    invoke-virtual {v2, v0}, La/ef;->l(I)V

    .line 80
    .line 81
    .line 82
    iget-object v0, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 83
    .line 84
    invoke-virtual {v0, v1}, La/dh;->L(Z)V

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    :cond_2
    new-instance v0, La/ME;

    .line 89
    .line 90
    new-instance v1, Ljava/lang/StringBuilder;

    .line 91
    .line 92
    const-string v3, "Fragment "

    .line 93
    .line 94
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    const-string v2, " did not call through to super.onStart()"

    .line 101
    .line 102
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    throw v0
.end method

.method public final M()V
    .locals 11

    .line 1
    iget-boolean v0, p0, Landroidx/fragment/app/w;->e:Z

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const-string v2, "FragmentManager"

    .line 5
    .line 6
    iget-object v3, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    new-instance v0, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    const-string v1, "Ignoring re-entrant call to moveToExpectedState() for "

    .line 19
    .line 20
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-static {v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void

    .line 34
    :cond_1
    const/4 v0, 0x1

    .line 35
    const/4 v4, 0x0

    .line 36
    :try_start_0
    iput-boolean v0, p0, Landroidx/fragment/app/w;->e:Z

    .line 37
    .line 38
    move v5, v4

    .line 39
    :goto_0
    invoke-virtual {p0}, Landroidx/fragment/app/w;->e()I

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    iget v7, v3, La/zr;->X:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    .line 45
    const/4 v8, 0x3

    .line 46
    const v9, 0x7f090226

    .line 47
    .line 48
    .line 49
    iget-object v10, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 50
    .line 51
    if-eq v6, v7, :cond_10

    .line 52
    .line 53
    if-le v6, v7, :cond_8

    .line 54
    .line 55
    add-int/lit8 v7, v7, 0x1

    .line 56
    .line 57
    packed-switch v7, :pswitch_data_0

    .line 58
    .line 59
    .line 60
    goto/16 :goto_5

    .line 61
    .line 62
    :pswitch_0
    :try_start_1
    invoke-virtual {p0}, Landroidx/fragment/app/w;->y()V

    .line 63
    .line 64
    .line 65
    goto/16 :goto_5

    .line 66
    .line 67
    :catchall_0
    move-exception v0

    .line 68
    goto/16 :goto_8

    .line 69
    .line 70
    :pswitch_1
    const/4 v5, 0x6

    .line 71
    iput v5, v3, La/zr;->X:I

    .line 72
    .line 73
    goto/16 :goto_5

    .line 74
    .line 75
    :pswitch_2
    invoke-virtual {p0}, Landroidx/fragment/app/w;->L()V

    .line 76
    .line 77
    .line 78
    goto/16 :goto_5

    .line 79
    .line 80
    :pswitch_3
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 81
    .line 82
    const/4 v6, 0x4

    .line 83
    if-eqz v5, :cond_7

    .line 84
    .line 85
    iget-object v5, v3, La/zr;->c:Landroid/view/ViewGroup;

    .line 86
    .line 87
    if-eqz v5, :cond_7

    .line 88
    .line 89
    invoke-virtual {v3}, La/zr;->d()La/ef;

    .line 90
    .line 91
    .line 92
    move-result-object v7

    .line 93
    invoke-virtual {v7}, La/ef;->k()La/XD;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5, v9}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v7

    .line 100
    instance-of v10, v7, La/lp;

    .line 101
    .line 102
    if-eqz v10, :cond_2

    .line 103
    .line 104
    check-cast v7, La/lp;

    .line 105
    .line 106
    goto :goto_1

    .line 107
    :cond_2
    new-instance v7, La/lp;

    .line 108
    .line 109
    invoke-direct {v7, v5}, La/lp;-><init>(Landroid/view/ViewGroup;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v5, v9, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :goto_1
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 116
    .line 117
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 118
    .line 119
    .line 120
    move-result v5

    .line 121
    if-eqz v5, :cond_5

    .line 122
    .line 123
    if-eq v5, v6, :cond_4

    .line 124
    .line 125
    const/16 v9, 0x8

    .line 126
    .line 127
    if-ne v5, v9, :cond_3

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 131
    .line 132
    new-instance v1, Ljava/lang/StringBuilder;

    .line 133
    .line 134
    const-string v2, "Unknown visibility "

    .line 135
    .line 136
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw v0

    .line 150
    :cond_4
    move v8, v6

    .line 151
    goto :goto_2

    .line 152
    :cond_5
    move v8, v1

    .line 153
    :goto_2
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 157
    .line 158
    .line 159
    move-result v5

    .line 160
    if-eqz v5, :cond_6

    .line 161
    .line 162
    new-instance v5, Ljava/lang/StringBuilder;

    .line 163
    .line 164
    const-string v9, "SpecialEffectsController: Enqueuing add operation for fragment "

    .line 165
    .line 166
    invoke-direct {v5, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    invoke-static {v2, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 177
    .line 178
    .line 179
    :cond_6
    invoke-virtual {v7, v8, v1, p0}, La/lp;->h(IILandroidx/fragment/app/w;)V

    .line 180
    .line 181
    .line 182
    :cond_7
    iput v6, v3, La/zr;->X:I

    .line 183
    .line 184
    goto/16 :goto_5

    .line 185
    .line 186
    :pswitch_4
    invoke-virtual {p0}, Landroidx/fragment/app/w;->w()V

    .line 187
    .line 188
    .line 189
    goto/16 :goto_5

    .line 190
    .line 191
    :pswitch_5
    invoke-virtual {p0}, Landroidx/fragment/app/w;->I()V

    .line 192
    .line 193
    .line 194
    invoke-virtual {p0}, Landroidx/fragment/app/w;->Q()V

    .line 195
    .line 196
    .line 197
    goto/16 :goto_5

    .line 198
    .line 199
    :pswitch_6
    invoke-virtual {p0}, Landroidx/fragment/app/w;->i()V

    .line 200
    .line 201
    .line 202
    goto/16 :goto_5

    .line 203
    .line 204
    :pswitch_7
    invoke-virtual {p0}, Landroidx/fragment/app/w;->p()V

    .line 205
    .line 206
    .line 207
    goto/16 :goto_5

    .line 208
    .line 209
    :cond_8
    add-int/lit8 v7, v7, -0x1

    .line 210
    .line 211
    packed-switch v7, :pswitch_data_1

    .line 212
    .line 213
    .line 214
    goto/16 :goto_5

    .line 215
    .line 216
    :pswitch_8
    invoke-virtual {p0}, Landroidx/fragment/app/w;->T()V

    .line 217
    .line 218
    .line 219
    goto/16 :goto_5

    .line 220
    .line 221
    :pswitch_9
    const/4 v5, 0x5

    .line 222
    iput v5, v3, La/zr;->X:I

    .line 223
    .line 224
    goto/16 :goto_5

    .line 225
    .line 226
    :pswitch_a
    invoke-virtual {p0}, Landroidx/fragment/app/w;->d()V

    .line 227
    .line 228
    .line 229
    goto/16 :goto_5

    .line 230
    .line 231
    :pswitch_b
    invoke-static {v2, v8}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 232
    .line 233
    .line 234
    move-result v5

    .line 235
    if-eqz v5, :cond_9

    .line 236
    .line 237
    new-instance v5, Ljava/lang/StringBuilder;

    .line 238
    .line 239
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 240
    .line 241
    .line 242
    const-string v6, "movefrom ACTIVITY_CREATED: "

    .line 243
    .line 244
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v5

    .line 254
    invoke-static {v2, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 255
    .line 256
    .line 257
    :cond_9
    iget-boolean v5, v3, La/zr;->H:Z

    .line 258
    .line 259
    if-eqz v5, :cond_a

    .line 260
    .line 261
    iget-object v5, v3, La/zr;->d:Ljava/lang/String;

    .line 262
    .line 263
    invoke-virtual {p0}, Landroidx/fragment/app/w;->K()Landroid/os/Bundle;

    .line 264
    .line 265
    .line 266
    move-result-object v6

    .line 267
    invoke-virtual {v10, v5, v6}, La/kQ;->l(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 268
    .line 269
    .line 270
    goto :goto_3

    .line 271
    :cond_a
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 272
    .line 273
    if-eqz v5, :cond_b

    .line 274
    .line 275
    iget-object v5, v3, La/zr;->R:Landroid/util/SparseArray;

    .line 276
    .line 277
    if-nez v5, :cond_b

    .line 278
    .line 279
    invoke-virtual {p0}, Landroidx/fragment/app/w;->R()V

    .line 280
    .line 281
    .line 282
    :cond_b
    :goto_3
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 283
    .line 284
    if-eqz v5, :cond_e

    .line 285
    .line 286
    iget-object v5, v3, La/zr;->c:Landroid/view/ViewGroup;

    .line 287
    .line 288
    if-eqz v5, :cond_e

    .line 289
    .line 290
    invoke-virtual {v3}, La/zr;->d()La/ef;

    .line 291
    .line 292
    .line 293
    move-result-object v6

    .line 294
    invoke-virtual {v6}, La/ef;->k()La/XD;

    .line 295
    .line 296
    .line 297
    invoke-virtual {v5, v9}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v6

    .line 301
    instance-of v7, v6, La/lp;

    .line 302
    .line 303
    if-eqz v7, :cond_c

    .line 304
    .line 305
    check-cast v6, La/lp;

    .line 306
    .line 307
    goto :goto_4

    .line 308
    :cond_c
    new-instance v6, La/lp;

    .line 309
    .line 310
    invoke-direct {v6, v5}, La/lp;-><init>(Landroid/view/ViewGroup;)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {v5, v9, v6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    :goto_4
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 317
    .line 318
    .line 319
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 320
    .line 321
    .line 322
    move-result v5

    .line 323
    if-eqz v5, :cond_d

    .line 324
    .line 325
    new-instance v5, Ljava/lang/StringBuilder;

    .line 326
    .line 327
    const-string v7, "SpecialEffectsController: Enqueuing remove operation for fragment "

    .line 328
    .line 329
    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 333
    .line 334
    .line 335
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object v5

    .line 339
    invoke-static {v2, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 340
    .line 341
    .line 342
    :cond_d
    invoke-virtual {v6, v0, v8, p0}, La/lp;->h(IILandroidx/fragment/app/w;)V

    .line 343
    .line 344
    .line 345
    :cond_e
    iput v8, v3, La/zr;->X:I

    .line 346
    .line 347
    goto :goto_5

    .line 348
    :pswitch_c
    iput-boolean v4, v3, La/zr;->P:Z

    .line 349
    .line 350
    iput v1, v3, La/zr;->X:I

    .line 351
    .line 352
    goto :goto_5

    .line 353
    :pswitch_d
    invoke-virtual {p0}, Landroidx/fragment/app/w;->O()V

    .line 354
    .line 355
    .line 356
    iput v0, v3, La/zr;->X:I

    .line 357
    .line 358
    goto :goto_5

    .line 359
    :pswitch_e
    iget-boolean v5, v3, La/zr;->H:Z

    .line 360
    .line 361
    if-eqz v5, :cond_f

    .line 362
    .line 363
    iget-object v5, v3, La/zr;->d:Ljava/lang/String;

    .line 364
    .line 365
    iget-object v6, v10, La/kQ;->p:Ljava/lang/Object;

    .line 366
    .line 367
    check-cast v6, Ljava/util/HashMap;

    .line 368
    .line 369
    invoke-virtual {v6, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v5

    .line 373
    check-cast v5, Landroid/os/Bundle;

    .line 374
    .line 375
    if-nez v5, :cond_f

    .line 376
    .line 377
    iget-object v5, v3, La/zr;->d:Ljava/lang/String;

    .line 378
    .line 379
    invoke-virtual {p0}, Landroidx/fragment/app/w;->K()Landroid/os/Bundle;

    .line 380
    .line 381
    .line 382
    move-result-object v6

    .line 383
    invoke-virtual {v10, v5, v6}, La/kQ;->l(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 384
    .line 385
    .line 386
    :cond_f
    invoke-virtual {p0}, Landroidx/fragment/app/w;->X()V

    .line 387
    .line 388
    .line 389
    goto :goto_5

    .line 390
    :pswitch_f
    invoke-virtual {p0}, Landroidx/fragment/app/w;->V()V

    .line 391
    .line 392
    .line 393
    :goto_5
    move v5, v0

    .line 394
    goto/16 :goto_0

    .line 395
    .line 396
    :cond_10
    if-nez v5, :cond_13

    .line 397
    .line 398
    const/4 v5, -0x1

    .line 399
    if-ne v7, v5, :cond_13

    .line 400
    .line 401
    iget-boolean v5, v3, La/zr;->S:Z

    .line 402
    .line 403
    if-eqz v5, :cond_13

    .line 404
    .line 405
    invoke-virtual {v3}, La/zr;->H()Z

    .line 406
    .line 407
    .line 408
    move-result v5

    .line 409
    if-nez v5, :cond_13

    .line 410
    .line 411
    iget-boolean v5, v3, La/zr;->H:Z

    .line 412
    .line 413
    if-nez v5, :cond_13

    .line 414
    .line 415
    invoke-static {v2, v8}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 416
    .line 417
    .line 418
    move-result v5

    .line 419
    if-eqz v5, :cond_11

    .line 420
    .line 421
    new-instance v5, Ljava/lang/StringBuilder;

    .line 422
    .line 423
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 424
    .line 425
    .line 426
    const-string v6, "Cleaning up state of never attached fragment: "

    .line 427
    .line 428
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 429
    .line 430
    .line 431
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 432
    .line 433
    .line 434
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 435
    .line 436
    .line 437
    move-result-object v5

    .line 438
    invoke-static {v2, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 439
    .line 440
    .line 441
    :cond_11
    iget-object v5, v10, La/kQ;->i:Ljava/lang/Object;

    .line 442
    .line 443
    check-cast v5, La/d5;

    .line 444
    .line 445
    invoke-virtual {v5, v3, v0}, La/d5;->V(La/zr;Z)V

    .line 446
    .line 447
    .line 448
    invoke-virtual {v10, p0}, La/kQ;->d(Landroidx/fragment/app/w;)V

    .line 449
    .line 450
    .line 451
    invoke-static {v2, v8}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 452
    .line 453
    .line 454
    move-result v5

    .line 455
    if-eqz v5, :cond_12

    .line 456
    .line 457
    new-instance v5, Ljava/lang/StringBuilder;

    .line 458
    .line 459
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 460
    .line 461
    .line 462
    const-string v6, "initState called for fragment: "

    .line 463
    .line 464
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 465
    .line 466
    .line 467
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 468
    .line 469
    .line 470
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v5

    .line 474
    invoke-static {v2, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 475
    .line 476
    .line 477
    :cond_12
    invoke-virtual {v3}, La/zr;->F()V

    .line 478
    .line 479
    .line 480
    :cond_13
    iget-boolean v5, v3, La/zr;->J:Z

    .line 481
    .line 482
    if-eqz v5, :cond_1a

    .line 483
    .line 484
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 485
    .line 486
    if-eqz v5, :cond_18

    .line 487
    .line 488
    iget-object v5, v3, La/zr;->c:Landroid/view/ViewGroup;

    .line 489
    .line 490
    if-eqz v5, :cond_18

    .line 491
    .line 492
    invoke-virtual {v3}, La/zr;->d()La/ef;

    .line 493
    .line 494
    .line 495
    move-result-object v6

    .line 496
    invoke-virtual {v6}, La/ef;->k()La/XD;

    .line 497
    .line 498
    .line 499
    invoke-virtual {v5, v9}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 500
    .line 501
    .line 502
    move-result-object v6

    .line 503
    instance-of v7, v6, La/lp;

    .line 504
    .line 505
    if-eqz v7, :cond_14

    .line 506
    .line 507
    check-cast v6, La/lp;

    .line 508
    .line 509
    goto :goto_6

    .line 510
    :cond_14
    new-instance v6, La/lp;

    .line 511
    .line 512
    invoke-direct {v6, v5}, La/lp;-><init>(Landroid/view/ViewGroup;)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {v5, v9, v6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    :goto_6
    iget-boolean v5, v3, La/zr;->C:Z

    .line 519
    .line 520
    if-eqz v5, :cond_16

    .line 521
    .line 522
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 523
    .line 524
    .line 525
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 526
    .line 527
    .line 528
    move-result v1

    .line 529
    if-eqz v1, :cond_15

    .line 530
    .line 531
    new-instance v1, Ljava/lang/StringBuilder;

    .line 532
    .line 533
    const-string v5, "SpecialEffectsController: Enqueuing hide operation for fragment "

    .line 534
    .line 535
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 536
    .line 537
    .line 538
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 539
    .line 540
    .line 541
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object v1

    .line 545
    invoke-static {v2, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 546
    .line 547
    .line 548
    :cond_15
    invoke-virtual {v6, v8, v0, p0}, La/lp;->h(IILandroidx/fragment/app/w;)V

    .line 549
    .line 550
    .line 551
    goto :goto_7

    .line 552
    :cond_16
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 553
    .line 554
    .line 555
    invoke-static {v2, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 556
    .line 557
    .line 558
    move-result v5

    .line 559
    if-eqz v5, :cond_17

    .line 560
    .line 561
    new-instance v5, Ljava/lang/StringBuilder;

    .line 562
    .line 563
    const-string v7, "SpecialEffectsController: Enqueuing show operation for fragment "

    .line 564
    .line 565
    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 566
    .line 567
    .line 568
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 572
    .line 573
    .line 574
    move-result-object v5

    .line 575
    invoke-static {v2, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 576
    .line 577
    .line 578
    :cond_17
    invoke-virtual {v6, v1, v0, p0}, La/lp;->h(IILandroidx/fragment/app/w;)V

    .line 579
    .line 580
    .line 581
    :cond_18
    :goto_7
    iget-object v1, v3, La/zr;->U:La/ef;

    .line 582
    .line 583
    if-eqz v1, :cond_19

    .line 584
    .line 585
    iget-boolean v2, v3, La/zr;->E:Z

    .line 586
    .line 587
    if-eqz v2, :cond_19

    .line 588
    .line 589
    invoke-static {v3}, La/ef;->s(La/zr;)Z

    .line 590
    .line 591
    .line 592
    move-result v2

    .line 593
    if-eqz v2, :cond_19

    .line 594
    .line 595
    iput-boolean v0, v1, La/ef;->u:Z

    .line 596
    .line 597
    :cond_19
    iput-boolean v4, v3, La/zr;->J:Z

    .line 598
    .line 599
    iget-object v0, v3, La/zr;->v:La/ef;

    .line 600
    .line 601
    invoke-virtual {v0}, La/ef;->y()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 602
    .line 603
    .line 604
    :cond_1a
    iput-boolean v4, p0, Landroidx/fragment/app/w;->e:Z

    .line 605
    .line 606
    return-void

    .line 607
    :goto_8
    iput-boolean v4, p0, Landroidx/fragment/app/w;->e:Z

    .line 608
    .line 609
    throw v0

    .line 610
    nop

    .line 611
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    :pswitch_data_1
    .packed-switch -0x1
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch
.end method

.method public final O()V
    .locals 5

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "movefrom CREATE_VIEW: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->c:Landroid/view/ViewGroup;

    .line 30
    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    iget-object v1, v2, La/zr;->B:Landroid/view/View;

    .line 34
    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 41
    .line 42
    const/4 v1, 0x1

    .line 43
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 44
    .line 45
    .line 46
    iget-object v0, v2, La/zr;->B:Landroid/view/View;

    .line 47
    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    iget-object v0, v2, La/zr;->rC:La/NT;

    .line 51
    .line 52
    invoke-virtual {v0}, La/NT;->e()V

    .line 53
    .line 54
    .line 55
    iget-object v0, v0, La/NT;->d:Landroidx/lifecycle/w;

    .line 56
    .line 57
    iget-object v0, v0, Landroidx/lifecycle/w;->e:La/m2;

    .line 58
    .line 59
    sget-object v3, La/m2;->R:La/m2;

    .line 60
    .line 61
    invoke-virtual {v0, v3}, La/m2;->w(La/m2;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_2

    .line 66
    .line 67
    iget-object v0, v2, La/zr;->rC:La/NT;

    .line 68
    .line 69
    sget-object v3, La/cw;->ON_DESTROY:La/cw;

    .line 70
    .line 71
    invoke-virtual {v0, v3}, La/NT;->p(La/cw;)V

    .line 72
    .line 73
    .line 74
    :cond_2
    iput v1, v2, La/zr;->X:I

    .line 75
    .line 76
    const/4 v0, 0x0

    .line 77
    iput-boolean v0, v2, La/zr;->r:Z

    .line 78
    .line 79
    invoke-virtual {v2}, La/zr;->U()V

    .line 80
    .line 81
    .line 82
    iget-boolean v1, v2, La/zr;->r:Z

    .line 83
    .line 84
    if-eqz v1, :cond_4

    .line 85
    .line 86
    invoke-interface {v2}, La/CG;->i()La/Sx;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    new-instance v3, La/yW;

    .line 91
    .line 92
    sget-object v4, La/WM;->d:La/oK;

    .line 93
    .line 94
    invoke-direct {v3, v1, v4}, La/yW;-><init>(La/Sx;La/o7;)V

    .line 95
    .line 96
    .line 97
    const-class v1, La/WM;

    .line 98
    .line 99
    invoke-virtual {v3, v1}, La/yW;->m(Ljava/lang/Class;)La/AZ;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    check-cast v1, La/WM;

    .line 104
    .line 105
    iget-object v1, v1, La/WM;->L:La/a1;

    .line 106
    .line 107
    invoke-virtual {v1}, La/a1;->O()I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    const/4 v4, 0x0

    .line 112
    if-gtz v3, :cond_3

    .line 113
    .line 114
    iput-boolean v0, v2, La/zr;->Y:Z

    .line 115
    .line 116
    iget-object v1, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 117
    .line 118
    invoke-virtual {v1, v0}, La/dh;->l(Z)V

    .line 119
    .line 120
    .line 121
    iput-object v4, v2, La/zr;->c:Landroid/view/ViewGroup;

    .line 122
    .line 123
    iput-object v4, v2, La/zr;->B:Landroid/view/View;

    .line 124
    .line 125
    iput-object v4, v2, La/zr;->rC:La/NT;

    .line 126
    .line 127
    iget-object v1, v2, La/zr;->p7:La/bc;

    .line 128
    .line 129
    invoke-virtual {v1, v4}, La/bc;->I(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    iput-boolean v0, v2, La/zr;->P:Z

    .line 133
    .line 134
    return-void

    .line 135
    :cond_3
    invoke-virtual {v1, v0}, La/a1;->V(I)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v0}, La/zq;->R(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    throw v4

    .line 143
    :cond_4
    new-instance v0, La/ME;

    .line 144
    .line 145
    new-instance v1, Ljava/lang/StringBuilder;

    .line 146
    .line 147
    const-string v3, "Fragment "

    .line 148
    .line 149
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    const-string v2, " did not call through to super.onDestroyView()"

    .line 156
    .line 157
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    throw v0
.end method

.method public final Q()V
    .locals 10

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 2
    .line 3
    iget-boolean v1, v0, La/zr;->z:Z

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    const-string v1, "FragmentManager"

    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_1

    .line 16
    .line 17
    new-instance v3, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v4, "moveto CREATE_VIEW: "

    .line 20
    .line 21
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    :cond_1
    iget-object v3, v0, La/zr;->K:Landroid/os/Bundle;

    .line 35
    .line 36
    const-string v4, "savedInstanceState"

    .line 37
    .line 38
    const/4 v5, 0x0

    .line 39
    if-eqz v3, :cond_2

    .line 40
    .line 41
    invoke-virtual {v3, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    goto :goto_0

    .line 46
    :cond_2
    move-object v3, v5

    .line 47
    :goto_0
    invoke-virtual {v0, v3}, La/zr;->v(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    iget-object v7, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 52
    .line 53
    if-eqz v7, :cond_3

    .line 54
    .line 55
    goto/16 :goto_2

    .line 56
    .line 57
    :cond_3
    iget v7, v0, La/zr;->t:I

    .line 58
    .line 59
    if-eqz v7, :cond_8

    .line 60
    .line 61
    const/4 v8, -0x1

    .line 62
    if-eq v7, v8, :cond_7

    .line 63
    .line 64
    iget-object v8, v0, La/zr;->U:La/ef;

    .line 65
    .line 66
    iget-object v8, v8, La/ef;->q:La/Yo;

    .line 67
    .line 68
    invoke-virtual {v8, v7}, La/Yo;->S(I)Landroid/view/View;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    check-cast v7, Landroid/view/ViewGroup;

    .line 73
    .line 74
    if-nez v7, :cond_5

    .line 75
    .line 76
    iget-boolean v8, v0, La/zr;->D:Z

    .line 77
    .line 78
    if-eqz v8, :cond_4

    .line 79
    .line 80
    goto :goto_2

    .line 81
    :cond_4
    :try_start_0
    invoke-virtual {v0}, La/zr;->f()Landroid/content/res/Resources;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    iget v2, v0, La/zr;->t:I

    .line 86
    .line 87
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 91
    goto :goto_1

    .line 92
    :catch_0
    const-string v1, "unknown"

    .line 93
    .line 94
    :goto_1
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 95
    .line 96
    new-instance v3, Ljava/lang/StringBuilder;

    .line 97
    .line 98
    const-string v4, "No view found for id 0x"

    .line 99
    .line 100
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    iget v4, v0, La/zr;->t:I

    .line 104
    .line 105
    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    const-string v4, " ("

    .line 113
    .line 114
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    const-string v1, ") for fragment "

    .line 121
    .line 122
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v2

    .line 136
    :cond_5
    instance-of v8, v7, Landroidx/fragment/app/FragmentContainerView;

    .line 137
    .line 138
    if-nez v8, :cond_9

    .line 139
    .line 140
    sget-object v8, La/VN;->w:La/j8;

    .line 141
    .line 142
    new-instance v8, La/ue;

    .line 143
    .line 144
    const/4 v9, 0x1

    .line 145
    invoke-direct {v8, v0, v7, v9}, La/ue;-><init>(La/zr;Landroid/view/ViewGroup;I)V

    .line 146
    .line 147
    .line 148
    invoke-static {v8}, La/VN;->h(La/eK;)V

    .line 149
    .line 150
    .line 151
    invoke-static {v0}, La/VN;->w(La/zr;)La/j8;

    .line 152
    .line 153
    .line 154
    move-result-object v8

    .line 155
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    sget-object v8, La/pZ;->L:La/pZ;

    .line 159
    .line 160
    instance-of v9, v8, Ljava/lang/Void;

    .line 161
    .line 162
    if-nez v9, :cond_6

    .line 163
    .line 164
    goto :goto_2

    .line 165
    :cond_6
    check-cast v8, Ljava/lang/Void;

    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_7
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 169
    .line 170
    new-instance v2, Ljava/lang/StringBuilder;

    .line 171
    .line 172
    const-string v3, "Cannot create fragment "

    .line 173
    .line 174
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    const-string v0, " for a container view with no id"

    .line 181
    .line 182
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    throw v1

    .line 193
    :cond_8
    move-object v7, v5

    .line 194
    :cond_9
    :goto_2
    iput-object v7, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 195
    .line 196
    invoke-virtual {v0, v6, v7, v3}, La/zr;->r(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    .line 197
    .line 198
    .line 199
    iget-object v3, v0, La/zr;->B:Landroid/view/View;

    .line 200
    .line 201
    const/4 v6, 0x2

    .line 202
    if-eqz v3, :cond_10

    .line 203
    .line 204
    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    if-eqz v2, :cond_a

    .line 209
    .line 210
    new-instance v2, Ljava/lang/StringBuilder;

    .line 211
    .line 212
    const-string v3, "moveto VIEW_CREATED: "

    .line 213
    .line 214
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v2

    .line 224
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 225
    .line 226
    .line 227
    :cond_a
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 228
    .line 229
    const/4 v3, 0x0

    .line 230
    invoke-virtual {v2, v3}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    .line 231
    .line 232
    .line 233
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 234
    .line 235
    const v8, 0x7f0900f8

    .line 236
    .line 237
    .line 238
    invoke-virtual {v2, v8, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    if-eqz v7, :cond_b

    .line 242
    .line 243
    invoke-virtual {p0}, Landroidx/fragment/app/w;->h()V

    .line 244
    .line 245
    .line 246
    :cond_b
    iget-boolean v2, v0, La/zr;->C:Z

    .line 247
    .line 248
    if-eqz v2, :cond_c

    .line 249
    .line 250
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 251
    .line 252
    const/16 v7, 0x8

    .line 253
    .line 254
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 255
    .line 256
    .line 257
    :cond_c
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 258
    .line 259
    sget-object v7, La/sI;->w:Ljava/util/WeakHashMap;

    .line 260
    .line 261
    invoke-static {v2}, La/AM;->h(Landroid/view/View;)Z

    .line 262
    .line 263
    .line 264
    move-result v2

    .line 265
    if-eqz v2, :cond_d

    .line 266
    .line 267
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 268
    .line 269
    invoke-static {v2}, La/O6;->p(Landroid/view/View;)V

    .line 270
    .line 271
    .line 272
    goto :goto_3

    .line 273
    :cond_d
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 274
    .line 275
    new-instance v7, La/qj;

    .line 276
    .line 277
    invoke-direct {v7, p0, v2}, La/qj;-><init>(Landroidx/fragment/app/w;Landroid/view/View;)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v2, v7}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 281
    .line 282
    .line 283
    :goto_3
    iget-object v2, v0, La/zr;->K:Landroid/os/Bundle;

    .line 284
    .line 285
    if-eqz v2, :cond_e

    .line 286
    .line 287
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 288
    .line 289
    .line 290
    move-result-object v5

    .line 291
    :cond_e
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 292
    .line 293
    invoke-virtual {v0, v2, v5}, La/zr;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 294
    .line 295
    .line 296
    iget-object v2, v0, La/zr;->v:La/ef;

    .line 297
    .line 298
    invoke-virtual {v2, v6}, La/ef;->l(I)V

    .line 299
    .line 300
    .line 301
    iget-object v2, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 302
    .line 303
    invoke-virtual {v2, v3}, La/dh;->f(Z)V

    .line 304
    .line 305
    .line 306
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 307
    .line 308
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 309
    .line 310
    .line 311
    move-result v2

    .line 312
    iget-object v3, v0, La/zr;->B:Landroid/view/View;

    .line 313
    .line 314
    invoke-virtual {v3}, Landroid/view/View;->getAlpha()F

    .line 315
    .line 316
    .line 317
    move-result v3

    .line 318
    invoke-virtual {v0}, La/zr;->m()La/gI;

    .line 319
    .line 320
    .line 321
    move-result-object v4

    .line 322
    iput v3, v4, La/gI;->T:F

    .line 323
    .line 324
    iget-object v3, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 325
    .line 326
    if-eqz v3, :cond_10

    .line 327
    .line 328
    if-nez v2, :cond_10

    .line 329
    .line 330
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 331
    .line 332
    invoke-virtual {v2}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 333
    .line 334
    .line 335
    move-result-object v2

    .line 336
    if-eqz v2, :cond_f

    .line 337
    .line 338
    invoke-virtual {v0}, La/zr;->m()La/gI;

    .line 339
    .line 340
    .line 341
    move-result-object v3

    .line 342
    iput-object v2, v3, La/gI;->m:Landroid/view/View;

    .line 343
    .line 344
    invoke-static {v1, v6}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 345
    .line 346
    .line 347
    move-result v3

    .line 348
    if-eqz v3, :cond_f

    .line 349
    .line 350
    new-instance v3, Ljava/lang/StringBuilder;

    .line 351
    .line 352
    const-string v4, "requestFocus: Saved focused view "

    .line 353
    .line 354
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 358
    .line 359
    .line 360
    const-string v2, " for Fragment "

    .line 361
    .line 362
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 363
    .line 364
    .line 365
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 366
    .line 367
    .line 368
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 369
    .line 370
    .line 371
    move-result-object v2

    .line 372
    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 373
    .line 374
    .line 375
    :cond_f
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 376
    .line 377
    const/4 v2, 0x0

    .line 378
    invoke-virtual {v1, v2}, Landroid/view/View;->setAlpha(F)V

    .line 379
    .line 380
    .line 381
    :cond_10
    iput v6, v0, La/zr;->X:I

    .line 382
    .line 383
    return-void
.end method

.method public final R()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 2
    .line 3
    iget-object v1, v0, La/zr;->B:Landroid/view/View;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    const-string v1, "FragmentManager"

    .line 9
    .line 10
    const/4 v2, 0x2

    .line 11
    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-eqz v2, :cond_1

    .line 16
    .line 17
    new-instance v2, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v3, "Saving view state for fragment "

    .line 20
    .line 21
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string v3, " with view "

    .line 28
    .line 29
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    iget-object v3, v0, La/zr;->B:Landroid/view/View;

    .line 33
    .line 34
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    :cond_1
    new-instance v1, Landroid/util/SparseArray;

    .line 45
    .line 46
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 47
    .line 48
    .line 49
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 50
    .line 51
    invoke-virtual {v2, v1}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-lez v2, :cond_2

    .line 59
    .line 60
    iput-object v1, v0, La/zr;->R:Landroid/util/SparseArray;

    .line 61
    .line 62
    :cond_2
    new-instance v1, Landroid/os/Bundle;

    .line 63
    .line 64
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 65
    .line 66
    .line 67
    iget-object v2, v0, La/zr;->rC:La/NT;

    .line 68
    .line 69
    iget-object v2, v2, La/NT;->f:La/fj;

    .line 70
    .line 71
    invoke-virtual {v2, v1}, La/fj;->p(Landroid/os/Bundle;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    if-nez v2, :cond_3

    .line 79
    .line 80
    iput-object v1, v0, La/zr;->L:Landroid/os/Bundle;

    .line 81
    .line 82
    :cond_3
    return-void
.end method

.method public final T()V
    .locals 4

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "movefrom RESUMED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 30
    .line 31
    const/4 v1, 0x5

    .line 32
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 33
    .line 34
    .line 35
    iget-object v0, v2, La/zr;->B:Landroid/view/View;

    .line 36
    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    iget-object v0, v2, La/zr;->rC:La/NT;

    .line 40
    .line 41
    sget-object v1, La/cw;->ON_PAUSE:La/cw;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, La/NT;->p(La/cw;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    iget-object v0, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 47
    .line 48
    sget-object v1, La/cw;->ON_PAUSE:La/cw;

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 51
    .line 52
    .line 53
    const/4 v0, 0x6

    .line 54
    iput v0, v2, La/zr;->X:I

    .line 55
    .line 56
    const/4 v0, 0x0

    .line 57
    iput-boolean v0, v2, La/zr;->r:Z

    .line 58
    .line 59
    invoke-virtual {v2}, La/zr;->j()V

    .line 60
    .line 61
    .line 62
    iget-boolean v1, v2, La/zr;->r:Z

    .line 63
    .line 64
    if-eqz v1, :cond_2

    .line 65
    .line 66
    iget-object v1, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 67
    .line 68
    invoke-virtual {v1, v0}, La/dh;->T(Z)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_2
    new-instance v0, La/ME;

    .line 73
    .line 74
    new-instance v1, Ljava/lang/StringBuilder;

    .line 75
    .line 76
    const-string v3, "Fragment "

    .line 77
    .line 78
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    const-string v2, " did not call through to super.onPause()"

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    throw v0
.end method

.method public final V()V
    .locals 7

    .line 1
    const-string v0, "FragmentManager"

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    iget-object v3, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    new-instance v2, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v4, "movefrom ATTACHED: "

    .line 15
    .line 16
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    const/4 v2, -0x1

    .line 30
    iput v2, v3, La/zr;->X:I

    .line 31
    .line 32
    const/4 v4, 0x0

    .line 33
    iput-boolean v4, v3, La/zr;->r:Z

    .line 34
    .line 35
    invoke-virtual {v3}, La/zr;->k()V

    .line 36
    .line 37
    .line 38
    iget-boolean v5, v3, La/zr;->r:Z

    .line 39
    .line 40
    if-eqz v5, :cond_7

    .line 41
    .line 42
    iget-object v5, v3, La/zr;->v:La/ef;

    .line 43
    .line 44
    iget-boolean v6, v5, La/ef;->v:Z

    .line 45
    .line 46
    if-nez v6, :cond_1

    .line 47
    .line 48
    invoke-virtual {v5}, La/ef;->M()V

    .line 49
    .line 50
    .line 51
    new-instance v5, La/ef;

    .line 52
    .line 53
    invoke-direct {v5}, La/ef;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object v5, v3, La/zr;->v:La/ef;

    .line 57
    .line 58
    :cond_1
    iget-object v5, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 59
    .line 60
    invoke-virtual {v5, v4}, La/dh;->M(Z)V

    .line 61
    .line 62
    .line 63
    iput v2, v3, La/zr;->X:I

    .line 64
    .line 65
    const/4 v2, 0x0

    .line 66
    iput-object v2, v3, La/zr;->k:La/Tz;

    .line 67
    .line 68
    iput-object v2, v3, La/zr;->s:La/zr;

    .line 69
    .line 70
    iput-object v2, v3, La/zr;->U:La/ef;

    .line 71
    .line 72
    iget-boolean v2, v3, La/zr;->S:Z

    .line 73
    .line 74
    if-eqz v2, :cond_2

    .line 75
    .line 76
    invoke-virtual {v3}, La/zr;->H()Z

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    if-nez v2, :cond_2

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_2
    iget-object v2, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 84
    .line 85
    iget-object v2, v2, La/kQ;->i:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v2, La/d5;

    .line 88
    .line 89
    iget-object v4, v2, La/d5;->L:Ljava/util/HashMap;

    .line 90
    .line 91
    iget-object v5, v3, La/zr;->d:Ljava/lang/String;

    .line 92
    .line 93
    invoke-virtual {v4, v5}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    if-nez v4, :cond_3

    .line 98
    .line 99
    goto :goto_0

    .line 100
    :cond_3
    iget-boolean v4, v2, La/d5;->l:Z

    .line 101
    .line 102
    if-eqz v4, :cond_4

    .line 103
    .line 104
    iget-boolean v2, v2, La/d5;->W:Z

    .line 105
    .line 106
    if-eqz v2, :cond_6

    .line 107
    .line 108
    :cond_4
    :goto_0
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_5

    .line 113
    .line 114
    new-instance v1, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    const-string v2, "initState called for fragment: "

    .line 117
    .line 118
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    .line 130
    .line 131
    :cond_5
    invoke-virtual {v3}, La/zr;->F()V

    .line 132
    .line 133
    .line 134
    :cond_6
    return-void

    .line 135
    :cond_7
    new-instance v0, La/ME;

    .line 136
    .line 137
    new-instance v1, Ljava/lang/StringBuilder;

    .line 138
    .line 139
    const-string v2, "Fragment "

    .line 140
    .line 141
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 145
    .line 146
    .line 147
    const-string v2, " did not call through to super.onDetach()"

    .line 148
    .line 149
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw v0
.end method

.method public final X()V
    .locals 9

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "movefrom CREATED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-boolean v0, v2, La/zr;->S:Z

    .line 30
    .line 31
    const/4 v1, 0x1

    .line 32
    const/4 v3, 0x0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-virtual {v2}, La/zr;->H()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    move v0, v1

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    move v0, v3

    .line 44
    :goto_0
    const/4 v4, 0x0

    .line 45
    iget-object v5, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 46
    .line 47
    if-eqz v0, :cond_2

    .line 48
    .line 49
    iget-boolean v6, v2, La/zr;->H:Z

    .line 50
    .line 51
    if-nez v6, :cond_2

    .line 52
    .line 53
    iget-object v6, v2, La/zr;->d:Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {v5, v6, v4}, La/kQ;->l(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 56
    .line 57
    .line 58
    :cond_2
    if-nez v0, :cond_6

    .line 59
    .line 60
    iget-object v6, v5, La/kQ;->i:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v6, La/d5;

    .line 63
    .line 64
    iget-object v7, v6, La/d5;->L:Ljava/util/HashMap;

    .line 65
    .line 66
    iget-object v8, v2, La/zr;->d:Ljava/lang/String;

    .line 67
    .line 68
    invoke-virtual {v7, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v7

    .line 72
    if-nez v7, :cond_3

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_3
    iget-boolean v7, v6, La/d5;->l:Z

    .line 76
    .line 77
    if-eqz v7, :cond_6

    .line 78
    .line 79
    iget-boolean v6, v6, La/d5;->W:Z

    .line 80
    .line 81
    if-eqz v6, :cond_4

    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_4
    iget-object v0, v2, La/zr;->W:Ljava/lang/String;

    .line 85
    .line 86
    if-eqz v0, :cond_5

    .line 87
    .line 88
    invoke-virtual {v5, v0}, La/kQ;->O(Ljava/lang/String;)La/zr;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    if-eqz v0, :cond_5

    .line 93
    .line 94
    iget-boolean v1, v0, La/zr;->g:Z

    .line 95
    .line 96
    if-eqz v1, :cond_5

    .line 97
    .line 98
    iput-object v0, v2, La/zr;->l:La/zr;

    .line 99
    .line 100
    :cond_5
    iput v3, v2, La/zr;->X:I

    .line 101
    .line 102
    goto/16 :goto_4

    .line 103
    .line 104
    :cond_6
    :goto_1
    iget-object v6, v2, La/zr;->k:La/Tz;

    .line 105
    .line 106
    instance-of v7, v6, La/CG;

    .line 107
    .line 108
    if-eqz v7, :cond_7

    .line 109
    .line 110
    iget-object v6, v5, La/kQ;->i:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast v6, La/d5;

    .line 113
    .line 114
    iget-boolean v6, v6, La/d5;->W:Z

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_7
    iget-object v6, v6, La/Tz;->R:Landroid/content/Context;

    .line 118
    .line 119
    instance-of v7, v6, Landroid/app/Activity;

    .line 120
    .line 121
    if-eqz v7, :cond_8

    .line 122
    .line 123
    check-cast v6, Landroid/app/Activity;

    .line 124
    .line 125
    invoke-virtual {v6}, Landroid/app/Activity;->isChangingConfigurations()Z

    .line 126
    .line 127
    .line 128
    move-result v6

    .line 129
    xor-int/2addr v6, v1

    .line 130
    goto :goto_2

    .line 131
    :cond_8
    move v6, v1

    .line 132
    :goto_2
    if-eqz v0, :cond_9

    .line 133
    .line 134
    iget-boolean v0, v2, La/zr;->H:Z

    .line 135
    .line 136
    if-eqz v0, :cond_a

    .line 137
    .line 138
    :cond_9
    if-eqz v6, :cond_b

    .line 139
    .line 140
    :cond_a
    iget-object v0, v5, La/kQ;->i:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v0, La/d5;

    .line 143
    .line 144
    invoke-virtual {v0, v2, v3}, La/d5;->V(La/zr;Z)V

    .line 145
    .line 146
    .line 147
    :cond_b
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 148
    .line 149
    invoke-virtual {v0}, La/ef;->M()V

    .line 150
    .line 151
    .line 152
    iget-object v0, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 153
    .line 154
    sget-object v6, La/cw;->ON_DESTROY:La/cw;

    .line 155
    .line 156
    invoke-virtual {v0, v6}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 157
    .line 158
    .line 159
    iput v3, v2, La/zr;->X:I

    .line 160
    .line 161
    iput-boolean v3, v2, La/zr;->G:Z

    .line 162
    .line 163
    iput-boolean v1, v2, La/zr;->r:Z

    .line 164
    .line 165
    iget-object v0, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 166
    .line 167
    invoke-virtual {v0, v3}, La/dh;->O(Z)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v5}, La/kQ;->M()Ljava/util/ArrayList;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    :cond_c
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    if-eqz v1, :cond_d

    .line 183
    .line 184
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    check-cast v1, Landroidx/fragment/app/w;

    .line 189
    .line 190
    if-eqz v1, :cond_c

    .line 191
    .line 192
    iget-object v3, v2, La/zr;->d:Ljava/lang/String;

    .line 193
    .line 194
    iget-object v1, v1, Landroidx/fragment/app/w;->p:La/zr;

    .line 195
    .line 196
    iget-object v6, v1, La/zr;->W:Ljava/lang/String;

    .line 197
    .line 198
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    move-result v3

    .line 202
    if-eqz v3, :cond_c

    .line 203
    .line 204
    iput-object v2, v1, La/zr;->l:La/zr;

    .line 205
    .line 206
    iput-object v4, v1, La/zr;->W:Ljava/lang/String;

    .line 207
    .line 208
    goto :goto_3

    .line 209
    :cond_d
    iget-object v0, v2, La/zr;->W:Ljava/lang/String;

    .line 210
    .line 211
    if-eqz v0, :cond_e

    .line 212
    .line 213
    invoke-virtual {v5, v0}, La/kQ;->O(Ljava/lang/String;)La/zr;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    iput-object v0, v2, La/zr;->l:La/zr;

    .line 218
    .line 219
    :cond_e
    invoke-virtual {v5, p0}, La/kQ;->d(Landroidx/fragment/app/w;)V

    .line 220
    .line 221
    .line 222
    :goto_4
    return-void
.end method

.method public final d()V
    .locals 4

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "movefrom STARTED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 30
    .line 31
    const/4 v1, 0x1

    .line 32
    iput-boolean v1, v0, La/ef;->k:Z

    .line 33
    .line 34
    iget-object v3, v0, La/ef;->C:La/d5;

    .line 35
    .line 36
    iput-boolean v1, v3, La/d5;->q:Z

    .line 37
    .line 38
    const/4 v1, 0x4

    .line 39
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 40
    .line 41
    .line 42
    iget-object v0, v2, La/zr;->B:Landroid/view/View;

    .line 43
    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    iget-object v0, v2, La/zr;->rC:La/NT;

    .line 47
    .line 48
    sget-object v3, La/cw;->ON_STOP:La/cw;

    .line 49
    .line 50
    invoke-virtual {v0, v3}, La/NT;->p(La/cw;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    iget-object v0, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 54
    .line 55
    sget-object v3, La/cw;->ON_STOP:La/cw;

    .line 56
    .line 57
    invoke-virtual {v0, v3}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 58
    .line 59
    .line 60
    iput v1, v2, La/zr;->X:I

    .line 61
    .line 62
    const/4 v0, 0x0

    .line 63
    iput-boolean v0, v2, La/zr;->r:Z

    .line 64
    .line 65
    invoke-virtual {v2}, La/zr;->x()V

    .line 66
    .line 67
    .line 68
    iget-boolean v1, v2, La/zr;->r:Z

    .line 69
    .line 70
    if-eqz v1, :cond_2

    .line 71
    .line 72
    iget-object v1, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 73
    .line 74
    invoke-virtual {v1, v0}, La/dh;->d(Z)V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_2
    new-instance v0, La/ME;

    .line 79
    .line 80
    new-instance v1, Ljava/lang/StringBuilder;

    .line 81
    .line 82
    const-string v3, "Fragment "

    .line 83
    .line 84
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    const-string v2, " did not call through to super.onStop()"

    .line 91
    .line 92
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    throw v0
.end method

.method public final e()I
    .locals 14

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 2
    .line 3
    iget-object v1, v0, La/zr;->U:La/ef;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    iget v0, v0, La/zr;->X:I

    .line 8
    .line 9
    return v0

    .line 10
    :cond_0
    iget v1, p0, Landroidx/fragment/app/w;->i:I

    .line 11
    .line 12
    iget-object v2, v0, La/zr;->FL:La/m2;

    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/4 v3, 0x2

    .line 19
    const/4 v4, 0x3

    .line 20
    const/4 v5, 0x0

    .line 21
    const/4 v6, 0x5

    .line 22
    const/4 v7, -0x1

    .line 23
    const/4 v8, 0x4

    .line 24
    const/4 v9, 0x1

    .line 25
    if-eq v2, v9, :cond_3

    .line 26
    .line 27
    if-eq v2, v3, :cond_2

    .line 28
    .line 29
    if-eq v2, v4, :cond_1

    .line 30
    .line 31
    if-eq v2, v8, :cond_4

    .line 32
    .line 33
    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    goto :goto_0

    .line 38
    :cond_1
    invoke-static {v1, v6}, Ljava/lang/Math;->min(II)I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    goto :goto_0

    .line 43
    :cond_2
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    goto :goto_0

    .line 48
    :cond_3
    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    :cond_4
    :goto_0
    iget-boolean v2, v0, La/zr;->z:Z

    .line 53
    .line 54
    if-eqz v2, :cond_7

    .line 55
    .line 56
    iget-boolean v2, v0, La/zr;->P:Z

    .line 57
    .line 58
    if-eqz v2, :cond_5

    .line 59
    .line 60
    iget v1, p0, Landroidx/fragment/app/w;->i:I

    .line 61
    .line 62
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    iget-object v2, v0, La/zr;->B:Landroid/view/View;

    .line 67
    .line 68
    if-eqz v2, :cond_7

    .line 69
    .line 70
    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    if-nez v2, :cond_7

    .line 75
    .line 76
    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    goto :goto_1

    .line 81
    :cond_5
    iget v2, p0, Landroidx/fragment/app/w;->i:I

    .line 82
    .line 83
    if-ge v2, v8, :cond_6

    .line 84
    .line 85
    iget v2, v0, La/zr;->X:I

    .line 86
    .line 87
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    goto :goto_1

    .line 92
    :cond_6
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    :cond_7
    :goto_1
    iget-boolean v2, v0, La/zr;->E:Z

    .line 97
    .line 98
    if-nez v2, :cond_8

    .line 99
    .line 100
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    :cond_8
    iget-object v2, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 105
    .line 106
    if-eqz v2, :cond_f

    .line 107
    .line 108
    invoke-virtual {v0}, La/zr;->d()La/ef;

    .line 109
    .line 110
    .line 111
    move-result-object v10

    .line 112
    invoke-virtual {v10}, La/ef;->k()La/XD;

    .line 113
    .line 114
    .line 115
    const v10, 0x7f090226

    .line 116
    .line 117
    .line 118
    invoke-virtual {v2, v10}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v11

    .line 122
    instance-of v12, v11, La/lp;

    .line 123
    .line 124
    if-eqz v12, :cond_9

    .line 125
    .line 126
    check-cast v11, La/lp;

    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_9
    new-instance v11, La/lp;

    .line 130
    .line 131
    invoke-direct {v11, v2}, La/lp;-><init>(Landroid/view/ViewGroup;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v2, v10, v11}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :goto_2
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v11, v0}, La/lp;->Q(La/zr;)La/Ra;

    .line 141
    .line 142
    .line 143
    move-result-object v2

    .line 144
    if-eqz v2, :cond_a

    .line 145
    .line 146
    iget v2, v2, La/Ra;->h:I

    .line 147
    .line 148
    goto :goto_3

    .line 149
    :cond_a
    move v2, v5

    .line 150
    :goto_3
    iget-object v10, v11, La/lp;->p:Ljava/util/ArrayList;

    .line 151
    .line 152
    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 153
    .line 154
    .line 155
    move-result-object v10

    .line 156
    :cond_b
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 157
    .line 158
    .line 159
    move-result v11

    .line 160
    if-eqz v11, :cond_c

    .line 161
    .line 162
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v11

    .line 166
    move-object v12, v11

    .line 167
    check-cast v12, La/Ra;

    .line 168
    .line 169
    iget-object v13, v12, La/Ra;->p:La/zr;

    .line 170
    .line 171
    invoke-static {v13, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v13

    .line 175
    if-eqz v13, :cond_b

    .line 176
    .line 177
    iget-boolean v12, v12, La/Ra;->Q:Z

    .line 178
    .line 179
    if-nez v12, :cond_b

    .line 180
    .line 181
    goto :goto_4

    .line 182
    :cond_c
    const/4 v11, 0x0

    .line 183
    :goto_4
    check-cast v11, La/Ra;

    .line 184
    .line 185
    if-eqz v11, :cond_d

    .line 186
    .line 187
    iget v5, v11, La/Ra;->h:I

    .line 188
    .line 189
    :cond_d
    if-nez v2, :cond_e

    .line 190
    .line 191
    move v10, v7

    .line 192
    goto :goto_5

    .line 193
    :cond_e
    sget-object v10, La/yI;->w:[I

    .line 194
    .line 195
    invoke-static {v2}, La/zq;->F(I)I

    .line 196
    .line 197
    .line 198
    move-result v11

    .line 199
    aget v10, v10, v11

    .line 200
    .line 201
    :goto_5
    if-eq v10, v7, :cond_f

    .line 202
    .line 203
    if-eq v10, v9, :cond_f

    .line 204
    .line 205
    move v5, v2

    .line 206
    :cond_f
    if-ne v5, v3, :cond_10

    .line 207
    .line 208
    const/4 v2, 0x6

    .line 209
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 210
    .line 211
    .line 212
    move-result v1

    .line 213
    goto :goto_6

    .line 214
    :cond_10
    if-ne v5, v4, :cond_11

    .line 215
    .line 216
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    goto :goto_6

    .line 221
    :cond_11
    iget-boolean v2, v0, La/zr;->S:Z

    .line 222
    .line 223
    if-eqz v2, :cond_13

    .line 224
    .line 225
    invoke-virtual {v0}, La/zr;->H()Z

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    if-eqz v2, :cond_12

    .line 230
    .line 231
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    .line 232
    .line 233
    .line 234
    move-result v1

    .line 235
    goto :goto_6

    .line 236
    :cond_12
    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    .line 237
    .line 238
    .line 239
    move-result v1

    .line 240
    :cond_13
    :goto_6
    iget-boolean v2, v0, La/zr;->Z:Z

    .line 241
    .line 242
    if-eqz v2, :cond_14

    .line 243
    .line 244
    iget v2, v0, La/zr;->X:I

    .line 245
    .line 246
    if-ge v2, v6, :cond_14

    .line 247
    .line 248
    invoke-static {v1, v8}, Ljava/lang/Math;->min(II)I

    .line 249
    .line 250
    .line 251
    move-result v1

    .line 252
    :cond_14
    const-string v2, "FragmentManager"

    .line 253
    .line 254
    invoke-static {v2, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 255
    .line 256
    .line 257
    move-result v3

    .line 258
    if-eqz v3, :cond_15

    .line 259
    .line 260
    new-instance v3, Ljava/lang/StringBuilder;

    .line 261
    .line 262
    const-string v4, "computeExpectedState() of "

    .line 263
    .line 264
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 268
    .line 269
    .line 270
    const-string v4, " for "

    .line 271
    .line 272
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 273
    .line 274
    .line 275
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    invoke-static {v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 283
    .line 284
    .line 285
    :cond_15
    return v1
.end method

.method public final h()V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 2
    .line 3
    iget-object v1, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 4
    .line 5
    :goto_0
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_3

    .line 7
    .line 8
    const v3, 0x7f0900f8

    .line 9
    .line 10
    .line 11
    invoke-virtual {v1, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    instance-of v4, v3, La/zr;

    .line 16
    .line 17
    if-eqz v4, :cond_0

    .line 18
    .line 19
    check-cast v3, La/zr;

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_0
    move-object v3, v2

    .line 23
    :goto_1
    if-eqz v3, :cond_1

    .line 24
    .line 25
    move-object v2, v3

    .line 26
    goto :goto_2

    .line 27
    :cond_1
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    instance-of v3, v1, Landroid/view/View;

    .line 32
    .line 33
    if-eqz v3, :cond_2

    .line 34
    .line 35
    check-cast v1, Landroid/view/View;

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_2
    move-object v1, v2

    .line 39
    goto :goto_0

    .line 40
    :cond_3
    :goto_2
    iget-object v1, v0, La/zr;->s:La/zr;

    .line 41
    .line 42
    if-eqz v2, :cond_5

    .line 43
    .line 44
    invoke-virtual {v2, v1}, La/zr;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-nez v1, :cond_5

    .line 49
    .line 50
    iget v1, v0, La/zr;->t:I

    .line 51
    .line 52
    sget-object v3, La/VN;->w:La/j8;

    .line 53
    .line 54
    new-instance v3, La/ue;

    .line 55
    .line 56
    new-instance v4, Ljava/lang/StringBuilder;

    .line 57
    .line 58
    const-string v5, "Attempting to nest fragment "

    .line 59
    .line 60
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    const-string v5, " within the view of parent fragment "

    .line 67
    .line 68
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    const-string v2, " via container with ID "

    .line 75
    .line 76
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const-string v1, " without using parent\'s childFragmentManager"

    .line 83
    .line 84
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-direct {v3, v0, v1}, La/eK;-><init>(La/zr;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    invoke-static {v3}, La/VN;->h(La/eK;)V

    .line 95
    .line 96
    .line 97
    invoke-static {v0}, La/VN;->w(La/zr;)La/j8;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 102
    .line 103
    .line 104
    sget-object v1, La/pZ;->R:La/pZ;

    .line 105
    .line 106
    instance-of v2, v1, Ljava/lang/Void;

    .line 107
    .line 108
    if-nez v2, :cond_4

    .line 109
    .line 110
    goto :goto_3

    .line 111
    :cond_4
    check-cast v1, Ljava/lang/Void;

    .line 112
    .line 113
    :cond_5
    :goto_3
    iget-object v1, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 114
    .line 115
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    .line 117
    .line 118
    iget-object v2, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 119
    .line 120
    const/4 v3, -0x1

    .line 121
    if-nez v2, :cond_6

    .line 122
    .line 123
    goto :goto_6

    .line 124
    :cond_6
    iget-object v4, v1, La/kQ;->e:Ljava/lang/Object;

    .line 125
    .line 126
    check-cast v4, Ljava/util/ArrayList;

    .line 127
    .line 128
    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    .line 129
    .line 130
    .line 131
    move-result v4

    .line 132
    add-int/lit8 v5, v4, -0x1

    .line 133
    .line 134
    :goto_4
    if-ltz v5, :cond_8

    .line 135
    .line 136
    iget-object v6, v1, La/kQ;->e:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v6, Ljava/util/ArrayList;

    .line 139
    .line 140
    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v6

    .line 144
    check-cast v6, La/zr;

    .line 145
    .line 146
    iget-object v7, v6, La/zr;->c:Landroid/view/ViewGroup;

    .line 147
    .line 148
    if-ne v7, v2, :cond_7

    .line 149
    .line 150
    iget-object v6, v6, La/zr;->B:Landroid/view/View;

    .line 151
    .line 152
    if-eqz v6, :cond_7

    .line 153
    .line 154
    invoke-virtual {v2, v6}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    add-int/lit8 v3, v1, 0x1

    .line 159
    .line 160
    goto :goto_6

    .line 161
    :cond_7
    add-int/lit8 v5, v5, -0x1

    .line 162
    .line 163
    goto :goto_4

    .line 164
    :cond_8
    :goto_5
    add-int/lit8 v4, v4, 0x1

    .line 165
    .line 166
    iget-object v5, v1, La/kQ;->e:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v5, Ljava/util/ArrayList;

    .line 169
    .line 170
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 171
    .line 172
    .line 173
    move-result v5

    .line 174
    if-ge v4, v5, :cond_a

    .line 175
    .line 176
    iget-object v5, v1, La/kQ;->e:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v5, Ljava/util/ArrayList;

    .line 179
    .line 180
    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v5

    .line 184
    check-cast v5, La/zr;

    .line 185
    .line 186
    iget-object v6, v5, La/zr;->c:Landroid/view/ViewGroup;

    .line 187
    .line 188
    if-ne v6, v2, :cond_9

    .line 189
    .line 190
    iget-object v5, v5, La/zr;->B:Landroid/view/View;

    .line 191
    .line 192
    if-eqz v5, :cond_9

    .line 193
    .line 194
    invoke-virtual {v2, v5}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 195
    .line 196
    .line 197
    move-result v3

    .line 198
    goto :goto_6

    .line 199
    :cond_9
    goto :goto_5

    .line 200
    :cond_a
    :goto_6
    iget-object v1, v0, La/zr;->c:Landroid/view/ViewGroup;

    .line 201
    .line 202
    iget-object v0, v0, La/zr;->B:Landroid/view/View;

    .line 203
    .line 204
    invoke-virtual {v1, v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 205
    .line 206
    .line 207
    return-void
.end method

.method public final i()V
    .locals 7

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "moveto CREATED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->K:Landroid/os/Bundle;

    .line 30
    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    const-string v1, "savedInstanceState"

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const/4 v0, 0x0

    .line 41
    :goto_0
    iget-boolean v1, v2, La/zr;->G:Z

    .line 42
    .line 43
    const/4 v3, 0x1

    .line 44
    if-nez v1, :cond_3

    .line 45
    .line 46
    iget-object v1, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-virtual {v1, v4}, La/dh;->y(Z)V

    .line 50
    .line 51
    .line 52
    iget-object v5, v2, La/zr;->v:La/ef;

    .line 53
    .line 54
    invoke-virtual {v5}, La/ef;->g()V

    .line 55
    .line 56
    .line 57
    iput v3, v2, La/zr;->X:I

    .line 58
    .line 59
    iput-boolean v4, v2, La/zr;->r:Z

    .line 60
    .line 61
    iget-object v5, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 62
    .line 63
    new-instance v6, Landroidx/fragment/app/Fragment$6;

    .line 64
    .line 65
    invoke-direct {v6, v2}, Landroidx/fragment/app/Fragment$6;-><init>(La/zr;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v5, v6}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v2, v0}, La/zr;->Y(Landroid/os/Bundle;)V

    .line 72
    .line 73
    .line 74
    iput-boolean v3, v2, La/zr;->G:Z

    .line 75
    .line 76
    iget-boolean v0, v2, La/zr;->r:Z

    .line 77
    .line 78
    if-eqz v0, :cond_2

    .line 79
    .line 80
    iget-object v0, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 81
    .line 82
    sget-object v2, La/cw;->ON_CREATE:La/cw;

    .line 83
    .line 84
    invoke-virtual {v0, v2}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1, v4}, La/dh;->e(Z)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_2
    new-instance v0, La/ME;

    .line 92
    .line 93
    new-instance v1, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    const-string v3, "Fragment "

    .line 96
    .line 97
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    const-string v2, " did not call through to super.onCreate()"

    .line 104
    .line 105
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw v0

    .line 116
    :cond_3
    iput v3, v2, La/zr;->X:I

    .line 117
    .line 118
    invoke-virtual {v2}, La/zr;->N()V

    .line 119
    .line 120
    .line 121
    :goto_1
    return-void
.end method

.method public final m(Ljava/lang/ClassLoader;)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/w;->p:La/zr;

    iget-object v1, v0, La/zr;->K:Landroid/os/Bundle;

    if-nez v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {v1, p1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    iget-object p1, v0, La/zr;->K:Landroid/os/Bundle;

    const-string v1, "savedInstanceState"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    if-nez p1, :cond_1

    iget-object p1, v0, La/zr;->K:Landroid/os/Bundle;

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v1, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_1
    iget-object p1, v0, La/zr;->K:Landroid/os/Bundle;

    const-string v1, "viewState"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object p1

    iput-object p1, v0, La/zr;->R:Landroid/util/SparseArray;

    iget-object p1, v0, La/zr;->K:Landroid/os/Bundle;

    const-string v1, "viewRegistryState"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    iput-object p1, v0, La/zr;->L:Landroid/os/Bundle;

    iget-object p1, v0, La/zr;->K:Landroid/os/Bundle;

    const-string v1, "state"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, La/Db;

    if-eqz p1, :cond_2

    iget-object v1, p1, La/Db;->S:Ljava/lang/String;

    iput-object v1, v0, La/zr;->W:Ljava/lang/String;

    iget v1, p1, La/Db;->H:I

    iput v1, v0, La/zr;->q:I

    iget-boolean p1, p1, La/Db;->z:Z

    iput-boolean p1, v0, La/zr;->N:Z

    :cond_2
    iget-boolean p1, v0, La/zr;->N:Z

    if-nez p1, :cond_3

    const/4 p1, 0x1

    iput-boolean p1, v0, La/zr;->Z:Z

    :cond_3
    return-void
.end method

.method public final p()V
    .locals 10

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "moveto ATTACHED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->l:La/zr;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    const-string v3, " that does not belong to this FragmentManager!"

    .line 33
    .line 34
    const-string v4, " declared target fragment "

    .line 35
    .line 36
    iget-object v5, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 37
    .line 38
    const-string v6, "Fragment "

    .line 39
    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    iget-object v0, v0, La/zr;->d:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v5, v5, La/kQ;->h:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v5, Ljava/util/HashMap;

    .line 47
    .line 48
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast v0, Landroidx/fragment/app/w;

    .line 53
    .line 54
    if-eqz v0, :cond_1

    .line 55
    .line 56
    iget-object v3, v2, La/zr;->l:La/zr;

    .line 57
    .line 58
    iget-object v3, v3, La/zr;->d:Ljava/lang/String;

    .line 59
    .line 60
    iput-object v3, v2, La/zr;->W:Ljava/lang/String;

    .line 61
    .line 62
    iput-object v1, v2, La/zr;->l:La/zr;

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 66
    .line 67
    new-instance v1, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    iget-object v2, v2, La/zr;->l:La/zr;

    .line 79
    .line 80
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    throw v0

    .line 94
    :cond_2
    iget-object v0, v2, La/zr;->W:Ljava/lang/String;

    .line 95
    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    iget-object v5, v5, La/kQ;->h:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v5, Ljava/util/HashMap;

    .line 101
    .line 102
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    check-cast v0, Landroidx/fragment/app/w;

    .line 107
    .line 108
    if-eqz v0, :cond_3

    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 112
    .line 113
    new-instance v1, Ljava/lang/StringBuilder;

    .line 114
    .line 115
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    iget-object v2, v2, La/zr;->W:Ljava/lang/String;

    .line 125
    .line 126
    invoke-static {v1, v2, v3}, La/zq;->M(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    throw v0

    .line 134
    :cond_4
    move-object v0, v1

    .line 135
    :goto_0
    if-eqz v0, :cond_5

    .line 136
    .line 137
    invoke-virtual {v0}, Landroidx/fragment/app/w;->M()V

    .line 138
    .line 139
    .line 140
    :cond_5
    iget-object v0, v2, La/zr;->U:La/ef;

    .line 141
    .line 142
    iget-object v3, v0, La/ef;->W:La/Tz;

    .line 143
    .line 144
    iput-object v3, v2, La/zr;->k:La/Tz;

    .line 145
    .line 146
    iget-object v0, v0, La/ef;->F:La/zr;

    .line 147
    .line 148
    iput-object v0, v2, La/zr;->s:La/zr;

    .line 149
    .line 150
    iget-object v0, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 151
    .line 152
    const/4 v3, 0x0

    .line 153
    invoke-virtual {v0, v3}, La/dh;->m(Z)V

    .line 154
    .line 155
    .line 156
    iget-object v4, v2, La/zr;->mh:Ljava/util/ArrayList;

    .line 157
    .line 158
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 159
    .line 160
    .line 161
    move-result-object v5

    .line 162
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 163
    .line 164
    .line 165
    move-result v7

    .line 166
    if-eqz v7, :cond_7

    .line 167
    .line 168
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    check-cast v7, La/w5;

    .line 173
    .line 174
    iget-object v7, v7, La/w5;->w:La/zr;

    .line 175
    .line 176
    iget-object v8, v7, La/zr;->eH:La/fj;

    .line 177
    .line 178
    invoke-virtual {v8}, La/fj;->w()V

    .line 179
    .line 180
    .line 181
    invoke-static {v7}, La/fe;->L(La/vd;)V

    .line 182
    .line 183
    .line 184
    iget-object v8, v7, La/zr;->K:Landroid/os/Bundle;

    .line 185
    .line 186
    if-eqz v8, :cond_6

    .line 187
    .line 188
    const-string v9, "registryState"

    .line 189
    .line 190
    invoke-virtual {v8, v9}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 191
    .line 192
    .line 193
    move-result-object v8

    .line 194
    goto :goto_2

    .line 195
    :cond_6
    move-object v8, v1

    .line 196
    :goto_2
    iget-object v7, v7, La/zr;->eH:La/fj;

    .line 197
    .line 198
    invoke-virtual {v7, v8}, La/fj;->h(Landroid/os/Bundle;)V

    .line 199
    .line 200
    .line 201
    goto :goto_1

    .line 202
    :cond_7
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 203
    .line 204
    .line 205
    iget-object v1, v2, La/zr;->v:La/ef;

    .line 206
    .line 207
    iget-object v4, v2, La/zr;->k:La/Tz;

    .line 208
    .line 209
    invoke-virtual {v2}, La/zr;->T()La/Yo;

    .line 210
    .line 211
    .line 212
    move-result-object v5

    .line 213
    invoke-virtual {v1, v4, v5, v2}, La/ef;->h(La/Tz;La/Yo;La/zr;)V

    .line 214
    .line 215
    .line 216
    iput v3, v2, La/zr;->X:I

    .line 217
    .line 218
    iput-boolean v3, v2, La/zr;->r:Z

    .line 219
    .line 220
    iget-object v1, v2, La/zr;->k:La/Tz;

    .line 221
    .line 222
    iget-object v1, v1, La/Tz;->R:Landroid/content/Context;

    .line 223
    .line 224
    invoke-virtual {v2, v1}, La/zr;->D(Landroid/content/Context;)V

    .line 225
    .line 226
    .line 227
    iget-boolean v1, v2, La/zr;->r:Z

    .line 228
    .line 229
    if-eqz v1, :cond_9

    .line 230
    .line 231
    iget-object v1, v2, La/zr;->U:La/ef;

    .line 232
    .line 233
    iget-object v1, v1, La/ef;->y:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 234
    .line 235
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 240
    .line 241
    .line 242
    move-result v4

    .line 243
    if-eqz v4, :cond_8

    .line 244
    .line 245
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v4

    .line 249
    check-cast v4, La/Ya;

    .line 250
    .line 251
    invoke-interface {v4, v2}, La/Ya;->w(La/zr;)V

    .line 252
    .line 253
    .line 254
    goto :goto_3

    .line 255
    :cond_8
    iget-object v1, v2, La/zr;->v:La/ef;

    .line 256
    .line 257
    iput-boolean v3, v1, La/ef;->U:Z

    .line 258
    .line 259
    iput-boolean v3, v1, La/ef;->k:Z

    .line 260
    .line 261
    iget-object v2, v1, La/ef;->C:La/d5;

    .line 262
    .line 263
    iput-boolean v3, v2, La/d5;->q:Z

    .line 264
    .line 265
    invoke-virtual {v1, v3}, La/ef;->l(I)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {v0, v3}, La/dh;->p(Z)V

    .line 269
    .line 270
    .line 271
    return-void

    .line 272
    :cond_9
    new-instance v0, La/ME;

    .line 273
    .line 274
    new-instance v1, Ljava/lang/StringBuilder;

    .line 275
    .line 276
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 280
    .line 281
    .line 282
    const-string v2, " did not call through to super.onAttach()"

    .line 283
    .line 284
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 285
    .line 286
    .line 287
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    throw v0
.end method

.method public final w()V
    .locals 7

    .line 1
    const-string v0, "FragmentManager"

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    iget-object v3, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    new-instance v2, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v4, "moveto ACTIVITY_CREATED: "

    .line 15
    .line 16
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v2, v3, La/zr;->K:Landroid/os/Bundle;

    .line 30
    .line 31
    const-string v4, "savedInstanceState"

    .line 32
    .line 33
    if-eqz v2, :cond_1

    .line 34
    .line 35
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 36
    .line 37
    .line 38
    :cond_1
    iget-object v2, v3, La/zr;->v:La/ef;

    .line 39
    .line 40
    invoke-virtual {v2}, La/ef;->g()V

    .line 41
    .line 42
    .line 43
    iput v1, v3, La/zr;->X:I

    .line 44
    .line 45
    const/4 v2, 0x0

    .line 46
    iput-boolean v2, v3, La/zr;->r:Z

    .line 47
    .line 48
    invoke-virtual {v3}, La/zr;->z()V

    .line 49
    .line 50
    .line 51
    iget-boolean v5, v3, La/zr;->r:Z

    .line 52
    .line 53
    const-string v6, "Fragment "

    .line 54
    .line 55
    if-eqz v5, :cond_7

    .line 56
    .line 57
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_2

    .line 62
    .line 63
    new-instance v1, Ljava/lang/StringBuilder;

    .line 64
    .line 65
    const-string v5, "moveto RESTORE_VIEW_STATE: "

    .line 66
    .line 67
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    :cond_2
    iget-object v0, v3, La/zr;->B:Landroid/view/View;

    .line 81
    .line 82
    const/4 v1, 0x0

    .line 83
    if-eqz v0, :cond_6

    .line 84
    .line 85
    iget-object v0, v3, La/zr;->K:Landroid/os/Bundle;

    .line 86
    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    invoke-virtual {v0, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    goto :goto_0

    .line 94
    :cond_3
    move-object v0, v1

    .line 95
    :goto_0
    iget-object v4, v3, La/zr;->R:Landroid/util/SparseArray;

    .line 96
    .line 97
    if-eqz v4, :cond_4

    .line 98
    .line 99
    iget-object v5, v3, La/zr;->B:Landroid/view/View;

    .line 100
    .line 101
    invoke-virtual {v5, v4}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    .line 102
    .line 103
    .line 104
    iput-object v1, v3, La/zr;->R:Landroid/util/SparseArray;

    .line 105
    .line 106
    :cond_4
    iput-boolean v2, v3, La/zr;->r:Z

    .line 107
    .line 108
    invoke-virtual {v3, v0}, La/zr;->o(Landroid/os/Bundle;)V

    .line 109
    .line 110
    .line 111
    iget-boolean v0, v3, La/zr;->r:Z

    .line 112
    .line 113
    if-eqz v0, :cond_5

    .line 114
    .line 115
    iget-object v0, v3, La/zr;->B:Landroid/view/View;

    .line 116
    .line 117
    if-eqz v0, :cond_6

    .line 118
    .line 119
    iget-object v0, v3, La/zr;->rC:La/NT;

    .line 120
    .line 121
    sget-object v4, La/cw;->ON_CREATE:La/cw;

    .line 122
    .line 123
    invoke-virtual {v0, v4}, La/NT;->p(La/cw;)V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_5
    new-instance v0, La/ME;

    .line 128
    .line 129
    new-instance v1, Ljava/lang/StringBuilder;

    .line 130
    .line 131
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 135
    .line 136
    .line 137
    const-string v2, " did not call through to super.onViewStateRestored()"

    .line 138
    .line 139
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw v0

    .line 150
    :cond_6
    :goto_1
    iput-object v1, v3, La/zr;->K:Landroid/os/Bundle;

    .line 151
    .line 152
    iget-object v0, v3, La/zr;->v:La/ef;

    .line 153
    .line 154
    iput-boolean v2, v0, La/ef;->U:Z

    .line 155
    .line 156
    iput-boolean v2, v0, La/ef;->k:Z

    .line 157
    .line 158
    iget-object v1, v0, La/ef;->C:La/d5;

    .line 159
    .line 160
    iput-boolean v2, v1, La/d5;->q:Z

    .line 161
    .line 162
    const/4 v1, 0x4

    .line 163
    invoke-virtual {v0, v1}, La/ef;->l(I)V

    .line 164
    .line 165
    .line 166
    iget-object v0, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 167
    .line 168
    invoke-virtual {v0, v2}, La/dh;->h(Z)V

    .line 169
    .line 170
    .line 171
    return-void

    .line 172
    :cond_7
    new-instance v0, La/ME;

    .line 173
    .line 174
    new-instance v1, Ljava/lang/StringBuilder;

    .line 175
    .line 176
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    const-string v2, " did not call through to super.onActivityCreated()"

    .line 183
    .line 184
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    throw v0
.end method

.method public final y()V
    .locals 7

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "FragmentManager"

    .line 3
    .line 4
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v2, p0, Landroidx/fragment/app/w;->p:La/zr;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v3, "moveto RESUMED: "

    .line 15
    .line 16
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, v2, La/zr;->b:La/gI;

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    move-object v0, v3

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    iget-object v0, v0, La/gI;->m:Landroid/view/View;

    .line 37
    .line 38
    :goto_0
    if-eqz v0, :cond_5

    .line 39
    .line 40
    iget-object v4, v2, La/zr;->B:Landroid/view/View;

    .line 41
    .line 42
    if-ne v0, v4, :cond_2

    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    :goto_1
    if-eqz v4, :cond_5

    .line 50
    .line 51
    iget-object v5, v2, La/zr;->B:Landroid/view/View;

    .line 52
    .line 53
    if-ne v4, v5, :cond_4

    .line 54
    .line 55
    :goto_2
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 56
    .line 57
    .line 58
    move-result v4

    .line 59
    const/4 v5, 0x2

    .line 60
    invoke-static {v1, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    if-eqz v5, :cond_5

    .line 65
    .line 66
    new-instance v5, Ljava/lang/StringBuilder;

    .line 67
    .line 68
    const-string v6, "requestFocus: Restoring focused view "

    .line 69
    .line 70
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v0, " "

    .line 77
    .line 78
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    if-eqz v4, :cond_3

    .line 82
    .line 83
    const-string v0, "succeeded"

    .line 84
    .line 85
    goto :goto_3

    .line 86
    :cond_3
    const-string v0, "failed"

    .line 87
    .line 88
    :goto_3
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    const-string v0, " on Fragment "

    .line 92
    .line 93
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    const-string v0, " resulting in focused view "

    .line 100
    .line 101
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    iget-object v0, v2, La/zr;->B:Landroid/view/View;

    .line 105
    .line 106
    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 118
    .line 119
    .line 120
    goto :goto_4

    .line 121
    :cond_4
    invoke-interface {v4}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 122
    .line 123
    .line 124
    move-result-object v4

    .line 125
    goto :goto_1

    .line 126
    :cond_5
    :goto_4
    invoke-virtual {v2}, La/zr;->m()La/gI;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    iput-object v3, v0, La/gI;->m:Landroid/view/View;

    .line 131
    .line 132
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 133
    .line 134
    invoke-virtual {v0}, La/ef;->g()V

    .line 135
    .line 136
    .line 137
    iget-object v0, v2, La/zr;->v:La/ef;

    .line 138
    .line 139
    const/4 v1, 0x1

    .line 140
    invoke-virtual {v0, v1}, La/ef;->E(Z)Z

    .line 141
    .line 142
    .line 143
    const/4 v0, 0x7

    .line 144
    iput v0, v2, La/zr;->X:I

    .line 145
    .line 146
    const/4 v1, 0x0

    .line 147
    iput-boolean v1, v2, La/zr;->r:Z

    .line 148
    .line 149
    invoke-virtual {v2}, La/zr;->t()V

    .line 150
    .line 151
    .line 152
    iget-boolean v4, v2, La/zr;->r:Z

    .line 153
    .line 154
    if-eqz v4, :cond_7

    .line 155
    .line 156
    iget-object v4, v2, La/zr;->rV:Landroidx/lifecycle/w;

    .line 157
    .line 158
    sget-object v5, La/cw;->ON_RESUME:La/cw;

    .line 159
    .line 160
    invoke-virtual {v4, v5}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 161
    .line 162
    .line 163
    iget-object v4, v2, La/zr;->B:Landroid/view/View;

    .line 164
    .line 165
    if-eqz v4, :cond_6

    .line 166
    .line 167
    iget-object v4, v2, La/zr;->rC:La/NT;

    .line 168
    .line 169
    invoke-virtual {v4, v5}, La/NT;->p(La/cw;)V

    .line 170
    .line 171
    .line 172
    :cond_6
    iget-object v4, v2, La/zr;->v:La/ef;

    .line 173
    .line 174
    iput-boolean v1, v4, La/ef;->U:Z

    .line 175
    .line 176
    iput-boolean v1, v4, La/ef;->k:Z

    .line 177
    .line 178
    iget-object v5, v4, La/ef;->C:La/d5;

    .line 179
    .line 180
    iput-boolean v1, v5, La/d5;->q:Z

    .line 181
    .line 182
    invoke-virtual {v4, v0}, La/ef;->l(I)V

    .line 183
    .line 184
    .line 185
    iget-object v0, p0, Landroidx/fragment/app/w;->w:La/dh;

    .line 186
    .line 187
    invoke-virtual {v0, v1}, La/dh;->K(Z)V

    .line 188
    .line 189
    .line 190
    iget-object v0, p0, Landroidx/fragment/app/w;->h:La/kQ;

    .line 191
    .line 192
    iget-object v1, v2, La/zr;->d:Ljava/lang/String;

    .line 193
    .line 194
    invoke-virtual {v0, v1, v3}, La/kQ;->l(Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 195
    .line 196
    .line 197
    iput-object v3, v2, La/zr;->K:Landroid/os/Bundle;

    .line 198
    .line 199
    iput-object v3, v2, La/zr;->R:Landroid/util/SparseArray;

    .line 200
    .line 201
    iput-object v3, v2, La/zr;->L:Landroid/os/Bundle;

    .line 202
    .line 203
    return-void

    .line 204
    :cond_7
    new-instance v0, La/ME;

    .line 205
    .line 206
    new-instance v1, Ljava/lang/StringBuilder;

    .line 207
    .line 208
    const-string v3, "Fragment "

    .line 209
    .line 210
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    const-string v2, " did not call through to super.onResume()"

    .line 217
    .line 218
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    .line 220
    .line 221
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    throw v0
.end method
