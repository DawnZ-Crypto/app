.class public interface abstract La/gk;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final O:La/H;

.field public static final Q:La/H;

.field public static final e:La/H;

.field public static final h:La/H;

.field public static final i:La/H;

.field public static final p:La/H;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    sget-object v0, La/Nj;->l:La/H;

    .line 2
    .line 3
    sput-object v0, La/gk;->h:La/H;

    .line 4
    .line 5
    sget-object v0, La/Nj;->W:La/H;

    .line 6
    .line 7
    sput-object v0, La/gk;->p:La/H;

    .line 8
    .line 9
    new-instance v0, La/H;

    .line 10
    .line 11
    const-string v1, "1.3.6.1.5.5.7.16"

    .line 12
    .line 13
    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v1, La/H;

    .line 17
    .line 18
    const-string v2, "2"

    .line 19
    .line 20
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    new-instance v1, La/H;

    .line 24
    .line 25
    const-string v2, "4"

    .line 26
    .line 27
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    new-instance v0, La/H;

    .line 31
    .line 32
    const-string v1, "1.3.6.1.5.5.7.6"

    .line 33
    .line 34
    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    new-instance v1, La/H;

    .line 38
    .line 39
    const-string v2, "30"

    .line 40
    .line 41
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sput-object v1, La/gk;->e:La/H;

    .line 45
    .line 46
    new-instance v1, La/H;

    .line 47
    .line 48
    const-string v2, "31"

    .line 49
    .line 50
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    sput-object v1, La/gk;->i:La/H;

    .line 54
    .line 55
    new-instance v1, La/H;

    .line 56
    .line 57
    const-string v2, "32"

    .line 58
    .line 59
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    sput-object v1, La/gk;->Q:La/H;

    .line 63
    .line 64
    new-instance v1, La/H;

    .line 65
    .line 66
    const-string v2, "33"

    .line 67
    .line 68
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    sput-object v1, La/gk;->O:La/H;

    .line 72
    .line 73
    new-instance v0, La/H;

    .line 74
    .line 75
    const-string v1, "1.2.840.113549.1.9.16.13"

    .line 76
    .line 77
    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    new-instance v1, La/H;

    .line 81
    .line 82
    const-string v2, "3"

    .line 83
    .line 84
    invoke-direct {v1, v0, v2}, La/H;-><init>(La/H;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    return-void
.end method
