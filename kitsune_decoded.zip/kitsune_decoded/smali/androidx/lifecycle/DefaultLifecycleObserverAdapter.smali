.class public final Landroidx/lifecycle/DefaultLifecycleObserverAdapter;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final K:La/dr;

.field public final X:La/no;


# direct methods
.method public constructor <init>(La/no;La/dr;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->X:La/no;

    iput-object p2, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->K:La/dr;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 2

    .line 1
    sget-object v0, La/On;->w:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    iget-object v1, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->X:La/no;

    packed-switch v0, :pswitch_data_0

    goto :goto_0

    :pswitch_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "ON_ANY must not been send by anybody"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_1
    invoke-interface {v1}, La/no;->X()V

    goto :goto_0

    :pswitch_2
    invoke-interface {v1}, La/no;->e()V

    goto :goto_0

    :pswitch_3
    invoke-interface {v1}, La/no;->i()V

    goto :goto_0

    :pswitch_4
    invoke-interface {v1}, La/no;->h()V

    goto :goto_0

    :pswitch_5
    invoke-interface {v1}, La/no;->p()V

    goto :goto_0

    :pswitch_6
    invoke-interface {v1}, La/no;->w()V

    :goto_0
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->K:La/dr;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1, p2}, La/dr;->Q(La/RH;La/cw;)V

    :cond_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
