.class public final La/sG;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .locals 8

    .line 1
    iget v0, p1, Landroid/os/Message;->what:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    if-eqz v0, :cond_5

    .line 7
    .line 8
    if-eq v0, v2, :cond_0

    .line 9
    .line 10
    return v3

    .line 11
    :cond_0
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, La/sl;

    .line 14
    .line 15
    iget p1, p1, Landroid/os/Message;->arg1:I

    .line 16
    .line 17
    iget-object v4, v0, La/sl;->W:Landroid/view/accessibility/AccessibilityManager;

    .line 18
    .line 19
    if-nez v4, :cond_1

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_1
    invoke-virtual {v4, v2}, Landroid/view/accessibility/AccessibilityManager;->getEnabledAccessibilityServiceList(I)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    if-eqz v4, :cond_4

    .line 27
    .line 28
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_4

    .line 33
    .line 34
    :goto_0
    iget-object v4, v0, La/sl;->V:Lcom/google/android/material/snackbar/Snackbar$SnackbarLayout;

    .line 35
    .line 36
    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    .line 37
    .line 38
    .line 39
    move-result v5

    .line 40
    if-nez v5, :cond_4

    .line 41
    .line 42
    iget v5, v4, Lcom/google/android/material/snackbar/Snackbar$SnackbarLayout;->L:I

    .line 43
    .line 44
    if-ne v5, v2, :cond_2

    .line 45
    .line 46
    new-array v1, v1, [F

    .line 47
    .line 48
    fill-array-data v1, :array_0

    .line 49
    .line 50
    .line 51
    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iget-object v4, v0, La/sl;->e:Landroid/animation/TimeInterpolator;

    .line 56
    .line 57
    invoke-virtual {v1, v4}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 58
    .line 59
    .line 60
    new-instance v4, La/mA;

    .line 61
    .line 62
    invoke-direct {v4, v0, v3}, La/mA;-><init>(La/sl;I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, v4}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 66
    .line 67
    .line 68
    iget v4, v0, La/sl;->h:I

    .line 69
    .line 70
    int-to-long v4, v4

    .line 71
    invoke-virtual {v1, v4, v5}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 72
    .line 73
    .line 74
    new-instance v4, La/h0;

    .line 75
    .line 76
    invoke-direct {v4, v0, p1, v3}, La/h0;-><init>(La/sl;II)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v1, v4}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->start()V

    .line 83
    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_2
    new-instance v1, Landroid/animation/ValueAnimator;

    .line 87
    .line 88
    invoke-direct {v1}, Landroid/animation/ValueAnimator;-><init>()V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    instance-of v6, v4, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 100
    .line 101
    if-eqz v6, :cond_3

    .line 102
    .line 103
    check-cast v4, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 104
    .line 105
    iget v4, v4, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 106
    .line 107
    add-int/2addr v5, v4

    .line 108
    :cond_3
    filled-new-array {v3, v5}, [I

    .line 109
    .line 110
    .line 111
    move-result-object v3

    .line 112
    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->setIntValues([I)V

    .line 113
    .line 114
    .line 115
    iget-object v3, v0, La/sl;->i:Landroid/animation/TimeInterpolator;

    .line 116
    .line 117
    invoke-virtual {v1, v3}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    .line 118
    .line 119
    .line 120
    iget v3, v0, La/sl;->p:I

    .line 121
    .line 122
    int-to-long v3, v3

    .line 123
    invoke-virtual {v1, v3, v4}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 124
    .line 125
    .line 126
    new-instance v3, La/h0;

    .line 127
    .line 128
    invoke-direct {v3, v0, p1, v2}, La/h0;-><init>(La/sl;II)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v1, v3}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 132
    .line 133
    .line 134
    new-instance p1, La/ba;

    .line 135
    .line 136
    invoke-direct {p1, v0}, La/ba;-><init>(La/sl;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v1, p1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->start()V

    .line 143
    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_4
    invoke-virtual {v0}, La/sl;->p()V

    .line 147
    .line 148
    .line 149
    :goto_1
    return v2

    .line 150
    :cond_5
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast p1, La/sl;

    .line 153
    .line 154
    iget-object v0, p1, La/sl;->V:Lcom/google/android/material/snackbar/Snackbar$SnackbarLayout;

    .line 155
    .line 156
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 157
    .line 158
    .line 159
    move-result-object v4

    .line 160
    if-nez v4, :cond_8

    .line 161
    .line 162
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    instance-of v5, v4, La/y9;

    .line 167
    .line 168
    if-eqz v5, :cond_6

    .line 169
    .line 170
    check-cast v4, La/y9;

    .line 171
    .line 172
    new-instance v5, Lcom/google/android/material/snackbar/BaseTransientBottomBar$Behavior;

    .line 173
    .line 174
    invoke-direct {v5}, Lcom/google/android/material/snackbar/BaseTransientBottomBar$Behavior;-><init>()V

    .line 175
    .line 176
    .line 177
    iget-object v6, v5, Lcom/google/android/material/snackbar/BaseTransientBottomBar$Behavior;->I:La/sR;

    .line 178
    .line 179
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    iget-object v7, p1, La/sl;->q:La/ow;

    .line 183
    .line 184
    iput-object v7, v6, La/sR;->K:Ljava/lang/Object;

    .line 185
    .line 186
    new-instance v6, La/sR;

    .line 187
    .line 188
    invoke-direct {v6, v3, p1}, La/sR;-><init>(ILjava/lang/Object;)V

    .line 189
    .line 190
    .line 191
    iput-object v6, v5, Lcom/google/android/material/behavior/SwipeDismissBehavior;->h:La/sR;

    .line 192
    .line 193
    invoke-virtual {v4, v5}, La/y9;->h(La/AC;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {p1}, La/sl;->h()Landroid/view/View;

    .line 197
    .line 198
    .line 199
    move-result-object v5

    .line 200
    if-nez v5, :cond_6

    .line 201
    .line 202
    const/16 v5, 0x50

    .line 203
    .line 204
    iput v5, v4, La/y9;->X:I

    .line 205
    .line 206
    :cond_6
    iput-boolean v2, v0, Lcom/google/android/material/snackbar/Snackbar$SnackbarLayout;->E:Z

    .line 207
    .line 208
    iget-object v4, p1, La/sl;->X:Landroid/view/ViewGroup;

    .line 209
    .line 210
    invoke-virtual {v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 211
    .line 212
    .line 213
    iput-boolean v3, v0, Lcom/google/android/material/snackbar/Snackbar$SnackbarLayout;->E:Z

    .line 214
    .line 215
    invoke-virtual {p1}, La/sl;->h()Landroid/view/View;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    if-nez v5, :cond_7

    .line 220
    .line 221
    goto :goto_2

    .line 222
    :cond_7
    new-array v3, v1, [I

    .line 223
    .line 224
    invoke-virtual {p1}, La/sl;->h()Landroid/view/View;

    .line 225
    .line 226
    .line 227
    move-result-object v5

    .line 228
    invoke-virtual {v5, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 229
    .line 230
    .line 231
    aget v3, v3, v2

    .line 232
    .line 233
    new-array v1, v1, [I

    .line 234
    .line 235
    invoke-virtual {v4, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 236
    .line 237
    .line 238
    aget v1, v1, v2

    .line 239
    .line 240
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 241
    .line 242
    .line 243
    move-result v4

    .line 244
    add-int/2addr v4, v1

    .line 245
    sub-int v3, v4, v3

    .line 246
    .line 247
    :goto_2
    iput v3, p1, La/sl;->L:I

    .line 248
    .line 249
    invoke-virtual {p1}, La/sl;->Q()V

    .line 250
    .line 251
    .line 252
    const/4 v1, 0x4

    .line 253
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 254
    .line 255
    .line 256
    :cond_8
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 257
    .line 258
    invoke-static {v0}, La/AM;->p(Landroid/view/View;)Z

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    if-eqz v0, :cond_9

    .line 263
    .line 264
    invoke-virtual {p1}, La/sl;->i()V

    .line 265
    .line 266
    .line 267
    goto :goto_3

    .line 268
    :cond_9
    iput-boolean v2, p1, La/sl;->l:Z

    .line 269
    .line 270
    :goto_3
    return v2

    .line 271
    :array_0
    .array-data 4
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method
