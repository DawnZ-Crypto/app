.class public final La/rz;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/nY;


# instance fields
.field public final synthetic K:I

.field public final synthetic L:La/nE;

.field public final synthetic R:La/K9;


# direct methods
.method public synthetic constructor <init>(La/K9;La/nE;I)V
    .locals 0

    .line 1
    iput p3, p0, La/rz;->K:I

    .line 2
    .line 3
    iput-object p1, p0, La/rz;->R:La/K9;

    .line 4
    .line 5
    iput-object p2, p0, La/rz;->L:La/nE;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, La/ig;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final V(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, La/rr;->w:La/rr;

    .line 2
    .line 3
    iget v1, p0, La/rz;->K:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, p0, La/rz;->L:La/nE;

    .line 7
    .line 8
    iget-object v4, p0, La/rz;->R:La/K9;

    .line 9
    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    check-cast p1, La/kj;

    .line 14
    .line 15
    const v1, 0x7f12006e

    .line 16
    .line 17
    .line 18
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {p1, v1}, La/kj;->X(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    new-instance v1, La/rz;

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-direct {v1, v4, v3, v2}, La/rz;-><init>(La/K9;La/nE;I)V

    .line 29
    .line 30
    .line 31
    iput-object v1, p1, La/kj;->f:La/nY;

    .line 32
    .line 33
    return-object v0

    .line 34
    :pswitch_0
    check-cast p1, Landroid/content/DialogInterface;

    .line 35
    .line 36
    new-instance p1, La/rz;

    .line 37
    .line 38
    invoke-direct {p1, v4, v3, v2}, La/rz;-><init>(La/K9;La/nE;I)V

    .line 39
    .line 40
    .line 41
    const-string v1, "android.permission.REQUEST_INSTALL_PACKAGES"

    .line 42
    .line 43
    invoke-virtual {v4, v1, p1}, La/Z4;->l(Ljava/lang/String;La/nY;)V

    .line 44
    .line 45
    .line 46
    return-object v0

    .line 47
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-nez p1, :cond_0

    .line 54
    .line 55
    const p1, 0x7f120075

    .line 56
    .line 57
    .line 58
    invoke-static {v4, p1, v2}, La/rE;->wU(Landroid/content/Context;II)V

    .line 59
    .line 60
    .line 61
    sget-boolean p1, La/K9;->rV:Z

    .line 62
    .line 63
    new-instance p1, La/St;

    .line 64
    .line 65
    invoke-direct {p1, v4, v2}, La/St;-><init>(La/K9;I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v4, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_0
    invoke-static {v3}, La/rE;->J(La/RH;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    new-instance v1, La/XP;

    .line 77
    .line 78
    const/4 v2, 0x0

    .line 79
    invoke-direct {v1, v4, v2}, La/XP;-><init>(La/K9;La/hu;)V

    .line 80
    .line 81
    .line 82
    const/4 v3, 0x3

    .line 83
    invoke-static {p1, v2, v1, v3}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 84
    .line 85
    .line 86
    :goto_0
    return-object v0

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
