.class public final La/Rf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/Y0;
.implements Ljava/io/Serializable;


# instance fields
.field public K:Ljava/lang/Object;

.field public X:La/Lc;


# virtual methods
.method public final getValue()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, La/Rf;->K:Ljava/lang/Object;

    sget-object v1, La/Qr;->W:La/Qr;

    if-ne v0, v1, :cond_0

    iget-object v0, p0, La/Rf;->X:La/Lc;

    invoke-interface {v0}, La/Lc;->w()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, La/Rf;->K:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-object v0, p0, La/Rf;->X:La/Lc;

    :cond_0
    iget-object v0, p0, La/Rf;->K:Ljava/lang/Object;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    iget-object v0, p0, La/Rf;->K:Ljava/lang/Object;

    .line 2
    .line 3
    sget-object v1, La/Qr;->W:La/Qr;

    .line 4
    .line 5
    if-eq v0, v1, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, La/Rf;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const-string v0, "Lazy value not initialized yet."

    .line 17
    .line 18
    :goto_0
    return-object v0
.end method
