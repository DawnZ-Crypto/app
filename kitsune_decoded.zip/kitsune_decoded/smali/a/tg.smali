.class public La/tg;
.super La/Z5;
.source "SourceFile"


# annotations
.annotation runtime La/BV;
    value = "navigation"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/Z5;"
    }
.end annotation


# instance fields
.field public final p:La/zd;


# direct methods
.method public constructor <init>(La/zd;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/tg;->p:La/zd;

    return-void
.end method


# virtual methods
.method public final e(Ljava/util/List;La/i1;)V
    .locals 6

    .line 1
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_8

    .line 10
    .line 11
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, La/GA;

    .line 16
    .line 17
    iget-object v1, v0, La/GA;->K:La/VT;

    .line 18
    .line 19
    check-cast v1, La/mE;

    .line 20
    .line 21
    invoke-virtual {v0}, La/GA;->p()Landroid/os/Bundle;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iget v2, v1, La/mE;->S:I

    .line 26
    .line 27
    iget-object v3, v1, La/mE;->z:Ljava/lang/String;

    .line 28
    .line 29
    if-nez v2, :cond_3

    .line 30
    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    goto :goto_2

    .line 34
    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string p2, "no start destination defined via app:startDestination for "

    .line 37
    .line 38
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget p2, v1, La/VT;->W:I

    .line 42
    .line 43
    if-eqz p2, :cond_1

    .line 44
    .line 45
    iget-object v0, v1, La/VT;->R:Ljava/lang/String;

    .line 46
    .line 47
    if-nez v0, :cond_2

    .line 48
    .line 49
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    goto :goto_1

    .line 54
    :cond_1
    const-string v0, "the root navigation"

    .line 55
    .line 56
    :cond_2
    :goto_1
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw p2

    .line 73
    :cond_3
    :goto_2
    const/4 v4, 0x0

    .line 74
    if-eqz v3, :cond_4

    .line 75
    .line 76
    invoke-virtual {v1, v3, v4}, La/mE;->T(Ljava/lang/String;Z)La/VT;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    goto :goto_3

    .line 81
    :cond_4
    invoke-virtual {v1, v2, v4}, La/mE;->M(IZ)La/VT;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    :goto_3
    if-nez v2, :cond_7

    .line 86
    .line 87
    iget-object p1, v1, La/mE;->H:Ljava/lang/String;

    .line 88
    .line 89
    if-nez p1, :cond_6

    .line 90
    .line 91
    iget-object p1, v1, La/mE;->z:Ljava/lang/String;

    .line 92
    .line 93
    if-nez p1, :cond_5

    .line 94
    .line 95
    iget p1, v1, La/mE;->S:I

    .line 96
    .line 97
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    :cond_5
    iput-object p1, v1, La/mE;->H:Ljava/lang/String;

    .line 102
    .line 103
    :cond_6
    iget-object p1, v1, La/mE;->H:Ljava/lang/String;

    .line 104
    .line 105
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 106
    .line 107
    const-string v0, "navigation destination "

    .line 108
    .line 109
    const-string v1, " is not a direct child of this NavGraph"

    .line 110
    .line 111
    invoke-static {v0, p1, v1}, La/zq;->I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    throw p2

    .line 119
    :cond_7
    iget-object v1, p0, La/tg;->p:La/zd;

    .line 120
    .line 121
    iget-object v3, v2, La/VT;->X:Ljava/lang/String;

    .line 122
    .line 123
    invoke-virtual {v1, v3}, La/zd;->h(Ljava/lang/String;)La/Z5;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    invoke-virtual {p0}, La/Z5;->h()La/Ws;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-virtual {v2, v0}, La/VT;->p(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    sget v4, La/GA;->H:I

    .line 136
    .line 137
    iget-object v3, v3, La/Ws;->O:La/r4;

    .line 138
    .line 139
    iget-object v4, v3, La/r4;->w:Landroid/content/Context;

    .line 140
    .line 141
    invoke-virtual {v3}, La/r4;->X()La/m2;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    iget-object v3, v3, La/r4;->K:La/IO;

    .line 146
    .line 147
    invoke-static {v4, v2, v0, v5, v3}, La/eI;->X(Landroid/content/Context;La/VT;Landroid/os/Bundle;La/m2;La/IO;)La/GA;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-virtual {v1, v0, p2}, La/Z5;->e(Ljava/util/List;La/i1;)V

    .line 156
    .line 157
    .line 158
    goto/16 :goto_0

    .line 159
    .line 160
    :cond_8
    return-void
.end method

.method public final w()La/VT;
    .locals 1

    .line 1
    new-instance v0, La/mE;

    .line 2
    .line 3
    invoke-direct {v0, p0}, La/mE;-><init>(La/Z5;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
