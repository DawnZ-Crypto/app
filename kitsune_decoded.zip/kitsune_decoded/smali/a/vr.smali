.class public final La/vr;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements La/mY;


# static fields
.field public static final synthetic L:I


# instance fields
.field public final K:La/k0;

.field public final R:Ljava/util/concurrent/ExecutorService;

.field public final X:La/FI;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "com.topjohnwu.superuser.internal.IFileSystemService"

    .line 5
    .line 6
    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    new-instance v0, La/FI;

    .line 10
    .line 11
    const/16 v1, 0x64

    .line 12
    .line 13
    invoke-direct {v0, v1}, Landroid/util/LruCache;-><init>(I)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, La/vr;->X:La/FI;

    .line 17
    .line 18
    new-instance v0, La/k0;

    .line 19
    .line 20
    const/4 v1, 0x5

    .line 21
    invoke-direct {v0, v1}, La/k0;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, La/vr;->K:La/k0;

    .line 25
    .line 26
    invoke-static {}, Ljava/util/concurrent/Executors;->newCachedThreadPool()Ljava/util/concurrent/ExecutorService;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iput-object v0, p0, La/vr;->R:Ljava/util/concurrent/ExecutorService;

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final D(Ljava/lang/String;ZZ)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1, p2, p3}, Ljava/io/File;->setReadable(ZZ)Z

    move-result p1

    return p1
.end method

.method public final F(Ljava/lang/String;)J
    .locals 2

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v0

    return-wide v0
.end method

.method public final I(Ljava/lang/String;)J
    .locals 2

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->getUsableSpace()J

    move-result-wide v0

    return-wide v0
.end method

.method public final L(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->isFile()Z

    move-result p1

    return p1
.end method

.method public final M(Ljava/lang/String;Landroid/os/ParcelFileDescriptor;Z)La/xZ;
    .locals 3

    .line 1
    new-instance v0, La/up;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    :try_start_0
    sget v1, Landroid/system/OsConstants;->O_CREAT:I

    sget v2, Landroid/system/OsConstants;->O_WRONLY:I

    or-int/2addr v1, v2

    if-eqz p3, :cond_0

    sget p3, Landroid/system/OsConstants;->O_APPEND:I

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :cond_0
    sget p3, Landroid/system/OsConstants;->O_TRUNC:I

    :goto_0
    or-int/2addr p3, v1

    const/16 v1, 0x1b6

    invoke-static {p1, p3, v1}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    move-result-object p1

    iput-object p1, v0, La/up;->X:Ljava/io/FileDescriptor;

    iget-object p1, p0, La/vr;->R:Ljava/util/concurrent/ExecutorService;

    new-instance p3, La/AL;

    const/4 v1, 0x0

    invoke-direct {p3, v0, p2, v1}, La/AL;-><init>(La/up;Landroid/os/ParcelFileDescriptor;I)V

    invoke-interface {p1, p3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    new-instance p1, La/xZ;

    invoke-direct {p1}, La/xZ;-><init>()V
    :try_end_0
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :goto_1
    invoke-virtual {v0}, La/up;->close()V

    new-instance p2, La/xZ;

    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    return-object p2
.end method

.method public final O(Ljava/lang/String;Landroid/os/ParcelFileDescriptor;)La/xZ;
    .locals 3

    .line 1
    new-instance v0, La/up;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    :try_start_0
    sget v1, Landroid/system/OsConstants;->O_RDONLY:I

    const/4 v2, 0x0

    invoke-static {p1, v1, v2}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    move-result-object p1

    iput-object p1, v0, La/up;->X:Ljava/io/FileDescriptor;

    iget-object p1, p0, La/vr;->R:Ljava/util/concurrent/ExecutorService;

    new-instance v1, La/AL;

    const/4 v2, 0x1

    invoke-direct {v1, v0, p2, v2}, La/AL;-><init>(La/up;Landroid/os/ParcelFileDescriptor;I)V

    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    new-instance p1, La/xZ;

    invoke-direct {p1}, La/xZ;-><init>()V
    :try_end_0
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {v0}, La/up;->close()V

    new-instance p2, La/xZ;

    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    return-object p2
.end method

.method public final P(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->mkdir()Z

    move-result p1

    return p1
.end method

.method public final Q(Ljava/lang/String;ZZ)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1, p2, p3}, Ljava/io/File;->setWritable(ZZ)Z

    move-result p1

    return p1
.end method

.method public final R(JLjava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p3}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/io/File;

    invoke-virtual {p3, p1, p2}, Ljava/io/File;->setLastModified(J)Z

    move-result p1

    return p1
.end method

.method public final S(Landroid/os/IBinder;)V
    .locals 2

    .line 1
    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    :try_start_0
    new-instance v1, La/fp;

    invoke-direct {v1, p0, v0}, La/fp;-><init>(La/vr;I)V

    const/4 v0, 0x0

    invoke-interface {p1, v1, v0}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public final T(Ljava/lang/String;)La/xZ;
    .locals 2

    .line 1
    :try_start_0
    new-instance v0, La/xZ;

    iget-object v1, p0, La/vr;->X:La/FI;

    invoke-virtual {v1, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p1

    new-instance v0, La/xZ;

    invoke-direct {v0, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    return-object v0
.end method

.method public final U(IIJ)La/xZ;
    .locals 2

    .line 1
    :try_start_0
    new-instance v0, La/xZ;

    .line 2
    .line 3
    iget-object v1, p0, La/vr;->K:La/k0;

    .line 4
    .line 5
    invoke-virtual {v1, p1}, La/k0;->p(I)La/up;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    monitor-enter p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    :try_start_1
    iget-object v1, p1, La/up;->X:Ljava/io/FileDescriptor;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-static {v1, p3, p4, p2}, Landroid/system/Os;->lseek(Ljava/io/FileDescriptor;JI)J

    .line 15
    .line 16
    .line 17
    move-result-wide p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 18
    :try_start_2
    monitor-exit p1

    .line 19
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-direct {v0, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/system/ErrnoException; {:try_start_2 .. :try_end_2} :catch_0

    .line 24
    .line 25
    .line 26
    return-object v0

    .line 27
    :catch_0
    move-exception p1

    .line 28
    goto :goto_1

    .line 29
    :catch_1
    move-exception p1

    .line 30
    goto :goto_1

    .line 31
    :catchall_0
    move-exception p2

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    :try_start_3
    new-instance p2, Ljava/nio/channels/ClosedChannelException;

    .line 34
    .line 35
    invoke-direct {p2}, Ljava/nio/channels/ClosedChannelException;-><init>()V

    .line 36
    .line 37
    .line 38
    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 39
    :goto_0
    :try_start_4
    monitor-exit p1

    .line 40
    throw p2
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Landroid/system/ErrnoException; {:try_start_4 .. :try_end_4} :catch_0

    .line 41
    :goto_1
    new-instance p2, La/xZ;

    .line 42
    .line 43
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 44
    .line 45
    .line 46
    return-object p2
.end method

.method public final V(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-result p1

    return p1
.end method

.method public final W(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->setReadOnly()Z

    move-result p1

    return p1
.end method

.method public final X(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result p1

    return p1
.end method

.method public final asBinder()Landroid/os/IBinder;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final d(Ljava/lang/String;)[Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final e(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {v0, p2}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/io/File;

    invoke-virtual {p1, p2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p1

    return p1
.end method

.method public final f(Ljava/lang/String;)J
    .locals 2

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->getFreeSpace()J

    move-result-wide v0

    return-wide v0
.end method

.method public final h(Ljava/lang/String;)La/xZ;
    .locals 2

    .line 1
    :try_start_0
    new-instance v0, La/xZ;

    iget-object v1, p0, La/vr;->X:La/FI;

    invoke-virtual {v1, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->createNewFile()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-direct {v0, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p1

    new-instance v0, La/xZ;

    invoke-direct {v0, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    return-object v0
.end method

.method public final i(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->isHidden()Z

    move-result p1

    return p1
.end method

.method public final k(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5

    .line 1
    const-string v0, "com.topjohnwu.superuser.internal.IFileSystemService"

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-lt p1, v1, :cond_0

    .line 5
    .line 6
    const v2, 0xffffff

    .line 7
    .line 8
    .line 9
    if-gt p1, v2, :cond_0

    .line 10
    .line 11
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    const v2, 0x5f4e5446

    .line 15
    .line 16
    .line 17
    if-eq p1, v2, :cond_c

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    packed-switch p1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    return p1

    .line 28
    :pswitch_0
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    if-eqz p2, :cond_1

    .line 37
    .line 38
    move v0, v1

    .line 39
    :cond_1
    :try_start_0
    iget-object p2, p0, La/vr;->K:La/k0;

    .line 40
    .line 41
    invoke-virtual {p2, p1}, La/k0;->p(I)La/up;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p1, v0}, La/up;->T(Z)V

    .line 46
    .line 47
    .line 48
    new-instance p1, La/xZ;

    .line 49
    .line 50
    invoke-direct {p1}, La/xZ;-><init>()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    .line 51
    .line 52
    .line 53
    goto :goto_2

    .line 54
    :catch_0
    move-exception p1

    .line 55
    goto :goto_0

    .line 56
    :catch_1
    move-exception p1

    .line 57
    :goto_0
    new-instance p2, La/xZ;

    .line 58
    .line 59
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 60
    .line 61
    .line 62
    :goto_1
    move-object p1, p2

    .line 63
    :goto_2
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 64
    .line 65
    .line 66
    invoke-static {p3, p1, v1}, La/A8;->w(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 67
    .line 68
    .line 69
    goto/16 :goto_10

    .line 70
    .line 71
    :pswitch_1
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 76
    .line 77
    .line 78
    move-result-wide v2

    .line 79
    :try_start_1
    iget-object p2, p0, La/vr;->K:La/k0;

    .line 80
    .line 81
    invoke-virtual {p2, p1}, La/k0;->p(I)La/up;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    monitor-enter p1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Landroid/system/ErrnoException; {:try_start_1 .. :try_end_1} :catch_2

    .line 86
    :try_start_2
    iget-object p2, p1, La/up;->X:Ljava/io/FileDescriptor;

    .line 87
    .line 88
    if-eqz p2, :cond_2

    .line 89
    .line 90
    invoke-static {p2, v2, v3}, Landroid/system/Os;->ftruncate(Ljava/io/FileDescriptor;J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 91
    .line 92
    .line 93
    :try_start_3
    monitor-exit p1

    .line 94
    new-instance p1, La/xZ;

    .line 95
    .line 96
    invoke-direct {p1}, La/xZ;-><init>()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catch Landroid/system/ErrnoException; {:try_start_3 .. :try_end_3} :catch_2

    .line 97
    .line 98
    .line 99
    goto :goto_2

    .line 100
    :catch_2
    move-exception p1

    .line 101
    goto :goto_4

    .line 102
    :catch_3
    move-exception p1

    .line 103
    goto :goto_4

    .line 104
    :catchall_0
    move-exception p2

    .line 105
    goto :goto_3

    .line 106
    :cond_2
    :try_start_4
    new-instance p2, Ljava/nio/channels/ClosedChannelException;

    .line 107
    .line 108
    invoke-direct {p2}, Ljava/nio/channels/ClosedChannelException;-><init>()V

    .line 109
    .line 110
    .line 111
    throw p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 112
    :goto_3
    :try_start_5
    monitor-exit p1

    .line 113
    throw p2
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Landroid/system/ErrnoException; {:try_start_5 .. :try_end_5} :catch_2

    .line 114
    :goto_4
    new-instance p2, La/xZ;

    .line 115
    .line 116
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 117
    .line 118
    .line 119
    goto :goto_1

    .line 120
    :pswitch_2
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 121
    .line 122
    .line 123
    move-result p1

    .line 124
    :try_start_6
    new-instance p2, La/xZ;

    .line 125
    .line 126
    iget-object p4, p0, La/vr;->K:La/k0;

    .line 127
    .line 128
    invoke-virtual {p4, p1}, La/k0;->p(I)La/up;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    invoke-virtual {p1}, La/up;->I()J

    .line 133
    .line 134
    .line 135
    move-result-wide v2

    .line 136
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_5
    .catch Landroid/system/ErrnoException; {:try_start_6 .. :try_end_6} :catch_4

    .line 141
    .line 142
    .line 143
    goto :goto_6

    .line 144
    :catch_4
    move-exception p1

    .line 145
    goto :goto_5

    .line 146
    :catch_5
    move-exception p1

    .line 147
    :goto_5
    new-instance p2, La/xZ;

    .line 148
    .line 149
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 150
    .line 151
    .line 152
    :goto_6
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 153
    .line 154
    .line 155
    invoke-static {p3, p2, v1}, La/A8;->w(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    .line 156
    .line 157
    .line 158
    goto/16 :goto_10

    .line 159
    .line 160
    :pswitch_3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 161
    .line 162
    .line 163
    move-result p1

    .line 164
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 165
    .line 166
    .line 167
    move-result-wide v2

    .line 168
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 169
    .line 170
    .line 171
    move-result p2

    .line 172
    invoke-virtual {p0, p1, p2, v2, v3}, La/vr;->U(IIJ)La/xZ;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    goto :goto_2

    .line 177
    :pswitch_4
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 178
    .line 179
    .line 180
    move-result p1

    .line 181
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 182
    .line 183
    .line 184
    move-result p4

    .line 185
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 186
    .line 187
    .line 188
    move-result-wide v2

    .line 189
    :try_start_7
    iget-object p2, p0, La/vr;->K:La/k0;

    .line 190
    .line 191
    invoke-virtual {p2, p1}, La/k0;->p(I)La/up;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    invoke-virtual {p1, p4, v2, v3, v1}, La/up;->h(IJZ)I

    .line 196
    .line 197
    .line 198
    new-instance p1, La/xZ;

    .line 199
    .line 200
    invoke-direct {p1}, La/xZ;-><init>()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_7
    .catch Landroid/system/ErrnoException; {:try_start_7 .. :try_end_7} :catch_6

    .line 201
    .line 202
    .line 203
    goto/16 :goto_2

    .line 204
    .line 205
    :catch_6
    move-exception p1

    .line 206
    goto :goto_7

    .line 207
    :catch_7
    move-exception p1

    .line 208
    :goto_7
    new-instance p2, La/xZ;

    .line 209
    .line 210
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 211
    .line 212
    .line 213
    goto/16 :goto_1

    .line 214
    .line 215
    :pswitch_5
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 216
    .line 217
    .line 218
    move-result p1

    .line 219
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 220
    .line 221
    .line 222
    move-result p4

    .line 223
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 224
    .line 225
    .line 226
    move-result-wide v2

    .line 227
    :try_start_8
    new-instance p2, La/xZ;

    .line 228
    .line 229
    iget-object v0, p0, La/vr;->K:La/k0;

    .line 230
    .line 231
    invoke-virtual {v0, p1}, La/k0;->p(I)La/up;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    invoke-virtual {p1, p4, v2, v3}, La/up;->w(IJ)I

    .line 236
    .line 237
    .line 238
    move-result p1

    .line 239
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 240
    .line 241
    .line 242
    move-result-object p1

    .line 243
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_9
    .catch Landroid/system/ErrnoException; {:try_start_8 .. :try_end_8} :catch_8

    .line 244
    .line 245
    .line 246
    goto :goto_6

    .line 247
    :catch_8
    move-exception p1

    .line 248
    goto :goto_8

    .line 249
    :catch_9
    move-exception p1

    .line 250
    :goto_8
    new-instance p2, La/xZ;

    .line 251
    .line 252
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 253
    .line 254
    .line 255
    goto :goto_6

    .line 256
    :pswitch_6
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 257
    .line 258
    .line 259
    move-result p1

    .line 260
    invoke-virtual {p0, p1}, La/vr;->u(I)V

    .line 261
    .line 262
    .line 263
    goto/16 :goto_10

    .line 264
    .line 265
    :pswitch_7
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object p1

    .line 269
    sget-object p4, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 270
    .line 271
    invoke-static {p2, p4}, La/A8;->h(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object p4

    .line 275
    check-cast p4, Landroid/os/ParcelFileDescriptor;

    .line 276
    .line 277
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 278
    .line 279
    .line 280
    move-result p2

    .line 281
    if-eqz p2, :cond_3

    .line 282
    .line 283
    move v0, v1

    .line 284
    :cond_3
    invoke-virtual {p0, p1, p4, v0}, La/vr;->M(Ljava/lang/String;Landroid/os/ParcelFileDescriptor;Z)La/xZ;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    goto/16 :goto_2

    .line 289
    .line 290
    :pswitch_8
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object p1

    .line 294
    sget-object p4, Landroid/os/ParcelFileDescriptor;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 295
    .line 296
    invoke-static {p2, p4}, La/A8;->h(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object p2

    .line 300
    check-cast p2, Landroid/os/ParcelFileDescriptor;

    .line 301
    .line 302
    invoke-virtual {p0, p1, p2}, La/vr;->O(Ljava/lang/String;Landroid/os/ParcelFileDescriptor;)La/xZ;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    goto/16 :goto_2

    .line 307
    .line 308
    :pswitch_9
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object p1

    .line 312
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 313
    .line 314
    .line 315
    move-result p4

    .line 316
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object p2

    .line 320
    new-instance v2, La/up;

    .line 321
    .line 322
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 323
    .line 324
    .line 325
    :try_start_9
    sget v3, Landroid/system/OsConstants;->O_NONBLOCK:I

    .line 326
    .line 327
    or-int/2addr p4, v3

    .line 328
    const/16 v4, 0x1b6

    .line 329
    .line 330
    invoke-static {p1, p4, v4}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    iput-object p1, v2, La/up;->X:Ljava/io/FileDescriptor;

    .line 335
    .line 336
    sget p1, Landroid/system/OsConstants;->O_RDONLY:I

    .line 337
    .line 338
    or-int/2addr p1, v3

    .line 339
    invoke-static {p2, p1, v0}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    .line 340
    .line 341
    .line 342
    move-result-object p1

    .line 343
    iput-object p1, v2, La/up;->K:Ljava/io/FileDescriptor;

    .line 344
    .line 345
    sget p1, Landroid/system/OsConstants;->O_WRONLY:I

    .line 346
    .line 347
    or-int/2addr p1, v3

    .line 348
    invoke-static {p2, p1, v0}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    .line 349
    .line 350
    .line 351
    move-result-object p1

    .line 352
    iput-object p1, v2, La/up;->R:Ljava/io/FileDescriptor;

    .line 353
    .line 354
    new-instance p1, La/xZ;

    .line 355
    .line 356
    iget-object p2, p0, La/vr;->K:La/k0;

    .line 357
    .line 358
    invoke-virtual {p2, v2}, La/k0;->i(La/up;)I

    .line 359
    .line 360
    .line 361
    move-result p2

    .line 362
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 363
    .line 364
    .line 365
    move-result-object p2

    .line 366
    invoke-direct {p1, p2}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_9
    .catch Landroid/system/ErrnoException; {:try_start_9 .. :try_end_9} :catch_a

    .line 367
    .line 368
    .line 369
    goto/16 :goto_2

    .line 370
    .line 371
    :catch_a
    move-exception p1

    .line 372
    invoke-virtual {v2}, La/up;->close()V

    .line 373
    .line 374
    .line 375
    new-instance p2, La/xZ;

    .line 376
    .line 377
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 378
    .line 379
    .line 380
    goto/16 :goto_1

    .line 381
    .line 382
    :pswitch_a
    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 383
    .line 384
    .line 385
    move-result-object p1

    .line 386
    invoke-virtual {p0, p1}, La/vr;->S(Landroid/os/IBinder;)V

    .line 387
    .line 388
    .line 389
    goto/16 :goto_10

    .line 390
    .line 391
    :pswitch_b
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 392
    .line 393
    .line 394
    move-result-object p1

    .line 395
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 396
    .line 397
    .line 398
    move-result-object p4

    .line 399
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 400
    .line 401
    .line 402
    move-result p2

    .line 403
    if-eqz p2, :cond_4

    .line 404
    .line 405
    :try_start_a
    invoke-static {p4, p1}, Landroid/system/Os;->symlink(Ljava/lang/String;Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    goto :goto_9

    .line 409
    :catch_b
    move-exception p1

    .line 410
    goto :goto_a

    .line 411
    :cond_4
    invoke-static {p4, p1}, Landroid/system/Os;->link(Ljava/lang/String;Ljava/lang/String;)V

    .line 412
    .line 413
    .line 414
    :goto_9
    new-instance p1, La/xZ;

    .line 415
    .line 416
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 417
    .line 418
    invoke-direct {p1, p2}, La/xZ;-><init>(Ljava/io/Serializable;)V
    :try_end_a
    .catch Landroid/system/ErrnoException; {:try_start_a .. :try_end_a} :catch_b

    .line 419
    .line 420
    .line 421
    goto/16 :goto_2

    .line 422
    .line 423
    :goto_a
    iget p2, p1, Landroid/system/ErrnoException;->errno:I

    .line 424
    .line 425
    sget p4, Landroid/system/OsConstants;->EEXIST:I

    .line 426
    .line 427
    if-ne p2, p4, :cond_5

    .line 428
    .line 429
    new-instance p1, La/xZ;

    .line 430
    .line 431
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 432
    .line 433
    invoke-direct {p1, p2}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 434
    .line 435
    .line 436
    goto/16 :goto_2

    .line 437
    .line 438
    :cond_5
    new-instance p2, La/xZ;

    .line 439
    .line 440
    invoke-direct {p2, p1}, La/xZ;-><init>(Ljava/io/Serializable;)V

    .line 441
    .line 442
    .line 443
    goto/16 :goto_1

    .line 444
    .line 445
    :pswitch_c
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    :try_start_b
    invoke-static {p1}, Landroid/system/Os;->lstat(Ljava/lang/String;)Landroid/system/StructStat;

    .line 450
    .line 451
    .line 452
    move-result-object p1

    .line 453
    iget v0, p1, Landroid/system/StructStat;->st_mode:I
    :try_end_b
    .catch Landroid/system/ErrnoException; {:try_start_b .. :try_end_b} :catch_c

    .line 454
    .line 455
    :catch_c
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 456
    .line 457
    .line 458
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 459
    .line 460
    .line 461
    goto/16 :goto_10

    .line 462
    .line 463
    :pswitch_d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 464
    .line 465
    .line 466
    move-result-object p1

    .line 467
    invoke-virtual {p0, p1}, La/vr;->I(Ljava/lang/String;)J

    .line 468
    .line 469
    .line 470
    move-result-wide p1

    .line 471
    :goto_b
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 472
    .line 473
    .line 474
    invoke-virtual {p3, p1, p2}, Landroid/os/Parcel;->writeLong(J)V

    .line 475
    .line 476
    .line 477
    goto/16 :goto_10

    .line 478
    .line 479
    :pswitch_e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 480
    .line 481
    .line 482
    move-result-object p1

    .line 483
    invoke-virtual {p0, p1}, La/vr;->f(Ljava/lang/String;)J

    .line 484
    .line 485
    .line 486
    move-result-wide p1

    .line 487
    goto :goto_b

    .line 488
    :pswitch_f
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object p1

    .line 492
    invoke-virtual {p0, p1}, La/vr;->p(Ljava/lang/String;)J

    .line 493
    .line 494
    .line 495
    move-result-wide p1

    .line 496
    goto :goto_b

    .line 497
    :pswitch_10
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 498
    .line 499
    .line 500
    move-result-object p1

    .line 501
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 502
    .line 503
    .line 504
    move-result p2

    .line 505
    invoke-virtual {p0, p2, p1}, La/vr;->q(ILjava/lang/String;)Z

    .line 506
    .line 507
    .line 508
    move-result p1

    .line 509
    :goto_c
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 510
    .line 511
    .line 512
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    .line 513
    .line 514
    .line 515
    goto/16 :goto_10

    .line 516
    .line 517
    :pswitch_11
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object p1

    .line 521
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 522
    .line 523
    .line 524
    move-result p4

    .line 525
    if-eqz p4, :cond_6

    .line 526
    .line 527
    move p4, v1

    .line 528
    goto :goto_d

    .line 529
    :cond_6
    move p4, v0

    .line 530
    :goto_d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 531
    .line 532
    .line 533
    move-result p2

    .line 534
    if-eqz p2, :cond_7

    .line 535
    .line 536
    move v0, v1

    .line 537
    :cond_7
    invoke-virtual {p0, p1, p4, v0}, La/vr;->l(Ljava/lang/String;ZZ)Z

    .line 538
    .line 539
    .line 540
    move-result p1

    .line 541
    goto :goto_c

    .line 542
    :pswitch_12
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object p1

    .line 546
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 547
    .line 548
    .line 549
    move-result p4

    .line 550
    if-eqz p4, :cond_8

    .line 551
    .line 552
    move p4, v1

    .line 553
    goto :goto_e

    .line 554
    :cond_8
    move p4, v0

    .line 555
    :goto_e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 556
    .line 557
    .line 558
    move-result p2

    .line 559
    if-eqz p2, :cond_9

    .line 560
    .line 561
    move v0, v1

    .line 562
    :cond_9
    invoke-virtual {p0, p1, p4, v0}, La/vr;->D(Ljava/lang/String;ZZ)Z

    .line 563
    .line 564
    .line 565
    move-result p1

    .line 566
    goto :goto_c

    .line 567
    :pswitch_13
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 568
    .line 569
    .line 570
    move-result-object p1

    .line 571
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 572
    .line 573
    .line 574
    move-result p4

    .line 575
    if-eqz p4, :cond_a

    .line 576
    .line 577
    move p4, v1

    .line 578
    goto :goto_f

    .line 579
    :cond_a
    move p4, v0

    .line 580
    :goto_f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    .line 581
    .line 582
    .line 583
    move-result p2

    .line 584
    if-eqz p2, :cond_b

    .line 585
    .line 586
    move v0, v1

    .line 587
    :cond_b
    invoke-virtual {p0, p1, p4, v0}, La/vr;->Q(Ljava/lang/String;ZZ)Z

    .line 588
    .line 589
    .line 590
    move-result p1

    .line 591
    goto :goto_c

    .line 592
    :pswitch_14
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 593
    .line 594
    .line 595
    move-result-object p1

    .line 596
    invoke-virtual {p0, p1}, La/vr;->W(Ljava/lang/String;)Z

    .line 597
    .line 598
    .line 599
    move-result p1

    .line 600
    goto :goto_c

    .line 601
    :pswitch_15
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 602
    .line 603
    .line 604
    move-result-object p1

    .line 605
    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    .line 606
    .line 607
    .line 608
    move-result-wide v2

    .line 609
    invoke-virtual {p0, v2, v3, p1}, La/vr;->R(JLjava/lang/String;)Z

    .line 610
    .line 611
    .line 612
    move-result p1

    .line 613
    goto :goto_c

    .line 614
    :pswitch_16
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 615
    .line 616
    .line 617
    move-result-object p1

    .line 618
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 619
    .line 620
    .line 621
    move-result-object p2

    .line 622
    invoke-virtual {p0, p1, p2}, La/vr;->e(Ljava/lang/String;Ljava/lang/String;)Z

    .line 623
    .line 624
    .line 625
    move-result p1

    .line 626
    goto :goto_c

    .line 627
    :pswitch_17
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 628
    .line 629
    .line 630
    move-result-object p1

    .line 631
    invoke-virtual {p0, p1}, La/vr;->y(Ljava/lang/String;)Z

    .line 632
    .line 633
    .line 634
    move-result p1

    .line 635
    goto :goto_c

    .line 636
    :pswitch_18
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 637
    .line 638
    .line 639
    move-result-object p1

    .line 640
    invoke-virtual {p0, p1}, La/vr;->P(Ljava/lang/String;)Z

    .line 641
    .line 642
    .line 643
    move-result p1

    .line 644
    goto/16 :goto_c

    .line 645
    .line 646
    :pswitch_19
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object p1

    .line 650
    invoke-virtual {p0, p1}, La/vr;->d(Ljava/lang/String;)[Ljava/lang/String;

    .line 651
    .line 652
    .line 653
    move-result-object p1

    .line 654
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    .line 655
    .line 656
    .line 657
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    .line 658
    .line 659
    .line 660
    goto :goto_10

    .line 661
    :pswitch_1a
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 662
    .line 663
    .line 664
    move-result-object p1

    .line 665
    invoke-virtual {p0, p1}, La/vr;->V(Ljava/lang/String;)Z

    .line 666
    .line 667
    .line 668
    move-result p1

    .line 669
    goto/16 :goto_c

    .line 670
    .line 671
    :pswitch_1b
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 672
    .line 673
    .line 674
    move-result-object p1

    .line 675
    invoke-virtual {p0, p1}, La/vr;->h(Ljava/lang/String;)La/xZ;

    .line 676
    .line 677
    .line 678
    move-result-object p1

    .line 679
    goto/16 :goto_2

    .line 680
    .line 681
    :pswitch_1c
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 682
    .line 683
    .line 684
    move-result-object p1

    .line 685
    invoke-virtual {p0, p1}, La/vr;->F(Ljava/lang/String;)J

    .line 686
    .line 687
    .line 688
    move-result-wide p1

    .line 689
    goto/16 :goto_b

    .line 690
    .line 691
    :pswitch_1d
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 692
    .line 693
    .line 694
    move-result-object p1

    .line 695
    invoke-virtual {p0, p1}, La/vr;->m(Ljava/lang/String;)J

    .line 696
    .line 697
    .line 698
    move-result-wide p1

    .line 699
    goto/16 :goto_b

    .line 700
    .line 701
    :pswitch_1e
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 702
    .line 703
    .line 704
    move-result-object p1

    .line 705
    invoke-virtual {p0, p1}, La/vr;->i(Ljava/lang/String;)Z

    .line 706
    .line 707
    .line 708
    move-result p1

    .line 709
    goto/16 :goto_c

    .line 710
    .line 711
    :pswitch_1f
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    move-result-object p1

    .line 715
    invoke-virtual {p0, p1}, La/vr;->L(Ljava/lang/String;)Z

    .line 716
    .line 717
    .line 718
    move-result p1

    .line 719
    goto/16 :goto_c

    .line 720
    .line 721
    :pswitch_20
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 722
    .line 723
    .line 724
    move-result-object p1

    .line 725
    invoke-virtual {p0, p1}, La/vr;->X(Ljava/lang/String;)Z

    .line 726
    .line 727
    .line 728
    move-result p1

    .line 729
    goto/16 :goto_c

    .line 730
    .line 731
    :pswitch_21
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 732
    .line 733
    .line 734
    move-result-object p1

    .line 735
    invoke-virtual {p0, p1}, La/vr;->T(Ljava/lang/String;)La/xZ;

    .line 736
    .line 737
    .line 738
    move-result-object p1

    .line 739
    goto/16 :goto_2

    .line 740
    .line 741
    :goto_10
    return v1

    .line 742
    :cond_c
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 743
    .line 744
    .line 745
    return v1

    .line 746
    nop

    .line 747
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final l(Ljava/lang/String;ZZ)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1, p2, p3}, Ljava/io/File;->setExecutable(ZZ)Z

    move-result p1

    return p1
.end method

.method public final m(Ljava/lang/String;)J
    .locals 2

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->lastModified()J

    move-result-wide v0

    return-wide v0
.end method

.method public final bridge synthetic onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2, p3, p4}, La/vr;->k(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public final p(Ljava/lang/String;)J
    .locals 2

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->getTotalSpace()J

    move-result-wide v0

    return-wide v0
.end method

.method public final q(ILjava/lang/String;)Z
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p2, p1}, Landroid/system/Os;->access(Ljava/lang/String;I)Z

    move-result p1
    :try_end_0
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    const/4 p1, 0x0

    return p1
.end method

.method public final u(I)V
    .locals 3

    .line 1
    iget-object v0, p0, La/vr;->K:La/k0;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    iget-object v2, v0, La/k0;->K:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Landroid/util/SparseArray;

    .line 11
    .line 12
    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Landroid/util/SparseArray;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 17
    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    :goto_0
    monitor-exit v0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :try_start_1
    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, La/up;

    .line 27
    .line 28
    if-nez v2, :cond_1

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_1
    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->remove(I)V

    .line 32
    .line 33
    .line 34
    monitor-enter v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 35
    :try_start_2
    invoke-virtual {v2}, La/up;->close()V

    .line 36
    .line 37
    .line 38
    monitor-exit v2

    .line 39
    goto :goto_0

    .line 40
    :goto_1
    return-void

    .line 41
    :catchall_0
    move-exception p1

    .line 42
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 43
    :try_start_3
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 44
    :catchall_1
    move-exception p1

    .line 45
    monitor-exit v0

    .line 46
    throw p1
.end method

.method public final y(Ljava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, La/vr;->X:La/FI;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    move-result p1

    return p1
.end method
