.class public final La/fE;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final Q:I

.field public final e:Ljava/lang/String;

.field public final h:I

.field public final i:I

.field public final p:Z

.field public final w:Ljava/lang/String;


# direct methods
.method public constructor <init>(IIILjava/lang/String;Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p4, p0, La/fE;->w:Ljava/lang/String;

    iput p1, p0, La/fE;->h:I

    iput-boolean p6, p0, La/fE;->p:Z

    iput-object p5, p0, La/fE;->e:Ljava/lang/String;

    iput p2, p0, La/fE;->i:I

    iput p3, p0, La/fE;->Q:I

    return-void
.end method
