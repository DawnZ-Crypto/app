.class public interface abstract La/f6;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract w(La/f6;)V
.end method
