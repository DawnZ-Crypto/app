.class public final La/S2;
.super La/yG;
.source "SourceFile"

# interfaces
.implements La/Wb;


# instance fields
.field public d:I

.field public final synthetic f:La/ac;

.field public final synthetic l:La/sh;


# direct methods
.method public constructor <init>(La/ac;La/sh;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/S2;->f:La/ac;

    iput-object p2, p0, La/S2;->l:La/sh;

    invoke-direct {p0, p3}, La/yG;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final I(Ljava/lang/Object;La/hu;)La/hu;
    .locals 2

    .line 1
    new-instance p1, La/S2;

    iget-object v0, p0, La/S2;->f:La/ac;

    iget-object v1, p0, La/S2;->l:La/sh;

    invoke-direct {p1, v0, v1, p2}, La/S2;-><init>(La/ac;La/sh;La/hu;)V

    return-object p1
.end method

.method public final O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, La/wE;

    .line 2
    .line 3
    check-cast p2, La/hu;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La/S2;->I(Ljava/lang/Object;La/hu;)La/hu;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La/S2;

    .line 10
    .line 11
    sget-object p2, La/rr;->w:La/rr;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La/S2;->T(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, La/cj;->X:La/cj;

    .line 2
    .line 3
    iget v1, p0, La/S2;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object p1, p0, La/S2;->f:La/ac;

    .line 26
    .line 27
    check-cast p1, La/Dp;

    .line 28
    .line 29
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    sget-object p1, La/uv;->X:La/N8;

    .line 33
    .line 34
    iget-object v1, p0, La/S2;->l:La/sh;

    .line 35
    .line 36
    iget-object v1, v1, La/sh;->X:Ljava/lang/String;

    .line 37
    .line 38
    iput v2, p0, La/S2;->d:I

    .line 39
    .line 40
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    invoke-static {v1, p0}, La/N8;->cC(Ljava/lang/String;La/hu;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    if-ne p1, v0, :cond_2

    .line 48
    .line 49
    return-object v0

    .line 50
    :cond_2
    :goto_0
    sget-object p1, La/rr;->w:La/rr;

    .line 51
    .line 52
    return-object p1
.end method
