.class public final La/Nw;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final I:Ljava/lang/String;

.field public final M:J

.field public final O:I

.field public final Q:Ljava/lang/String;

.field public T:I

.field public final V:Ljava/lang/String;

.field public final X:I

.field public final e:Ljava/lang/String;

.field public final h:I

.field public final i:Ljava/lang/String;

.field public final p:I

.field public final w:I


# direct methods
.method public synthetic constructor <init>(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)V
    .locals 13

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    move-object v0, p0

    move v1, p1

    move v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move-object/from16 v9, p9

    move-object/from16 v10, p10

    invoke-direct/range {v0 .. v12}, La/Nw;-><init>(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;J)V

    return-void
.end method

.method public constructor <init>(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;J)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La/Nw;->w:I

    iput p2, p0, La/Nw;->h:I

    iput p3, p0, La/Nw;->p:I

    iput-object p4, p0, La/Nw;->e:Ljava/lang/String;

    iput-object p5, p0, La/Nw;->i:Ljava/lang/String;

    iput-object p6, p0, La/Nw;->Q:Ljava/lang/String;

    iput p7, p0, La/Nw;->X:I

    iput p8, p0, La/Nw;->O:I

    iput-object p9, p0, La/Nw;->V:Ljava/lang/String;

    iput-object p10, p0, La/Nw;->I:Ljava/lang/String;

    iput-wide p11, p0, La/Nw;->M:J

    return-void
.end method
