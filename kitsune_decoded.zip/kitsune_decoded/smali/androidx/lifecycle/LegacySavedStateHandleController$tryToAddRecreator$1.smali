.class public final Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic K:La/VV;

.field public final synthetic X:La/GK;


# direct methods
.method public constructor <init>(La/GK;La/VV;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;->X:La/GK;

    iput-object p2, p0, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;->K:La/VV;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 0

    .line 1
    sget-object p1, La/cw;->ON_START:La/cw;

    if-ne p2, p1, :cond_0

    iget-object p1, p0, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;->X:La/GK;

    invoke-virtual {p1, p0}, La/GK;->h(La/IQ;)V

    iget-object p1, p0, Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;->K:La/VV;

    invoke-virtual {p1}, La/VV;->e()V

    :cond_0
    return-void
.end method
