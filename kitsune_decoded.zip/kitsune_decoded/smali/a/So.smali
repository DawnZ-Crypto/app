.class public La/So;
.super La/XM;
.source "SourceFile"


# instance fields
.field public AW:Landroid/widget/ImageView;

.field public GI:Landroid/widget/TextView;

.field public N3:I

.field public final Vm:Landroid/os/Handler;

.field public final Vy:La/oE;

.field public an:La/TO;

.field public cM:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La/XM;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, La/So;->Vm:Landroid/os/Handler;

    new-instance v0, La/oE;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0}, La/oE;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, La/So;->Vy:La/oE;

    return-void
.end method


# virtual methods
.method public final Pc()Landroid/app/Dialog;
    .locals 9

    .line 1
    new-instance v0, La/k0;

    .line 2
    .line 3
    invoke-virtual {p0}, La/zr;->B()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, La/k0;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, La/So;->an:La/TO;

    .line 11
    .line 12
    iget-object v1, v1, La/TO;->f:La/Fg;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    iget-object v1, v1, La/Fg;->w:Ljava/lang/CharSequence;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    move-object v1, v2

    .line 21
    :goto_0
    iget-object v3, v0, La/k0;->K:Ljava/lang/Object;

    .line 22
    .line 23
    move-object v4, v3

    .line 24
    check-cast v4, La/UJ;

    .line 25
    .line 26
    iput-object v1, v4, La/UJ;->e:Ljava/lang/CharSequence;

    .line 27
    .line 28
    move-object v1, v3

    .line 29
    check-cast v1, La/UJ;

    .line 30
    .line 31
    iget-object v1, v1, La/UJ;->w:Landroid/content/Context;

    .line 32
    .line 33
    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const v4, 0x7f0c0032

    .line 38
    .line 39
    .line 40
    invoke-virtual {v1, v4, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const v4, 0x7f0900ec

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Landroid/widget/TextView;

    .line 52
    .line 53
    const/16 v5, 0x8

    .line 54
    .line 55
    const/4 v6, 0x0

    .line 56
    if-eqz v4, :cond_3

    .line 57
    .line 58
    iget-object v7, p0, La/So;->an:La/TO;

    .line 59
    .line 60
    iget-object v7, v7, La/TO;->f:La/Fg;

    .line 61
    .line 62
    if-eqz v7, :cond_1

    .line 63
    .line 64
    iget-object v7, v7, La/Fg;->h:Ljava/lang/CharSequence;

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_1
    move-object v7, v2

    .line 68
    :goto_1
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 69
    .line 70
    .line 71
    move-result v8

    .line 72
    if-eqz v8, :cond_2

    .line 73
    .line 74
    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    .line 75
    .line 76
    .line 77
    goto :goto_2

    .line 78
    :cond_2
    invoke-virtual {v4, v6}, Landroid/view/View;->setVisibility(I)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 82
    .line 83
    .line 84
    :cond_3
    :goto_2
    const v4, 0x7f0900e9

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    check-cast v4, Landroid/widget/TextView;

    .line 92
    .line 93
    if-eqz v4, :cond_6

    .line 94
    .line 95
    iget-object v7, p0, La/So;->an:La/TO;

    .line 96
    .line 97
    iget-object v7, v7, La/TO;->f:La/Fg;

    .line 98
    .line 99
    if-eqz v7, :cond_4

    .line 100
    .line 101
    iget-object v2, v7, La/Fg;->p:Ljava/lang/CharSequence;

    .line 102
    .line 103
    :cond_4
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 104
    .line 105
    .line 106
    move-result v7

    .line 107
    if-eqz v7, :cond_5

    .line 108
    .line 109
    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    .line 110
    .line 111
    .line 112
    goto :goto_3

    .line 113
    :cond_5
    invoke-virtual {v4, v6}, Landroid/view/View;->setVisibility(I)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 117
    .line 118
    .line 119
    :cond_6
    :goto_3
    const v2, 0x7f0900eb

    .line 120
    .line 121
    .line 122
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    check-cast v2, Landroid/widget/ImageView;

    .line 127
    .line 128
    iput-object v2, p0, La/So;->AW:Landroid/widget/ImageView;

    .line 129
    .line 130
    const v2, 0x7f0900ea

    .line 131
    .line 132
    .line 133
    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    check-cast v2, Landroid/widget/TextView;

    .line 138
    .line 139
    iput-object v2, p0, La/So;->GI:Landroid/widget/TextView;

    .line 140
    .line 141
    iget-object v2, p0, La/So;->an:La/TO;

    .line 142
    .line 143
    invoke-virtual {v2}, La/TO;->V()I

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    invoke-static {v2}, La/fe;->Y(I)Z

    .line 148
    .line 149
    .line 150
    move-result v2

    .line 151
    if-eqz v2, :cond_7

    .line 152
    .line 153
    const v2, 0x7f120035

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0, v2}, La/zr;->l(I)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    goto :goto_4

    .line 161
    :cond_7
    iget-object v2, p0, La/So;->an:La/TO;

    .line 162
    .line 163
    invoke-virtual {v2}, La/TO;->M()Ljava/lang/CharSequence;

    .line 164
    .line 165
    .line 166
    move-result-object v2

    .line 167
    :goto_4
    new-instance v4, La/Gu;

    .line 168
    .line 169
    invoke-direct {v4, p0}, La/Gu;-><init>(La/So;)V

    .line 170
    .line 171
    .line 172
    check-cast v3, La/UJ;

    .line 173
    .line 174
    iput-object v2, v3, La/UJ;->Q:Ljava/lang/CharSequence;

    .line 175
    .line 176
    iput-object v4, v3, La/UJ;->X:Landroid/content/DialogInterface$OnClickListener;

    .line 177
    .line 178
    iput-object v1, v3, La/UJ;->M:Landroid/view/View;

    .line 179
    .line 180
    invoke-virtual {v0}, La/k0;->w()La/Zo;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    invoke-virtual {v0, v6}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 185
    .line 186
    .line 187
    return-object v0
.end method

.method public final Y(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, La/XM;->Y(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/zr;->y()La/Jf;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v0, 0x0

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance v1, La/yW;

    .line 13
    .line 14
    invoke-direct {v1, p1}, La/yW;-><init>(La/CG;)V

    .line 15
    .line 16
    .line 17
    const-class p1, La/TO;

    .line 18
    .line 19
    invoke-virtual {v1, p1}, La/yW;->m(Ljava/lang/Class;)La/AZ;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, La/TO;

    .line 24
    .line 25
    iput-object p1, p0, La/So;->an:La/TO;

    .line 26
    .line 27
    iget-object v1, p1, La/TO;->C:La/bc;

    .line 28
    .line 29
    if-nez v1, :cond_1

    .line 30
    .line 31
    new-instance v1, La/bc;

    .line 32
    .line 33
    invoke-direct {v1}, Landroidx/lifecycle/h;-><init>()V

    .line 34
    .line 35
    .line 36
    iput-object v1, p1, La/TO;->C:La/bc;

    .line 37
    .line 38
    :cond_1
    iget-object p1, p1, La/TO;->C:La/bc;

    .line 39
    .line 40
    new-instance v1, La/ne;

    .line 41
    .line 42
    invoke-direct {v1, p0, v0}, La/ne;-><init>(La/XM;I)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, p0, v1}, Landroidx/lifecycle/h;->i(La/RH;La/yb;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, p0, La/So;->an:La/TO;

    .line 49
    .line 50
    iget-object v1, p1, La/TO;->x:La/bc;

    .line 51
    .line 52
    if-nez v1, :cond_2

    .line 53
    .line 54
    new-instance v1, La/bc;

    .line 55
    .line 56
    invoke-direct {v1}, Landroidx/lifecycle/h;-><init>()V

    .line 57
    .line 58
    .line 59
    iput-object v1, p1, La/TO;->x:La/bc;

    .line 60
    .line 61
    :cond_2
    iget-object p1, p1, La/TO;->x:La/bc;

    .line 62
    .line 63
    new-instance v1, La/ne;

    .line 64
    .line 65
    const/4 v2, 0x1

    .line 66
    invoke-direct {v1, p0, v2}, La/ne;-><init>(La/XM;I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, p0, v1}, Landroidx/lifecycle/h;->i(La/RH;La/yb;)V

    .line 70
    .line 71
    .line 72
    :goto_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 73
    .line 74
    const/16 v1, 0x1a

    .line 75
    .line 76
    if-lt p1, v1, :cond_3

    .line 77
    .line 78
    invoke-static {}, La/Q7;->w()I

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    invoke-virtual {p0, p1}, La/So;->rC(I)I

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    iput p1, p0, La/So;->cM:I

    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_3
    invoke-virtual {p0}, La/zr;->R()Landroid/content/Context;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    if-eqz p1, :cond_4

    .line 94
    .line 95
    sget-object v0, La/hA;->w:Ljava/lang/Object;

    .line 96
    .line 97
    const v0, 0x7f060021

    .line 98
    .line 99
    .line 100
    invoke-static {p1, v0}, La/Ex;->w(Landroid/content/Context;I)I

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    :cond_4
    iput v0, p0, La/So;->cM:I

    .line 105
    .line 106
    :goto_1
    const p1, 0x1010038

    .line 107
    .line 108
    .line 109
    invoke-virtual {p0, p1}, La/So;->rC(I)I

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    iput p1, p0, La/So;->N3:I

    .line 114
    .line 115
    return-void
.end method

.method public final j()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La/zr;->r:Z

    .line 3
    .line 4
    iget-object v0, p0, La/So;->Vm:Landroid/os/Handler;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .locals 1

    .line 1
    iget-object p1, p0, La/So;->an:La/TO;

    .line 2
    .line 3
    iget-object v0, p1, La/TO;->t:La/bc;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, La/bc;

    .line 8
    .line 9
    invoke-direct {v0}, Landroidx/lifecycle/h;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p1, La/TO;->t:La/bc;

    .line 13
    .line 14
    :cond_0
    iget-object p1, p1, La/TO;->t:La/bc;

    .line 15
    .line 16
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 17
    .line 18
    invoke-static {p1, v0}, La/TO;->R(La/bc;Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final rC(I)I
    .locals 5

    .line 1
    invoke-virtual {p0}, La/zr;->R()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, La/zr;->y()La/Jf;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v3, Landroid/util/TypedValue;

    invoke-direct {v3}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {v0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v0

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v3, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    iget v0, v3, Landroid/util/TypedValue;->data:I

    filled-new-array {p1}, [I

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1, v2, v2}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v0

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return v0

    :cond_1
    :goto_0
    const-string p1, "FingerprintFragment"

    const-string v0, "Unable to get themed color. Context or activity is null."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v2
.end method

.method public final t()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La/zr;->r:Z

    .line 3
    .line 4
    iget-object v1, p0, La/So;->an:La/TO;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    iput v2, v1, La/TO;->n:I

    .line 8
    .line 9
    invoke-virtual {v1, v0}, La/TO;->y(I)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, La/So;->an:La/TO;

    .line 13
    .line 14
    const v1, 0x7f12004e

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, v1}, La/zr;->l(I)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, La/TO;->m(Ljava/lang/CharSequence;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
