.class public final Lcom/topjohnwu/magisk/ui/home/HomeFragment;
.super La/zZ;
.source "SourceFile"

# interfaces
.implements La/We;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/Ov;",
        ">;",
        "La/We;"
    }
.end annotation


# static fields
.field public static final synthetic Pb:I


# instance fields
.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0035

    iput v0, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 7

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const v1, 0x7f120120

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(I)V

    .line 14
    .line 15
    .line 16
    :cond_0
    sget v0, Lcom/topjohnwu/magisk/core/download/DownloadService;->d:I

    .line 17
    .line 18
    new-instance v0, La/x2;

    .line 19
    .line 20
    iget-object v1, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->xF:La/Y0;

    .line 21
    .line 22
    invoke-interface {v1}, La/Y0;->getValue()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    move-object v3, v1

    .line 27
    check-cast v3, La/Cu;

    .line 28
    .line 29
    const/4 v2, 0x2

    .line 30
    const-class v4, La/Cu;

    .line 31
    .line 32
    const-string v5, "onProgressUpdate"

    .line 33
    .line 34
    const-string v6, "onProgressUpdate(FLcom/topjohnwu/magisk/core/download/Subject;)V"

    .line 35
    .line 36
    move-object v1, v0

    .line 37
    invoke-direct/range {v1 .. v6}, La/cm;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    sget-object v1, La/US;->R:La/bc;

    .line 41
    .line 42
    const/4 v2, 0x0

    .line 43
    invoke-virtual {v1, v2}, La/bc;->I(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    new-instance v2, La/HY;

    .line 47
    .line 48
    const/4 v3, 0x3

    .line 49
    invoke-direct {v2, v3, v0}, La/HY;-><init>(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    new-instance v0, La/Do;

    .line 53
    .line 54
    invoke-direct {v0, v3, v2}, La/Do;-><init>(ILa/nY;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1, p0, v0}, Landroidx/lifecycle/h;->i(La/RH;La/yb;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method

.method public final synthetic O(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/Cu;

    .line 8
    .line 9
    return-object v0
.end method

.method public final X(Landroid/view/MenuItem;)Z
    .locals 5

    .line 1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x1

    .line 6
    const v1, 0x7f09004a

    .line 7
    .line 8
    .line 9
    if-eq p1, v1, :cond_3

    .line 10
    .line 11
    const v1, 0x7f090053

    .line 12
    .line 13
    .line 14
    if-eq p1, v1, :cond_0

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    return p1

    .line 18
    :cond_0
    new-instance p1, La/jR;

    .line 19
    .line 20
    const v1, 0x7f090041

    .line 21
    .line 22
    .line 23
    invoke-direct {p1, v1}, La/jR;-><init>(I)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    const/4 v3, 0x0

    .line 31
    if-eqz v2, :cond_1

    .line 32
    .line 33
    iget-object v2, v2, La/o5;->Pc:La/Yi;

    .line 34
    .line 35
    invoke-virtual {v2}, La/Yi;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, Landroidx/navigation/fragment/NavHostFragment;

    .line 40
    .line 41
    iget-object v2, v2, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 42
    .line 43
    invoke-virtual {v2}, La/Yi;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    check-cast v2, La/sv;

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    move-object v2, v3

    .line 51
    :goto_0
    if-eqz v2, :cond_5

    .line 52
    .line 53
    invoke-virtual {v2}, La/r4;->Q()La/VT;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    if-eqz v2, :cond_5

    .line 58
    .line 59
    invoke-virtual {v2, v1}, La/VT;->i(I)La/R5;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    if-eqz v1, :cond_5

    .line 64
    .line 65
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    if-eqz v1, :cond_2

    .line 70
    .line 71
    iget-object v1, v1, La/o5;->Pc:La/Yi;

    .line 72
    .line 73
    invoke-virtual {v1}, La/Yi;->getValue()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    check-cast v1, Landroidx/navigation/fragment/NavHostFragment;

    .line 78
    .line 79
    iget-object v1, v1, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 80
    .line 81
    invoke-virtual {v1}, La/Yi;->getValue()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    move-object v3, v1

    .line 86
    check-cast v3, La/sv;

    .line 87
    .line 88
    :cond_2
    invoke-virtual {v3, p1}, La/r4;->I(La/EI;)V

    .line 89
    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_3
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    if-eqz p1, :cond_5

    .line 97
    .line 98
    new-instance v2, Landroid/view/ContextThemeWrapper;

    .line 99
    .line 100
    const v3, 0x7f13013e

    .line 101
    .line 102
    .line 103
    invoke-direct {v2, p1, v3}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 104
    .line 105
    .line 106
    new-instance v3, Landroid/widget/PopupMenu;

    .line 107
    .line 108
    invoke-virtual {p1, v1}, La/m1;->findViewById(I)Landroid/view/View;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    invoke-direct {v3, v2, v1}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {p1}, La/m1;->getMenuInflater()Landroid/view/MenuInflater;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    const v2, 0x7f0e0005

    .line 120
    .line 121
    .line 122
    invoke-virtual {v3}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    .line 123
    .line 124
    .line 125
    move-result-object v4

    .line 126
    invoke-virtual {v1, v2, v4}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 127
    .line 128
    .line 129
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 130
    .line 131
    const/16 v2, 0x1e

    .line 132
    .line 133
    if-lt v1, v2, :cond_4

    .line 134
    .line 135
    sget-object v1, La/hA;->w:Ljava/lang/Object;

    .line 136
    .line 137
    const-class v1, Landroid/os/PowerManager;

    .line 138
    .line 139
    invoke-static {p1, v1}, La/Ex;->h(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    check-cast p1, Landroid/os/PowerManager;

    .line 144
    .line 145
    if-eqz p1, :cond_4

    .line 146
    .line 147
    invoke-static {p1}, La/cM;->E(Landroid/os/PowerManager;)Z

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    if-ne p1, v0, :cond_4

    .line 152
    .line 153
    invoke-virtual {v3}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    const v1, 0x7f090050

    .line 158
    .line 159
    .line 160
    invoke-interface {p1, v1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    .line 165
    .line 166
    .line 167
    :cond_4
    new-instance p1, La/Jl;

    .line 168
    .line 169
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v3, p1}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v3}, Landroid/widget/PopupMenu;->show()V

    .line 176
    .line 177
    .line 178
    :cond_5
    :goto_1
    return v0
.end method

.method public final synthetic e(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final p(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 1

    .line 1
    const v0, 0x7f0e0003

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 5
    .line 6
    .line 7
    sget-object p2, La/Mv;->w:La/Mv;

    .line 8
    .line 9
    sget-boolean p2, La/Mv;->y:Z

    .line 10
    .line 11
    if-nez p2, :cond_0

    .line 12
    .line 13
    const p2, 0x7f09004a

    .line 14
    .line 15
    .line 16
    invoke-interface {p1, p2}, Landroid/view/Menu;->removeItem(I)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public final t()V
    .locals 2

    .line 1
    invoke-super {p0}, La/zZ;->t()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/home/HomeFragment;->xF:La/Y0;

    .line 5
    .line 6
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, La/Cu;

    .line 11
    .line 12
    iget v1, v0, La/Cu;->H:I

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    iput v1, v0, La/Cu;->H:I

    .line 18
    .line 19
    const/16 v1, 0x25

    .line 20
    .line 21
    invoke-virtual {v0, v1}, La/hb;->Q(I)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void
.end method

.method public final u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 2

    .line 1
    invoke-super {p0, p1, p2, p3}, La/zZ;->u(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 5
    .line 6
    const/4 p2, 0x0

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object p1, p2

    .line 11
    :goto_0
    check-cast p1, La/Ov;

    .line 12
    .line 13
    iget-object p1, p1, La/Ov;->t:La/gv;

    .line 14
    .line 15
    iget-object p3, p1, La/gv;->n:Landroid/widget/TextView;

    .line 16
    .line 17
    new-instance v0, La/lw;

    .line 18
    .line 19
    const/16 v1, 0xb

    .line 20
    .line 21
    iget-object p1, p1, La/gv;->t:Landroid/widget/ImageView;

    .line 22
    .line 23
    invoke-direct {v0, p3, v1, p1}, La/lw;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p3, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 27
    .line 28
    .line 29
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 30
    .line 31
    if-eqz p1, :cond_1

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_1
    move-object p1, p2

    .line 35
    :goto_1
    check-cast p1, La/Ov;

    .line 36
    .line 37
    iget-object p1, p1, La/Ov;->n:La/U5;

    .line 38
    .line 39
    iget-object p3, p1, La/U5;->C:Landroid/widget/TextView;

    .line 40
    .line 41
    new-instance v0, La/lw;

    .line 42
    .line 43
    iget-object p1, p1, La/U5;->n:Landroid/widget/ImageView;

    .line 44
    .line 45
    invoke-direct {v0, p3, v1, p1}, La/lw;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p3, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 52
    .line 53
    if-eqz p1, :cond_2

    .line 54
    .line 55
    move-object p2, p1

    .line 56
    :cond_2
    check-cast p2, La/Ov;

    .line 57
    .line 58
    iget-object p1, p2, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 59
    .line 60
    return-object p1
.end method
