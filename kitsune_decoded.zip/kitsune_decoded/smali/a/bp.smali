.class public final La/bp;
.super La/Yo;
.source "SourceFile"


# instance fields
.field public final K:Ljava/lang/reflect/Method;

.field public final L:Ljava/lang/String;

.field public final R:I

.field public final d:Z


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;ILjava/lang/String;Z)V
    .locals 1

    .line 1
    const/16 v0, 0xd

    invoke-direct {p0, v0}, La/Yo;-><init>(I)V

    iput-object p1, p0, La/bp;->K:Ljava/lang/reflect/Method;

    iput p2, p0, La/bp;->R:I

    iput-object p3, p0, La/bp;->L:Ljava/lang/String;

    iput-boolean p4, p0, La/bp;->d:Z

    return-void
.end method


# virtual methods
.method public final p(La/Y8;Ljava/lang/Object;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, v0, La/bp;->L:Ljava/lang/String;

    .line 7
    .line 8
    if-eqz p2, :cond_b

    .line 9
    .line 10
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    iget-object v5, v1, La/Y8;->p:Ljava/lang/String;

    .line 15
    .line 16
    if-eqz v5, :cond_a

    .line 17
    .line 18
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    move v6, v2

    .line 23
    :goto_0
    if-ge v6, v5, :cond_8

    .line 24
    .line 25
    invoke-virtual {v4, v6}, Ljava/lang/String;->codePointAt(I)I

    .line 26
    .line 27
    .line 28
    move-result v7

    .line 29
    iget-boolean v8, v0, La/bp;->d:Z

    .line 30
    .line 31
    const/16 v9, 0x25

    .line 32
    .line 33
    const/16 v10, 0x2f

    .line 34
    .line 35
    const/4 v11, -0x1

    .line 36
    const-string v12, " \"<>^`{}|\\?#"

    .line 37
    .line 38
    const/16 v13, 0x7f

    .line 39
    .line 40
    const/16 v14, 0x20

    .line 41
    .line 42
    if-lt v7, v14, :cond_1

    .line 43
    .line 44
    if-ge v7, v13, :cond_1

    .line 45
    .line 46
    invoke-virtual {v12, v7}, Ljava/lang/String;->indexOf(I)I

    .line 47
    .line 48
    .line 49
    move-result v15

    .line 50
    if-ne v15, v11, :cond_1

    .line 51
    .line 52
    if-nez v8, :cond_0

    .line 53
    .line 54
    if-eq v7, v10, :cond_1

    .line 55
    .line 56
    if-ne v7, v9, :cond_0

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_0
    invoke-static {v7}, Ljava/lang/Character;->charCount(I)I

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    add-int/2addr v6, v7

    .line 64
    goto :goto_0

    .line 65
    :cond_1
    :goto_1
    new-instance v7, La/WI;

    .line 66
    .line 67
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v7, v2, v6, v4}, La/WI;->nA(IILjava/lang/String;)V

    .line 71
    .line 72
    .line 73
    const/4 v2, 0x0

    .line 74
    :goto_2
    if-ge v6, v5, :cond_7

    .line 75
    .line 76
    invoke-virtual {v4, v6}, Ljava/lang/String;->codePointAt(I)I

    .line 77
    .line 78
    .line 79
    move-result v15

    .line 80
    if-eqz v8, :cond_2

    .line 81
    .line 82
    const/16 v9, 0x9

    .line 83
    .line 84
    if-eq v15, v9, :cond_4

    .line 85
    .line 86
    const/16 v9, 0xa

    .line 87
    .line 88
    if-eq v15, v9, :cond_4

    .line 89
    .line 90
    const/16 v9, 0xc

    .line 91
    .line 92
    if-eq v15, v9, :cond_4

    .line 93
    .line 94
    const/16 v9, 0xd

    .line 95
    .line 96
    if-ne v15, v9, :cond_2

    .line 97
    .line 98
    goto :goto_3

    .line 99
    :cond_2
    if-lt v15, v14, :cond_5

    .line 100
    .line 101
    if-ge v15, v13, :cond_5

    .line 102
    .line 103
    invoke-virtual {v12, v15}, Ljava/lang/String;->indexOf(I)I

    .line 104
    .line 105
    .line 106
    move-result v9

    .line 107
    if-ne v9, v11, :cond_5

    .line 108
    .line 109
    if-nez v8, :cond_3

    .line 110
    .line 111
    if-eq v15, v10, :cond_5

    .line 112
    .line 113
    const/16 v9, 0x25

    .line 114
    .line 115
    if-ne v15, v9, :cond_3

    .line 116
    .line 117
    goto :goto_4

    .line 118
    :cond_3
    invoke-virtual {v7, v15}, La/WI;->Vy(I)V

    .line 119
    .line 120
    .line 121
    :cond_4
    :goto_3
    const/16 v11, 0x25

    .line 122
    .line 123
    goto :goto_6

    .line 124
    :cond_5
    :goto_4
    if-nez v2, :cond_6

    .line 125
    .line 126
    new-instance v2, La/WI;

    .line 127
    .line 128
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 129
    .line 130
    .line 131
    :cond_6
    invoke-virtual {v2, v15}, La/WI;->Vy(I)V

    .line 132
    .line 133
    .line 134
    :goto_5
    invoke-virtual {v2}, La/WI;->b()Z

    .line 135
    .line 136
    .line 137
    move-result v9

    .line 138
    if-nez v9, :cond_4

    .line 139
    .line 140
    invoke-virtual {v2}, La/WI;->eH()B

    .line 141
    .line 142
    .line 143
    move-result v9

    .line 144
    and-int/lit16 v10, v9, 0xff

    .line 145
    .line 146
    const/16 v11, 0x25

    .line 147
    .line 148
    invoke-virtual {v7, v11}, La/WI;->cS(I)V

    .line 149
    .line 150
    .line 151
    sget-object v16, La/Y8;->T:[C

    .line 152
    .line 153
    shr-int/lit8 v10, v10, 0x4

    .line 154
    .line 155
    and-int/lit8 v10, v10, 0xf

    .line 156
    .line 157
    aget-char v10, v16, v10

    .line 158
    .line 159
    invoke-virtual {v7, v10}, La/WI;->cS(I)V

    .line 160
    .line 161
    .line 162
    and-int/lit8 v9, v9, 0xf

    .line 163
    .line 164
    aget-char v9, v16, v9

    .line 165
    .line 166
    invoke-virtual {v7, v9}, La/WI;->cS(I)V

    .line 167
    .line 168
    .line 169
    const/16 v10, 0x2f

    .line 170
    .line 171
    const/4 v11, -0x1

    .line 172
    goto :goto_5

    .line 173
    :goto_6
    invoke-static {v15}, Ljava/lang/Character;->charCount(I)I

    .line 174
    .line 175
    .line 176
    move-result v9

    .line 177
    add-int/2addr v6, v9

    .line 178
    move v9, v11

    .line 179
    const/16 v10, 0x2f

    .line 180
    .line 181
    const/4 v11, -0x1

    .line 182
    goto :goto_2

    .line 183
    :cond_7
    invoke-virtual {v7}, La/WI;->VQ()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    goto :goto_7

    .line 188
    :cond_8
    move-object v2, v4

    .line 189
    :goto_7
    iget-object v5, v1, La/Y8;->p:Ljava/lang/String;

    .line 190
    .line 191
    new-instance v6, Ljava/lang/StringBuilder;

    .line 192
    .line 193
    const-string v7, "{"

    .line 194
    .line 195
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 199
    .line 200
    .line 201
    const-string v3, "}"

    .line 202
    .line 203
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v3

    .line 210
    invoke-virtual {v5, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    sget-object v3, La/Y8;->m:Ljava/util/regex/Pattern;

    .line 215
    .line 216
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 217
    .line 218
    .line 219
    move-result-object v3

    .line 220
    invoke-virtual {v3}, Ljava/util/regex/Matcher;->matches()Z

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    if-nez v3, :cond_9

    .line 225
    .line 226
    iput-object v2, v1, La/Y8;->p:Ljava/lang/String;

    .line 227
    .line 228
    return-void

    .line 229
    :cond_9
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 230
    .line 231
    const-string v2, "@Path parameters shouldn\'t perform path traversal (\'.\' or \'..\'): "

    .line 232
    .line 233
    invoke-virtual {v2, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    throw v1

    .line 241
    :cond_a
    new-instance v1, Ljava/lang/AssertionError;

    .line 242
    .line 243
    invoke-direct {v1}, Ljava/lang/AssertionError;-><init>()V

    .line 244
    .line 245
    .line 246
    throw v1

    .line 247
    :cond_b
    const-string v1, "Path parameter \""

    .line 248
    .line 249
    const-string v4, "\" value must not be null."

    .line 250
    .line 251
    invoke-static {v1, v3, v4}, La/zq;->I(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v1

    .line 255
    new-array v2, v2, [Ljava/lang/Object;

    .line 256
    .line 257
    iget-object v3, v0, La/bp;->K:Ljava/lang/reflect/Method;

    .line 258
    .line 259
    iget v4, v0, La/bp;->R:I

    .line 260
    .line 261
    invoke-static {v3, v4, v1, v2}, La/A8;->G(Ljava/lang/reflect/Method;ILjava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    .line 262
    .line 263
    .line 264
    move-result-object v1

    .line 265
    throw v1
.end method
