.class public final Lcom/topjohnwu/magisk/ui/flash/FlashFragment;
.super La/zZ;
.source "SourceFile"

# interfaces
.implements La/We;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/zi;",
        ">;",
        "La/We;"
    }
.end annotation


# static fields
.field public static final synthetic lI:I


# instance fields
.field public Pb:I

.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c0034

    iput v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->y6:I

    new-instance v0, La/Vn;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->xF:La/Y0;

    const/4 v0, -0x1

    iput v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->Pb:I

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 4

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const v1, 0x7f120055

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(I)V

    .line 14
    .line 15
    .line 16
    :cond_0
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v0, v0, La/Rp;->f:La/bc;

    .line 21
    .line 22
    new-instance v1, La/HY;

    .line 23
    .line 24
    const/16 v2, 0x8

    .line 25
    .line 26
    invoke-direct {v1, v2, p0}, La/HY;-><init>(ILjava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    new-instance v2, La/Do;

    .line 30
    .line 31
    const/4 v3, 0x4

    .line 32
    invoke-direct {v2, v3, v1}, La/Do;-><init>(ILa/nY;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0, p0, v2}, Landroidx/lifecycle/h;->i(La/RH;La/yb;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final bridge synthetic F9(Landroidx/databinding/w;)V
    .locals 0

    .line 1
    check-cast p1, La/zi;

    return-void
.end method

.method public final FL()Landroid/view/View;
    .locals 2

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    move-object v0, v1

    .line 8
    :goto_0
    check-cast v0, La/zi;

    .line 9
    .line 10
    iget-object v0, v0, La/zi;->n:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    move-object v1, v0

    .line 23
    :cond_1
    check-cast v1, La/zi;

    .line 24
    .line 25
    iget-object v1, v1, La/zi;->n:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    .line 26
    .line 27
    :cond_2
    return-object v1
.end method

.method public final synthetic O(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->y6:I

    return v0
.end method

.method public final U()V
    .locals 2

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->Pb:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p0}, La/zZ;->G()La/o5;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget v1, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->Pb:I

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    :cond_1
    :goto_0
    const/4 v0, 0x1

    iput-boolean v0, p0, La/zr;->r:Z

    return-void
.end method

.method public final bridge synthetic V()La/hb;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    move-result-object v0

    return-object v0
.end method

.method public final X(Landroid/view/MenuItem;)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    const v1, 0x7f090051

    .line 13
    .line 14
    .line 15
    if-ne p1, v1, :cond_0

    .line 16
    .line 17
    new-instance p1, La/a8;

    .line 18
    .line 19
    const/4 v1, 0x6

    .line 20
    invoke-direct {p1, v0, v1, v0}, La/a8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    const-string v1, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 24
    .line 25
    invoke-virtual {v0, v1, p1}, La/hb;->K(Ljava/lang/String;La/nY;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    const/4 p1, 0x1

    .line 29
    return p1
.end method

.method public final Y(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, La/zZ;->Y(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iget-object v0, p0, La/zr;->f:Landroid/os/Bundle;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-static {v0}, La/Qr;->W(Landroid/os/Bundle;)La/ED;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p1, La/Rp;->F:La/ED;

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    new-instance v0, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    const-string v1, "Fragment "

    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, " does not have any arguments."

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw p1
.end method

.method public final synthetic e(Landroid/view/Menu;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final eH()La/Rp;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->xF:La/Y0;

    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/Rp;

    return-object v0
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, La/zZ;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/app/Activity;->getRequestedOrientation()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 p1, -0x1

    .line 16
    :goto_0
    iput p1, p0, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->Pb:I

    .line 17
    .line 18
    invoke-virtual {p0}, La/zZ;->G()La/o5;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    if-nez p1, :cond_1

    .line 23
    .line 24
    goto :goto_1

    .line 25
    :cond_1
    const/4 v0, 0x5

    .line 26
    invoke-virtual {p1, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 27
    .line 28
    .line 29
    :goto_1
    if-nez p2, :cond_3

    .line 30
    .line 31
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    iget-object p2, p1, La/Rp;->F:La/ED;

    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    if-eqz p2, :cond_2

    .line 39
    .line 40
    goto :goto_2

    .line 41
    :cond_2
    move-object p2, v0

    .line 42
    :goto_2
    iget-object v1, p2, La/ED;->w:Ljava/lang/String;

    .line 43
    .line 44
    invoke-static {p1}, La/rE;->mh(La/AZ;)La/wE;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    new-instance v3, La/HJ;

    .line 49
    .line 50
    iget-object p2, p2, La/ED;->h:Landroid/net/Uri;

    .line 51
    .line 52
    invoke-direct {v3, v1, p2, p1, v0}, La/HJ;-><init>(Ljava/lang/String;Landroid/net/Uri;La/Rp;La/hu;)V

    .line 53
    .line 54
    .line 55
    const/4 p1, 0x3

    .line 56
    invoke-static {v2, v0, v3, p1}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 57
    .line 58
    .line 59
    :cond_3
    return-void
.end method

.method public final p(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 1

    .line 1
    const v0, 0x7f0e0002

    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    return-void
.end method

.method public final p7(Landroid/view/KeyEvent;)Z
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result p1

    const/16 v0, 0x18

    if-eq p1, v0, :cond_0

    const/16 v0, 0x19

    if-eq p1, v0, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    :goto_0
    return p1
.end method

.method public final rC()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/ui/flash/FlashFragment;->eH()La/Rp;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, La/Rp;->l:La/kK;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/lifecycle/h;->e()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-static {v0, v1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const/4 v0, 0x1

    .line 20
    return v0

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    return v0
.end method

.method public final rV()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    :goto_0
    check-cast v0, La/zi;

    .line 8
    .line 9
    iget-object v0, v0, La/zi;->C:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    .line 10
    .line 11
    return-object v0
.end method
