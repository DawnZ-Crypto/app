.class public final La/IH;
.super Ljava/lang/RuntimeException;
.source "SourceFile"


# instance fields
.field public K:Ljava/io/IOException;

.field public final X:Ljava/io/IOException;


# direct methods
.method public constructor <init>(Ljava/io/IOException;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    iput-object p1, p0, La/IH;->X:Ljava/io/IOException;

    iput-object p1, p0, La/IH;->K:Ljava/io/IOException;

    return-void
.end method
