.class public final La/ph;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/FH;


# instance fields
.field public final synthetic K:La/pv;


# direct methods
.method public constructor <init>(La/pv;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/ph;->K:La/pv;

    const/4 p1, 0x4

    invoke-direct {p0, p1}, La/ig;-><init>(I)V

    return-void
.end method
