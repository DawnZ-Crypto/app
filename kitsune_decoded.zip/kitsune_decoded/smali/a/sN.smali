.class public final La/sN;
.super La/ig;
.source "SourceFile"

# interfaces
.implements La/nY;


# instance fields
.field public final synthetic K:I

.field public final synthetic L:La/nE;

.field public final synthetic R:La/f7;


# direct methods
.method public synthetic constructor <init>(La/f7;La/nE;I)V
    .locals 0

    .line 1
    iput p3, p0, La/sN;->K:I

    .line 2
    .line 3
    iput-object p1, p0, La/sN;->R:La/f7;

    .line 4
    .line 5
    iput-object p2, p0, La/sN;->L:La/nE;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, La/ig;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final V(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, La/rr;->w:La/rr;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object v3, p0, La/sN;->L:La/nE;

    .line 6
    .line 7
    iget-object v4, p0, La/sN;->R:La/f7;

    .line 8
    .line 9
    iget v5, p0, La/sN;->K:I

    .line 10
    .line 11
    packed-switch v5, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    check-cast p1, La/kj;

    .line 15
    .line 16
    invoke-virtual {p0, p1}, La/sN;->h(La/kj;)V

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_0
    check-cast p1, Landroid/content/DialogInterface;

    .line 21
    .line 22
    packed-switch v5, :pswitch_data_1

    .line 23
    .line 24
    .line 25
    invoke-static {v4, v3, v2}, La/f7;->rZ(La/f7;La/nE;Z)V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :pswitch_1
    invoke-static {v4, v3, v1}, La/f7;->rZ(La/f7;La/nE;Z)V

    .line 30
    .line 31
    .line 32
    :goto_0
    return-object v0

    .line 33
    :pswitch_2
    check-cast p1, La/kj;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, La/sN;->h(La/kj;)V

    .line 36
    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_3
    check-cast p1, Landroid/content/DialogInterface;

    .line 40
    .line 41
    packed-switch v5, :pswitch_data_2

    .line 42
    .line 43
    .line 44
    invoke-static {v4, v3, v2}, La/f7;->rZ(La/f7;La/nE;Z)V

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :pswitch_4
    invoke-static {v4, v3, v1}, La/f7;->rZ(La/f7;La/nE;Z)V

    .line 49
    .line 50
    .line 51
    :goto_1
    return-object v0

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_0
    .end packed-switch

    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_4
    .end packed-switch
.end method

.method public final h(La/kj;)V
    .locals 4

    .line 1
    iget v0, p0, La/sN;->K:I

    .line 2
    .line 3
    iget-object v1, p0, La/sN;->R:La/f7;

    .line 4
    .line 5
    iget-object v2, p0, La/sN;->L:La/nE;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    const v0, 0x7f12006e

    .line 11
    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p1, v0}, La/kj;->X(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    new-instance v0, La/sN;

    .line 21
    .line 22
    const/4 v3, 0x2

    .line 23
    invoke-direct {v0, v1, v2, v3}, La/sN;-><init>(La/f7;La/nE;I)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p1, La/kj;->f:La/nY;

    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_0
    const v0, 0x7f120040

    .line 30
    .line 31
    .line 32
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {p1, v0}, La/kj;->X(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    new-instance v0, La/sN;

    .line 40
    .line 41
    const/4 v3, 0x0

    .line 42
    invoke-direct {v0, v1, v2, v3}, La/sN;-><init>(La/f7;La/nE;I)V

    .line 43
    .line 44
    .line 45
    iput-object v0, p1, La/kj;->f:La/nY;

    .line 46
    .line 47
    return-void

    .line 48
    nop

    .line 49
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
