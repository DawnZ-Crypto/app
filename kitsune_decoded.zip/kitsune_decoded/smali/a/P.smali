.class public interface abstract La/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/m;
.implements La/J7;


# virtual methods
.method public abstract e()Ljava/io/InputStream;
.end method
