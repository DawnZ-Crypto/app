.class public interface abstract La/Dy;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final h:La/H;

.field public static final w:La/H;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/H;

    const-string v1, "0.4.0.127.0.15.1.1.13.0"

    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    sput-object v0, La/Dy;->w:La/H;

    new-instance v0, La/H;

    const-string v1, "0.4.0.127.0.15.1.1.14.0"

    invoke-direct {v0, v1}, La/H;-><init>(Ljava/lang/String;)V

    sput-object v0, La/Dy;->h:La/H;

    return-void
.end method
