.class public Lcom/topjohnwu/magisk/core/App;
.super Landroid/app/Application;
.source "SourceFile"


# static fields
.field public static final synthetic X:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    sget-object v0, La/wL;->w:La/pd;

    new-instance v1, La/oP;

    invoke-direct {v1}, La/oP;-><init>()V

    invoke-virtual {v0, v1}, La/pd;->O(La/oP;)V

    new-instance v0, La/Vi;

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 5

    invoke-direct {p0}, Lcom/topjohnwu/magisk/core/App;-><init>()V

    new-instance v0, La/sR;

    invoke-direct {v0, p1}, La/sR;-><init>(Ljava/lang/Object;)V

    iget-object p1, v0, La/sR;->K:Ljava/lang/Object;

    check-cast p1, [Ljava/lang/Object;

    const/4 v1, 0x1

    .line 3
    aget-object p1, p1, v1

    check-cast p1, Ljava/util/Map;

    const-class v1, La/uM;

    .line 4
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v0, La/sR;->K:Ljava/lang/Object;

    check-cast v3, [Ljava/lang/Object;

    const/4 v4, 0x2

    .line 5
    aget-object v3, v3, v4

    check-cast v3, Ljava/lang/Class;

    .line 6
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {p1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, v0, La/sR;->K:Ljava/lang/Object;

    check-cast p1, [Ljava/lang/Object;

    .line 7
    aput-object v1, p1, v4

    .line 8
    sput-object v0, La/Mv;->h:La/sR;

    return-void
.end method


# virtual methods
.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 8

    .line 1
    instance-of v0, p1, Landroid/app/Application;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p1, Landroid/app/Application;

    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, La/A8;->l(Landroid/content/Context;)Ljava/io/File;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sput-object v1, La/C8;->w:Ljava/lang/String;

    .line 20
    .line 21
    move-object v7, v0

    .line 22
    move-object v0, p1

    .line 23
    move-object p1, v7

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageResourcePath()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    sput-object v0, La/C8;->w:Ljava/lang/String;

    .line 30
    .line 31
    move-object v0, p0

    .line 32
    :goto_0
    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    .line 33
    .line 34
    .line 35
    sput-object p1, La/uv;->w:Landroid/content/Context;

    .line 36
    .line 37
    sget-object v1, La/dO;->w:La/dO;

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 40
    .line 41
    .line 42
    new-instance v0, La/q4;

    .line 43
    .line 44
    invoke-direct {v0}, La/q4;-><init>()V

    .line 45
    .line 46
    .line 47
    const/4 v1, 0x2

    .line 48
    iput v1, v0, La/q4;->h:I

    .line 49
    .line 50
    const-class v2, La/ps;

    .line 51
    .line 52
    const/4 v3, 0x1

    .line 53
    new-array v4, v3, [La/ps;

    .line 54
    .line 55
    iput-object v4, v0, La/q4;->p:[La/ps;

    .line 56
    .line 57
    const/4 v4, 0x0

    .line 58
    :try_start_0
    new-array v5, v4, [Ljava/lang/Class;

    .line 59
    .line 60
    invoke-virtual {v2, v5}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    invoke-virtual {v2, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 65
    .line 66
    .line 67
    iget-object v5, v0, La/q4;->p:[La/ps;

    .line 68
    .line 69
    new-array v6, v4, [Ljava/lang/Object;

    .line 70
    .line 71
    invoke-virtual {v2, v6}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    check-cast v2, La/ps;

    .line 76
    .line 77
    aput-object v2, v5, v4
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    .line 78
    .line 79
    goto :goto_2

    .line 80
    :catch_0
    move-exception v2

    .line 81
    goto :goto_1

    .line 82
    :catch_1
    move-exception v2

    .line 83
    :goto_1
    const-string v5, "LIBSU"

    .line 84
    .line 85
    invoke-static {v5, v2}, La/rE;->s(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 86
    .line 87
    .line 88
    :goto_2
    instance-of v2, p1, Landroid/content/ContextWrapper;

    .line 89
    .line 90
    if-eqz v2, :cond_1

    .line 91
    .line 92
    check-cast p1, Landroid/content/ContextWrapper;

    .line 93
    .line 94
    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    goto :goto_2

    .line 99
    :cond_1
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    if-eqz v2, :cond_2

    .line 104
    .line 105
    move-object p1, v2

    .line 106
    :cond_2
    :goto_3
    nop

    .line 107
    instance-of v2, p1, Landroid/content/ContextWrapper;

    .line 108
    .line 109
    if-eqz v2, :cond_3

    .line 110
    .line 111
    check-cast p1, Landroid/content/ContextWrapper;

    .line 112
    .line 113
    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    goto :goto_3

    .line 118
    :cond_3
    sput-object p1, La/rE;->p:Landroid/content/Context;

    .line 119
    .line 120
    const-wide/16 v5, 0x2

    .line 121
    .line 122
    iput-wide v5, v0, La/q4;->w:J

    .line 123
    .line 124
    sget-object p1, La/Id;->X:Ljava/util/concurrent/ExecutorService;

    .line 125
    .line 126
    const-class p1, La/rx;

    .line 127
    .line 128
    monitor-enter p1

    .line 129
    :try_start_1
    sget-boolean v2, La/rx;->h:Z

    .line 130
    .line 131
    if-nez v2, :cond_8

    .line 132
    .line 133
    invoke-static {}, La/rx;->U()La/WD;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    if-nez v2, :cond_8

    .line 138
    .line 139
    sput-object v0, La/rx;->p:La/q4;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 140
    .line 141
    monitor-exit p1

    .line 142
    new-instance p1, La/mW;

    .line 143
    .line 144
    sget-object v0, La/Th;->h:La/Zs;

    .line 145
    .line 146
    invoke-direct {p1, v0}, La/mW;-><init>(La/Zs;)V

    .line 147
    .line 148
    .line 149
    sput-object p1, La/Id;->X:Ljava/util/concurrent/ExecutorService;

    .line 150
    .line 151
    sget-object p1, La/uM;->e:La/zU;

    .line 152
    .line 153
    new-instance v0, Landroid/content/Intent;

    .line 154
    .line 155
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 156
    .line 157
    .line 158
    const-class v2, La/uM;

    .line 159
    .line 160
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    invoke-static {v2, v5}, La/C8;->h(Ljava/lang/Class;Ljava/lang/String;)Landroid/content/ComponentName;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    sget-object v2, La/rT;->h:La/fW;

    .line 173
    .line 174
    sget-object v5, La/hN;->X:La/hN;

    .line 175
    .line 176
    invoke-static {v0, v2, v5}, La/Er;->p(Landroid/content/Intent;Ljava/util/concurrent/Executor;Landroid/content/ServiceConnection;)La/iX;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 181
    .line 182
    .line 183
    invoke-static {v0}, La/uM;->l(La/iX;)V

    .line 184
    .line 185
    .line 186
    new-instance p1, La/TD;

    .line 187
    .line 188
    invoke-direct {p1, v1}, La/TD;-><init>(I)V

    .line 189
    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    invoke-static {v0, p1}, La/rx;->Y(Ljava/util/concurrent/ExecutorService;La/QM;)V

    .line 193
    .line 194
    .line 195
    invoke-static {}, La/UD;->w()V

    .line 196
    .line 197
    .line 198
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    invoke-static {}, La/rx;->Pc()Z

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    if-eqz v2, :cond_5

    .line 207
    .line 208
    sget-object v2, La/C8;->w:Ljava/lang/String;

    .line 209
    .line 210
    if-eqz v2, :cond_4

    .line 211
    .line 212
    goto :goto_4

    .line 213
    :cond_4
    move-object v2, v0

    .line 214
    :goto_4
    invoke-static {p1, v2}, La/C8;->w(Landroid/content/res/Resources;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    :cond_5
    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 218
    .line 219
    .line 220
    move-result-object v2

    .line 221
    sget-object v5, La/UD;->w:Ljava/util/Locale;

    .line 222
    .line 223
    invoke-virtual {v2, v5}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 227
    .line 228
    .line 229
    move-result-object v5

    .line 230
    invoke-virtual {p1, v2, v5}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    .line 231
    .line 232
    .line 233
    sget-object p1, La/Ed;->w:La/Yi;

    .line 234
    .line 235
    sget-object p1, La/uv;->w:Landroid/content/Context;

    .line 236
    .line 237
    if-eqz p1, :cond_6

    .line 238
    .line 239
    move-object v0, p1

    .line 240
    :cond_6
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 241
    .line 242
    const/16 v2, 0x1a

    .line 243
    .line 244
    if-lt p1, v2, :cond_7

    .line 245
    .line 246
    invoke-static {}, La/p;->m()V

    .line 247
    .line 248
    .line 249
    const p1, 0x7f1201a1

    .line 250
    .line 251
    .line 252
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    invoke-static {p1}, La/p;->p(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    invoke-static {}, La/p;->m()V

    .line 261
    .line 262
    .line 263
    const v2, 0x7f120108

    .line 264
    .line 265
    .line 266
    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v2

    .line 270
    invoke-static {v2}, La/p;->z(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 271
    .line 272
    .line 273
    move-result-object v2

    .line 274
    invoke-static {}, La/p;->m()V

    .line 275
    .line 276
    .line 277
    const v5, 0x7f1201a2

    .line 278
    .line 279
    .line 280
    invoke-virtual {v0, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-static {v0}, La/p;->Y(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    invoke-static {}, La/Ed;->w()Landroid/app/NotificationManager;

    .line 289
    .line 290
    .line 291
    move-result-object v5

    .line 292
    const/4 v6, 0x3

    .line 293
    new-array v6, v6, [Landroid/app/NotificationChannel;

    .line 294
    .line 295
    aput-object p1, v6, v4

    .line 296
    .line 297
    aput-object v2, v6, v3

    .line 298
    .line 299
    aput-object v0, v6, v1

    .line 300
    .line 301
    invoke-static {v6}, La/rE;->NE([Ljava/lang/Object;)Ljava/util/List;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    invoke-static {v5, p1}, La/p;->K(Landroid/app/NotificationManager;Ljava/util/List;)V

    .line 306
    .line 307
    .line 308
    :cond_7
    return-void

    .line 309
    :catchall_0
    move-exception v0

    .line 310
    goto :goto_5

    .line 311
    :cond_8
    :try_start_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 312
    .line 313
    const-string v1, "The main shell was already created"

    .line 314
    .line 315
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 316
    .line 317
    .line 318
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 319
    :goto_5
    monitor-exit p1

    .line 320
    throw v0
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0, p1}, Landroid/content/res/Configuration;->diff(Landroid/content/res/Configuration;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sget-object v1, La/UD;->w:Ljava/util/Locale;

    .line 20
    .line 21
    invoke-virtual {p1, v1}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, p1, v1}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    invoke-static {}, La/rx;->Pc()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_1

    .line 36
    .line 37
    invoke-super {p0, p1}, Landroid/app/Application;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    return-void
.end method

.method public final onCreate()V
    .locals 8

    .line 1
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 2
    .line 3
    .line 4
    sget-object v0, La/tn;->w:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Landroid/app/Application;

    .line 19
    .line 20
    new-instance v2, La/am;

    .line 21
    .line 22
    invoke-direct {v2}, La/am;-><init>()V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v2}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    sget-object v0, La/pL;->q:La/pL;

    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    new-instance v2, Landroid/os/Handler;

    .line 34
    .line 35
    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object v2, v0, La/pL;->d:Landroid/os/Handler;

    .line 39
    .line 40
    iget-object v2, v0, La/pL;->f:Landroidx/lifecycle/w;

    .line 41
    .line 42
    sget-object v3, La/cw;->ON_CREATE:La/cw;

    .line 43
    .line 44
    invoke-virtual {v2, v3}, Landroidx/lifecycle/w;->i(La/cw;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    check-cast v2, Landroid/app/Application;

    .line 52
    .line 53
    new-instance v3, La/mV;

    .line 54
    .line 55
    invoke-direct {v3, v0}, La/mV;-><init>(La/pL;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v3}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 59
    .line 60
    .line 61
    new-instance v0, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;

    .line 62
    .line 63
    invoke-direct {v0, p0}, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;-><init>(Landroid/content/Context;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0}, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;->O()V

    .line 67
    .line 68
    .line 69
    invoke-static {}, La/rx;->Pc()Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    if-nez v0, :cond_6

    .line 74
    .line 75
    sget-object v0, La/Th;->h:La/Zs;

    .line 76
    .line 77
    new-instance v2, La/DX;

    .line 78
    .line 79
    const/4 v3, 0x0

    .line 80
    invoke-direct {v2, p0, v3}, La/DX;-><init>(Lcom/topjohnwu/magisk/core/App;La/hu;)V

    .line 81
    .line 82
    .line 83
    const/4 v4, 0x2

    .line 84
    and-int/2addr v4, v1

    .line 85
    sget-object v5, La/nZ;->X:La/nZ;

    .line 86
    .line 87
    if-eqz v4, :cond_1

    .line 88
    .line 89
    move-object v0, v5

    .line 90
    :cond_1
    const/4 v4, 0x2

    .line 91
    and-int v6, v4, v4

    .line 92
    .line 93
    if-eqz v6, :cond_2

    .line 94
    .line 95
    move v6, v1

    .line 96
    goto :goto_1

    .line 97
    :cond_2
    const/4 v6, 0x0

    .line 98
    :goto_1
    invoke-static {v5, v0, v1}, La/rE;->n(La/oj;La/oj;Z)La/oj;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    sget-object v5, La/Th;->w:La/Fu;

    .line 103
    .line 104
    if-eq v0, v5, :cond_3

    .line 105
    .line 106
    sget-object v7, La/Qr;->K:La/Qr;

    .line 107
    .line 108
    invoke-interface {v0, v7}, La/oj;->f(La/sE;)La/ol;

    .line 109
    .line 110
    .line 111
    move-result-object v7

    .line 112
    if-nez v7, :cond_3

    .line 113
    .line 114
    invoke-interface {v0, v5}, La/oj;->I(La/oj;)La/oj;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    :cond_3
    if-eqz v6, :cond_5

    .line 119
    .line 120
    if-ne v6, v4, :cond_4

    .line 121
    .line 122
    new-instance v1, La/lc;

    .line 123
    .line 124
    invoke-direct {v1, v0, v2}, La/lc;-><init>(La/oj;La/Wb;)V

    .line 125
    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_4
    new-instance v3, La/ve;

    .line 129
    .line 130
    invoke-direct {v3, v0, v1}, La/N;-><init>(La/oj;Z)V

    .line 131
    .line 132
    .line 133
    move-object v1, v3

    .line 134
    :goto_2
    invoke-virtual {v1, v6, v1, v2}, La/N;->Z(ILa/N;La/Wb;)V

    .line 135
    .line 136
    .line 137
    goto :goto_3

    .line 138
    :cond_5
    throw v3

    .line 139
    :cond_6
    :goto_3
    return-void
.end method
