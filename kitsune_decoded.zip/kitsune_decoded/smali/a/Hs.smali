.class public final La/Hs;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final I:La/Hs;

.field public static final M:La/Hs;

.field public static final O:La/Hs;

.field public static final Q:La/Hs;

.field public static final T:La/Hs;

.field public static final V:La/Hs;

.field public static final X:La/Hs;

.field public static final i:La/Hs;


# instance fields
.field public final e:La/Fl;

.field public final h:I

.field public final p:Ljava/lang/Class;

.field public final w:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 21

    .line 1
    new-instance v0, La/Hs;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->i:La/Hs;

    new-instance v0, La/Hs;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/16 v2, 0x40

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/16 v2, 0x80

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/16 v2, 0x100

    const-class v3, La/xK;

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v0, La/Hs;

    const/16 v2, 0x200

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v0, La/Hs;

    const/16 v2, 0x400

    const-class v3, La/ID;

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v0, La/Hs;

    const/16 v2, 0x800

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v0, La/Hs;

    const/16 v2, 0x1000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->Q:La/Hs;

    new-instance v0, La/Hs;

    const/16 v2, 0x2000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->X:La/Hs;

    new-instance v0, La/Hs;

    const/16 v2, 0x4000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const v2, 0x8000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/high16 v2, 0x10000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    new-instance v0, La/Hs;

    const/high16 v2, 0x20000

    const-class v3, La/cC;

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v0, La/Hs;

    const/high16 v2, 0x40000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->O:La/Hs;

    new-instance v0, La/Hs;

    const/high16 v2, 0x80000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->V:La/Hs;

    new-instance v0, La/Hs;

    const/high16 v2, 0x100000

    invoke-direct {v0, v2}, La/Hs;-><init>(I)V

    sput-object v0, La/Hs;->I:La/Hs;

    new-instance v0, La/Hs;

    const/high16 v2, 0x200000

    const-class v3, La/OS;

    invoke-direct {v0, v2, v3}, La/Hs;-><init>(ILjava/lang/Class;)V

    new-instance v4, La/Hs;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sget-object v5, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SHOW_ON_SCREEN:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v6, 0x1020036

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v4 .. v9}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v10, La/Hs;

    sget-object v11, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_TO_POSITION:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v12, 0x1020037

    const/4 v13, 0x0

    const/4 v14, 0x0

    const-class v15, La/Ek;

    invoke-direct/range {v10 .. v15}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v8, La/Hs;

    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_UP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v4, 0x1020038

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, v8

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    sput-object v8, La/Hs;->M:La/Hs;

    new-instance v9, La/Hs;

    sget-object v10, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_LEFT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v11, 0x1020039

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v8, La/Hs;

    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_DOWN:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v4, 0x102003a

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, v8

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    sput-object v8, La/Hs;->T:La/Hs;

    new-instance v9, La/Hs;

    sget-object v10, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_RIGHT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v11, 0x102003b

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    const/4 v8, 0x0

    const/16 v9, 0x1d

    if-lt v0, v9, :cond_0

    invoke-static {}, La/an;->I()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    goto :goto_0

    :cond_0
    move-object v3, v8

    :goto_0
    const v4, 0x1020046

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v10, La/Hs;

    if-lt v0, v9, :cond_1

    invoke-static {}, La/an;->S()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object v11, v2

    goto :goto_1

    :cond_1
    move-object v11, v8

    :goto_1
    const v12, 0x1020047

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-direct/range {v10 .. v15}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    if-lt v0, v9, :cond_2

    invoke-static {}, La/an;->P()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    goto :goto_2

    :cond_2
    move-object v3, v8

    :goto_2
    const v4, 0x1020048

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v10, La/Hs;

    if-lt v0, v9, :cond_3

    invoke-static {}, La/an;->Y()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object v11, v2

    goto :goto_3

    :cond_3
    move-object v11, v8

    :goto_3
    const v12, 0x1020049

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-direct/range {v10 .. v15}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_CONTEXT_CLICK:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    const v4, 0x102003c

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v9, La/Hs;

    const/16 v2, 0x18

    if-lt v0, v2, :cond_4

    invoke-static {}, La/Vm;->X()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object v10, v2

    goto :goto_4

    :cond_4
    move-object v10, v8

    :goto_4
    const v11, 0x102003d

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-class v14, La/Te;

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    const/16 v3, 0x1a

    if-lt v0, v3, :cond_5

    invoke-static {}, La/p;->i()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    goto :goto_5

    :cond_5
    move-object v3, v8

    :goto_5
    const v4, 0x1020042

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-class v7, La/ck;

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v9, La/Hs;

    const/16 v2, 0x1c

    if-lt v0, v2, :cond_6

    invoke-static {}, La/Vy;->O()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    move-object v10, v3

    goto :goto_6

    :cond_6
    move-object v10, v8

    :goto_6
    const v11, 0x1020044

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v15, La/Hs;

    if-lt v0, v2, :cond_7

    invoke-static {}, La/Vy;->R()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object/from16 v16, v2

    goto :goto_7

    :cond_7
    move-object/from16 v16, v8

    :goto_7
    const v17, 0x1020045

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-direct/range {v15 .. v20}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    const/16 v9, 0x1e

    if-lt v0, v9, :cond_8

    invoke-static {}, La/cM;->K()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    goto :goto_8

    :cond_8
    move-object v3, v8

    :goto_8
    const v4, 0x102004a

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v10, La/Hs;

    if-lt v0, v9, :cond_9

    invoke-static {}, La/cM;->P()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object v11, v2

    goto :goto_9

    :cond_9
    move-object v11, v8

    :goto_9
    const v12, 0x1020054

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-direct/range {v10 .. v15}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    if-lt v0, v1, :cond_a

    invoke-static {}, La/N3;->w()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v3

    goto :goto_a

    :cond_a
    move-object v3, v8

    :goto_a
    const v4, 0x1020055

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v9, La/Hs;

    if-lt v0, v1, :cond_b

    invoke-static {}, La/N3;->h()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v2

    move-object v10, v2

    goto :goto_b

    :cond_b
    move-object v10, v8

    :goto_b
    const v11, 0x1020056

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v2, La/Hs;

    if-lt v0, v1, :cond_c

    invoke-static {}, La/N3;->p()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v1

    move-object v3, v1

    goto :goto_c

    :cond_c
    move-object v3, v8

    :goto_c
    const v4, 0x1020057

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v9, La/Hs;

    const/16 v1, 0x21

    if-lt v0, v1, :cond_d

    invoke-static {}, La/AW;->w()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v1

    move-object v10, v1

    goto :goto_d

    :cond_d
    move-object v10, v8

    :goto_d
    const v11, 0x1020058

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v9 .. v14}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    new-instance v1, La/Hs;

    const/16 v2, 0x22

    if-lt v0, v2, :cond_e

    invoke-static {}, La/GI;->w()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    move-result-object v8

    :cond_e
    move-object v2, v8

    const v3, 0x102005e

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct/range {v1 .. v6}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 6

    .line 1
    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    return-void
.end method

.method public constructor <init>(ILjava/lang/Class;)V
    .locals 6

    .line 2
    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    move v2, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, La/Hs;-><init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;ILjava/lang/String;La/Fl;Ljava/lang/Class;)V
    .locals 0

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, La/Hs;->h:I

    iput-object p4, p0, La/Hs;->e:La/Fl;

    if-nez p1, :cond_0

    new-instance p1, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-direct {p1, p2, p3}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;-><init>(ILjava/lang/CharSequence;)V

    :cond_0
    iput-object p1, p0, La/Hs;->w:Ljava/lang/Object;

    iput-object p5, p0, La/Hs;->p:Ljava/lang/Class;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, La/Hs;

    if-nez v1, :cond_1

    return v0

    :cond_1
    check-cast p1, La/Hs;

    iget-object p1, p1, La/Hs;->w:Ljava/lang/Object;

    iget-object v1, p0, La/Hs;->w:Ljava/lang/Object;

    if-nez v1, :cond_2

    if-eqz p1, :cond_3

    return v0

    :cond_2
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    return v0

    :cond_3
    const/4 p1, 0x1

    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, La/Hs;->w:Ljava/lang/Object;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "AccessibilityActionCompat: "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget v1, p0, La/Hs;->h:I

    .line 9
    .line 10
    invoke-static {v1}, La/sH;->e(I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v2, "ACTION_UNKNOWN"

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    iget-object v2, p0, La/Hs;->w:Ljava/lang/Object;

    .line 23
    .line 24
    move-object v3, v2

    .line 25
    check-cast v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 26
    .line 27
    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 34
    .line 35
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    return-object v0
.end method

.method public final w()I
    .locals 1

    .line 1
    iget-object v0, p0, La/Hs;->w:Ljava/lang/Object;

    check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I

    move-result v0

    return v0
.end method
