.class public final La/wo;
.super La/F;
.source "SourceFile"

# interfaces
.implements La/gk;


# instance fields
.field public final K:La/m;

.field public final R:Z

.field public final X:La/H;


# direct methods
.method public constructor <init>(La/H;La/F;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/wo;->X:La/H;

    iput-object p2, p0, La/wo;->K:La/m;

    const/4 p1, 0x1

    if-eqz p2, :cond_1

    invoke-interface {p2}, La/m;->i()La/Y;

    move-result-object p2

    instance-of v0, p2, La/kV;

    if-nez v0, :cond_1

    instance-of v0, p2, La/Dz;

    if-nez v0, :cond_1

    instance-of p2, p2, La/os;

    if-eqz p2, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :cond_1
    :goto_0
    iput-boolean p1, p0, La/wo;->R:Z

    return-void
.end method


# virtual methods
.method public final i()La/Y;
    .locals 6

    .line 1
    new-instance v0, La/y;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, La/y;-><init>(I)V

    .line 5
    .line 6
    .line 7
    iget-object v1, p0, La/wo;->X:La/H;

    .line 8
    .line 9
    invoke-virtual {v0, v1}, La/y;->w(La/m;)V

    .line 10
    .line 11
    .line 12
    iget-boolean v1, p0, La/wo;->R:Z

    .line 13
    .line 14
    iget-object v2, p0, La/wo;->K:La/m;

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    new-instance v3, La/Hj;

    .line 21
    .line 22
    invoke-direct {v3, v2}, La/Hj;-><init>(La/m;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v3}, La/y;->w(La/m;)V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    new-instance v3, La/Gw;

    .line 30
    .line 31
    const/4 v4, 0x1

    .line 32
    const/4 v5, 0x0

    .line 33
    invoke-direct {v3, v4, v5, v2}, La/j;-><init>(ZILa/m;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0, v3}, La/y;->w(La/m;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    :goto_0
    if-eqz v1, :cond_2

    .line 40
    .line 41
    new-instance v1, La/Dz;

    .line 42
    .line 43
    invoke-direct {v1, v0}, La/k;-><init>(La/y;)V

    .line 44
    .line 45
    .line 46
    const/4 v0, -0x1

    .line 47
    iput v0, v1, La/Dz;->R:I

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_2
    new-instance v1, La/MG;

    .line 51
    .line 52
    invoke-direct {v1, v0}, La/k;-><init>(La/y;)V

    .line 53
    .line 54
    .line 55
    :goto_1
    return-object v1
.end method
