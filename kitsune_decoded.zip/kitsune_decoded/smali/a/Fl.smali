.class public interface abstract La/Fl;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract h(Landroid/view/View;)Z
.end method
