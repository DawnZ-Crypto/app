.class public La/ze;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/ys;
.implements La/Wq;
.implements La/Lk;
.implements La/Fl;
.implements La/JJ;
.implements La/mt;


# instance fields
.field public K:Ljava/lang/Object;

.field public final synthetic X:I


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, La/ze;->X:I

    const/4 v0, 0x7

    if-eq p1, v0, :cond_4

    const/16 v0, 0xd

    if-eq p1, v0, :cond_1

    const/16 v0, 0x19

    if-eq p1, v0, :cond_0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void

    .line 2
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    .line 3
    :cond_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1e

    if-lt p1, v0, :cond_2

    new-instance p1, La/Ms;

    invoke-direct {p1}, La/Ms;-><init>()V

    :goto_0
    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    goto :goto_1

    :cond_2
    const/16 v0, 0x1d

    if-lt p1, v0, :cond_3

    new-instance p1, La/JK;

    invoke-direct {p1}, La/JK;-><init>()V

    goto :goto_0

    :cond_3
    new-instance p1, La/MM;

    invoke-direct {p1}, La/MM;-><init>()V

    goto :goto_0

    :goto_1
    return-void

    .line 4
    :cond_4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La/ze;->X:I

    iput-object p2, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(La/TZ;)V
    .locals 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    iput v0, p0, La/ze;->X:I

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(La/VB;)V
    .locals 2

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xd

    iput v0, p0, La/ze;->X:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    new-instance v0, La/Ms;

    invoke-direct {v0, p1}, La/Ms;-><init>(La/VB;)V

    :goto_0
    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    goto :goto_1

    :cond_0
    const/16 v1, 0x1d

    if-lt v0, v1, :cond_1

    new-instance v0, La/JK;

    invoke-direct {v0, p1}, La/JK;-><init>(La/VB;)V

    goto :goto_0

    :cond_1
    new-instance v0, La/MM;

    invoke-direct {v0, p1}, La/MM;-><init>(La/VB;)V

    goto :goto_0

    :goto_1
    return-void
.end method

.method public constructor <init>(La/ZR;)V
    .locals 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    iput v0, p0, La/ze;->X:I

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/ClipData;I)V
    .locals 2

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x9

    iput v0, p0, La/ze;->X:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_0

    new-instance v0, La/Cf;

    invoke-direct {v0, p1, p2}, La/Cf;-><init>(Landroid/content/ClipData;I)V

    :goto_0
    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    goto :goto_1

    :cond_0
    new-instance v0, La/bI;

    invoke-direct {v0, p1, p2}, La/bI;-><init>(Landroid/content/ClipData;I)V

    goto :goto_0

    :goto_1
    return-void
.end method

.method public constructor <init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V
    .locals 2

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xe

    iput v0, p0, La/ze;->X:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x19

    if-lt v0, v1, :cond_0

    new-instance v0, La/Z3;

    invoke-direct {v0, p1, p2, p3}, La/Z3;-><init>(Landroid/net/Uri;Landroid/content/ClipDescription;Landroid/net/Uri;)V

    :goto_0
    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    goto :goto_1

    :cond_0
    new-instance v0, La/yW;

    const/4 v1, 0x6

    invoke-direct {v0, p1, p2, p3, v1}, La/yW;-><init>(Landroid/net/Uri;Ljava/lang/Object;Ljava/lang/Comparable;I)V

    goto :goto_0

    :goto_1
    return-void
.end method

.method public constructor <init>(Landroid/view/ContentInfo;)V
    .locals 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xa

    iput v0, p0, La/ze;->X:I

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    invoke-static {p1}, La/e;->X(Ljava/lang/Object;)Landroid/view/ContentInfo;

    move-result-object p1

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;I)V
    .locals 1

    iput p2, p0, La/ze;->X:I

    const/16 v0, 0x14

    if-eq p2, v0, :cond_1

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1e

    if-lt p2, v0, :cond_0

    new-instance p2, La/zY;

    .line 15
    invoke-direct {p2, p1}, La/lm;-><init>(Landroid/view/View;)V

    iput-object p1, p2, La/zY;->R:Landroid/view/View;

    :goto_0
    iput-object p2, p0, La/ze;->K:Ljava/lang/Object;

    goto :goto_1

    .line 16
    :cond_0
    new-instance p2, La/lm;

    invoke-direct {p2, p1}, La/lm;-><init>(Landroid/view/View;)V

    goto :goto_0

    :goto_1
    return-void

    .line 17
    :cond_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object p1

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 1

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x13

    iput v0, p0, La/ze;->X:I

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getOverlay()Landroid/view/ViewGroupOverlay;

    move-result-object p1

    iput-object p1, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsetsController;)V
    .locals 2

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xc

    iput v0, p0, La/ze;->X:I

    new-instance v0, La/zY;

    const/4 v1, 0x0

    .line 20
    invoke-direct {v0, v1}, La/lm;-><init>(Landroid/view/View;)V

    iput-object p1, v0, La/zY;->L:Landroid/view/WindowInsetsController;

    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10

    iput v0, p0, La/ze;->X:I

    if-eqz p1, :cond_0

    new-instance v0, La/b1;

    invoke-direct {v0, p1}, La/b1;-><init>(Landroid/widget/TextView;)V

    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    return-void

    .line 22
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "textView cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Landroidx/databinding/w;ILjava/lang/ref/ReferenceQueue;)V
    .locals 1

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xf

    iput v0, p0, La/ze;->X:I

    .line 24
    new-instance v0, La/Cj;

    invoke-direct {v0, p1, p2, p0, p3}, La/Cj;-><init>(Landroidx/databinding/w;ILa/Lk;Ljava/lang/ref/ReferenceQueue;)V

    iput-object v0, p0, La/ze;->K:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;)V
    .locals 1

    const/16 v0, 0x17

    iput v0, p0, La/ze;->X:I

    .line 25
    invoke-direct {p0, v0, p1}, La/ze;-><init>(ILjava/lang/Object;)V

    return-void
.end method

.method public static f([Ljava/lang/Object;ILa/oK;)Ljava/lang/Object;
    .locals 10

    .line 1
    and-int/lit8 v0, p1, 0x1

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/16 v0, 0x190

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/16 v0, 0x2bc

    .line 9
    .line 10
    :goto_0
    and-int/lit8 p1, p1, 0x2

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    move p1, v1

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    move p1, v2

    .line 19
    :goto_1
    array-length v3, p0

    .line 20
    const/4 v4, 0x0

    .line 21
    const v5, 0x7fffffff

    .line 22
    .line 23
    .line 24
    move v6, v2

    .line 25
    :goto_2
    if-ge v6, v3, :cond_5

    .line 26
    .line 27
    aget-object v7, p0, v6

    .line 28
    .line 29
    iget v8, p2, La/oK;->X:I

    .line 30
    .line 31
    packed-switch v8, :pswitch_data_0

    .line 32
    .line 33
    .line 34
    move-object v9, v7

    .line 35
    check-cast v9, La/fE;

    .line 36
    .line 37
    iget v9, v9, La/fE;->h:I

    .line 38
    .line 39
    goto :goto_3

    .line 40
    :pswitch_0
    move-object v9, v7

    .line 41
    check-cast v9, La/mn;

    .line 42
    .line 43
    iget v9, v9, La/mn;->p:I

    .line 44
    .line 45
    :goto_3
    sub-int/2addr v9, v0

    .line 46
    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    .line 47
    .line 48
    .line 49
    move-result v9

    .line 50
    mul-int/lit8 v9, v9, 0x2

    .line 51
    .line 52
    packed-switch v8, :pswitch_data_1

    .line 53
    .line 54
    .line 55
    move-object v8, v7

    .line 56
    check-cast v8, La/fE;

    .line 57
    .line 58
    iget-boolean v8, v8, La/fE;->p:Z

    .line 59
    .line 60
    goto :goto_4

    .line 61
    :pswitch_1
    move-object v8, v7

    .line 62
    check-cast v8, La/mn;

    .line 63
    .line 64
    iget-boolean v8, v8, La/mn;->e:Z

    .line 65
    .line 66
    :goto_4
    if-ne v8, p1, :cond_2

    .line 67
    .line 68
    move v8, v2

    .line 69
    goto :goto_5

    .line 70
    :cond_2
    move v8, v1

    .line 71
    :goto_5
    add-int/2addr v9, v8

    .line 72
    if-eqz v4, :cond_3

    .line 73
    .line 74
    if-le v5, v9, :cond_4

    .line 75
    .line 76
    :cond_3
    move-object v4, v7

    .line 77
    move v5, v9

    .line 78
    :cond_4
    add-int/lit8 v6, v6, 0x1

    .line 79
    .line 80
    goto :goto_2

    .line 81
    :cond_5
    return-object v4

    .line 82
    nop

    .line 83
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch
.end method


# virtual methods
.method public final I(La/pY;)V
    .locals 0

    .line 1
    return-void
.end method

.method public K(Landroid/content/Context;La/L2;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    .locals 9

    .line 1
    new-instance v0, La/oK;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, La/oK;-><init>(I)V

    .line 5
    .line 6
    .line 7
    iget-object v2, p2, La/L2;->w:[La/fE;

    .line 8
    .line 9
    invoke-static {v2, p4, v0}, La/ze;->f([Ljava/lang/Object;ILa/oK;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, La/fE;

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    return-object p1

    .line 19
    :cond_0
    iget v8, v0, La/fE;->Q:I

    .line 20
    .line 21
    iget-object v0, v0, La/fE;->w:Ljava/lang/String;

    .line 22
    .line 23
    sget-object v2, La/lA;->w:La/ze;

    .line 24
    .line 25
    move-object v3, p1

    .line 26
    move-object v4, p3

    .line 27
    move v5, v8

    .line 28
    move-object v6, v0

    .line 29
    move v7, p4

    .line 30
    invoke-virtual/range {v2 .. v7}, La/ze;->d(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    if-eqz p1, :cond_1

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-static {p3, v8, v0, v2, p4}, La/lA;->h(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    sget-object p4, La/lA;->h:La/Qe;

    .line 42
    .line 43
    invoke-virtual {p4, p3, p1}, La/Qe;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    :cond_1
    const-string p3, "Could not retrieve font from family."

    .line 47
    .line 48
    const-string p4, "TypefaceCompatBaseImpl"

    .line 49
    .line 50
    const-wide/16 v2, 0x0

    .line 51
    .line 52
    if-nez p1, :cond_2

    .line 53
    .line 54
    :goto_0
    move-wide p3, v2

    .line 55
    goto :goto_2

    .line 56
    :cond_2
    :try_start_0
    const-class v0, Landroid/graphics/Typeface;

    .line 57
    .line 58
    const-string v4, "native_instance"

    .line 59
    .line 60
    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Ljava/lang/Number;

    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 74
    .line 75
    .line 76
    move-result-wide p3
    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    .line 77
    goto :goto_2

    .line 78
    :catch_0
    move-exception v0

    .line 79
    goto :goto_1

    .line 80
    :catch_1
    move-exception v0

    .line 81
    :goto_1
    invoke-static {p4, p3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 82
    .line 83
    .line 84
    goto :goto_0

    .line 85
    :goto_2
    cmp-long v0, p3, v2

    .line 86
    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 92
    .line 93
    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 94
    .line 95
    .line 96
    move-result-object p3

    .line 97
    invoke-virtual {v0, p3, p2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    :cond_3
    return-object p1
.end method

.method public L(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    .locals 1

    .line 1
    invoke-static {p1}, La/cH;->y(Landroid/content/Context;)Ljava/io/File;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    invoke-static {p1, p2}, La/cH;->X(Ljava/io/File;Ljava/io/InputStream;)Z

    move-result p2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez p2, :cond_1

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object v0

    :cond_1
    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/graphics/Typeface;->createFromFile(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object p2
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object p2

    :catchall_0
    move-exception p2

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    throw p2

    :catch_0
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object v0
.end method

.method public final M(La/RH;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final O(La/pY;La/HN;)V
    .locals 5

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Uk;

    iget-object v0, v0, La/Uk;->l:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Uk;

    iget-object v0, v0, La/Uk;->q:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x0

    :goto_0
    const/4 v3, -0x1

    if-ge v2, v0, :cond_1

    iget-object v4, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v4, La/Uk;

    iget-object v4, v4, La/Uk;->q:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La/KS;

    iget-object v4, v4, La/KS;->h:La/pY;

    if-ne p1, v4, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    move v2, v3

    :goto_1
    if-ne v2, v3, :cond_2

    return-void

    :cond_2
    add-int/lit8 v2, v2, 0x1

    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Uk;

    iget-object v0, v0, La/Uk;->q:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v2, v0, :cond_3

    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Uk;

    iget-object v0, v0, La/Uk;->q:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, La/KS;

    :cond_3
    new-instance v0, La/YM;

    invoke-direct {v0, p0, v1, p2, p1}, La/YM;-><init>(La/ze;La/KS;La/HN;La/pY;)V

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0xc8

    add-long/2addr v1, v3

    iget-object p2, p0, La/ze;->K:Ljava/lang/Object;

    check-cast p2, La/Uk;

    iget-object p2, p2, La/Uk;->l:Landroid/os/Handler;

    invoke-virtual {p2, v0, p1, v1, v2}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z

    return-void
.end method

.method public final Q(Landroid/view/View;La/VB;La/u7;)La/VB;
    .locals 5

    .line 1
    iget v0, p3, La/u7;->e:I

    .line 2
    .line 3
    invoke-virtual {p2}, La/VB;->w()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    add-int/2addr v1, v0

    .line 8
    iput v1, p3, La/u7;->e:I

    .line 9
    .line 10
    sget-object v0, La/sI;->w:Ljava/util/WeakHashMap;

    .line 11
    .line 12
    invoke-static {p1}, La/XC;->e(Landroid/view/View;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x1

    .line 17
    if-ne v0, v1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    invoke-virtual {p2}, La/VB;->h()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-virtual {p2}, La/VB;->p()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    iget v3, p3, La/u7;->w:I

    .line 30
    .line 31
    if-eqz v1, :cond_1

    .line 32
    .line 33
    move v4, v2

    .line 34
    goto :goto_1

    .line 35
    :cond_1
    move v4, v0

    .line 36
    :goto_1
    add-int/2addr v3, v4

    .line 37
    iput v3, p3, La/u7;->w:I

    .line 38
    .line 39
    iget v4, p3, La/u7;->p:I

    .line 40
    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :cond_2
    move v0, v2

    .line 45
    :goto_2
    add-int/2addr v4, v0

    .line 46
    iput v4, p3, La/u7;->p:I

    .line 47
    .line 48
    iget v0, p3, La/u7;->h:I

    .line 49
    .line 50
    iget p3, p3, La/u7;->e:I

    .line 51
    .line 52
    invoke-static {p1, v3, v0, v4, p3}, La/XC;->M(Landroid/view/View;IIII)V

    .line 53
    .line 54
    .line 55
    return-object p2
.end method

.method public R(Landroid/content/Context;[La/mn;I)Landroid/graphics/Typeface;
    .locals 3

    .line 1
    array-length v0, p2

    .line 2
    const/4 v1, 0x1

    .line 3
    const/4 v2, 0x0

    .line 4
    if-ge v0, v1, :cond_0

    .line 5
    .line 6
    return-object v2

    .line 7
    :cond_0
    invoke-virtual {p0, p3, p2}, La/ze;->l(I[La/mn;)La/mn;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    :try_start_0
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 12
    .line 13
    .line 14
    move-result-object p3

    .line 15
    iget-object p2, p2, La/mn;->w:Landroid/net/Uri;

    .line 16
    .line 17
    invoke-virtual {p3, p2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    .line 18
    .line 19
    .line 20
    move-result-object p2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 21
    :try_start_1
    invoke-virtual {p0, p1, p2}, La/ze;->L(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;

    .line 22
    .line 23
    .line 24
    move-result-object p1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 25
    invoke-static {p2}, La/cH;->i(Ljava/io/Closeable;)V

    .line 26
    .line 27
    .line 28
    return-object p1

    .line 29
    :catchall_0
    move-exception p1

    .line 30
    move-object v2, p2

    .line 31
    goto :goto_0

    .line 32
    :catchall_1
    move-exception p1

    .line 33
    goto :goto_0

    .line 34
    :catch_0
    move-object p2, v2

    .line 35
    goto :goto_1

    .line 36
    :goto_0
    invoke-static {v2}, La/cH;->i(Ljava/io/Closeable;)V

    .line 37
    .line 38
    .line 39
    throw p1

    .line 40
    :catch_1
    :goto_1
    invoke-static {p2}, La/cH;->i(Ljava/io/Closeable;)V

    .line 41
    .line 42
    .line 43
    return-object v2
.end method

.method public final T(La/pY;Landroid/view/MenuItem;)V
    .locals 0

    .line 1
    iget-object p2, p0, La/ze;->K:Ljava/lang/Object;

    check-cast p2, La/Uk;

    iget-object p2, p2, La/Uk;->l:Landroid/os/Handler;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    return-void
.end method

.method public final V()I
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, La/e;->d(Landroid/view/ContentInfo;)I

    move-result v0

    return v0
.end method

.method public final W()La/ef;
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Tz;

    iget-object v0, v0, La/Tz;->d:La/ef;

    return-object v0
.end method

.method public final X()Landroid/view/ContentInfo;
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    return-object v0
.end method

.method public d(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    .locals 0

    .line 1
    invoke-static {p1}, La/cH;->y(Landroid/content/Context;)Ljava/io/File;

    move-result-object p1

    const/4 p4, 0x0

    if-nez p1, :cond_0

    return-object p4

    :cond_0
    :try_start_0
    invoke-static {p1, p2, p3}, La/cH;->Q(Ljava/io/File;Landroid/content/res/Resources;I)Z

    move-result p2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez p2, :cond_1

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object p4

    :cond_1
    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/graphics/Typeface;->createFromFile(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object p2
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object p2

    :catchall_0
    move-exception p2

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    throw p2

    :catch_0
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    return-object p4
.end method

.method public final e()I
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, La/e;->h(Landroid/view/ContentInfo;)I

    move-result v0

    return v0
.end method

.method public final h(Landroid/view/View;)Z
    .locals 3

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f(Landroid/view/View;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_5

    .line 11
    .line 12
    sget-object v0, La/sI;->w:Ljava/util/WeakHashMap;

    .line 13
    .line 14
    invoke-static {p1}, La/XC;->e(Landroid/view/View;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v2, 0x1

    .line 19
    if-ne v0, v2, :cond_0

    .line 20
    .line 21
    move v1, v2

    .line 22
    :cond_0
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;

    .line 25
    .line 26
    iget v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->i:I

    .line 27
    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    if-nez v1, :cond_2

    .line 31
    .line 32
    :cond_1
    if-ne v0, v2, :cond_3

    .line 33
    .line 34
    if-nez v1, :cond_3

    .line 35
    .line 36
    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    neg-int v0, v0

    .line 41
    goto :goto_0

    .line 42
    :cond_3
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 47
    .line 48
    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;

    .line 56
    .line 57
    iget-object v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->h:La/sR;

    .line 58
    .line 59
    if-eqz v0, :cond_4

    .line 60
    .line 61
    invoke-virtual {v0, p1}, La/sR;->V(Landroid/view/View;)V

    .line 62
    .line 63
    .line 64
    :cond_4
    return v2

    .line 65
    :cond_5
    return v1
.end method

.method public final i(La/pY;Landroid/view/MenuItem;)Z
    .locals 2

    .line 1
    iget-object p1, p0, La/ze;->K:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, La/eg;

    .line 4
    .line 5
    iget-object p1, p1, La/eg;->l:La/TD;

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    invoke-interface {p2}, Landroid/view/MenuItem;->getItemId()I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, La/eg;

    .line 16
    .line 17
    iget-object v1, v0, La/eg;->R:La/eO;

    .line 18
    .line 19
    iget v1, v1, La/qI;->W:I

    .line 20
    .line 21
    if-ne p1, v1, :cond_0

    .line 22
    .line 23
    iget-object p1, v0, La/eg;->l:La/TD;

    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    sget p1, Lcom/topjohnwu/magisk/ui/MainActivity;->mh:I

    .line 29
    .line 30
    const/4 p1, 0x1

    .line 31
    return p1

    .line 32
    :cond_0
    iget-object p1, p0, La/ze;->K:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p1, La/eg;

    .line 35
    .line 36
    iget-object p1, p1, La/eg;->f:La/Mq;

    .line 37
    .line 38
    if-eqz p1, :cond_1

    .line 39
    .line 40
    iget-object p1, p1, La/Mq;->K:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p1, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 43
    .line 44
    sget v0, Lcom/topjohnwu/magisk/ui/MainActivity;->mh:I

    .line 45
    .line 46
    invoke-interface {p2}, Landroid/view/MenuItem;->getItemId()I

    .line 47
    .line 48
    .line 49
    move-result p2

    .line 50
    sparse-switch p2, :sswitch_data_0

    .line 51
    .line 52
    .line 53
    const/4 p2, 0x0

    .line 54
    goto :goto_0

    .line 55
    :sswitch_0
    new-instance p2, La/jR;

    .line 56
    .line 57
    const v0, 0x7f090058

    .line 58
    .line 59
    .line 60
    invoke-direct {p2, v0}, La/jR;-><init>(I)V

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :sswitch_1
    new-instance p2, La/jR;

    .line 65
    .line 66
    const v0, 0x7f090049

    .line 67
    .line 68
    .line 69
    invoke-direct {p2, v0}, La/jR;-><init>(I)V

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :sswitch_2
    new-instance p2, La/jR;

    .line 74
    .line 75
    const v0, 0x7f090043

    .line 76
    .line 77
    .line 78
    invoke-direct {p2, v0}, La/jR;-><init>(I)V

    .line 79
    .line 80
    .line 81
    goto :goto_0

    .line 82
    :sswitch_3
    new-instance p2, La/jR;

    .line 83
    .line 84
    const v0, 0x7f09003f

    .line 85
    .line 86
    .line 87
    invoke-direct {p2, v0}, La/jR;-><init>(I)V

    .line 88
    .line 89
    .line 90
    :goto_0
    if-eqz p2, :cond_1

    .line 91
    .line 92
    iget-object p1, p1, La/o5;->Pc:La/Yi;

    .line 93
    .line 94
    invoke-virtual {p1}, La/Yi;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    check-cast p1, Landroidx/navigation/fragment/NavHostFragment;

    .line 99
    .line 100
    iget-object p1, p1, Landroidx/navigation/fragment/NavHostFragment;->B1:La/Yi;

    .line 101
    .line 102
    invoke-virtual {p1}, La/Yi;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    check-cast p1, La/sv;

    .line 107
    .line 108
    invoke-virtual {p1, p2}, La/r4;->I(La/EI;)V

    .line 109
    .line 110
    .line 111
    :cond_1
    const/4 p1, 0x0

    .line 112
    return p1

    .line 113
    :sswitch_data_0
    .sparse-switch
        0x7f090110 -> :sswitch_3
        0x7f090144 -> :sswitch_2
        0x7f090183 -> :sswitch_1
        0x7f09023d -> :sswitch_0
    .end sparse-switch
.end method

.method public l(I[La/mn;)La/mn;
    .locals 2

    .line 1
    new-instance v0, La/oK;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La/oK;-><init>(I)V

    invoke-static {p2, p1, v0}, La/ze;->f([Ljava/lang/Object;ILa/oK;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/mn;

    return-object p1
.end method

.method public final m(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public final p(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    throw p1
.end method

.method public final q()V
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/Tz;

    iget-object v0, v0, La/Tz;->d:La/ef;

    invoke-virtual {v0}, La/ef;->g()V

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    iget v0, p0, La/ze;->X:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "ContentInfoCompat{"

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, La/ze;->K:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Landroid/view/ContentInfo;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, "}"

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0

    .line 35
    :pswitch_data_0
    .packed-switch 0xa
        :pswitch_0
    .end packed-switch
.end method

.method public final w()Landroid/content/ClipData;
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, Landroid/view/ContentInfo;

    invoke-static {v0}, La/e;->e(Landroid/view/ContentInfo;)Landroid/content/ClipData;

    move-result-object v0

    return-object v0
.end method

.method public final y()La/VB;
    .locals 1

    .line 1
    iget-object v0, p0, La/ze;->K:Ljava/lang/Object;

    check-cast v0, La/DJ;

    invoke-virtual {v0}, La/DJ;->h()La/VB;

    move-result-object v0

    return-object v0
.end method
