.class public Lcom/google/android/material/carousel/CarouselLayoutManager;
.super La/XG;
.source "SourceFile"

# interfaces
.implements La/wx;


# instance fields
.field public final L:La/ms;

.field public R:La/z2;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, La/XG;-><init>()V

    new-instance v0, La/mw;

    invoke-direct {v0}, La/mw;-><init>()V

    new-instance v0, La/ms;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, La/ms;-><init>(Lcom/google/android/material/carousel/CarouselLayoutManager;I)V

    iput-object v0, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->L:La/ms;

    .line 2
    invoke-virtual {p0}, La/XG;->lI()V

    .line 3
    invoke-virtual {p0, v1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->B2(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 0
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    invoke-direct {p0}, La/XG;-><init>()V

    new-instance p3, La/mw;

    invoke-direct {p3}, La/mw;-><init>()V

    new-instance p3, La/ms;

    const/4 p4, 0x1

    invoke-direct {p3, p0, p4}, La/ms;-><init>(Lcom/google/android/material/carousel/CarouselLayoutManager;I)V

    iput-object p3, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->L:La/ms;

    .line 4
    invoke-virtual {p0}, La/XG;->lI()V

    if-eqz p2, :cond_0

    sget-object p3, La/tS;->X:[I

    .line 5
    invoke-virtual {p1, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 6
    invoke-virtual {p0}, La/XG;->lI()V

    .line 7
    invoke-virtual {p1, p2, p2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    invoke-virtual {p0, p2}, Lcom/google/android/material/carousel/CarouselLayoutManager;->B2(I)V

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_0
    return-void
.end method

.method public static AW(FLa/dh;)F
    .locals 4

    .line 1
    iget-object v0, p1, La/dh;->K:Ljava/lang/Object;

    check-cast v0, La/Jr;

    const/4 v1, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, La/dh;->R:Ljava/lang/Object;

    check-cast p1, La/Jr;

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2, v3, v0, p0}, La/FP;->h(FFFFF)F

    move-result p0

    return p0
.end method

.method public static GI(FLjava/util/List;Z)La/dh;
    .locals 13

    .line 1
    const/4 v0, -0x1

    const v1, 0x7f7fffff    # Float.MAX_VALUE

    const v2, -0x800001

    const/4 v3, 0x0

    move v6, v0

    move v7, v6

    move v8, v7

    move v9, v8

    move v4, v2

    move v5, v3

    move v2, v1

    move v3, v2

    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v10

    if-ge v5, v10, :cond_4

    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La/Jr;

    const/4 v11, 0x0

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sub-float v10, v11, p0

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v10

    cmpg-float v12, v11, p0

    if-gtz v12, :cond_0

    cmpg-float v12, v10, v1

    if-gtz v12, :cond_0

    move v6, v5

    move v1, v10

    :cond_0
    cmpl-float v12, v11, p0

    if-lez v12, :cond_1

    cmpg-float v12, v10, v2

    if-gtz v12, :cond_1

    move v8, v5

    move v2, v10

    :cond_1
    cmpg-float v10, v11, v3

    if-gtz v10, :cond_2

    move v7, v5

    move v3, v11

    :cond_2
    cmpl-float v10, v11, v4

    if-lez v10, :cond_3

    move v9, v5

    move v4, v11

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    if-ne v6, v0, :cond_5

    move v6, v7

    :cond_5
    if-ne v8, v0, :cond_6

    move v8, v9

    :cond_6
    new-instance p0, La/dh;

    invoke-interface {p1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, La/Jr;

    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/Jr;

    invoke-direct {p0, p2, p1}, La/dh;-><init>(La/Jr;La/Jr;)V

    return-object p0
.end method


# virtual methods
.method public final B(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, La/XG;->B(Landroid/view/accessibility/AccessibilityEvent;)V

    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, La/XG;->U(Landroid/view/View;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, La/XG;->U(Landroid/view/View;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    :cond_0
    return-void
.end method

.method public final B2(I)V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    if-eqz p1, :cond_1

    .line 3
    .line 4
    if-ne p1, v0, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 8
    .line 9
    const-string v1, "invalid orientation:"

    .line 10
    .line 11
    invoke-static {v1, p1}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw v0

    .line 19
    :cond_1
    :goto_0
    const/4 v1, 0x0

    .line 20
    invoke-virtual {p0, v1}, La/XG;->p(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object v1, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->R:La/z2;

    .line 24
    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    iget v1, v1, La/di;->w:I

    .line 28
    .line 29
    if-eq p1, v1, :cond_5

    .line 30
    .line 31
    :cond_2
    const/4 v1, 0x0

    .line 32
    if-eqz p1, :cond_4

    .line 33
    .line 34
    if-ne p1, v0, :cond_3

    .line 35
    .line 36
    new-instance p1, La/z2;

    .line 37
    .line 38
    invoke-direct {p1, v0, p0, v1}, La/z2;-><init>(ILcom/google/android/material/carousel/CarouselLayoutManager;I)V

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 43
    .line 44
    const-string v0, "invalid orientation"

    .line 45
    .line 46
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    throw p1

    .line 50
    :cond_4
    new-instance p1, La/z2;

    .line 51
    .line 52
    invoke-direct {p1, v1, p0, v0}, La/z2;-><init>(ILcom/google/android/material/carousel/CarouselLayoutManager;I)V

    .line 53
    .line 54
    .line 55
    :goto_1
    iput-object p1, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->R:La/z2;

    .line 56
    .line 57
    invoke-virtual {p0}, La/XG;->lI()V

    .line 58
    .line 59
    .line 60
    :cond_5
    return-void
.end method

.method public final Ey()V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final FL(II)V
    .locals 0

    .line 1
    invoke-virtual {p0}, La/XG;->H()I

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final Gy(ILa/fl;La/R8;)I
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->i()Z

    .line 2
    .line 3
    .line 4
    move-result p3

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz p3, :cond_1

    .line 7
    .line 8
    invoke-virtual {p0}, La/XG;->q()I

    .line 9
    .line 10
    .line 11
    move-result p3

    .line 12
    if-eqz p3, :cond_1

    .line 13
    .line 14
    if-nez p1, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p2, v0}, La/fl;->e(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Ey()V

    .line 21
    .line 22
    .line 23
    const/4 p1, 0x0

    .line 24
    throw p1

    .line 25
    :cond_1
    :goto_0
    return v0
.end method

.method public final HF(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final Hs()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->R:La/z2;

    iget v0, v0, La/di;->w:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final I(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    const/4 p1, 0x0

    return p1
.end method

.method public final IL()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/XG;->z()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final J(II)V
    .locals 0

    .line 1
    invoke-virtual {p0}, La/XG;->H()I

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final K(La/R8;)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public final M(La/R8;)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public final N3()I
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, La/XG;->y:I

    return v0

    :cond_0
    iget v0, p0, La/XG;->K:I

    return v0
.end method

.method public final Pb(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;ZZ)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public final S(Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, La/XG;->S(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Landroid/graphics/Rect;->centerY()I

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p2}, Landroid/graphics/Rect;->centerX()I

    .line 14
    .line 15
    .line 16
    :cond_0
    const/4 p1, 0x0

    .line 17
    throw p1
.end method

.method public final T(La/R8;)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public final VQ(ILa/fl;La/R8;)I
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    .line 2
    .line 3
    .line 4
    move-result p3

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz p3, :cond_1

    .line 7
    .line 8
    invoke-virtual {p0}, La/XG;->q()I

    .line 9
    .line 10
    .line 11
    move-result p3

    .line 12
    if-eqz p3, :cond_1

    .line 13
    .line 14
    if-nez p1, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p2, v0}, La/fl;->e(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Ey()V

    .line 21
    .line 22
    .line 23
    const/4 p1, 0x0

    .line 24
    throw p1

    .line 25
    :cond_1
    :goto_0
    return v0
.end method

.method public final Vm(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 2

    .line 1
    new-instance v0, La/S0;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {v0, p0, p1, v1}, La/S0;-><init>(Ljava/lang/Object;Landroid/content/Context;I)V

    .line 9
    .line 10
    .line 11
    iput p2, v0, La/VS;->w:I

    .line 12
    .line 13
    invoke-virtual {p0, v0}, La/XG;->Vy(La/VS;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final c(Landroid/view/View;ILa/fl;La/R8;)Landroid/view/View;
    .locals 5

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    .line 2
    .line 3
    .line 4
    move-result p4

    .line 5
    const/4 v0, 0x0

    .line 6
    if-nez p4, :cond_0

    .line 7
    .line 8
    return-object v0

    .line 9
    :cond_0
    iget-object p4, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->R:La/z2;

    .line 10
    .line 11
    iget p4, p4, La/di;->w:I

    .line 12
    .line 13
    const/high16 v1, -0x80000000

    .line 14
    .line 15
    const/4 v2, -0x1

    .line 16
    const/4 v3, 0x1

    .line 17
    if-eq p2, v3, :cond_7

    .line 18
    .line 19
    const/4 v4, 0x2

    .line 20
    if-eq p2, v4, :cond_6

    .line 21
    .line 22
    const/16 v4, 0x11

    .line 23
    .line 24
    if-eq p2, v4, :cond_5

    .line 25
    .line 26
    const/16 v4, 0x21

    .line 27
    .line 28
    if-eq p2, v4, :cond_4

    .line 29
    .line 30
    const/16 v4, 0x42

    .line 31
    .line 32
    if-eq p2, v4, :cond_3

    .line 33
    .line 34
    const/16 v4, 0x82

    .line 35
    .line 36
    if-eq p2, v4, :cond_2

    .line 37
    .line 38
    new-instance p4, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    const-string v4, "Unknown focus request:"

    .line 41
    .line 42
    invoke-direct {p4, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    const-string p4, "CarouselLayoutManager"

    .line 53
    .line 54
    invoke-static {p4, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    :cond_1
    move p2, v1

    .line 58
    goto :goto_2

    .line 59
    :cond_2
    if-ne p4, v3, :cond_1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_3
    if-nez p4, :cond_1

    .line 63
    .line 64
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    if-eqz p2, :cond_6

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_4
    if-ne p4, v3, :cond_1

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_5
    if-nez p4, :cond_1

    .line 75
    .line 76
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 77
    .line 78
    .line 79
    move-result p2

    .line 80
    if-eqz p2, :cond_7

    .line 81
    .line 82
    :cond_6
    :goto_0
    move p2, v3

    .line 83
    goto :goto_2

    .line 84
    :cond_7
    :goto_1
    move p2, v2

    .line 85
    :goto_2
    if-ne p2, v1, :cond_8

    .line 86
    .line 87
    return-object v0

    .line 88
    :cond_8
    const/4 p4, 0x0

    .line 89
    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    if-ne p2, v2, :cond_d

    .line 94
    .line 95
    if-nez p1, :cond_9

    .line 96
    .line 97
    return-object v0

    .line 98
    :cond_9
    invoke-virtual {p0, p4}, La/XG;->W(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    .line 103
    .line 104
    .line 105
    move-result p1

    .line 106
    sub-int/2addr p1, v3

    .line 107
    if-ltz p1, :cond_b

    .line 108
    .line 109
    invoke-virtual {p0}, La/XG;->H()I

    .line 110
    .line 111
    .line 112
    move-result p2

    .line 113
    if-lt p1, p2, :cond_a

    .line 114
    .line 115
    goto :goto_3

    .line 116
    :cond_a
    invoke-virtual {p0, p1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->cM(I)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {p3, p1}, La/fl;->e(I)Landroid/view/View;

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Ey()V

    .line 123
    .line 124
    .line 125
    throw v0

    .line 126
    :cond_b
    :goto_3
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 127
    .line 128
    .line 129
    move-result p1

    .line 130
    if-eqz p1, :cond_c

    .line 131
    .line 132
    invoke-virtual {p0}, La/XG;->q()I

    .line 133
    .line 134
    .line 135
    move-result p1

    .line 136
    add-int/lit8 p4, p1, -0x1

    .line 137
    .line 138
    :cond_c
    invoke-virtual {p0, p4}, La/XG;->W(I)Landroid/view/View;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    goto :goto_6

    .line 143
    :cond_d
    invoke-virtual {p0}, La/XG;->H()I

    .line 144
    .line 145
    .line 146
    move-result p2

    .line 147
    sub-int/2addr p2, v3

    .line 148
    if-ne p1, p2, :cond_e

    .line 149
    .line 150
    return-object v0

    .line 151
    :cond_e
    invoke-virtual {p0}, La/XG;->q()I

    .line 152
    .line 153
    .line 154
    move-result p1

    .line 155
    sub-int/2addr p1, v3

    .line 156
    invoke-virtual {p0, p1}, La/XG;->W(I)Landroid/view/View;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    .line 161
    .line 162
    .line 163
    move-result p1

    .line 164
    add-int/2addr p1, v3

    .line 165
    if-ltz p1, :cond_10

    .line 166
    .line 167
    invoke-virtual {p0}, La/XG;->H()I

    .line 168
    .line 169
    .line 170
    move-result p2

    .line 171
    if-lt p1, p2, :cond_f

    .line 172
    .line 173
    goto :goto_4

    .line 174
    :cond_f
    invoke-virtual {p0, p1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->cM(I)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {p3, p1}, La/fl;->e(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Ey()V

    .line 181
    .line 182
    .line 183
    throw v0

    .line 184
    :cond_10
    :goto_4
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 185
    .line 186
    .line 187
    move-result p1

    .line 188
    if-eqz p1, :cond_11

    .line 189
    .line 190
    goto :goto_5

    .line 191
    :cond_11
    invoke-virtual {p0}, La/XG;->q()I

    .line 192
    .line 193
    .line 194
    move-result p1

    .line 195
    add-int/lit8 p4, p1, -0x1

    .line 196
    .line 197
    :goto_5
    invoke-virtual {p0, p4}, La/XG;->W(I)Landroid/view/View;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    :goto_6
    return-object p1
.end method

.method public final cM(I)V
    .locals 2

    .line 1
    iget-object p1, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->R:La/z2;

    .line 2
    .line 3
    iget v0, p1, La/z2;->h:I

    .line 4
    .line 5
    iget-object v1, p1, La/z2;->p:Lcom/google/android/material/carousel/CarouselLayoutManager;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget p1, p1, La/z2;->h:I

    .line 17
    .line 18
    packed-switch p1, :pswitch_data_1

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :pswitch_0
    invoke-virtual {v1}, La/XG;->D()I

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {p1}, La/z2;->X()I

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :pswitch_1
    packed-switch v0, :pswitch_data_2

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1}, La/XG;->u()I

    .line 34
    .line 35
    .line 36
    :goto_0
    :pswitch_2
    const/4 p1, 0x0

    .line 37
    throw p1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch
.end method

.method public final d()La/Mk;
    .locals 2

    .line 1
    new-instance v0, La/Mk;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, La/Mk;-><init>(II)V

    return-object v0
.end method

.method public final e()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    move-result v0

    return v0
.end method

.method public final i()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Hs()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public final m(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    const/4 p1, 0x0

    return p1
.end method

.method public final o(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La/XG;->lI()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->L:La/ms;

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final p7(La/R8;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, La/XG;->W(I)Landroid/view/View;

    move-result-object p1

    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    :goto_0
    return-void
.end method

.method public final r(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/carousel/CarouselLayoutManager;->L:La/ms;

    invoke-virtual {p1, v0}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    return-void
.end method

.method public final rC(La/fl;La/R8;)V
    .locals 1

    .line 1
    invoke-virtual {p2}, La/R8;->h()I

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    if-lez p2, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->N3()I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    int-to-float p2, p2

    .line 12
    const/4 v0, 0x0

    .line 13
    cmpg-float p2, p2, v0

    .line 14
    .line 15
    if-gtz p2, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->IL()Z

    .line 19
    .line 20
    .line 21
    const/4 p2, 0x0

    .line 22
    invoke-virtual {p1, p2}, La/fl;->e(I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, Lcom/google/android/material/carousel/CarouselLayoutManager;->Ey()V

    .line 26
    .line 27
    .line 28
    const/4 p1, 0x0

    .line 29
    throw p1

    .line 30
    :cond_1
    :goto_0
    invoke-virtual {p0, p1}, La/XG;->ZU(La/fl;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final w(I)Landroid/graphics/PointF;
    .locals 0

    .line 1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final y(La/R8;)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method
