.class public final synthetic La/z8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic K:Ljava/lang/Object;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, La/z8;->X:I

    .line 5
    .line 6
    iput-object p2, p0, La/z8;->K:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 6

    .line 1
    iget v0, p0, La/z8;->X:I

    .line 2
    .line 3
    iget-object v1, p0, La/z8;->K:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast v1, La/VV;

    .line 9
    .line 10
    sget-object p1, La/cw;->ON_START:La/cw;

    .line 11
    .line 12
    if-ne p2, p1, :cond_0

    .line 13
    .line 14
    const/4 p1, 0x1

    .line 15
    :goto_0
    iput-boolean p1, v1, La/VV;->Q:Z

    .line 16
    .line 17
    goto :goto_1

    .line 18
    :cond_0
    sget-object p1, La/cw;->ON_STOP:La/cw;

    .line 19
    .line 20
    if-ne p2, p1, :cond_1

    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    goto :goto_0

    .line 24
    :cond_1
    :goto_1
    return-void

    .line 25
    :pswitch_0
    check-cast v1, La/Vt;

    .line 26
    .line 27
    sget-object v0, La/cw;->ON_DESTROY:La/cw;

    .line 28
    .line 29
    if-ne p2, v0, :cond_5

    .line 30
    .line 31
    move-object p2, p1

    .line 32
    check-cast p2, La/zr;

    .line 33
    .line 34
    invoke-virtual {v1}, La/Z5;->h()La/Ws;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iget-object v0, v0, La/Ws;->Q:La/Zz;

    .line 39
    .line 40
    iget-object v0, v0, La/Zz;->X:La/Jk;

    .line 41
    .line 42
    invoke-interface {v0}, La/Jk;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Ljava/lang/Iterable;

    .line 47
    .line 48
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    const/4 v2, 0x0

    .line 53
    :cond_2
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    if-eqz v3, :cond_3

    .line 58
    .line 59
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    move-object v4, v3

    .line 64
    check-cast v4, La/GA;

    .line 65
    .line 66
    iget-object v4, v4, La/GA;->f:Ljava/lang/String;

    .line 67
    .line 68
    iget-object v5, p2, La/zr;->n:Ljava/lang/String;

    .line 69
    .line 70
    invoke-static {v4, v5}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    if-eqz v4, :cond_2

    .line 75
    .line 76
    move-object v2, v3

    .line 77
    goto :goto_2

    .line 78
    :cond_3
    check-cast v2, La/GA;

    .line 79
    .line 80
    if-eqz v2, :cond_5

    .line 81
    .line 82
    const-string p2, "FragmentManager"

    .line 83
    .line 84
    const/4 v0, 0x2

    .line 85
    invoke-static {p2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 86
    .line 87
    .line 88
    move-result p2

    .line 89
    if-eqz p2, :cond_4

    .line 90
    .line 91
    new-instance p2, Ljava/lang/StringBuilder;

    .line 92
    .line 93
    const-string v0, "Marking transition complete for entry "

    .line 94
    .line 95
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    const-string v0, " due to fragment "

    .line 102
    .line 103
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    const-string p1, " lifecycle reaching DESTROYED"

    .line 110
    .line 111
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    const-string p2, "FragmentNavigator"

    .line 119
    .line 120
    invoke-static {p2, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 121
    .line 122
    .line 123
    :cond_4
    invoke-virtual {v1}, La/Z5;->h()La/Ws;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    invoke-virtual {p1, v2}, La/Ws;->h(La/GA;)V

    .line 128
    .line 129
    .line 130
    :cond_5
    return-void

    .line 131
    :pswitch_1
    check-cast v1, La/r4;

    .line 132
    .line 133
    invoke-virtual {p2}, La/cw;->w()La/m2;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    iput-object p1, v1, La/r4;->L:La/m2;

    .line 138
    .line 139
    iget-object p1, v1, La/r4;->p:La/mE;

    .line 140
    .line 141
    if-eqz p1, :cond_6

    .line 142
    .line 143
    iget-object p1, v1, La/r4;->X:La/qP;

    .line 144
    .line 145
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    if-eqz v0, :cond_6

    .line 154
    .line 155
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    check-cast v0, La/GA;

    .line 160
    .line 161
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 162
    .line 163
    .line 164
    invoke-virtual {p2}, La/cw;->w()La/m2;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    iput-object v1, v0, La/GA;->L:La/m2;

    .line 169
    .line 170
    invoke-virtual {v0}, La/GA;->X()V

    .line 171
    .line 172
    .line 173
    goto :goto_3

    .line 174
    :cond_6
    return-void

    .line 175
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
