.class public Lcom/google/android/material/chip/Chip;
.super La/q8;
.source "SourceFile"

# interfaces
.implements La/NJ;
.implements La/Io;
.implements Landroid/widget/Checkable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/q8;",
        "La/NJ;",
        "La/Io;",
        "Landroid/widget/Checkable;"
    }
.end annotation


# static fields
.field public static final j:[I

.field public static final s:Landroid/graphics/Rect;

.field public static final t:[I


# instance fields
.field public D:I

.field public E:Z

.field public F:Z

.field public H:Z

.field public P:I

.field public S:Z

.field public final U:Landroid/graphics/Rect;

.field public W:Landroid/graphics/drawable/RippleDrawable;

.field public final f:La/X9;

.field public final k:Landroid/graphics/RectF;

.field public l:Landroid/graphics/drawable/InsetDrawable;

.field public q:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field public u:Ljava/lang/CharSequence;

.field public final v:La/dc;

.field public final z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    sput-object v0, Lcom/google/android/material/chip/Chip;->s:Landroid/graphics/Rect;

    const v0, 0x10100a1

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/chip/Chip;->j:[I

    const v0, 0x101009f

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/chip/Chip;->t:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p2

    .line 4
    .line 5
    const v8, 0x7f0400d6

    .line 6
    .line 7
    .line 8
    const v1, 0x7f13043d

    .line 9
    .line 10
    .line 11
    move-object/from16 v2, p1

    .line 12
    .line 13
    invoke-static {v2, v7, v8, v1}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1, v7, v8}, La/q8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 18
    .line 19
    .line 20
    new-instance v1, Landroid/graphics/Rect;

    .line 21
    .line 22
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v1, v0, Lcom/google/android/material/chip/Chip;->U:Landroid/graphics/Rect;

    .line 26
    .line 27
    new-instance v1, Landroid/graphics/RectF;

    .line 28
    .line 29
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v1, v0, Lcom/google/android/material/chip/Chip;->k:Landroid/graphics/RectF;

    .line 33
    .line 34
    new-instance v1, La/dc;

    .line 35
    .line 36
    const/4 v9, 0x0

    .line 37
    invoke-direct {v1, v9, v0}, La/dc;-><init>(ILjava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iput-object v1, v0, Lcom/google/android/material/chip/Chip;->v:La/dc;

    .line 41
    .line 42
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 43
    .line 44
    .line 45
    move-result-object v10

    .line 46
    const/4 v11, 0x1

    .line 47
    const v12, 0x800013

    .line 48
    .line 49
    .line 50
    if-nez v7, :cond_0

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    const-string v1, "http://schemas.android.com/apk/res/android"

    .line 54
    .line 55
    const-string v2, "background"

    .line 56
    .line 57
    invoke-interface {v7, v1, v2}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    const-string v3, "Chip"

    .line 62
    .line 63
    if-eqz v2, :cond_1

    .line 64
    .line 65
    const-string v2, "Do not set the background; Chip manages its own background drawable."

    .line 66
    .line 67
    invoke-static {v3, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    .line 69
    .line 70
    :cond_1
    const-string v2, "drawableLeft"

    .line 71
    .line 72
    invoke-interface {v7, v1, v2}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    if-nez v2, :cond_3d

    .line 77
    .line 78
    const-string v2, "drawableStart"

    .line 79
    .line 80
    invoke-interface {v7, v1, v2}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    if-nez v2, :cond_3c

    .line 85
    .line 86
    const-string v2, "drawableEnd"

    .line 87
    .line 88
    invoke-interface {v7, v1, v2}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    const-string v4, "Please set end drawable using R.attr#closeIcon."

    .line 93
    .line 94
    if-nez v2, :cond_3b

    .line 95
    .line 96
    const-string v2, "drawableRight"

    .line 97
    .line 98
    invoke-interface {v7, v1, v2}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    if-nez v2, :cond_3a

    .line 103
    .line 104
    const-string v2, "singleLine"

    .line 105
    .line 106
    invoke-interface {v7, v1, v2, v11}, Landroid/util/AttributeSet;->getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    if-eqz v2, :cond_39

    .line 111
    .line 112
    const-string v2, "lines"

    .line 113
    .line 114
    invoke-interface {v7, v1, v2, v11}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    .line 115
    .line 116
    .line 117
    move-result v2

    .line 118
    if-ne v2, v11, :cond_39

    .line 119
    .line 120
    const-string v2, "minLines"

    .line 121
    .line 122
    invoke-interface {v7, v1, v2, v11}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    if-ne v2, v11, :cond_39

    .line 127
    .line 128
    const-string v2, "maxLines"

    .line 129
    .line 130
    invoke-interface {v7, v1, v2, v11}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    .line 131
    .line 132
    .line 133
    move-result v2

    .line 134
    if-ne v2, v11, :cond_39

    .line 135
    .line 136
    const-string v2, "gravity"

    .line 137
    .line 138
    invoke-interface {v7, v1, v2, v12}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-eq v1, v12, :cond_2

    .line 143
    .line 144
    const-string v1, "Chip text must be vertically center and start aligned"

    .line 145
    .line 146
    invoke-static {v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 147
    .line 148
    .line 149
    :cond_2
    :goto_0
    const v5, 0x7f13043d

    .line 150
    .line 151
    .line 152
    new-instance v13, La/X9;

    .line 153
    .line 154
    invoke-direct {v13, v10, v7}, La/X9;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 155
    .line 156
    .line 157
    iget-object v1, v13, La/X9;->Gy:Landroid/content/Context;

    .line 158
    .line 159
    sget-object v14, La/tS;->O:[I

    .line 160
    .line 161
    new-array v6, v9, [I

    .line 162
    .line 163
    move-object/from16 v2, p2

    .line 164
    .line 165
    move-object v3, v14

    .line 166
    move v4, v8

    .line 167
    invoke-static/range {v1 .. v6}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    const/16 v15, 0x25

    .line 172
    .line 173
    invoke-virtual {v1, v15}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    iput-boolean v2, v13, La/X9;->xY:Z

    .line 178
    .line 179
    const/16 v2, 0x18

    .line 180
    .line 181
    iget-object v3, v13, La/X9;->Gy:Landroid/content/Context;

    .line 182
    .line 183
    invoke-static {v3, v1, v2}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    iget-object v4, v13, La/X9;->n:Landroid/content/res/ColorStateList;

    .line 188
    .line 189
    if-eq v4, v2, :cond_3

    .line 190
    .line 191
    iput-object v2, v13, La/X9;->n:Landroid/content/res/ColorStateList;

    .line 192
    .line 193
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 194
    .line 195
    .line 196
    move-result-object v2

    .line 197
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 198
    .line 199
    .line 200
    :cond_3
    const/16 v2, 0xb

    .line 201
    .line 202
    invoke-static {v3, v1, v2}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 203
    .line 204
    .line 205
    move-result-object v2

    .line 206
    iget-object v4, v13, La/X9;->C:Landroid/content/res/ColorStateList;

    .line 207
    .line 208
    if-eq v4, v2, :cond_4

    .line 209
    .line 210
    iput-object v2, v13, La/X9;->C:Landroid/content/res/ColorStateList;

    .line 211
    .line 212
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 213
    .line 214
    .line 215
    move-result-object v2

    .line 216
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 217
    .line 218
    .line 219
    :cond_4
    const/16 v2, 0x13

    .line 220
    .line 221
    const/4 v4, 0x0

    .line 222
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 223
    .line 224
    .line 225
    move-result v2

    .line 226
    iget v5, v13, La/X9;->x:F

    .line 227
    .line 228
    cmpl-float v5, v5, v2

    .line 229
    .line 230
    if-eqz v5, :cond_5

    .line 231
    .line 232
    iput v2, v13, La/X9;->x:F

    .line 233
    .line 234
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v13}, La/X9;->z()V

    .line 238
    .line 239
    .line 240
    :cond_5
    const/16 v2, 0xc

    .line 241
    .line 242
    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 243
    .line 244
    .line 245
    move-result v5

    .line 246
    if-eqz v5, :cond_6

    .line 247
    .line 248
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 249
    .line 250
    .line 251
    move-result v2

    .line 252
    iget v5, v13, La/X9;->g:F

    .line 253
    .line 254
    cmpl-float v5, v5, v2

    .line 255
    .line 256
    if-eqz v5, :cond_6

    .line 257
    .line 258
    iput v2, v13, La/X9;->g:F

    .line 259
    .line 260
    iget-object v5, v13, La/ex;->X:La/JP;

    .line 261
    .line 262
    iget-object v5, v5, La/JP;->w:La/c9;

    .line 263
    .line 264
    invoke-virtual {v5}, La/c9;->Q()La/as;

    .line 265
    .line 266
    .line 267
    move-result-object v5

    .line 268
    new-instance v6, La/r;

    .line 269
    .line 270
    invoke-direct {v6, v2}, La/r;-><init>(F)V

    .line 271
    .line 272
    .line 273
    iput-object v6, v5, La/as;->i:La/cv;

    .line 274
    .line 275
    new-instance v6, La/r;

    .line 276
    .line 277
    invoke-direct {v6, v2}, La/r;-><init>(F)V

    .line 278
    .line 279
    .line 280
    iput-object v6, v5, La/as;->Q:La/cv;

    .line 281
    .line 282
    new-instance v6, La/r;

    .line 283
    .line 284
    invoke-direct {v6, v2}, La/r;-><init>(F)V

    .line 285
    .line 286
    .line 287
    iput-object v6, v5, La/as;->X:La/cv;

    .line 288
    .line 289
    new-instance v6, La/r;

    .line 290
    .line 291
    invoke-direct {v6, v2}, La/r;-><init>(F)V

    .line 292
    .line 293
    .line 294
    iput-object v6, v5, La/as;->O:La/cv;

    .line 295
    .line 296
    invoke-virtual {v5}, La/as;->w()La/c9;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    invoke-virtual {v13, v2}, La/ex;->h(La/c9;)V

    .line 301
    .line 302
    .line 303
    :cond_6
    const/16 v2, 0x16

    .line 304
    .line 305
    invoke-static {v3, v1, v2}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    iget-object v5, v13, La/X9;->o:Landroid/content/res/ColorStateList;

    .line 310
    .line 311
    if-eq v5, v2, :cond_8

    .line 312
    .line 313
    iput-object v2, v13, La/X9;->o:Landroid/content/res/ColorStateList;

    .line 314
    .line 315
    iget-boolean v5, v13, La/X9;->xY:Z

    .line 316
    .line 317
    if-eqz v5, :cond_7

    .line 318
    .line 319
    iget-object v5, v13, La/ex;->X:La/JP;

    .line 320
    .line 321
    iget-object v6, v5, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 322
    .line 323
    if-eq v6, v2, :cond_7

    .line 324
    .line 325
    iput-object v2, v5, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 326
    .line 327
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 328
    .line 329
    .line 330
    move-result-object v2

    .line 331
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 332
    .line 333
    .line 334
    :cond_7
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 335
    .line 336
    .line 337
    move-result-object v2

    .line 338
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 339
    .line 340
    .line 341
    :cond_8
    const/16 v2, 0x17

    .line 342
    .line 343
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 344
    .line 345
    .line 346
    move-result v2

    .line 347
    iget v5, v13, La/X9;->r:F

    .line 348
    .line 349
    cmpl-float v5, v5, v2

    .line 350
    .line 351
    if-eqz v5, :cond_a

    .line 352
    .line 353
    iput v2, v13, La/X9;->r:F

    .line 354
    .line 355
    iget-object v5, v13, La/X9;->NE:Landroid/graphics/Paint;

    .line 356
    .line 357
    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 358
    .line 359
    .line 360
    iget-boolean v5, v13, La/X9;->xY:Z

    .line 361
    .line 362
    if-eqz v5, :cond_9

    .line 363
    .line 364
    iget-object v5, v13, La/ex;->X:La/JP;

    .line 365
    .line 366
    iput v2, v5, La/JP;->M:F

    .line 367
    .line 368
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 369
    .line 370
    .line 371
    :cond_9
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 372
    .line 373
    .line 374
    :cond_a
    const/16 v2, 0x24

    .line 375
    .line 376
    invoke-static {v3, v1, v2}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    iget-object v5, v13, La/X9;->c:Landroid/content/res/ColorStateList;

    .line 381
    .line 382
    if-eq v5, v2, :cond_c

    .line 383
    .line 384
    iput-object v2, v13, La/X9;->c:Landroid/content/res/ColorStateList;

    .line 385
    .line 386
    iget-boolean v5, v13, La/X9;->au:Z

    .line 387
    .line 388
    if-eqz v5, :cond_b

    .line 389
    .line 390
    invoke-static {v2}, La/J3;->h(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    .line 391
    .line 392
    .line 393
    move-result-object v2

    .line 394
    goto :goto_1

    .line 395
    :cond_b
    const/4 v2, 0x0

    .line 396
    :goto_1
    iput-object v2, v13, La/X9;->sH:Landroid/content/res/ColorStateList;

    .line 397
    .line 398
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 399
    .line 400
    .line 401
    move-result-object v2

    .line 402
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 403
    .line 404
    .line 405
    :cond_c
    const/4 v2, 0x5

    .line 406
    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    .line 407
    .line 408
    .line 409
    move-result-object v2

    .line 410
    if-nez v2, :cond_d

    .line 411
    .line 412
    const-string v2, ""

    .line 413
    .line 414
    :cond_d
    iget-object v5, v13, La/X9;->B:Ljava/lang/CharSequence;

    .line 415
    .line 416
    invoke-static {v5, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 417
    .line 418
    .line 419
    move-result v5

    .line 420
    iget-object v6, v13, La/X9;->yd:La/rY;

    .line 421
    .line 422
    if-nez v5, :cond_e

    .line 423
    .line 424
    iput-object v2, v13, La/X9;->B:Ljava/lang/CharSequence;

    .line 425
    .line 426
    iput-boolean v11, v6, La/rY;->i:Z

    .line 427
    .line 428
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 429
    .line 430
    .line 431
    invoke-virtual {v13}, La/X9;->z()V

    .line 432
    .line 433
    .line 434
    :cond_e
    invoke-virtual {v1, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 435
    .line 436
    .line 437
    move-result v2

    .line 438
    if-eqz v2, :cond_f

    .line 439
    .line 440
    invoke-virtual {v1, v9, v9}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 441
    .line 442
    .line 443
    move-result v2

    .line 444
    if-eqz v2, :cond_f

    .line 445
    .line 446
    new-instance v5, La/fy;

    .line 447
    .line 448
    invoke-direct {v5, v3, v2}, La/fy;-><init>(Landroid/content/Context;I)V

    .line 449
    .line 450
    .line 451
    goto :goto_2

    .line 452
    :cond_f
    const/4 v5, 0x0

    .line 453
    :goto_2
    iget v2, v5, La/fy;->M:F

    .line 454
    .line 455
    invoke-virtual {v1, v11, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 456
    .line 457
    .line 458
    move-result v2

    .line 459
    iput v2, v5, La/fy;->M:F

    .line 460
    .line 461
    invoke-virtual {v6, v5, v3}, La/rY;->h(La/fy;Landroid/content/Context;)V

    .line 462
    .line 463
    .line 464
    const/4 v2, 0x3

    .line 465
    invoke-virtual {v1, v2, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 466
    .line 467
    .line 468
    move-result v5

    .line 469
    if-eq v5, v11, :cond_12

    .line 470
    .line 471
    const/4 v6, 0x2

    .line 472
    if-eq v5, v6, :cond_11

    .line 473
    .line 474
    if-eq v5, v2, :cond_10

    .line 475
    .line 476
    goto :goto_4

    .line 477
    :cond_10
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 478
    .line 479
    :goto_3
    iput-object v2, v13, La/X9;->Pi:Landroid/text/TextUtils$TruncateAt;

    .line 480
    .line 481
    goto :goto_4

    .line 482
    :cond_11
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->MIDDLE:Landroid/text/TextUtils$TruncateAt;

    .line 483
    .line 484
    goto :goto_3

    .line 485
    :cond_12
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->START:Landroid/text/TextUtils$TruncateAt;

    .line 486
    .line 487
    goto :goto_3

    .line 488
    :goto_4
    const/16 v2, 0x12

    .line 489
    .line 490
    invoke-virtual {v1, v2, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 491
    .line 492
    .line 493
    move-result v2

    .line 494
    invoke-virtual {v13, v2}, La/X9;->Y(Z)V

    .line 495
    .line 496
    .line 497
    const-string v2, "http://schemas.android.com/apk/res-auto"

    .line 498
    .line 499
    if-eqz v7, :cond_13

    .line 500
    .line 501
    const-string v5, "chipIconEnabled"

    .line 502
    .line 503
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v5

    .line 507
    if-eqz v5, :cond_13

    .line 508
    .line 509
    const-string v5, "chipIconVisible"

    .line 510
    .line 511
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object v5

    .line 515
    if-nez v5, :cond_13

    .line 516
    .line 517
    const/16 v5, 0xf

    .line 518
    .line 519
    invoke-virtual {v1, v5, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 520
    .line 521
    .line 522
    move-result v5

    .line 523
    invoke-virtual {v13, v5}, La/X9;->Y(Z)V

    .line 524
    .line 525
    .line 526
    :cond_13
    const/16 v5, 0xe

    .line 527
    .line 528
    invoke-static {v3, v1, v5}, La/rx;->t(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    .line 529
    .line 530
    .line 531
    move-result-object v5

    .line 532
    iget-object v6, v13, La/X9;->N:Landroid/graphics/drawable/Drawable;

    .line 533
    .line 534
    if-eqz v6, :cond_14

    .line 535
    .line 536
    instance-of v12, v6, La/Ju;

    .line 537
    .line 538
    if-eqz v12, :cond_15

    .line 539
    .line 540
    check-cast v6, La/Ju;

    .line 541
    .line 542
    check-cast v6, La/nW;

    .line 543
    .line 544
    const/4 v12, 0x0

    .line 545
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 546
    .line 547
    .line 548
    move-object v6, v12

    .line 549
    goto :goto_5

    .line 550
    :cond_14
    const/4 v6, 0x0

    .line 551
    :cond_15
    :goto_5
    if-eq v6, v5, :cond_18

    .line 552
    .line 553
    invoke-virtual {v13}, La/X9;->q()F

    .line 554
    .line 555
    .line 556
    move-result v12

    .line 557
    if-eqz v5, :cond_16

    .line 558
    .line 559
    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 560
    .line 561
    .line 562
    move-result-object v5

    .line 563
    goto :goto_6

    .line 564
    :cond_16
    const/4 v5, 0x0

    .line 565
    :goto_6
    iput-object v5, v13, La/X9;->N:Landroid/graphics/drawable/Drawable;

    .line 566
    .line 567
    invoke-virtual {v13}, La/X9;->q()F

    .line 568
    .line 569
    .line 570
    move-result v5

    .line 571
    invoke-static {v6}, La/X9;->s(Landroid/graphics/drawable/Drawable;)V

    .line 572
    .line 573
    .line 574
    invoke-virtual {v13}, La/X9;->k()Z

    .line 575
    .line 576
    .line 577
    move-result v6

    .line 578
    if-eqz v6, :cond_17

    .line 579
    .line 580
    iget-object v6, v13, La/X9;->N:Landroid/graphics/drawable/Drawable;

    .line 581
    .line 582
    invoke-virtual {v13, v6}, La/X9;->l(Landroid/graphics/drawable/Drawable;)V

    .line 583
    .line 584
    .line 585
    :cond_17
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 586
    .line 587
    .line 588
    cmpl-float v5, v12, v5

    .line 589
    .line 590
    if-eqz v5, :cond_18

    .line 591
    .line 592
    invoke-virtual {v13}, La/X9;->z()V

    .line 593
    .line 594
    .line 595
    :cond_18
    const/16 v5, 0x11

    .line 596
    .line 597
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 598
    .line 599
    .line 600
    move-result v6

    .line 601
    if-eqz v6, :cond_1a

    .line 602
    .line 603
    invoke-static {v3, v1, v5}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 604
    .line 605
    .line 606
    move-result-object v5

    .line 607
    iput-boolean v11, v13, La/X9;->G:Z

    .line 608
    .line 609
    iget-object v6, v13, La/X9;->b:Landroid/content/res/ColorStateList;

    .line 610
    .line 611
    if-eq v6, v5, :cond_1a

    .line 612
    .line 613
    iput-object v5, v13, La/X9;->b:Landroid/content/res/ColorStateList;

    .line 614
    .line 615
    invoke-virtual {v13}, La/X9;->k()Z

    .line 616
    .line 617
    .line 618
    move-result v6

    .line 619
    if-eqz v6, :cond_19

    .line 620
    .line 621
    iget-object v6, v13, La/X9;->N:Landroid/graphics/drawable/Drawable;

    .line 622
    .line 623
    invoke-static {v6, v5}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 624
    .line 625
    .line 626
    :cond_19
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 627
    .line 628
    .line 629
    move-result-object v5

    .line 630
    invoke-virtual {v13, v5}, La/X9;->onStateChange([I)Z

    .line 631
    .line 632
    .line 633
    :cond_1a
    const/16 v5, 0x10

    .line 634
    .line 635
    const/high16 v6, -0x40800000    # -1.0f

    .line 636
    .line 637
    invoke-virtual {v1, v5, v6}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 638
    .line 639
    .line 640
    move-result v5

    .line 641
    iget v6, v13, La/X9;->J:F

    .line 642
    .line 643
    cmpl-float v6, v6, v5

    .line 644
    .line 645
    if-eqz v6, :cond_1b

    .line 646
    .line 647
    invoke-virtual {v13}, La/X9;->q()F

    .line 648
    .line 649
    .line 650
    move-result v6

    .line 651
    iput v5, v13, La/X9;->J:F

    .line 652
    .line 653
    invoke-virtual {v13}, La/X9;->q()F

    .line 654
    .line 655
    .line 656
    move-result v5

    .line 657
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 658
    .line 659
    .line 660
    cmpl-float v5, v6, v5

    .line 661
    .line 662
    if-eqz v5, :cond_1b

    .line 663
    .line 664
    invoke-virtual {v13}, La/X9;->z()V

    .line 665
    .line 666
    .line 667
    :cond_1b
    const/16 v5, 0x1f

    .line 668
    .line 669
    invoke-virtual {v1, v5, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 670
    .line 671
    .line 672
    move-result v5

    .line 673
    invoke-virtual {v13, v5}, La/X9;->u(Z)V

    .line 674
    .line 675
    .line 676
    if-eqz v7, :cond_1c

    .line 677
    .line 678
    const-string v5, "closeIconEnabled"

    .line 679
    .line 680
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 681
    .line 682
    .line 683
    move-result-object v5

    .line 684
    if-eqz v5, :cond_1c

    .line 685
    .line 686
    const-string v5, "closeIconVisible"

    .line 687
    .line 688
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 689
    .line 690
    .line 691
    move-result-object v5

    .line 692
    if-nez v5, :cond_1c

    .line 693
    .line 694
    const/16 v5, 0x1a

    .line 695
    .line 696
    invoke-virtual {v1, v5, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 697
    .line 698
    .line 699
    move-result v5

    .line 700
    invoke-virtual {v13, v5}, La/X9;->u(Z)V

    .line 701
    .line 702
    .line 703
    :cond_1c
    const/16 v5, 0x19

    .line 704
    .line 705
    invoke-static {v3, v1, v5}, La/rx;->t(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    .line 706
    .line 707
    .line 708
    move-result-object v5

    .line 709
    iget-object v6, v13, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 710
    .line 711
    if-eqz v6, :cond_1d

    .line 712
    .line 713
    instance-of v12, v6, La/Ju;

    .line 714
    .line 715
    if-eqz v12, :cond_1e

    .line 716
    .line 717
    check-cast v6, La/Ju;

    .line 718
    .line 719
    check-cast v6, La/nW;

    .line 720
    .line 721
    const/4 v12, 0x0

    .line 722
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 723
    .line 724
    .line 725
    move-object v6, v12

    .line 726
    goto :goto_7

    .line 727
    :cond_1d
    const/4 v6, 0x0

    .line 728
    :cond_1e
    :goto_7
    if-eq v6, v5, :cond_21

    .line 729
    .line 730
    invoke-virtual {v13}, La/X9;->F()F

    .line 731
    .line 732
    .line 733
    move-result v12

    .line 734
    if-eqz v5, :cond_1f

    .line 735
    .line 736
    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 737
    .line 738
    .line 739
    move-result-object v5

    .line 740
    goto :goto_8

    .line 741
    :cond_1f
    const/4 v5, 0x0

    .line 742
    :goto_8
    iput-object v5, v13, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 743
    .line 744
    sget-object v5, La/J3;->w:[I

    .line 745
    .line 746
    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    .line 747
    .line 748
    iget-object v15, v13, La/X9;->c:Landroid/content/res/ColorStateList;

    .line 749
    .line 750
    invoke-static {v15}, La/J3;->h(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    .line 751
    .line 752
    .line 753
    move-result-object v15

    .line 754
    iget-object v11, v13, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 755
    .line 756
    sget-object v8, La/X9;->ID:Landroid/graphics/drawable/ShapeDrawable;

    .line 757
    .line 758
    invoke-direct {v5, v15, v11, v8}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 759
    .line 760
    .line 761
    iput-object v5, v13, La/X9;->rV:Landroid/graphics/drawable/RippleDrawable;

    .line 762
    .line 763
    invoke-virtual {v13}, La/X9;->F()F

    .line 764
    .line 765
    .line 766
    move-result v5

    .line 767
    invoke-static {v6}, La/X9;->s(Landroid/graphics/drawable/Drawable;)V

    .line 768
    .line 769
    .line 770
    invoke-virtual {v13}, La/X9;->v()Z

    .line 771
    .line 772
    .line 773
    move-result v6

    .line 774
    if-eqz v6, :cond_20

    .line 775
    .line 776
    iget-object v6, v13, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 777
    .line 778
    invoke-virtual {v13, v6}, La/X9;->l(Landroid/graphics/drawable/Drawable;)V

    .line 779
    .line 780
    .line 781
    :cond_20
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 782
    .line 783
    .line 784
    cmpl-float v5, v12, v5

    .line 785
    .line 786
    if-eqz v5, :cond_21

    .line 787
    .line 788
    invoke-virtual {v13}, La/X9;->z()V

    .line 789
    .line 790
    .line 791
    :cond_21
    const/16 v5, 0x1e

    .line 792
    .line 793
    invoke-static {v3, v1, v5}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 794
    .line 795
    .line 796
    move-result-object v5

    .line 797
    iget-object v6, v13, La/X9;->rC:Landroid/content/res/ColorStateList;

    .line 798
    .line 799
    if-eq v6, v5, :cond_23

    .line 800
    .line 801
    iput-object v5, v13, La/X9;->rC:Landroid/content/res/ColorStateList;

    .line 802
    .line 803
    invoke-virtual {v13}, La/X9;->v()Z

    .line 804
    .line 805
    .line 806
    move-result v6

    .line 807
    if-eqz v6, :cond_22

    .line 808
    .line 809
    iget-object v6, v13, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 810
    .line 811
    invoke-static {v6, v5}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 812
    .line 813
    .line 814
    :cond_22
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 815
    .line 816
    .line 817
    move-result-object v5

    .line 818
    invoke-virtual {v13, v5}, La/X9;->onStateChange([I)Z

    .line 819
    .line 820
    .line 821
    :cond_23
    const/16 v5, 0x1c

    .line 822
    .line 823
    invoke-virtual {v1, v5, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 824
    .line 825
    .line 826
    move-result v5

    .line 827
    iget v6, v13, La/X9;->p7:F

    .line 828
    .line 829
    cmpl-float v6, v6, v5

    .line 830
    .line 831
    if-eqz v6, :cond_24

    .line 832
    .line 833
    iput v5, v13, La/X9;->p7:F

    .line 834
    .line 835
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 836
    .line 837
    .line 838
    invoke-virtual {v13}, La/X9;->v()Z

    .line 839
    .line 840
    .line 841
    move-result v5

    .line 842
    if-eqz v5, :cond_24

    .line 843
    .line 844
    invoke-virtual {v13}, La/X9;->z()V

    .line 845
    .line 846
    .line 847
    :cond_24
    const/4 v5, 0x6

    .line 848
    invoke-virtual {v1, v5, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 849
    .line 850
    .line 851
    move-result v5

    .line 852
    iget-boolean v6, v13, La/X9;->F9:Z

    .line 853
    .line 854
    if-eq v6, v5, :cond_26

    .line 855
    .line 856
    iput-boolean v5, v13, La/X9;->F9:Z

    .line 857
    .line 858
    invoke-virtual {v13}, La/X9;->q()F

    .line 859
    .line 860
    .line 861
    move-result v6

    .line 862
    if-nez v5, :cond_25

    .line 863
    .line 864
    iget-boolean v5, v13, La/X9;->N3:Z

    .line 865
    .line 866
    if-eqz v5, :cond_25

    .line 867
    .line 868
    iput-boolean v9, v13, La/X9;->N3:Z

    .line 869
    .line 870
    :cond_25
    invoke-virtual {v13}, La/X9;->q()F

    .line 871
    .line 872
    .line 873
    move-result v5

    .line 874
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 875
    .line 876
    .line 877
    cmpl-float v5, v6, v5

    .line 878
    .line 879
    if-eqz v5, :cond_26

    .line 880
    .line 881
    invoke-virtual {v13}, La/X9;->z()V

    .line 882
    .line 883
    .line 884
    :cond_26
    const/16 v5, 0xa

    .line 885
    .line 886
    invoke-virtual {v1, v5, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 887
    .line 888
    .line 889
    move-result v5

    .line 890
    invoke-virtual {v13, v5}, La/X9;->D(Z)V

    .line 891
    .line 892
    .line 893
    if-eqz v7, :cond_27

    .line 894
    .line 895
    const-string v5, "checkedIconEnabled"

    .line 896
    .line 897
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 898
    .line 899
    .line 900
    move-result-object v5

    .line 901
    if-eqz v5, :cond_27

    .line 902
    .line 903
    const-string v5, "checkedIconVisible"

    .line 904
    .line 905
    invoke-interface {v7, v2, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 906
    .line 907
    .line 908
    move-result-object v2

    .line 909
    if-nez v2, :cond_27

    .line 910
    .line 911
    const/16 v2, 0x8

    .line 912
    .line 913
    invoke-virtual {v1, v2, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 914
    .line 915
    .line 916
    move-result v2

    .line 917
    invoke-virtual {v13, v2}, La/X9;->D(Z)V

    .line 918
    .line 919
    .line 920
    :cond_27
    const/4 v2, 0x7

    .line 921
    invoke-static {v3, v1, v2}, La/rx;->t(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    .line 922
    .line 923
    .line 924
    move-result-object v2

    .line 925
    iget-object v5, v13, La/X9;->mh:Landroid/graphics/drawable/Drawable;

    .line 926
    .line 927
    if-eq v5, v2, :cond_28

    .line 928
    .line 929
    invoke-virtual {v13}, La/X9;->q()F

    .line 930
    .line 931
    .line 932
    move-result v5

    .line 933
    iput-object v2, v13, La/X9;->mh:Landroid/graphics/drawable/Drawable;

    .line 934
    .line 935
    invoke-virtual {v13}, La/X9;->q()F

    .line 936
    .line 937
    .line 938
    move-result v2

    .line 939
    iget-object v6, v13, La/X9;->mh:Landroid/graphics/drawable/Drawable;

    .line 940
    .line 941
    invoke-static {v6}, La/X9;->s(Landroid/graphics/drawable/Drawable;)V

    .line 942
    .line 943
    .line 944
    iget-object v6, v13, La/X9;->mh:Landroid/graphics/drawable/Drawable;

    .line 945
    .line 946
    invoke-virtual {v13, v6}, La/X9;->l(Landroid/graphics/drawable/Drawable;)V

    .line 947
    .line 948
    .line 949
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 950
    .line 951
    .line 952
    cmpl-float v2, v5, v2

    .line 953
    .line 954
    if-eqz v2, :cond_28

    .line 955
    .line 956
    invoke-virtual {v13}, La/X9;->z()V

    .line 957
    .line 958
    .line 959
    :cond_28
    const/16 v2, 0x9

    .line 960
    .line 961
    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 962
    .line 963
    .line 964
    move-result v5

    .line 965
    if-eqz v5, :cond_2a

    .line 966
    .line 967
    invoke-static {v3, v1, v2}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 968
    .line 969
    .line 970
    move-result-object v2

    .line 971
    iget-object v5, v13, La/X9;->ZU:Landroid/content/res/ColorStateList;

    .line 972
    .line 973
    if-eq v5, v2, :cond_2a

    .line 974
    .line 975
    iput-object v2, v13, La/X9;->ZU:Landroid/content/res/ColorStateList;

    .line 976
    .line 977
    iget-boolean v5, v13, La/X9;->eH:Z

    .line 978
    .line 979
    if-eqz v5, :cond_29

    .line 980
    .line 981
    iget-object v5, v13, La/X9;->mh:Landroid/graphics/drawable/Drawable;

    .line 982
    .line 983
    if-eqz v5, :cond_29

    .line 984
    .line 985
    iget-boolean v6, v13, La/X9;->F9:Z

    .line 986
    .line 987
    if-eqz v6, :cond_29

    .line 988
    .line 989
    invoke-static {v5, v2}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 990
    .line 991
    .line 992
    :cond_29
    invoke-virtual {v13}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 993
    .line 994
    .line 995
    move-result-object v2

    .line 996
    invoke-virtual {v13, v2}, La/X9;->onStateChange([I)Z

    .line 997
    .line 998
    .line 999
    :cond_2a
    const/16 v2, 0x27

    .line 1000
    .line 1001
    invoke-static {v3, v1, v2}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 1002
    .line 1003
    .line 1004
    const/16 v2, 0x21

    .line 1005
    .line 1006
    invoke-static {v3, v1, v2}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 1007
    .line 1008
    .line 1009
    const/16 v2, 0x15

    .line 1010
    .line 1011
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1012
    .line 1013
    .line 1014
    move-result v2

    .line 1015
    iget v3, v13, La/X9;->rZ:F

    .line 1016
    .line 1017
    cmpl-float v3, v3, v2

    .line 1018
    .line 1019
    if-eqz v3, :cond_2b

    .line 1020
    .line 1021
    iput v2, v13, La/X9;->rZ:F

    .line 1022
    .line 1023
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1024
    .line 1025
    .line 1026
    invoke-virtual {v13}, La/X9;->z()V

    .line 1027
    .line 1028
    .line 1029
    :cond_2b
    const/16 v2, 0x23

    .line 1030
    .line 1031
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1032
    .line 1033
    .line 1034
    move-result v2

    .line 1035
    iget v3, v13, La/X9;->B1:F

    .line 1036
    .line 1037
    cmpl-float v3, v3, v2

    .line 1038
    .line 1039
    if-eqz v3, :cond_2c

    .line 1040
    .line 1041
    invoke-virtual {v13}, La/X9;->q()F

    .line 1042
    .line 1043
    .line 1044
    move-result v3

    .line 1045
    iput v2, v13, La/X9;->B1:F

    .line 1046
    .line 1047
    invoke-virtual {v13}, La/X9;->q()F

    .line 1048
    .line 1049
    .line 1050
    move-result v2

    .line 1051
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1052
    .line 1053
    .line 1054
    cmpl-float v2, v3, v2

    .line 1055
    .line 1056
    if-eqz v2, :cond_2c

    .line 1057
    .line 1058
    invoke-virtual {v13}, La/X9;->z()V

    .line 1059
    .line 1060
    .line 1061
    :cond_2c
    const/16 v2, 0x22

    .line 1062
    .line 1063
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1064
    .line 1065
    .line 1066
    move-result v2

    .line 1067
    iget v3, v13, La/X9;->y6:F

    .line 1068
    .line 1069
    cmpl-float v3, v3, v2

    .line 1070
    .line 1071
    if-eqz v3, :cond_2d

    .line 1072
    .line 1073
    invoke-virtual {v13}, La/X9;->q()F

    .line 1074
    .line 1075
    .line 1076
    move-result v3

    .line 1077
    iput v2, v13, La/X9;->y6:F

    .line 1078
    .line 1079
    invoke-virtual {v13}, La/X9;->q()F

    .line 1080
    .line 1081
    .line 1082
    move-result v2

    .line 1083
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1084
    .line 1085
    .line 1086
    cmpl-float v2, v3, v2

    .line 1087
    .line 1088
    if-eqz v2, :cond_2d

    .line 1089
    .line 1090
    invoke-virtual {v13}, La/X9;->z()V

    .line 1091
    .line 1092
    .line 1093
    :cond_2d
    const/16 v2, 0x29

    .line 1094
    .line 1095
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1096
    .line 1097
    .line 1098
    move-result v2

    .line 1099
    iget v3, v13, La/X9;->xF:F

    .line 1100
    .line 1101
    cmpl-float v3, v3, v2

    .line 1102
    .line 1103
    if-eqz v3, :cond_2e

    .line 1104
    .line 1105
    iput v2, v13, La/X9;->xF:F

    .line 1106
    .line 1107
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1108
    .line 1109
    .line 1110
    invoke-virtual {v13}, La/X9;->z()V

    .line 1111
    .line 1112
    .line 1113
    :cond_2e
    const/16 v2, 0x28

    .line 1114
    .line 1115
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1116
    .line 1117
    .line 1118
    move-result v2

    .line 1119
    iget v3, v13, La/X9;->Pb:F

    .line 1120
    .line 1121
    cmpl-float v3, v3, v2

    .line 1122
    .line 1123
    if-eqz v3, :cond_2f

    .line 1124
    .line 1125
    iput v2, v13, La/X9;->Pb:F

    .line 1126
    .line 1127
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1128
    .line 1129
    .line 1130
    invoke-virtual {v13}, La/X9;->z()V

    .line 1131
    .line 1132
    .line 1133
    :cond_2f
    const/16 v2, 0x1d

    .line 1134
    .line 1135
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1136
    .line 1137
    .line 1138
    move-result v2

    .line 1139
    iget v3, v13, La/X9;->lI:F

    .line 1140
    .line 1141
    cmpl-float v3, v3, v2

    .line 1142
    .line 1143
    if-eqz v3, :cond_30

    .line 1144
    .line 1145
    iput v2, v13, La/X9;->lI:F

    .line 1146
    .line 1147
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1148
    .line 1149
    .line 1150
    invoke-virtual {v13}, La/X9;->v()Z

    .line 1151
    .line 1152
    .line 1153
    move-result v2

    .line 1154
    if-eqz v2, :cond_30

    .line 1155
    .line 1156
    invoke-virtual {v13}, La/X9;->z()V

    .line 1157
    .line 1158
    .line 1159
    :cond_30
    const/16 v2, 0x1b

    .line 1160
    .line 1161
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1162
    .line 1163
    .line 1164
    move-result v2

    .line 1165
    iget v3, v13, La/X9;->VQ:F

    .line 1166
    .line 1167
    cmpl-float v3, v3, v2

    .line 1168
    .line 1169
    if-eqz v3, :cond_31

    .line 1170
    .line 1171
    iput v2, v13, La/X9;->VQ:F

    .line 1172
    .line 1173
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1174
    .line 1175
    .line 1176
    invoke-virtual {v13}, La/X9;->v()Z

    .line 1177
    .line 1178
    .line 1179
    move-result v2

    .line 1180
    if-eqz v2, :cond_31

    .line 1181
    .line 1182
    invoke-virtual {v13}, La/X9;->z()V

    .line 1183
    .line 1184
    .line 1185
    :cond_31
    const/16 v2, 0xd

    .line 1186
    .line 1187
    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1188
    .line 1189
    .line 1190
    move-result v2

    .line 1191
    iget v3, v13, La/X9;->HF:F

    .line 1192
    .line 1193
    cmpl-float v3, v3, v2

    .line 1194
    .line 1195
    if-eqz v3, :cond_32

    .line 1196
    .line 1197
    iput v2, v13, La/X9;->HF:F

    .line 1198
    .line 1199
    invoke-virtual {v13}, La/ex;->invalidateSelf()V

    .line 1200
    .line 1201
    .line 1202
    invoke-virtual {v13}, La/X9;->z()V

    .line 1203
    .line 1204
    .line 1205
    :cond_32
    const/4 v2, 0x4

    .line 1206
    const v3, 0x7fffffff

    .line 1207
    .line 1208
    .line 1209
    invoke-virtual {v1, v2, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 1210
    .line 1211
    .line 1212
    move-result v2

    .line 1213
    iput v2, v13, La/X9;->rn:I

    .line 1214
    .line 1215
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 1216
    .line 1217
    .line 1218
    const v8, 0x7f13043d

    .line 1219
    .line 1220
    .line 1221
    new-array v6, v9, [I

    .line 1222
    .line 1223
    const v11, 0x7f0400d6

    .line 1224
    .line 1225
    .line 1226
    invoke-static {v10, v7, v11, v8}, La/fe;->i(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 1227
    .line 1228
    .line 1229
    move-object v1, v10

    .line 1230
    move-object/from16 v2, p2

    .line 1231
    .line 1232
    move-object v3, v14

    .line 1233
    move v4, v11

    .line 1234
    move v5, v8

    .line 1235
    const/4 v12, 0x0

    .line 1236
    invoke-static/range {v1 .. v6}, La/fe;->O(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V

    .line 1237
    .line 1238
    .line 1239
    invoke-virtual {v10, v7, v14, v11, v8}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 1240
    .line 1241
    .line 1242
    move-result-object v1

    .line 1243
    const/16 v2, 0x20

    .line 1244
    .line 1245
    invoke-virtual {v1, v2, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 1246
    .line 1247
    .line 1248
    move-result v2

    .line 1249
    iput-boolean v2, v0, Lcom/google/android/material/chip/Chip;->z:Z

    .line 1250
    .line 1251
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1252
    .line 1253
    .line 1254
    move-result-object v2

    .line 1255
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 1256
    .line 1257
    .line 1258
    move-result-object v2

    .line 1259
    const/16 v3, 0x30

    .line 1260
    .line 1261
    int-to-float v3, v3

    .line 1262
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 1263
    .line 1264
    .line 1265
    move-result-object v2

    .line 1266
    const/4 v4, 0x1

    .line 1267
    invoke-static {v4, v3, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 1268
    .line 1269
    .line 1270
    move-result v2

    .line 1271
    float-to-double v2, v2

    .line 1272
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 1273
    .line 1274
    .line 1275
    move-result-wide v2

    .line 1276
    double-to-float v2, v2

    .line 1277
    const/16 v3, 0x14

    .line 1278
    .line 1279
    invoke-virtual {v1, v3, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 1280
    .line 1281
    .line 1282
    move-result v2

    .line 1283
    float-to-double v2, v2

    .line 1284
    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    .line 1285
    .line 1286
    .line 1287
    move-result-wide v2

    .line 1288
    double-to-int v2, v2

    .line 1289
    iput v2, v0, Lcom/google/android/material/chip/Chip;->D:I

    .line 1290
    .line 1291
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 1292
    .line 1293
    .line 1294
    iget-object v1, v0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 1295
    .line 1296
    if-eq v1, v13, :cond_34

    .line 1297
    .line 1298
    if-eqz v1, :cond_33

    .line 1299
    .line 1300
    new-instance v2, Ljava/lang/ref/WeakReference;

    .line 1301
    .line 1302
    invoke-direct {v2, v12}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 1303
    .line 1304
    .line 1305
    iput-object v2, v1, La/X9;->Qn:Ljava/lang/ref/WeakReference;

    .line 1306
    .line 1307
    :cond_33
    iput-object v13, v0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 1308
    .line 1309
    iput-boolean v9, v13, La/X9;->ZZ:Z

    .line 1310
    .line 1311
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 1312
    .line 1313
    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 1314
    .line 1315
    .line 1316
    iput-object v1, v13, La/X9;->Qn:Ljava/lang/ref/WeakReference;

    .line 1317
    .line 1318
    iget v1, v0, Lcom/google/android/material/chip/Chip;->D:I

    .line 1319
    .line 1320
    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/Chip;->w(I)V

    .line 1321
    .line 1322
    .line 1323
    :cond_34
    invoke-static/range {p0 .. p0}, La/Sg;->V(Landroid/view/View;)F

    .line 1324
    .line 1325
    .line 1326
    move-result v1

    .line 1327
    invoke-virtual {v13, v1}, La/ex;->y(F)V

    .line 1328
    .line 1329
    .line 1330
    const v8, 0x7f13043d

    .line 1331
    .line 1332
    .line 1333
    new-array v6, v9, [I

    .line 1334
    .line 1335
    const v9, 0x7f0400d6

    .line 1336
    .line 1337
    .line 1338
    invoke-static {v10, v7, v9, v8}, La/fe;->i(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 1339
    .line 1340
    .line 1341
    move-object v1, v10

    .line 1342
    move-object/from16 v2, p2

    .line 1343
    .line 1344
    move-object v3, v14

    .line 1345
    move v4, v9

    .line 1346
    move v5, v8

    .line 1347
    invoke-static/range {v1 .. v6}, La/fe;->O(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V

    .line 1348
    .line 1349
    .line 1350
    invoke-virtual {v10, v7, v14, v9, v8}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 1351
    .line 1352
    .line 1353
    move-result-object v1

    .line 1354
    const/16 v2, 0x25

    .line 1355
    .line 1356
    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 1357
    .line 1358
    .line 1359
    move-result v2

    .line 1360
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 1361
    .line 1362
    .line 1363
    new-instance v1, La/ku;

    .line 1364
    .line 1365
    invoke-direct {v1, v0, v0}, La/ku;-><init>(Lcom/google/android/material/chip/Chip;Lcom/google/android/material/chip/Chip;)V

    .line 1366
    .line 1367
    .line 1368
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/chip/Chip;->p()Z

    .line 1369
    .line 1370
    .line 1371
    move-result v1

    .line 1372
    if-eqz v1, :cond_35

    .line 1373
    .line 1374
    iget-object v1, v0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 1375
    .line 1376
    if-eqz v1, :cond_35

    .line 1377
    .line 1378
    iget-boolean v1, v1, La/X9;->Pc:Z

    .line 1379
    .line 1380
    :cond_35
    invoke-static {v0, v12}, La/sI;->T(Landroid/view/View;La/Qg;)V

    .line 1381
    .line 1382
    .line 1383
    if-nez v2, :cond_36

    .line 1384
    .line 1385
    new-instance v1, La/cK;

    .line 1386
    .line 1387
    invoke-direct {v1, v0}, La/cK;-><init>(Lcom/google/android/material/chip/Chip;)V

    .line 1388
    .line 1389
    .line 1390
    invoke-virtual {v0, v1}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    .line 1391
    .line 1392
    .line 1393
    :cond_36
    iget-boolean v1, v0, Lcom/google/android/material/chip/Chip;->F:Z

    .line 1394
    .line 1395
    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/Chip;->setChecked(Z)V

    .line 1396
    .line 1397
    .line 1398
    iget-object v1, v13, La/X9;->B:Ljava/lang/CharSequence;

    .line 1399
    .line 1400
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1401
    .line 1402
    .line 1403
    iget-object v1, v13, La/X9;->Pi:Landroid/text/TextUtils$TruncateAt;

    .line 1404
    .line 1405
    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/Chip;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1406
    .line 1407
    .line 1408
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/chip/Chip;->V()V

    .line 1409
    .line 1410
    .line 1411
    iget-object v1, v0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 1412
    .line 1413
    iget-boolean v1, v1, La/X9;->ZZ:Z

    .line 1414
    .line 1415
    if-nez v1, :cond_37

    .line 1416
    .line 1417
    const/4 v1, 0x1

    .line 1418
    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/Chip;->setLines(I)V

    .line 1419
    .line 1420
    .line 1421
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    .line 1422
    .line 1423
    .line 1424
    :cond_37
    const v1, 0x800013

    .line 1425
    .line 1426
    .line 1427
    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/Chip;->setGravity(I)V

    .line 1428
    .line 1429
    .line 1430
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/chip/Chip;->O()V

    .line 1431
    .line 1432
    .line 1433
    iget-boolean v1, v0, Lcom/google/android/material/chip/Chip;->z:Z

    .line 1434
    .line 1435
    if-eqz v1, :cond_38

    .line 1436
    .line 1437
    iget v1, v0, Lcom/google/android/material/chip/Chip;->D:I

    .line 1438
    .line 1439
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 1440
    .line 1441
    .line 1442
    :cond_38
    invoke-static/range {p0 .. p0}, La/XC;->e(Landroid/view/View;)I

    .line 1443
    .line 1444
    .line 1445
    move-result v1

    .line 1446
    iput v1, v0, Lcom/google/android/material/chip/Chip;->P:I

    .line 1447
    .line 1448
    new-instance v1, La/tK;

    .line 1449
    .line 1450
    invoke-direct {v1, v0}, La/tK;-><init>(Lcom/google/android/material/chip/Chip;)V

    .line 1451
    .line 1452
    .line 1453
    invoke-super {v0, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 1454
    .line 1455
    .line 1456
    return-void

    .line 1457
    :cond_39
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1458
    .line 1459
    const-string v2, "Chip does not support multi-line text"

    .line 1460
    .line 1461
    invoke-direct {v1, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1462
    .line 1463
    .line 1464
    throw v1

    .line 1465
    :cond_3a
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1466
    .line 1467
    invoke-direct {v1, v4}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1468
    .line 1469
    .line 1470
    throw v1

    .line 1471
    :cond_3b
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1472
    .line 1473
    invoke-direct {v1, v4}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1474
    .line 1475
    .line 1476
    throw v1

    .line 1477
    :cond_3c
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1478
    .line 1479
    const-string v2, "Please set start drawable using R.attr#chipIcon."

    .line 1480
    .line 1481
    invoke-direct {v1, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1482
    .line 1483
    .line 1484
    throw v1

    .line 1485
    :cond_3d
    new-instance v1, Ljava/lang/UnsupportedOperationException;

    .line 1486
    .line 1487
    const-string v2, "Please set left drawable using R.attr#chipIcon."

    .line 1488
    .line 1489
    invoke-direct {v1, v2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 1490
    .line 1491
    .line 1492
    throw v1
.end method


# virtual methods
.method public final O()V
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_2

    .line 10
    .line 11
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    iget v1, v0, La/X9;->HF:F

    .line 17
    .line 18
    iget v2, v0, La/X9;->Pb:F

    .line 19
    .line 20
    add-float/2addr v1, v2

    .line 21
    invoke-virtual {v0}, La/X9;->F()F

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    add-float/2addr v0, v1

    .line 26
    float-to-int v0, v0

    .line 27
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 28
    .line 29
    iget v2, v1, La/X9;->rZ:F

    .line 30
    .line 31
    iget v3, v1, La/X9;->xF:F

    .line 32
    .line 33
    add-float/2addr v2, v3

    .line 34
    invoke-virtual {v1}, La/X9;->q()F

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    add-float/2addr v1, v2

    .line 39
    float-to-int v1, v1

    .line 40
    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 41
    .line 42
    if-eqz v2, :cond_1

    .line 43
    .line 44
    new-instance v2, Landroid/graphics/Rect;

    .line 45
    .line 46
    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    .line 47
    .line 48
    .line 49
    iget-object v3, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 50
    .line 51
    invoke-virtual {v3, v2}, Landroid/graphics/drawable/InsetDrawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 52
    .line 53
    .line 54
    iget v3, v2, Landroid/graphics/Rect;->left:I

    .line 55
    .line 56
    add-int/2addr v1, v3

    .line 57
    iget v2, v2, Landroid/graphics/Rect;->right:I

    .line 58
    .line 59
    add-int/2addr v0, v2

    .line 60
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    sget-object v4, La/sI;->w:Ljava/util/WeakHashMap;

    .line 69
    .line 70
    invoke-static {p0, v1, v2, v0, v3}, La/XC;->M(Landroid/view/View;IIII)V

    .line 71
    .line 72
    .line 73
    :cond_2
    :goto_0
    return-void
.end method

.method public final V()V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iput-object v1, v0, Landroid/text/TextPaint;->drawableState:[I

    .line 14
    .line 15
    :cond_0
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 16
    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    iget-object v1, v1, La/X9;->yd:La/rY;

    .line 20
    .line 21
    iget-object v1, v1, La/rY;->X:La/fy;

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const/4 v1, 0x0

    .line 25
    :goto_0
    if-eqz v1, :cond_2

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    iget-object v3, p0, Lcom/google/android/material/chip/Chip;->v:La/dc;

    .line 32
    .line 33
    invoke-virtual {v1, v2, v0, v3}, La/fy;->i(Landroid/content/Context;Landroid/text/TextPaint;La/Yo;)V

    .line 34
    .line 35
    .line 36
    :cond_2
    return-void
.end method

.method public final X()V
    .locals 4

    .line 1
    sget-object v0, La/J3;->w:[I

    .line 2
    .line 3
    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    .line 4
    .line 5
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 6
    .line 7
    iget-object v1, v1, La/X9;->c:Landroid/content/res/ColorStateList;

    .line 8
    .line 9
    invoke-static {v1}, La/J3;->h(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 14
    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 18
    .line 19
    :cond_0
    const/4 v3, 0x0

    .line 20
    invoke-direct {v0, v1, v2, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lcom/google/android/material/chip/Chip;->W:Landroid/graphics/drawable/RippleDrawable;

    .line 24
    .line 25
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 26
    .line 27
    iget-boolean v1, v0, La/X9;->au:Z

    .line 28
    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    iput-boolean v1, v0, La/X9;->au:Z

    .line 33
    .line 34
    iput-object v3, v0, La/X9;->sH:Landroid/content/res/ColorStateList;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-virtual {v0, v1}, La/X9;->onStateChange([I)Z

    .line 41
    .line 42
    .line 43
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->W:Landroid/graphics/drawable/RippleDrawable;

    .line 44
    .line 45
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 46
    .line 47
    invoke-static {p0, v0}, La/Tl;->L(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->O()V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final dispatchHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public final drawableStateChanged()V
    .locals 4

    .line 1
    invoke-super {p0}, La/q8;->drawableStateChanged()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 5
    .line 6
    if-eqz v0, :cond_9

    .line 7
    .line 8
    iget-object v0, v0, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 9
    .line 10
    invoke-static {v0}, La/X9;->H(Landroid/graphics/drawable/Drawable;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_9

    .line 15
    .line 16
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->H:Z

    .line 23
    .line 24
    if-eqz v2, :cond_0

    .line 25
    .line 26
    add-int/lit8 v1, v1, 0x1

    .line 27
    .line 28
    :cond_0
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->S:Z

    .line 29
    .line 30
    if-eqz v2, :cond_1

    .line 31
    .line 32
    add-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    :cond_1
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 35
    .line 36
    if-eqz v2, :cond_2

    .line 37
    .line 38
    add-int/lit8 v1, v1, 0x1

    .line 39
    .line 40
    :cond_2
    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-eqz v2, :cond_3

    .line 45
    .line 46
    add-int/lit8 v1, v1, 0x1

    .line 47
    .line 48
    :cond_3
    new-array v1, v1, [I

    .line 49
    .line 50
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    const/4 v3, 0x0

    .line 55
    if-eqz v2, :cond_4

    .line 56
    .line 57
    const v2, 0x101009e

    .line 58
    .line 59
    .line 60
    aput v2, v1, v3

    .line 61
    .line 62
    const/4 v3, 0x1

    .line 63
    :cond_4
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->H:Z

    .line 64
    .line 65
    if-eqz v2, :cond_5

    .line 66
    .line 67
    const v2, 0x101009c

    .line 68
    .line 69
    .line 70
    aput v2, v1, v3

    .line 71
    .line 72
    add-int/lit8 v3, v3, 0x1

    .line 73
    .line 74
    :cond_5
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->S:Z

    .line 75
    .line 76
    if-eqz v2, :cond_6

    .line 77
    .line 78
    const v2, 0x1010367

    .line 79
    .line 80
    .line 81
    aput v2, v1, v3

    .line 82
    .line 83
    add-int/lit8 v3, v3, 0x1

    .line 84
    .line 85
    :cond_6
    iget-boolean v2, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 86
    .line 87
    if-eqz v2, :cond_7

    .line 88
    .line 89
    const v2, 0x10100a7

    .line 90
    .line 91
    .line 92
    aput v2, v1, v3

    .line 93
    .line 94
    add-int/lit8 v3, v3, 0x1

    .line 95
    .line 96
    :cond_7
    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    if-eqz v2, :cond_8

    .line 101
    .line 102
    const v2, 0x10100a1

    .line 103
    .line 104
    .line 105
    aput v2, v1, v3

    .line 106
    .line 107
    :cond_8
    iget-object v2, v0, La/X9;->vz:[I

    .line 108
    .line 109
    invoke-static {v2, v1}, Ljava/util/Arrays;->equals([I[I)Z

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    if-nez v2, :cond_9

    .line 114
    .line 115
    iput-object v1, v0, La/X9;->vz:[I

    .line 116
    .line 117
    invoke-virtual {v0}, La/X9;->v()Z

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    if-eqz v2, :cond_9

    .line 122
    .line 123
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    invoke-virtual {v0, v2, v1}, La/X9;->P([I[I)Z

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    if-eqz v0, :cond_9

    .line 132
    .line 133
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 134
    .line 135
    .line 136
    :cond_9
    return-void
.end method

.method public final e()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-boolean v0, v0, La/X9;->F9:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    return v0
.end method

.method public final getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->u:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->u:Ljava/lang/CharSequence;

    return-object v0

    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->e()Z

    move-result v0

    const-string v1, "android.widget.Button"

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    return-object v1

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    move-result v0

    if-eqz v0, :cond_2

    return-object v1

    :cond_2
    const-string v0, "android.view.View"

    return-object v0
.end method

.method public final getEllipsize()Landroid/text/TextUtils$TruncateAt;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, v0, La/X9;->Pi:Landroid/text/TextUtils$TruncateAt;

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    return-object v0
.end method

.method public final getFocusedRect(Landroid/graphics/Rect;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->getFocusedRect(Landroid/graphics/Rect;)V

    return-void
.end method

.method public final h(La/c9;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    invoke-virtual {v0, p1}, La/ex;->h(La/c9;)V

    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 1

    invoke-super {p0}, Landroid/widget/CheckBox;->onAttachedToWindow()V

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    invoke-static {p0, v0}, La/rx;->GI(Landroid/view/View;La/ex;)V

    return-void
.end method

.method public final onCreateDrawableState(I)[I
    .locals 1

    add-int/lit8 p1, p1, 0x2

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onCreateDrawableState(I)[I

    move-result-object p1

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/google/android/material/chip/Chip;->j:[I

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->e()Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/google/android/material/chip/Chip;->t:[I

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_1
    return-object p1
.end method

.method public final onFocusChanged(ZILandroid/graphics/Rect;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/widget/CheckBox;->onFocusChanged(ZILandroid/graphics/Rect;)V

    return-void
.end method

.method public final onHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x7

    .line 6
    if-eq v0, v1, :cond_1

    .line 7
    .line 8
    const/16 v1, 0xa

    .line 9
    .line 10
    if-eq v0, v1, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->S:Z

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    :goto_0
    iput-boolean v0, p0, Lcom/google/android/material/chip/Chip;->S:Z

    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 21
    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->k:Landroid/graphics/RectF;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->p()Z

    .line 30
    .line 31
    .line 32
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-virtual {v0, v1, v2}, Landroid/graphics/RectF;->contains(FF)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->S:Z

    .line 45
    .line 46
    if-eq v1, v0, :cond_2

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_2
    :goto_1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    return p1
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getAccessibilityClassName()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->e()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    return-void
.end method

.method public final onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->k:Landroid/graphics/RectF;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->p()Z

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    invoke-virtual {v0, v1, v2}, Landroid/graphics/RectF;->contains(FF)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    const/16 p2, 0x3ea

    .line 34
    .line 35
    invoke-static {p1, p2}, Landroid/view/PointerIcon;->getSystemIcon(Landroid/content/Context;I)Landroid/view/PointerIcon;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    return-object p1

    .line 40
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    return-object p1
.end method

.method public final onRtlPropertiesChanged(I)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onRtlPropertiesChanged(I)V

    iget v0, p0, Lcom/google/android/material/chip/Chip;->P:I

    if-eq v0, p1, :cond_0

    iput p1, p0, Lcom/google/android/material/chip/Chip;->P:I

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->O()V

    :cond_0
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 5

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->k:Landroid/graphics/RectF;

    .line 6
    .line 7
    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->p()Z

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v2, 0x1

    .line 26
    const/4 v3, 0x0

    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    if-eq v0, v2, :cond_1

    .line 30
    .line 31
    const/4 v4, 0x2

    .line 32
    if-eq v0, v4, :cond_0

    .line 33
    .line 34
    const/4 v1, 0x3

    .line 35
    if-eq v0, v1, :cond_2

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 39
    .line 40
    if-eqz v0, :cond_5

    .line 41
    .line 42
    if-nez v1, :cond_7

    .line 43
    .line 44
    if-eqz v0, :cond_7

    .line 45
    .line 46
    iput-boolean v3, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 47
    .line 48
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 49
    .line 50
    .line 51
    goto :goto_2

    .line 52
    :cond_1
    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 53
    .line 54
    if-eqz v0, :cond_2

    .line 55
    .line 56
    invoke-virtual {p0, v3}, Landroid/view/View;->playSoundEffect(I)V

    .line 57
    .line 58
    .line 59
    move v0, v2

    .line 60
    goto :goto_0

    .line 61
    :cond_2
    move v0, v3

    .line 62
    :goto_0
    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 63
    .line 64
    if-eqz v1, :cond_3

    .line 65
    .line 66
    iput-boolean v3, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 67
    .line 68
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 69
    .line 70
    .line 71
    :cond_3
    if-nez v0, :cond_7

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_4
    if-eqz v1, :cond_5

    .line 75
    .line 76
    iget-boolean p1, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 77
    .line 78
    if-eq p1, v2, :cond_7

    .line 79
    .line 80
    iput-boolean v2, p0, Lcom/google/android/material/chip/Chip;->E:Z

    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 83
    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_5
    :goto_1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    if-eqz p1, :cond_6

    .line 91
    .line 92
    goto :goto_2

    .line 93
    :cond_6
    move v2, v3

    .line 94
    :cond_7
    :goto_2
    return v2
.end method

.method public final p()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    iget-object v0, v0, La/X9;->FL:Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    instance-of v1, v0, La/Ju;

    .line 10
    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    check-cast v0, La/Ju;

    .line 14
    .line 15
    check-cast v0, La/nW;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    move-object v0, v1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v0, 0x0

    .line 24
    :cond_1
    :goto_0
    if-eqz v0, :cond_2

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    goto :goto_1

    .line 28
    :cond_2
    const/4 v0, 0x0

    .line 29
    :goto_1
    return v0
.end method

.method public final setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 6
    .line 7
    :cond_0
    if-eq p1, v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->W:Landroid/graphics/drawable/RippleDrawable;

    .line 10
    .line 11
    if-eq p1, v0, :cond_1

    .line 12
    .line 13
    const-string p1, "Chip"

    .line 14
    .line 15
    const-string v0, "Do not set the background; Chip manages its own background drawable."

    .line 16
    .line 17
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    return-void
.end method

.method public final setBackgroundColor(I)V
    .locals 1

    const-string p1, "Chip"

    const-string v0, "Do not set the background color; Chip manages its own background drawable."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public final setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 6
    .line 7
    :cond_0
    if-eq p1, v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->W:Landroid/graphics/drawable/RippleDrawable;

    .line 10
    .line 11
    if-eq p1, v0, :cond_1

    .line 12
    .line 13
    const-string p1, "Chip"

    .line 14
    .line 15
    const-string v0, "Do not set the background drawable; Chip manages its own background drawable."

    .line 16
    .line 17
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_1
    invoke-super {p0, p1}, La/q8;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 22
    .line 23
    .line 24
    :goto_0
    return-void
.end method

.method public final setBackgroundResource(I)V
    .locals 1

    const-string p1, "Chip"

    const-string v0, "Do not set the background resource; Chip manages its own background drawable."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public final setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    const-string p1, "Chip"

    const-string v0, "Do not set the background tint list; Chip manages its own background drawable."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public final setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    const-string p1, "Chip"

    const-string v0, "Do not set the background tint mode; Chip manages its own background drawable."

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public final setChecked(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->F:Z

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-boolean v0, v0, La/X9;->F9:Z

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 13
    .line 14
    .line 15
    :cond_1
    :goto_0
    return-void
.end method

.method public final setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, La/q8;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, La/q8;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V
    .locals 0

    .line 1
    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 2
    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setCompoundDrawablesWithIntrinsicBounds(IIII)V
    .locals 0

    .line 1
    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 2
    if-nez p1, :cond_1

    if-nez p3, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set right drawable using R.attr#closeIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string p2, "Please set left drawable using R.attr#chipIcon."

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setElevation(F)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setElevation(F)V

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, La/ex;->y(F)V

    :cond_0
    return-void
.end method

.method public final setEllipsize(Landroid/text/TextUtils$TruncateAt;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    sget-object v0, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    .line 7
    .line 8
    if-eq p1, v0, :cond_2

    .line 9
    .line 10
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iput-object p1, v0, La/X9;->Pi:Landroid/text/TextUtils$TruncateAt;

    .line 18
    .line 19
    :cond_1
    return-void

    .line 20
    :cond_2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 21
    .line 22
    const-string v0, "Text within a chip are not allowed to scroll."

    .line 23
    .line 24
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw p1
.end method

.method public final setGravity(I)V
    .locals 1

    const v0, 0x800013

    if-eq p1, v0, :cond_0

    const-string p1, "Chip"

    const-string v0, "Chip text must be vertically center and start aligned"

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setGravity(I)V

    :goto_0
    return-void
.end method

.method public final setLayoutDirection(I)V
    .locals 1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setLayoutDirection(I)V

    return-void
.end method

.method public final setLines(I)V
    .locals 1

    const/4 v0, 0x1

    if-gt p1, v0, :cond_0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setLines(I)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Chip does not support multi-line text"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setMaxLines(I)V
    .locals 1

    const/4 v0, 0x1

    if-gt p1, v0, :cond_0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMaxLines(I)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Chip does not support multi-line text"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setMaxWidth(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMaxWidth(I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iput p1, v0, La/X9;->rn:I

    .line 9
    .line 10
    :cond_0
    return-void
.end method

.method public final setMinLines(I)V
    .locals 1

    const/4 v0, 0x1

    if-gt p1, v0, :cond_0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMinLines(I)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Chip does not support multi-line text"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V
    .locals 0

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->q:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    return-void
.end method

.method public final setSingleLine(Z)V
    .locals 1

    if-eqz p1, :cond_0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setSingleLine(Z)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Chip does not support multi-line text"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    if-nez p1, :cond_1

    .line 7
    .line 8
    const-string p1, ""

    .line 9
    .line 10
    :cond_1
    iget-boolean v0, v0, La/X9;->ZZ:Z

    .line 11
    .line 12
    if-eqz v0, :cond_2

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    goto :goto_0

    .line 16
    :cond_2
    move-object v0, p1

    .line 17
    :goto_0
    invoke-super {p0, v0, p2}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V

    .line 18
    .line 19
    .line 20
    iget-object p2, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 21
    .line 22
    if-eqz p2, :cond_3

    .line 23
    .line 24
    iget-object v0, p2, La/X9;->B:Ljava/lang/CharSequence;

    .line 25
    .line 26
    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_3

    .line 31
    .line 32
    iput-object p1, p2, La/X9;->B:Ljava/lang/CharSequence;

    .line 33
    .line 34
    iget-object p1, p2, La/X9;->yd:La/rY;

    .line 35
    .line 36
    const/4 v0, 0x1

    .line 37
    iput-boolean v0, p1, La/rY;->i:Z

    .line 38
    .line 39
    invoke-virtual {p2}, La/ex;->invalidateSelf()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p2}, La/X9;->z()V

    .line 43
    .line 44
    .line 45
    :cond_3
    return-void
.end method

.method public final setTextAppearance(I)V
    .locals 3

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setTextAppearance(I)V

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    if-eqz v0, :cond_0

    .line 1
    new-instance v1, La/fy;

    iget-object v2, v0, La/X9;->Gy:Landroid/content/Context;

    invoke-direct {v1, v2, p1}, La/fy;-><init>(Landroid/content/Context;I)V

    .line 2
    iget-object p1, v0, La/X9;->yd:La/rY;

    invoke-virtual {p1, v1, v2}, La/rY;->h(La/fy;Landroid/content/Context;)V

    .line 3
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->V()V

    return-void
.end method

.method public final setTextAppearance(Landroid/content/Context;I)V
    .locals 2

    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->setTextAppearance(Landroid/content/Context;I)V

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    if-eqz p1, :cond_0

    .line 4
    new-instance v0, La/fy;

    iget-object v1, p1, La/X9;->Gy:Landroid/content/Context;

    invoke-direct {v0, v1, p2}, La/fy;-><init>(Landroid/content/Context;I)V

    .line 5
    iget-object p1, p1, La/X9;->yd:La/rY;

    invoke-virtual {p1, v0, v1}, La/rY;->h(La/fy;Landroid/content/Context;)V

    .line 6
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->V()V

    return-void
.end method

.method public final setTextSize(IF)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->setTextSize(IF)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-static {p1, p2, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    iget-object p2, v0, La/X9;->yd:La/rY;

    .line 21
    .line 22
    iget-object v1, p2, La/rY;->X:La/fy;

    .line 23
    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    iput p1, v1, La/fy;->M:F

    .line 27
    .line 28
    iget-object p2, p2, La/rY;->w:Landroid/text/TextPaint;

    .line 29
    .line 30
    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, La/X9;->w()V

    .line 34
    .line 35
    .line 36
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->V()V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final w(I)V
    .locals 11

    .line 1
    iput p1, p0, Lcom/google/android/material/chip/Chip;->D:I

    .line 2
    .line 3
    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->z:Z

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x0

    .line 7
    const/4 v3, 0x0

    .line 8
    if-nez v0, :cond_3

    .line 9
    .line 10
    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 11
    .line 12
    if-eqz p1, :cond_1

    .line 13
    .line 14
    if-eqz p1, :cond_2

    .line 15
    .line 16
    iput-object v2, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 17
    .line 18
    invoke-virtual {p0, v3}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 19
    .line 20
    .line 21
    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 22
    .line 23
    if-eqz p1, :cond_0

    .line 24
    .line 25
    iget v1, p1, La/X9;->x:F

    .line 26
    .line 27
    :cond_0
    float-to-int p1, v1

    .line 28
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 32
    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 36
    .line 37
    .line 38
    :cond_2
    :goto_0
    return-void

    .line 39
    :cond_3
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 40
    .line 41
    iget v0, v0, La/X9;->x:F

    .line 42
    .line 43
    float-to-int v0, v0

    .line 44
    sub-int v0, p1, v0

    .line 45
    .line 46
    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    iget-object v4, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 51
    .line 52
    invoke-virtual {v4}, La/X9;->getIntrinsicWidth()I

    .line 53
    .line 54
    .line 55
    move-result v4

    .line 56
    sub-int v4, p1, v4

    .line 57
    .line 58
    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    if-gtz v4, :cond_7

    .line 63
    .line 64
    if-gtz v0, :cond_7

    .line 65
    .line 66
    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 67
    .line 68
    if-eqz p1, :cond_5

    .line 69
    .line 70
    if-eqz p1, :cond_6

    .line 71
    .line 72
    iput-object v2, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 73
    .line 74
    invoke-virtual {p0, v3}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 75
    .line 76
    .line 77
    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 78
    .line 79
    if-eqz p1, :cond_4

    .line 80
    .line 81
    iget v1, p1, La/X9;->x:F

    .line 82
    .line 83
    :cond_4
    float-to-int p1, v1

    .line 84
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_5
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 92
    .line 93
    .line 94
    :cond_6
    :goto_1
    return-void

    .line 95
    :cond_7
    if-lez v4, :cond_8

    .line 96
    .line 97
    div-int/lit8 v4, v4, 0x2

    .line 98
    .line 99
    move v9, v4

    .line 100
    goto :goto_2

    .line 101
    :cond_8
    move v9, v3

    .line 102
    :goto_2
    if-lez v0, :cond_9

    .line 103
    .line 104
    div-int/lit8 v3, v0, 0x2

    .line 105
    .line 106
    :cond_9
    move v10, v3

    .line 107
    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 108
    .line 109
    if-eqz v0, :cond_a

    .line 110
    .line 111
    new-instance v0, Landroid/graphics/Rect;

    .line 112
    .line 113
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 114
    .line 115
    .line 116
    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 117
    .line 118
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/InsetDrawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 119
    .line 120
    .line 121
    iget v1, v0, Landroid/graphics/Rect;->top:I

    .line 122
    .line 123
    if-ne v1, v10, :cond_a

    .line 124
    .line 125
    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 126
    .line 127
    if-ne v1, v10, :cond_a

    .line 128
    .line 129
    iget v1, v0, Landroid/graphics/Rect;->left:I

    .line 130
    .line 131
    if-ne v1, v9, :cond_a

    .line 132
    .line 133
    iget v0, v0, Landroid/graphics/Rect;->right:I

    .line 134
    .line 135
    if-ne v0, v9, :cond_a

    .line 136
    .line 137
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 138
    .line 139
    .line 140
    return-void

    .line 141
    :cond_a
    invoke-virtual {p0}, Landroid/widget/TextView;->getMinHeight()I

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-eq v0, p1, :cond_b

    .line 146
    .line 147
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 148
    .line 149
    .line 150
    :cond_b
    invoke-virtual {p0}, Landroid/widget/TextView;->getMinWidth()I

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    if-eq v0, p1, :cond_c

    .line 155
    .line 156
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 157
    .line 158
    .line 159
    :cond_c
    new-instance p1, Landroid/graphics/drawable/InsetDrawable;

    .line 160
    .line 161
    iget-object v6, p0, Lcom/google/android/material/chip/Chip;->f:La/X9;

    .line 162
    .line 163
    move-object v5, p1

    .line 164
    move v7, v9

    .line 165
    move v8, v10

    .line 166
    invoke-direct/range {v5 .. v10}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    .line 167
    .line 168
    .line 169
    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->l:Landroid/graphics/drawable/InsetDrawable;

    .line 170
    .line 171
    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->X()V

    .line 172
    .line 173
    .line 174
    return-void
.end method
