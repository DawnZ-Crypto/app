.class public final La/tr;
.super La/CY;
.source "SourceFile"

# interfaces
.implements La/ym;


# virtual methods
.method public final X()La/tr;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final h()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    invoke-super {p0}, La/CY;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final bridge synthetic y()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method
