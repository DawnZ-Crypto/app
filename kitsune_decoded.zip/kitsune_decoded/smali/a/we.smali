.class public final La/we;
.super La/CS;
.source "SourceFile"


# instance fields
.field public final synthetic m:La/WO;


# direct methods
.method public constructor <init>(La/WO;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La/we;->m:La/WO;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final M()V
    .locals 1

    .line 1
    iget-object v0, p0, La/we;->m:La/WO;

    invoke-virtual {v0}, La/WO;->cancel()V

    return-void
.end method
