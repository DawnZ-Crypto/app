.class public final La/h9;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# static fields
.field public static final synthetic j:I


# instance fields
.field public final D:La/c8;

.field public final E:Landroid/content/res/ColorStateList;

.field public final F:Ljava/util/LinkedHashSet;

.field public final H:I

.field public final K:Lcom/google/android/material/textfield/TextInputLayout;

.field public final L:Lcom/google/android/material/internal/CheckableImageButton;

.field public final P:Ljava/lang/CharSequence;

.field public final R:Landroid/widget/FrameLayout;

.field public final S:Landroid/graphics/PorterDuff$Mode;

.field public U:Landroid/widget/EditText;

.field public final W:La/JE;

.field public final d:Landroid/content/res/ColorStateList;

.field public final f:Landroid/graphics/PorterDuff$Mode;

.field public final k:Landroid/view/accessibility/AccessibilityManager;

.field public final l:Lcom/google/android/material/internal/CheckableImageButton;

.field public q:I

.field public final s:La/yA;

.field public u:Z

.field public v:La/C6;

.field public z:Landroid/view/View$OnLongClickListener;


# direct methods
.method public constructor <init>(Lcom/google/android/material/textfield/TextInputLayout;La/yW;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    iput v3, v0, La/h9;->q:I

    .line 16
    .line 17
    new-instance v4, Ljava/util/LinkedHashSet;

    .line 18
    .line 19
    invoke-direct {v4}, Ljava/util/LinkedHashSet;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object v4, v0, La/h9;->F:Ljava/util/LinkedHashSet;

    .line 23
    .line 24
    new-instance v4, La/yA;

    .line 25
    .line 26
    invoke-direct {v4, v0}, La/yA;-><init>(La/h9;)V

    .line 27
    .line 28
    .line 29
    iput-object v4, v0, La/h9;->s:La/yA;

    .line 30
    .line 31
    new-instance v4, La/Wg;

    .line 32
    .line 33
    invoke-direct {v4, v0}, La/Wg;-><init>(La/h9;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    const-string v6, "accessibility"

    .line 41
    .line 42
    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v5

    .line 46
    check-cast v5, Landroid/view/accessibility/AccessibilityManager;

    .line 47
    .line 48
    iput-object v5, v0, La/h9;->k:Landroid/view/accessibility/AccessibilityManager;

    .line 49
    .line 50
    iput-object v1, v0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 51
    .line 52
    const/16 v5, 0x8

    .line 53
    .line 54
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 58
    .line 59
    .line 60
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    .line 61
    .line 62
    const/4 v7, -0x2

    .line 63
    const/4 v8, -0x1

    .line 64
    const v9, 0x800005

    .line 65
    .line 66
    .line 67
    invoke-direct {v6, v7, v8, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 71
    .line 72
    .line 73
    new-instance v6, Landroid/widget/FrameLayout;

    .line 74
    .line 75
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 76
    .line 77
    .line 78
    move-result-object v9

    .line 79
    invoke-direct {v6, v9}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 80
    .line 81
    .line 82
    iput-object v6, v0, La/h9;->R:Landroid/widget/FrameLayout;

    .line 83
    .line 84
    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    .line 85
    .line 86
    .line 87
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 88
    .line 89
    invoke-direct {v9, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v6, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 96
    .line 97
    .line 98
    move-result-object v9

    .line 99
    invoke-static {v9}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 100
    .line 101
    .line 102
    move-result-object v9

    .line 103
    const v10, 0x7f09025a

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0, v0, v9, v10}, La/h9;->w(Landroid/view/ViewGroup;Landroid/view/LayoutInflater;I)Lcom/google/android/material/internal/CheckableImageButton;

    .line 107
    .line 108
    .line 109
    move-result-object v10

    .line 110
    iput-object v10, v0, La/h9;->L:Lcom/google/android/material/internal/CheckableImageButton;

    .line 111
    .line 112
    const v11, 0x7f090259

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0, v6, v9, v11}, La/h9;->w(Landroid/view/ViewGroup;Landroid/view/LayoutInflater;I)Lcom/google/android/material/internal/CheckableImageButton;

    .line 116
    .line 117
    .line 118
    move-result-object v9

    .line 119
    iput-object v9, v0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 120
    .line 121
    new-instance v11, La/JE;

    .line 122
    .line 123
    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    .line 124
    .line 125
    .line 126
    new-instance v12, Landroid/util/SparseArray;

    .line 127
    .line 128
    invoke-direct {v12}, Landroid/util/SparseArray;-><init>()V

    .line 129
    .line 130
    .line 131
    iput-object v12, v11, La/JE;->p:Ljava/lang/Object;

    .line 132
    .line 133
    iput-object v0, v11, La/JE;->e:Ljava/lang/Object;

    .line 134
    .line 135
    const/16 v12, 0x1c

    .line 136
    .line 137
    invoke-virtual {v2, v12, v3}, La/yW;->E(II)I

    .line 138
    .line 139
    .line 140
    move-result v12

    .line 141
    iput v12, v11, La/JE;->w:I

    .line 142
    .line 143
    const/16 v12, 0x34

    .line 144
    .line 145
    invoke-virtual {v2, v12, v3}, La/yW;->E(II)I

    .line 146
    .line 147
    .line 148
    move-result v12

    .line 149
    iput v12, v11, La/JE;->h:I

    .line 150
    .line 151
    iput-object v11, v0, La/h9;->W:La/JE;

    .line 152
    .line 153
    new-instance v11, La/c8;

    .line 154
    .line 155
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 156
    .line 157
    .line 158
    move-result-object v12

    .line 159
    const/4 v13, 0x0

    .line 160
    invoke-direct {v11, v12, v13}, La/c8;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 161
    .line 162
    .line 163
    iput-object v11, v0, La/h9;->D:La/c8;

    .line 164
    .line 165
    const/16 v12, 0x26

    .line 166
    .line 167
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 168
    .line 169
    .line 170
    move-result v14

    .line 171
    if-eqz v14, :cond_0

    .line 172
    .line 173
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 174
    .line 175
    .line 176
    move-result-object v14

    .line 177
    invoke-static {v14, v2, v12}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 178
    .line 179
    .line 180
    move-result-object v12

    .line 181
    iput-object v12, v0, La/h9;->d:Landroid/content/res/ColorStateList;

    .line 182
    .line 183
    :cond_0
    const/16 v12, 0x27

    .line 184
    .line 185
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 186
    .line 187
    .line 188
    move-result v14

    .line 189
    if-eqz v14, :cond_1

    .line 190
    .line 191
    invoke-virtual {v2, v12, v8}, La/yW;->q(II)I

    .line 192
    .line 193
    .line 194
    move-result v12

    .line 195
    invoke-static {v12, v13}, La/rE;->C6(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 196
    .line 197
    .line 198
    move-result-object v12

    .line 199
    iput-object v12, v0, La/h9;->f:Landroid/graphics/PorterDuff$Mode;

    .line 200
    .line 201
    :cond_1
    const/16 v12, 0x25

    .line 202
    .line 203
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 204
    .line 205
    .line 206
    move-result v14

    .line 207
    if-eqz v14, :cond_2

    .line 208
    .line 209
    invoke-virtual {v2, v12}, La/yW;->f(I)Landroid/graphics/drawable/Drawable;

    .line 210
    .line 211
    .line 212
    move-result-object v12

    .line 213
    invoke-virtual {v10, v12}, La/CN;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 214
    .line 215
    .line 216
    invoke-virtual/range {p0 .. p0}, La/h9;->M()V

    .line 217
    .line 218
    .line 219
    iget-object v12, v0, La/h9;->d:Landroid/content/res/ColorStateList;

    .line 220
    .line 221
    iget-object v14, v0, La/h9;->f:Landroid/graphics/PorterDuff$Mode;

    .line 222
    .line 223
    invoke-static {v1, v10, v12, v14}, La/rx;->O(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)V

    .line 224
    .line 225
    .line 226
    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 227
    .line 228
    .line 229
    move-result-object v12

    .line 230
    const v14, 0x7f120048

    .line 231
    .line 232
    .line 233
    invoke-virtual {v12, v14}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 234
    .line 235
    .line 236
    move-result-object v12

    .line 237
    invoke-virtual {v10, v12}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 238
    .line 239
    .line 240
    sget-object v12, La/sI;->w:Ljava/util/WeakHashMap;

    .line 241
    .line 242
    const/4 v12, 0x2

    .line 243
    invoke-static {v10, v12}, La/Tl;->f(Landroid/view/View;I)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {v10, v3}, Landroid/view/View;->setClickable(Z)V

    .line 247
    .line 248
    .line 249
    iput-boolean v3, v10, Lcom/google/android/material/internal/CheckableImageButton;->l:Z

    .line 250
    .line 251
    invoke-virtual {v10, v3}, Landroid/view/View;->setFocusable(Z)V

    .line 252
    .line 253
    .line 254
    const/16 v14, 0x35

    .line 255
    .line 256
    invoke-virtual {v2, v14}, La/yW;->z(I)Z

    .line 257
    .line 258
    .line 259
    move-result v15

    .line 260
    if-nez v15, :cond_4

    .line 261
    .line 262
    const/16 v15, 0x20

    .line 263
    .line 264
    invoke-virtual {v2, v15}, La/yW;->z(I)Z

    .line 265
    .line 266
    .line 267
    move-result v16

    .line 268
    if-eqz v16, :cond_3

    .line 269
    .line 270
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 271
    .line 272
    .line 273
    move-result-object v12

    .line 274
    invoke-static {v12, v2, v15}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 275
    .line 276
    .line 277
    move-result-object v12

    .line 278
    iput-object v12, v0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 279
    .line 280
    :cond_3
    const/16 v12, 0x21

    .line 281
    .line 282
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 283
    .line 284
    .line 285
    move-result v15

    .line 286
    if-eqz v15, :cond_4

    .line 287
    .line 288
    invoke-virtual {v2, v12, v8}, La/yW;->q(II)I

    .line 289
    .line 290
    .line 291
    move-result v12

    .line 292
    invoke-static {v12, v13}, La/rE;->C6(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 293
    .line 294
    .line 295
    move-result-object v12

    .line 296
    iput-object v12, v0, La/h9;->S:Landroid/graphics/PorterDuff$Mode;

    .line 297
    .line 298
    :cond_4
    const/16 v12, 0x1e

    .line 299
    .line 300
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 301
    .line 302
    .line 303
    move-result v15

    .line 304
    const/4 v7, 0x1

    .line 305
    if-eqz v15, :cond_6

    .line 306
    .line 307
    invoke-virtual {v2, v12, v3}, La/yW;->q(II)I

    .line 308
    .line 309
    .line 310
    move-result v12

    .line 311
    invoke-virtual {v0, v12}, La/h9;->X(I)V

    .line 312
    .line 313
    .line 314
    const/16 v12, 0x1b

    .line 315
    .line 316
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 317
    .line 318
    .line 319
    move-result v14

    .line 320
    if-eqz v14, :cond_5

    .line 321
    .line 322
    invoke-virtual {v2, v12}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 323
    .line 324
    .line 325
    move-result-object v12

    .line 326
    invoke-virtual {v9}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    .line 327
    .line 328
    .line 329
    move-result-object v14

    .line 330
    if-eq v14, v12, :cond_5

    .line 331
    .line 332
    invoke-virtual {v9, v12}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 333
    .line 334
    .line 335
    :cond_5
    const/16 v12, 0x1a

    .line 336
    .line 337
    invoke-virtual {v2, v12, v7}, La/yW;->K(IZ)Z

    .line 338
    .line 339
    .line 340
    move-result v12

    .line 341
    iget-boolean v14, v9, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    .line 342
    .line 343
    if-eq v14, v12, :cond_9

    .line 344
    .line 345
    iput-boolean v12, v9, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    .line 346
    .line 347
    invoke-virtual {v9, v3}, Landroid/view/View;->sendAccessibilityEvent(I)V

    .line 348
    .line 349
    .line 350
    goto :goto_0

    .line 351
    :cond_6
    invoke-virtual {v2, v14}, La/yW;->z(I)Z

    .line 352
    .line 353
    .line 354
    move-result v12

    .line 355
    if-eqz v12, :cond_9

    .line 356
    .line 357
    const/16 v12, 0x36

    .line 358
    .line 359
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 360
    .line 361
    .line 362
    move-result v15

    .line 363
    if-eqz v15, :cond_7

    .line 364
    .line 365
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 366
    .line 367
    .line 368
    move-result-object v15

    .line 369
    invoke-static {v15, v2, v12}, La/rx;->k(Landroid/content/Context;La/yW;I)Landroid/content/res/ColorStateList;

    .line 370
    .line 371
    .line 372
    move-result-object v12

    .line 373
    iput-object v12, v0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 374
    .line 375
    :cond_7
    const/16 v12, 0x37

    .line 376
    .line 377
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 378
    .line 379
    .line 380
    move-result v15

    .line 381
    if-eqz v15, :cond_8

    .line 382
    .line 383
    invoke-virtual {v2, v12, v8}, La/yW;->q(II)I

    .line 384
    .line 385
    .line 386
    move-result v12

    .line 387
    invoke-static {v12, v13}, La/rE;->C6(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 388
    .line 389
    .line 390
    move-result-object v12

    .line 391
    iput-object v12, v0, La/h9;->S:Landroid/graphics/PorterDuff$Mode;

    .line 392
    .line 393
    :cond_8
    invoke-virtual {v2, v14, v3}, La/yW;->K(IZ)Z

    .line 394
    .line 395
    .line 396
    move-result v12

    .line 397
    invoke-virtual {v0, v12}, La/h9;->X(I)V

    .line 398
    .line 399
    .line 400
    const/16 v12, 0x33

    .line 401
    .line 402
    invoke-virtual {v2, v12}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 403
    .line 404
    .line 405
    move-result-object v12

    .line 406
    invoke-virtual {v9}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    .line 407
    .line 408
    .line 409
    move-result-object v14

    .line 410
    if-eq v14, v12, :cond_9

    .line 411
    .line 412
    invoke-virtual {v9, v12}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 413
    .line 414
    .line 415
    :cond_9
    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 416
    .line 417
    .line 418
    move-result-object v12

    .line 419
    const v14, 0x7f0702d1

    .line 420
    .line 421
    .line 422
    invoke-virtual {v12, v14}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 423
    .line 424
    .line 425
    move-result v12

    .line 426
    const/16 v14, 0x1d

    .line 427
    .line 428
    invoke-virtual {v2, v14, v12}, La/yW;->d(II)I

    .line 429
    .line 430
    .line 431
    move-result v12

    .line 432
    if-ltz v12, :cond_f

    .line 433
    .line 434
    iget v14, v0, La/h9;->H:I

    .line 435
    .line 436
    if-eq v12, v14, :cond_a

    .line 437
    .line 438
    iput v12, v0, La/h9;->H:I

    .line 439
    .line 440
    invoke-virtual {v9, v12}, Landroid/view/View;->setMinimumWidth(I)V

    .line 441
    .line 442
    .line 443
    invoke-virtual {v9, v12}, Landroid/view/View;->setMinimumHeight(I)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {v10, v12}, Landroid/view/View;->setMinimumWidth(I)V

    .line 447
    .line 448
    .line 449
    invoke-virtual {v10, v12}, Landroid/view/View;->setMinimumHeight(I)V

    .line 450
    .line 451
    .line 452
    :cond_a
    const/16 v12, 0x1f

    .line 453
    .line 454
    invoke-virtual {v2, v12}, La/yW;->z(I)Z

    .line 455
    .line 456
    .line 457
    move-result v14

    .line 458
    if-eqz v14, :cond_b

    .line 459
    .line 460
    invoke-virtual {v2, v12, v8}, La/yW;->q(II)I

    .line 461
    .line 462
    .line 463
    move-result v8

    .line 464
    invoke-static {v8}, La/rx;->R(I)Landroid/widget/ImageView$ScaleType;

    .line 465
    .line 466
    .line 467
    move-result-object v8

    .line 468
    invoke-virtual {v9, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v10, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 472
    .line 473
    .line 474
    :cond_b
    invoke-virtual {v11, v5}, Landroid/view/View;->setVisibility(I)V

    .line 475
    .line 476
    .line 477
    const v5, 0x7f090261

    .line 478
    .line 479
    .line 480
    invoke-virtual {v11, v5}, Landroid/view/View;->setId(I)V

    .line 481
    .line 482
    .line 483
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 484
    .line 485
    const/high16 v8, 0x42a00000    # 80.0f

    .line 486
    .line 487
    const/4 v12, -0x2

    .line 488
    invoke-direct {v5, v12, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 489
    .line 490
    .line 491
    invoke-virtual {v11, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 492
    .line 493
    .line 494
    invoke-static {v11, v7}, La/AM;->Q(Landroid/view/View;I)V

    .line 495
    .line 496
    .line 497
    const/16 v5, 0x48

    .line 498
    .line 499
    invoke-virtual {v2, v5, v3}, La/yW;->E(II)I

    .line 500
    .line 501
    .line 502
    move-result v3

    .line 503
    invoke-virtual {v11, v3}, Landroid/widget/TextView;->setTextAppearance(I)V

    .line 504
    .line 505
    .line 506
    const/16 v3, 0x49

    .line 507
    .line 508
    invoke-virtual {v2, v3}, La/yW;->z(I)Z

    .line 509
    .line 510
    .line 511
    move-result v5

    .line 512
    if-eqz v5, :cond_c

    .line 513
    .line 514
    invoke-virtual {v2, v3}, La/yW;->R(I)Landroid/content/res/ColorStateList;

    .line 515
    .line 516
    .line 517
    move-result-object v3

    .line 518
    invoke-virtual {v11, v3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 519
    .line 520
    .line 521
    :cond_c
    const/16 v3, 0x47

    .line 522
    .line 523
    invoke-virtual {v2, v3}, La/yW;->H(I)Ljava/lang/CharSequence;

    .line 524
    .line 525
    .line 526
    move-result-object v2

    .line 527
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 528
    .line 529
    .line 530
    move-result v3

    .line 531
    if-eqz v3, :cond_d

    .line 532
    .line 533
    goto :goto_1

    .line 534
    :cond_d
    move-object v13, v2

    .line 535
    :goto_1
    iput-object v13, v0, La/h9;->P:Ljava/lang/CharSequence;

    .line 536
    .line 537
    invoke-virtual {v11, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 538
    .line 539
    .line 540
    invoke-virtual/range {p0 .. p0}, La/h9;->m()V

    .line 541
    .line 542
    .line 543
    invoke-virtual {v6, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 544
    .line 545
    .line 546
    invoke-virtual {v0, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 550
    .line 551
    .line 552
    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 553
    .line 554
    .line 555
    iget-object v2, v1, Lcom/google/android/material/textfield/TextInputLayout;->NE:Ljava/util/LinkedHashSet;

    .line 556
    .line 557
    invoke-virtual {v2, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 558
    .line 559
    .line 560
    iget-object v2, v1, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 561
    .line 562
    if-eqz v2, :cond_e

    .line 563
    .line 564
    invoke-virtual {v4, v1}, La/Wg;->w(Lcom/google/android/material/textfield/TextInputLayout;)V

    .line 565
    .line 566
    .line 567
    :cond_e
    new-instance v1, La/Mb;

    .line 568
    .line 569
    const/4 v2, 0x2

    .line 570
    invoke-direct {v1, v2, v0}, La/Mb;-><init>(ILjava/lang/Object;)V

    .line 571
    .line 572
    .line 573
    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 574
    .line 575
    .line 576
    return-void

    .line 577
    :cond_f
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 578
    .line 579
    const-string v2, "endIconSize cannot be less than 0"

    .line 580
    .line 581
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 582
    .line 583
    .line 584
    throw v1
.end method


# virtual methods
.method public final I()V
    .locals 4

    .line 1
    iget-object v0, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/16 v1, 0x8

    const/4 v2, 0x0

    if-nez v0, :cond_0

    invoke-virtual {p0}, La/h9;->i()Z

    move-result v0

    if-nez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, La/h9;->R:Landroid/widget/FrameLayout;

    invoke-virtual {v3, v0}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, La/h9;->P:Ljava/lang/CharSequence;

    if-eqz v0, :cond_1

    iget-boolean v0, p0, La/h9;->u:Z

    if-nez v0, :cond_1

    move v0, v2

    goto :goto_1

    :cond_1
    move v0, v1

    :goto_1
    invoke-virtual {p0}, La/h9;->e()Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {p0}, La/h9;->i()Z

    move-result v3

    if-nez v3, :cond_2

    if-nez v0, :cond_3

    :cond_2
    move v1, v2

    :cond_3
    invoke-virtual {p0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public final M()V
    .locals 3

    .line 1
    iget-object v0, p0, La/h9;->L:Lcom/google/android/material/internal/CheckableImageButton;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-object v2, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    iget-object v1, v2, Lcom/google/android/material/textfield/TextInputLayout;->E:La/A7;

    .line 12
    .line 13
    iget-boolean v1, v1, La/A7;->L:Z

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    invoke-virtual {v2}, Lcom/google/android/material/textfield/TextInputLayout;->d()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/16 v1, 0x8

    .line 26
    .line 27
    :goto_0
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0}, La/h9;->I()V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0}, La/h9;->T()V

    .line 34
    .line 35
    .line 36
    iget v0, p0, La/h9;->q:I

    .line 37
    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_1
    invoke-virtual {v2}, Lcom/google/android/material/textfield/TextInputLayout;->q()Z

    .line 42
    .line 43
    .line 44
    :goto_1
    return-void
.end method

.method public final O(Z)V
    .locals 1

    .line 1
    invoke-virtual {p0}, La/h9;->e()Z

    move-result v0

    if-eq v0, p1, :cond_1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    iget-object v0, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, La/h9;->I()V

    invoke-virtual {p0}, La/h9;->T()V

    iget-object p1, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {p1}, Lcom/google/android/material/textfield/TextInputLayout;->q()Z

    :cond_1
    return-void
.end method

.method public final Q(Z)V
    .locals 5

    .line 1
    invoke-virtual {p0}, La/h9;->h()La/sb;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, La/sb;->M()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x1

    .line 10
    iget-object v3, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v3}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    invoke-virtual {v0}, La/sb;->T()Z

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    if-eq v1, v4, :cond_0

    .line 23
    .line 24
    xor-int/2addr v1, v2

    .line 25
    invoke-virtual {v3, v1}, Lcom/google/android/material/internal/CheckableImageButton;->setChecked(Z)V

    .line 26
    .line 27
    .line 28
    move v1, v2

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const/4 v1, 0x0

    .line 31
    :goto_0
    instance-of v4, v0, La/P0;

    .line 32
    .line 33
    if-eqz v4, :cond_1

    .line 34
    .line 35
    invoke-virtual {v3}, Landroid/view/View;->isActivated()Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    invoke-virtual {v0}, La/sb;->I()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eq v4, v0, :cond_1

    .line 44
    .line 45
    xor-int/lit8 v0, v4, 0x1

    .line 46
    .line 47
    invoke-virtual {v3, v0}, Landroid/view/View;->setActivated(Z)V

    .line 48
    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    move v2, v1

    .line 52
    :goto_1
    if-nez p1, :cond_2

    .line 53
    .line 54
    if-eqz v2, :cond_3

    .line 55
    .line 56
    :cond_2
    iget-object p1, p0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 57
    .line 58
    iget-object v0, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 59
    .line 60
    invoke-static {v0, v3, p1}, La/rx;->NE(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    .line 61
    .line 62
    .line 63
    :cond_3
    return-void
.end method

.method public final T()V
    .locals 5

    .line 1
    iget-object v0, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 2
    .line 3
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    invoke-virtual {p0}, La/h9;->e()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-nez v1, :cond_2

    .line 13
    .line 14
    invoke-virtual {p0}, La/h9;->i()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget-object v1, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 22
    .line 23
    sget-object v2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 24
    .line 25
    invoke-static {v1}, La/XC;->i(Landroid/view/View;)I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    goto :goto_1

    .line 30
    :cond_2
    :goto_0
    const/4 v1, 0x0

    .line 31
    :goto_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    const v3, 0x7f07024f

    .line 40
    .line 41
    .line 42
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    iget-object v3, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 47
    .line 48
    invoke-virtual {v3}, Landroid/view/View;->getPaddingTop()I

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    iget-object v0, v0, Lcom/google/android/material/textfield/TextInputLayout;->d:Landroid/widget/EditText;

    .line 53
    .line 54
    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    sget-object v4, La/sI;->w:Ljava/util/WeakHashMap;

    .line 59
    .line 60
    iget-object v4, p0, La/h9;->D:La/c8;

    .line 61
    .line 62
    invoke-static {v4, v2, v3, v1, v0}, La/XC;->M(Landroid/view/View;IIII)V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final V(La/sb;)V
    .locals 2

    .line 1
    iget-object v0, p0, La/h9;->U:Landroid/widget/EditText;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, La/sb;->i()Landroid/view/View$OnFocusChangeListener;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, La/h9;->U:Landroid/widget/EditText;

    invoke-virtual {p1}, La/sb;->i()Landroid/view/View$OnFocusChangeListener;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    :cond_1
    invoke-virtual {p1}, La/sb;->X()Landroid/view/View$OnFocusChangeListener;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v0, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {p1}, La/sb;->X()Landroid/view/View$OnFocusChangeListener;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    :cond_2
    return-void
.end method

.method public final X(I)V
    .locals 9

    .line 1
    iget v0, p0, La/h9;->q:I

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-virtual {p0}, La/h9;->h()La/sb;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object v1, p0, La/h9;->v:La/C6;

    .line 11
    .line 12
    iget-object v2, p0, La/h9;->k:Landroid/view/accessibility/AccessibilityManager;

    .line 13
    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    invoke-static {v2, v1}, La/yd;->h(Landroid/view/accessibility/AccessibilityManager;La/C6;)Z

    .line 19
    .line 20
    .line 21
    :cond_1
    const/4 v1, 0x0

    .line 22
    iput-object v1, p0, La/h9;->v:La/C6;

    .line 23
    .line 24
    invoke-virtual {v0}, La/sb;->f()V

    .line 25
    .line 26
    .line 27
    iput p1, p0, La/h9;->q:I

    .line 28
    .line 29
    iget-object v0, p0, La/h9;->F:Ljava/util/LinkedHashSet;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-nez v3, :cond_c

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    const/4 v3, 0x1

    .line 43
    if-eqz p1, :cond_2

    .line 44
    .line 45
    move v4, v3

    .line 46
    goto :goto_0

    .line 47
    :cond_2
    move v4, v0

    .line 48
    :goto_0
    invoke-virtual {p0, v4}, La/h9;->O(Z)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, La/h9;->h()La/sb;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    iget-object v5, p0, La/h9;->W:La/JE;

    .line 56
    .line 57
    iget v5, v5, La/JE;->w:I

    .line 58
    .line 59
    if-nez v5, :cond_3

    .line 60
    .line 61
    invoke-virtual {v4}, La/sb;->e()I

    .line 62
    .line 63
    .line 64
    move-result v5

    .line 65
    :cond_3
    if-eqz v5, :cond_4

    .line 66
    .line 67
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 68
    .line 69
    .line 70
    move-result-object v6

    .line 71
    invoke-static {v6, v5}, La/fe;->q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    goto :goto_1

    .line 76
    :cond_4
    move-object v5, v1

    .line 77
    :goto_1
    iget-object v6, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 78
    .line 79
    invoke-virtual {v6, v5}, La/CN;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 80
    .line 81
    .line 82
    iget-object v7, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    .line 83
    .line 84
    if-eqz v5, :cond_5

    .line 85
    .line 86
    iget-object v5, p0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 87
    .line 88
    iget-object v8, p0, La/h9;->S:Landroid/graphics/PorterDuff$Mode;

    .line 89
    .line 90
    invoke-static {v7, v6, v5, v8}, La/rx;->O(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)V

    .line 91
    .line 92
    .line 93
    iget-object v5, p0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 94
    .line 95
    invoke-static {v7, v6, v5}, La/rx;->NE(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;)V

    .line 96
    .line 97
    .line 98
    :cond_5
    invoke-virtual {v4}, La/sb;->p()I

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    if-eqz v5, :cond_6

    .line 103
    .line 104
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-virtual {v1, v5}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    :cond_6
    invoke-virtual {v6}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    if-eq v5, v1, :cond_7

    .line 117
    .line 118
    invoke-virtual {v6, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 119
    .line 120
    .line 121
    :cond_7
    invoke-virtual {v4}, La/sb;->M()Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    iget-boolean v5, v6, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    .line 126
    .line 127
    if-eq v5, v1, :cond_8

    .line 128
    .line 129
    iput-boolean v1, v6, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    .line 130
    .line 131
    invoke-virtual {v6, v0}, Landroid/view/View;->sendAccessibilityEvent(I)V

    .line 132
    .line 133
    .line 134
    :cond_8
    iget v0, v7, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 135
    .line 136
    invoke-virtual {v4, v0}, La/sb;->V(I)Z

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-eqz v0, :cond_b

    .line 141
    .line 142
    invoke-virtual {v4}, La/sb;->d()V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v4}, La/sb;->O()La/C6;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    iput-object p1, p0, La/h9;->v:La/C6;

    .line 150
    .line 151
    if-eqz p1, :cond_9

    .line 152
    .line 153
    if-eqz v2, :cond_9

    .line 154
    .line 155
    sget-object p1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 156
    .line 157
    invoke-static {p0}, La/AM;->h(Landroid/view/View;)Z

    .line 158
    .line 159
    .line 160
    move-result p1

    .line 161
    if-eqz p1, :cond_9

    .line 162
    .line 163
    iget-object p1, p0, La/h9;->v:La/C6;

    .line 164
    .line 165
    invoke-static {v2, p1}, La/yd;->w(Landroid/view/accessibility/AccessibilityManager;La/C6;)Z

    .line 166
    .line 167
    .line 168
    :cond_9
    invoke-virtual {v4}, La/sb;->Q()Landroid/view/View$OnClickListener;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    iget-object v0, p0, La/h9;->z:Landroid/view/View$OnLongClickListener;

    .line 173
    .line 174
    invoke-virtual {v6, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v6, v0}, La/rx;->N3(Lcom/google/android/material/internal/CheckableImageButton;Landroid/view/View$OnLongClickListener;)V

    .line 178
    .line 179
    .line 180
    iget-object p1, p0, La/h9;->U:Landroid/widget/EditText;

    .line 181
    .line 182
    if-eqz p1, :cond_a

    .line 183
    .line 184
    invoke-virtual {v4, p1}, La/sb;->m(Landroid/widget/EditText;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {p0, v4}, La/h9;->V(La/sb;)V

    .line 188
    .line 189
    .line 190
    :cond_a
    iget-object p1, p0, La/h9;->E:Landroid/content/res/ColorStateList;

    .line 191
    .line 192
    iget-object v0, p0, La/h9;->S:Landroid/graphics/PorterDuff$Mode;

    .line 193
    .line 194
    invoke-static {v7, v6, p1, v0}, La/rx;->O(Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/internal/CheckableImageButton;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {p0, v3}, La/h9;->Q(Z)V

    .line 198
    .line 199
    .line 200
    return-void

    .line 201
    :cond_b
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 202
    .line 203
    new-instance v1, Ljava/lang/StringBuilder;

    .line 204
    .line 205
    const-string v2, "The current box background mode "

    .line 206
    .line 207
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    iget v2, v7, Lcom/google/android/material/textfield/TextInputLayout;->eH:I

    .line 211
    .line 212
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 213
    .line 214
    .line 215
    const-string v2, " is not supported by the end icon mode "

    .line 216
    .line 217
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 221
    .line 222
    .line 223
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    throw v0

    .line 231
    :cond_c
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    invoke-static {p1}, La/zq;->R(Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    throw v1
.end method

.method public final e()Z
    .locals 1

    .line 1
    iget-object v0, p0, La/h9;->R:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final h()La/sb;
    .locals 5

    .line 1
    iget v0, p0, La/h9;->q:I

    .line 2
    .line 3
    iget-object v1, p0, La/h9;->W:La/JE;

    .line 4
    .line 5
    iget-object v2, v1, La/JE;->p:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Landroid/util/SparseArray;

    .line 8
    .line 9
    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    check-cast v3, La/sb;

    .line 14
    .line 15
    if-nez v3, :cond_5

    .line 16
    .line 17
    const/4 v3, -0x1

    .line 18
    if-eq v0, v3, :cond_4

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    if-eq v0, v3, :cond_2

    .line 24
    .line 25
    const/4 v3, 0x2

    .line 26
    if-eq v0, v3, :cond_1

    .line 27
    .line 28
    const/4 v3, 0x3

    .line 29
    if-ne v0, v3, :cond_0

    .line 30
    .line 31
    new-instance v3, La/P0;

    .line 32
    .line 33
    iget-object v1, v1, La/JE;->e:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, La/h9;

    .line 36
    .line 37
    invoke-direct {v3, v1}, La/P0;-><init>(La/h9;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 42
    .line 43
    const-string v2, "Invalid end icon mode: "

    .line 44
    .line 45
    invoke-static {v2, v0}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v1

    .line 53
    :cond_1
    new-instance v3, La/kT;

    .line 54
    .line 55
    iget-object v1, v1, La/JE;->e:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v1, La/h9;

    .line 58
    .line 59
    invoke-direct {v3, v1}, La/kT;-><init>(La/h9;)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_2
    new-instance v3, La/Fq;

    .line 64
    .line 65
    iget-object v4, v1, La/JE;->e:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v4, La/h9;

    .line 68
    .line 69
    iget v1, v1, La/JE;->h:I

    .line 70
    .line 71
    invoke-direct {v3, v4, v1}, La/Fq;-><init>(La/h9;I)V

    .line 72
    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    new-instance v4, La/T5;

    .line 76
    .line 77
    iget-object v1, v1, La/JE;->e:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v1, La/h9;

    .line 80
    .line 81
    invoke-direct {v4, v1, v3}, La/T5;-><init>(La/h9;I)V

    .line 82
    .line 83
    .line 84
    move-object v3, v4

    .line 85
    goto :goto_0

    .line 86
    :cond_4
    new-instance v3, La/T5;

    .line 87
    .line 88
    iget-object v1, v1, La/JE;->e:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v1, La/h9;

    .line 91
    .line 92
    const/4 v4, 0x0

    .line 93
    invoke-direct {v3, v1, v4}, La/T5;-><init>(La/h9;I)V

    .line 94
    .line 95
    .line 96
    :goto_0
    invoke-virtual {v2, v0, v3}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :cond_5
    return-object v3
.end method

.method public final i()Z
    .locals 1

    .line 1
    iget-object v0, p0, La/h9;->L:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m()V
    .locals 4

    .line 1
    iget-object v0, p0, La/h9;->D:La/c8;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    iget-object v2, p0, La/h9;->P:Ljava/lang/CharSequence;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    iget-boolean v2, p0, La/h9;->u:Z

    if-nez v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    const/16 v2, 0x8

    :goto_0
    if-eq v1, v2, :cond_2

    invoke-virtual {p0}, La/h9;->h()La/sb;

    move-result-object v1

    if-nez v2, :cond_1

    const/4 v3, 0x1

    :cond_1
    invoke-virtual {v1, v3}, La/sb;->R(Z)V

    :cond_2
    invoke-virtual {p0}, La/h9;->I()V

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, La/h9;->K:Lcom/google/android/material/textfield/TextInputLayout;

    invoke-virtual {v0}, Lcom/google/android/material/textfield/TextInputLayout;->q()Z

    return-void
.end method

.method public final p()I
    .locals 3

    .line 1
    invoke-virtual {p0}, La/h9;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, La/h9;->i()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    goto :goto_1

    .line 16
    :cond_1
    :goto_0
    iget-object v0, p0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 27
    .line 28
    invoke-static {v0}, La/WK;->p(Landroid/view/ViewGroup$MarginLayoutParams;)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    add-int/2addr v0, v1

    .line 33
    :goto_1
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 34
    .line 35
    invoke-static {p0}, La/XC;->i(Landroid/view/View;)I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    iget-object v2, p0, La/h9;->D:La/c8;

    .line 40
    .line 41
    invoke-static {v2}, La/XC;->i(Landroid/view/View;)I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    add-int/2addr v2, v1

    .line 46
    add-int/2addr v2, v0

    .line 47
    return v2
.end method

.method public final w(Landroid/view/ViewGroup;Landroid/view/LayoutInflater;I)Lcom/google/android/material/internal/CheckableImageButton;
    .locals 2

    .line 1
    const v0, 0x7f0c002c

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    invoke-virtual {p2, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lcom/google/android/material/internal/CheckableImageButton;

    .line 10
    .line 11
    invoke-virtual {p1, p3}, Landroid/view/View;->setId(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    invoke-static {p2}, La/rx;->J(Landroid/content/Context;)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    if-eqz p2, :cond_0

    .line 23
    .line 24
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    check-cast p2, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 29
    .line 30
    invoke-static {p2, v1}, La/WK;->O(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-object p1
.end method
