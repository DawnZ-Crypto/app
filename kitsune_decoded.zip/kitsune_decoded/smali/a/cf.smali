.class public interface abstract La/cf;
.super Ljava/lang/Object;
.source "SourceFile"
