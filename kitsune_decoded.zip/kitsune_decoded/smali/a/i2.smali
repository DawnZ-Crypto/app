.class public final La/i2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final I:La/ee;

.field public static final O:Landroid/graphics/PorterDuff$Mode;

.field public static V:La/i2;


# instance fields
.field public Q:Z

.field public X:La/EW;

.field public final e:Ljava/util/WeakHashMap;

.field public h:La/LC;

.field public i:Landroid/util/TypedValue;

.field public p:La/a1;

.field public w:Ljava/util/WeakHashMap;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    sput-object v0, La/i2;->O:Landroid/graphics/PorterDuff$Mode;

    .line 4
    .line 5
    new-instance v0, La/ee;

    .line 6
    .line 7
    const/4 v1, 0x6

    .line 8
    invoke-direct {v0, v1}, La/Qe;-><init>(I)V

    .line 9
    .line 10
    .line 11
    sput-object v0, La/i2;->I:La/ee;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    iput-object v0, p0, La/i2;->e:Ljava/util/WeakHashMap;

    return-void
.end method

.method public static I(La/i2;)V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x18

    if-ge v0, v1, :cond_0

    new-instance v0, La/xr;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, La/xr;-><init>(I)V

    const-string v1, "vector"

    invoke-virtual {p0, v1, v0}, La/i2;->w(Ljava/lang/String;La/xr;)V

    new-instance v0, La/xr;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La/xr;-><init>(I)V

    const-string v1, "animated-vector"

    invoke-virtual {p0, v1, v0}, La/i2;->w(Ljava/lang/String;La/xr;)V

    new-instance v0, La/xr;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La/xr;-><init>(I)V

    const-string v1, "animated-selector"

    invoke-virtual {p0, v1, v0}, La/i2;->w(Ljava/lang/String;La/xr;)V

    new-instance v0, La/xr;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La/xr;-><init>(I)V

    const-string v1, "drawable"

    invoke-virtual {p0, v1, v0}, La/i2;->w(Ljava/lang/String;La/xr;)V

    :cond_0
    return-void
.end method

.method public static declared-synchronized O(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .locals 4

    .line 1
    const-class v0, La/i2;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, La/i2;->I:La/ee;

    .line 5
    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/16 v2, 0x1f

    .line 10
    .line 11
    add-int v3, v2, p0

    .line 12
    .line 13
    mul-int/2addr v3, v2

    .line 14
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    add-int/2addr v2, v3

    .line 19
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-virtual {v1, v2}, La/Qe;->w(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Landroid/graphics/PorterDuffColorFilter;

    .line 28
    .line 29
    if-nez v2, :cond_0

    .line 30
    .line 31
    new-instance v2, Landroid/graphics/PorterDuffColorFilter;

    .line 32
    .line 33
    invoke-direct {v2, p0, p1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    add-int/2addr p0, v3

    .line 41
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-virtual {v1, p0, v2}, La/Qe;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Landroid/graphics/PorterDuffColorFilter;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :catchall_0
    move-exception p0

    .line 53
    goto :goto_1

    .line 54
    :cond_0
    :goto_0
    monitor-exit v0

    .line 55
    return-object v2

    .line 56
    :goto_1
    monitor-exit v0

    .line 57
    throw p0
.end method

.method public static declared-synchronized e()La/i2;
    .locals 2

    .line 1
    const-class v0, La/i2;

    monitor-enter v0

    :try_start_0
    sget-object v1, La/i2;->V:La/i2;

    if-nez v1, :cond_0

    new-instance v1, La/i2;

    invoke-direct {v1}, La/i2;-><init>()V

    sput-object v1, La/i2;->V:La/i2;

    invoke-static {v1}, La/i2;->I(La/i2;)V

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    sget-object v1, La/i2;->V:La/i2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object v1

    :goto_1
    monitor-exit v0

    throw v1
.end method


# virtual methods
.method public final declared-synchronized M(Landroid/content/Context;)V
    .locals 1

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, La/i2;->e:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, La/iC;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/iC;->p()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit p0

    return-void

    :goto_1
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized Q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    monitor-enter p0

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1, p2, v0}, La/i2;->X(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized T(La/EW;)V
    .locals 0

    .line 1
    monitor-enter p0

    :try_start_0
    iput-object p1, p0, La/i2;->X:La/EW;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized V(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/i2;->w:Ljava/util/WeakHashMap;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, La/a1;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {v0, p2, v1}, La/a1;->i(ILjava/lang/Integer;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Landroid/content/res/ColorStateList;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move-object v0, v1

    .line 23
    :goto_0
    if-nez v0, :cond_5

    .line 24
    .line 25
    iget-object v0, p0, La/i2;->X:La/EW;

    .line 26
    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_1
    invoke-virtual {v0, p1, p2}, La/EW;->i(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    :goto_1
    if-eqz v1, :cond_4

    .line 35
    .line 36
    iget-object v0, p0, La/i2;->w:Ljava/util/WeakHashMap;

    .line 37
    .line 38
    if-nez v0, :cond_2

    .line 39
    .line 40
    new-instance v0, Ljava/util/WeakHashMap;

    .line 41
    .line 42
    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object v0, p0, La/i2;->w:Ljava/util/WeakHashMap;

    .line 46
    .line 47
    :cond_2
    iget-object v0, p0, La/i2;->w:Ljava/util/WeakHashMap;

    .line 48
    .line 49
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    check-cast v0, La/a1;

    .line 54
    .line 55
    if-nez v0, :cond_3

    .line 56
    .line 57
    new-instance v0, La/a1;

    .line 58
    .line 59
    invoke-direct {v0}, La/a1;-><init>()V

    .line 60
    .line 61
    .line 62
    iget-object v2, p0, La/i2;->w:Ljava/util/WeakHashMap;

    .line 63
    .line 64
    invoke-virtual {v2, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    :cond_3
    invoke-virtual {v0, p2, v1}, La/a1;->w(ILjava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    .line 69
    .line 70
    :cond_4
    move-object v0, v1

    .line 71
    goto :goto_2

    .line 72
    :catchall_0
    move-exception p1

    .line 73
    goto :goto_3

    .line 74
    :cond_5
    :goto_2
    monitor-exit p0

    .line 75
    return-object v0

    .line 76
    :goto_3
    monitor-exit p0

    .line 77
    throw p1
.end method

.method public final declared-synchronized X(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    .locals 11

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-boolean v0, p0, La/i2;->Q:Z

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iput-boolean v1, p0, La/i2;->Q:Z

    .line 9
    .line 10
    const v0, 0x7f0800b0

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, p1, v0}, La/i2;->Q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_18

    .line 18
    .line 19
    instance-of v2, v0, La/Ww;

    .line 20
    .line 21
    if-nez v2, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const-string v2, "android.graphics.drawable.VectorDrawable"

    .line 32
    .line 33
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_18

    .line 38
    .line 39
    :cond_1
    :goto_0
    iget-object v0, p0, La/i2;->h:La/LC;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    invoke-virtual {v0}, La/LC;->isEmpty()Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_2

    .line 49
    .line 50
    iget-object v0, p0, La/i2;->p:La/a1;

    .line 51
    .line 52
    const-string v3, "appcompat_skip_skip"

    .line 53
    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    invoke-virtual {v0, p2, v2}, La/a1;->i(ILjava/lang/Integer;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Ljava/lang/String;

    .line 61
    .line 62
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    if-nez v4, :cond_2

    .line 67
    .line 68
    if-eqz v0, :cond_4

    .line 69
    .line 70
    iget-object v4, p0, La/i2;->h:La/LC;

    .line 71
    .line 72
    invoke-virtual {v4, v0, v2}, La/LC;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    if-nez v0, :cond_4

    .line 77
    .line 78
    :cond_2
    move-object v7, v2

    .line 79
    goto/16 :goto_5

    .line 80
    .line 81
    :cond_3
    new-instance v0, La/a1;

    .line 82
    .line 83
    invoke-direct {v0}, La/a1;-><init>()V

    .line 84
    .line 85
    .line 86
    iput-object v0, p0, La/i2;->p:La/a1;

    .line 87
    .line 88
    :cond_4
    iget-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 89
    .line 90
    if-nez v0, :cond_5

    .line 91
    .line 92
    new-instance v0, Landroid/util/TypedValue;

    .line 93
    .line 94
    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 95
    .line 96
    .line 97
    iput-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 98
    .line 99
    :cond_5
    iget-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 100
    .line 101
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 102
    .line 103
    .line 104
    move-result-object v4

    .line 105
    invoke-virtual {v4, p2, v0, v1}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 106
    .line 107
    .line 108
    iget v5, v0, Landroid/util/TypedValue;->assetCookie:I

    .line 109
    .line 110
    int-to-long v5, v5

    .line 111
    const/16 v7, 0x20

    .line 112
    .line 113
    shl-long/2addr v5, v7

    .line 114
    iget v7, v0, Landroid/util/TypedValue;->data:I

    .line 115
    .line 116
    int-to-long v7, v7

    .line 117
    or-long/2addr v5, v7

    .line 118
    invoke-virtual {p0, p1, v5, v6}, La/i2;->i(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    if-eqz v7, :cond_6

    .line 123
    .line 124
    goto :goto_5

    .line 125
    :cond_6
    iget-object v8, v0, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    .line 126
    .line 127
    if-eqz v8, :cond_a

    .line 128
    .line 129
    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v8

    .line 133
    const-string v9, ".xml"

    .line 134
    .line 135
    invoke-virtual {v8, v9}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 136
    .line 137
    .line 138
    move-result v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 139
    if-eqz v8, :cond_a

    .line 140
    .line 141
    :try_start_1
    invoke-virtual {v4, p2}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 142
    .line 143
    .line 144
    move-result-object v4

    .line 145
    invoke-static {v4}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 146
    .line 147
    .line 148
    move-result-object v8

    .line 149
    :goto_1
    invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    .line 150
    .line 151
    .line 152
    move-result v9

    .line 153
    const/4 v10, 0x2

    .line 154
    if-eq v9, v10, :cond_7

    .line 155
    .line 156
    if-eq v9, v1, :cond_7

    .line 157
    .line 158
    goto :goto_1

    .line 159
    :cond_7
    if-ne v9, v10, :cond_9

    .line 160
    .line 161
    invoke-interface {v4}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    iget-object v9, p0, La/i2;->p:La/a1;

    .line 166
    .line 167
    invoke-virtual {v9, p2, v1}, La/a1;->w(ILjava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    iget-object v9, p0, La/i2;->h:La/LC;

    .line 171
    .line 172
    invoke-virtual {v9, v1, v2}, La/LC;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v1

    .line 176
    check-cast v1, La/gg;

    .line 177
    .line 178
    if-eqz v1, :cond_8

    .line 179
    .line 180
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 181
    .line 182
    .line 183
    move-result-object v9

    .line 184
    check-cast v1, La/xr;

    .line 185
    .line 186
    invoke-virtual {v1, p1, v4, v8, v9}, La/xr;->w(Landroid/content/Context;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 187
    .line 188
    .line 189
    move-result-object v7

    .line 190
    goto :goto_2

    .line 191
    :catch_0
    move-exception v0

    .line 192
    goto :goto_3

    .line 193
    :cond_8
    :goto_2
    if-eqz v7, :cond_a

    .line 194
    .line 195
    iget v0, v0, Landroid/util/TypedValue;->changingConfigurations:I

    .line 196
    .line 197
    invoke-virtual {v7, v0}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {p0, p1, v5, v6, v7}, La/i2;->h(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)V

    .line 201
    .line 202
    .line 203
    goto :goto_4

    .line 204
    :cond_9
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    .line 205
    .line 206
    const-string v1, "No start tag found"

    .line 207
    .line 208
    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    throw v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 212
    :goto_3
    :try_start_2
    const-string v1, "ResourceManagerInternal"

    .line 213
    .line 214
    const-string v4, "Exception while inflating drawable"

    .line 215
    .line 216
    invoke-static {v1, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 217
    .line 218
    .line 219
    :cond_a
    :goto_4
    if-nez v7, :cond_b

    .line 220
    .line 221
    iget-object v0, p0, La/i2;->p:La/a1;

    .line 222
    .line 223
    invoke-virtual {v0, p2, v3}, La/a1;->w(ILjava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    :cond_b
    :goto_5
    if-nez v7, :cond_c

    .line 227
    .line 228
    invoke-virtual {p0, p1, p2}, La/i2;->p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 229
    .line 230
    .line 231
    move-result-object v7

    .line 232
    goto :goto_6

    .line 233
    :catchall_0
    move-exception p1

    .line 234
    goto/16 :goto_b

    .line 235
    .line 236
    :cond_c
    :goto_6
    if-nez v7, :cond_d

    .line 237
    .line 238
    sget-object v0, La/hA;->w:Ljava/lang/Object;

    .line 239
    .line 240
    invoke-static {p1, p2}, La/Sh;->h(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 241
    .line 242
    .line 243
    move-result-object v7

    .line 244
    :cond_d
    if-eqz v7, :cond_16

    .line 245
    .line 246
    invoke-virtual {p0, p1, p2}, La/i2;->V(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    if-eqz v0, :cond_11

    .line 251
    .line 252
    sget-object p1, La/iR;->w:[I

    .line 253
    .line 254
    invoke-virtual {v7}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 255
    .line 256
    .line 257
    move-result-object p1

    .line 258
    invoke-static {p1, v0}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 259
    .line 260
    .line 261
    iget-object p3, p0, La/i2;->X:La/EW;

    .line 262
    .line 263
    if-nez p3, :cond_e

    .line 264
    .line 265
    goto :goto_7

    .line 266
    :cond_e
    const p3, 0x7f0800a3

    .line 267
    .line 268
    .line 269
    if-ne p2, p3, :cond_f

    .line 270
    .line 271
    sget-object v2, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    .line 272
    .line 273
    :cond_f
    :goto_7
    if-eqz v2, :cond_10

    .line 274
    .line 275
    invoke-static {p1, v2}, La/YU;->V(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    .line 276
    .line 277
    .line 278
    :cond_10
    move-object v2, p1

    .line 279
    goto/16 :goto_a

    .line 280
    .line 281
    :cond_11
    iget-object v0, p0, La/i2;->X:La/EW;

    .line 282
    .line 283
    if-eqz v0, :cond_14

    .line 284
    .line 285
    const v0, 0x7f08009e

    .line 286
    .line 287
    .line 288
    const v1, 0x102000d

    .line 289
    .line 290
    .line 291
    const v3, 0x102000f

    .line 292
    .line 293
    .line 294
    const/high16 v4, 0x1020000

    .line 295
    .line 296
    const v5, 0x7f040100

    .line 297
    .line 298
    .line 299
    const v6, 0x7f040103

    .line 300
    .line 301
    .line 302
    if-ne p2, v0, :cond_12

    .line 303
    .line 304
    move-object p2, v7

    .line 305
    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    .line 306
    .line 307
    invoke-virtual {p2, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 308
    .line 309
    .line 310
    move-result-object p3

    .line 311
    invoke-static {p1, v6}, La/PJ;->p(Landroid/content/Context;I)I

    .line 312
    .line 313
    .line 314
    move-result v0

    .line 315
    sget-object v2, La/gJ;->h:Landroid/graphics/PorterDuff$Mode;

    .line 316
    .line 317
    invoke-static {p3, v0, v2}, La/EW;->O(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 321
    .line 322
    .line 323
    move-result-object p3

    .line 324
    invoke-static {p1, v6}, La/PJ;->p(Landroid/content/Context;I)I

    .line 325
    .line 326
    .line 327
    move-result v0

    .line 328
    invoke-static {p3, v0, v2}, La/EW;->O(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 329
    .line 330
    .line 331
    invoke-virtual {p2, v1}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 332
    .line 333
    .line 334
    move-result-object p2

    .line 335
    invoke-static {p1, v5}, La/PJ;->p(Landroid/content/Context;I)I

    .line 336
    .line 337
    .line 338
    move-result p1

    .line 339
    :goto_8
    invoke-static {p2, p1, v2}, La/EW;->O(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 340
    .line 341
    .line 342
    goto :goto_9

    .line 343
    :cond_12
    const v0, 0x7f080095

    .line 344
    .line 345
    .line 346
    if-eq p2, v0, :cond_13

    .line 347
    .line 348
    const v0, 0x7f080094

    .line 349
    .line 350
    .line 351
    if-eq p2, v0, :cond_13

    .line 352
    .line 353
    const v0, 0x7f080096

    .line 354
    .line 355
    .line 356
    if-ne p2, v0, :cond_14

    .line 357
    .line 358
    :cond_13
    move-object p2, v7

    .line 359
    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    .line 360
    .line 361
    invoke-virtual {p2, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 362
    .line 363
    .line 364
    move-result-object p3

    .line 365
    invoke-static {p1, v6}, La/PJ;->h(Landroid/content/Context;I)I

    .line 366
    .line 367
    .line 368
    move-result v0

    .line 369
    sget-object v2, La/gJ;->h:Landroid/graphics/PorterDuff$Mode;

    .line 370
    .line 371
    invoke-static {p3, v0, v2}, La/EW;->O(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 375
    .line 376
    .line 377
    move-result-object p3

    .line 378
    invoke-static {p1, v5}, La/PJ;->p(Landroid/content/Context;I)I

    .line 379
    .line 380
    .line 381
    move-result v0

    .line 382
    invoke-static {p3, v0, v2}, La/EW;->O(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 383
    .line 384
    .line 385
    invoke-virtual {p2, v1}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 386
    .line 387
    .line 388
    move-result-object p2

    .line 389
    invoke-static {p1, v5}, La/PJ;->p(Landroid/content/Context;I)I

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    goto :goto_8

    .line 394
    :cond_14
    invoke-virtual {p0, p1, p2, v7}, La/i2;->m(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z

    .line 395
    .line 396
    .line 397
    move-result p1

    .line 398
    if-nez p1, :cond_15

    .line 399
    .line 400
    if-eqz p3, :cond_15

    .line 401
    .line 402
    goto :goto_a

    .line 403
    :cond_15
    :goto_9
    move-object v2, v7

    .line 404
    :goto_a
    move-object v7, v2

    .line 405
    :cond_16
    if-eqz v7, :cond_17

    .line 406
    .line 407
    invoke-static {v7}, La/iR;->w(Landroid/graphics/drawable/Drawable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 408
    .line 409
    .line 410
    :cond_17
    monitor-exit p0

    .line 411
    return-object v7

    .line 412
    :cond_18
    const/4 p1, 0x0

    .line 413
    :try_start_3
    iput-boolean p1, p0, La/i2;->Q:Z

    .line 414
    .line 415
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 416
    .line 417
    const-string p2, "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."

    .line 418
    .line 419
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 420
    .line 421
    .line 422
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 423
    :goto_b
    monitor-exit p0

    .line 424
    throw p1
.end method

.method public final declared-synchronized h(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)V
    .locals 2

    .line 1
    monitor-enter p0

    :try_start_0
    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p4

    if-eqz p4, :cond_1

    iget-object v0, p0, La/i2;->e:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/iC;

    if-nez v0, :cond_0

    new-instance v0, La/iC;

    invoke-direct {v0}, La/iC;-><init>()V

    iget-object v1, p0, La/i2;->e:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p2, p3, p1}, La/iC;->X(JLjava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized i(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/i2;->e:Ljava/util/WeakHashMap;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, La/iC;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-object v1

    .line 15
    :cond_0
    :try_start_1
    invoke-virtual {v0, p2, p3, v1}, La/iC;->Q(JLjava/lang/Long;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    check-cast v2, Ljava/lang/ref/WeakReference;

    .line 20
    .line 21
    if-eqz v2, :cond_2

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Landroid/graphics/drawable/Drawable$ConstantState;

    .line 28
    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-virtual {v2, p1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    .line 36
    .line 37
    .line 38
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 39
    monitor-exit p0

    .line 40
    return-object p1

    .line 41
    :catchall_0
    move-exception p1

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    :try_start_2
    iget-object p1, v0, La/iC;->K:[J

    .line 44
    .line 45
    iget v2, v0, La/iC;->L:I

    .line 46
    .line 47
    invoke-static {p1, v2, p2, p3}, La/rx;->M([JIJ)I

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-ltz p1, :cond_2

    .line 52
    .line 53
    iget-object p2, v0, La/iC;->R:[Ljava/lang/Object;

    .line 54
    .line 55
    aget-object p3, p2, p1

    .line 56
    .line 57
    sget-object v2, La/iC;->d:Ljava/lang/Object;

    .line 58
    .line 59
    if-eq p3, v2, :cond_2

    .line 60
    .line 61
    aput-object v2, p2, p1

    .line 62
    .line 63
    const/4 p1, 0x1

    .line 64
    iput-boolean p1, v0, La/iC;->X:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 65
    .line 66
    :cond_2
    monitor-exit p0

    .line 67
    return-object v1

    .line 68
    :goto_0
    monitor-exit p0

    .line 69
    throw p1
.end method

.method public final m(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Z
    .locals 7

    .line 1
    iget-object v0, p0, La/i2;->X:La/EW;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    sget-object v2, La/gJ;->h:Landroid/graphics/PorterDuff$Mode;

    .line 7
    .line 8
    iget-object v3, v0, La/EW;->h:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v3, [I

    .line 11
    .line 12
    invoke-static {v3, p2}, La/EW;->w([II)Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v4, 0x1

    .line 17
    const/4 v5, -0x1

    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    const p2, 0x7f040103

    .line 21
    .line 22
    .line 23
    :goto_0
    move v3, v4

    .line 24
    :goto_1
    move v0, v5

    .line 25
    goto :goto_3

    .line 26
    :cond_0
    iget-object v3, v0, La/EW;->e:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v3, [I

    .line 29
    .line 30
    invoke-static {v3, p2}, La/EW;->w([II)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-eqz v3, :cond_1

    .line 35
    .line 36
    const p2, 0x7f040100

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    iget-object v0, v0, La/EW;->i:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v0, [I

    .line 43
    .line 44
    invoke-static {v0, p2}, La/EW;->w([II)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    const v3, 0x1010031

    .line 49
    .line 50
    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    sget-object v2, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    .line 54
    .line 55
    :goto_2
    move p2, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_2
    const v0, 0x7f080087

    .line 58
    .line 59
    .line 60
    if-ne p2, v0, :cond_3

    .line 61
    .line 62
    const p2, 0x42233333    # 40.8f

    .line 63
    .line 64
    .line 65
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 66
    .line 67
    .line 68
    move-result p2

    .line 69
    const v0, 0x1010030

    .line 70
    .line 71
    .line 72
    move v3, v4

    .line 73
    move v6, v0

    .line 74
    move v0, p2

    .line 75
    move p2, v6

    .line 76
    goto :goto_3

    .line 77
    :cond_3
    const v0, 0x7f080075

    .line 78
    .line 79
    .line 80
    if-ne p2, v0, :cond_4

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_4
    move p2, v1

    .line 84
    move v3, p2

    .line 85
    goto :goto_1

    .line 86
    :goto_3
    if-eqz v3, :cond_6

    .line 87
    .line 88
    sget-object v1, La/iR;->w:[I

    .line 89
    .line 90
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 91
    .line 92
    .line 93
    move-result-object p3

    .line 94
    invoke-static {p1, p2}, La/PJ;->p(Landroid/content/Context;I)I

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    invoke-static {p1, v2}, La/gJ;->p(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    invoke-virtual {p3, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 103
    .line 104
    .line 105
    if-eq v0, v5, :cond_5

    .line 106
    .line 107
    invoke-virtual {p3, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 108
    .line 109
    .line 110
    :cond_5
    move v1, v4

    .line 111
    :cond_6
    return v1
.end method

.method public final p(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 7

    .line 1
    iget-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Landroid/util/TypedValue;

    .line 6
    .line 7
    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, La/i2;->i:Landroid/util/TypedValue;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, p2, v0, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 20
    .line 21
    .line 22
    iget v1, v0, Landroid/util/TypedValue;->assetCookie:I

    .line 23
    .line 24
    int-to-long v3, v1

    .line 25
    const/16 v1, 0x20

    .line 26
    .line 27
    shl-long/2addr v3, v1

    .line 28
    iget v1, v0, Landroid/util/TypedValue;->data:I

    .line 29
    .line 30
    int-to-long v5, v1

    .line 31
    or-long/2addr v3, v5

    .line 32
    invoke-virtual {p0, p1, v3, v4}, La/i2;->i(Landroid/content/Context;J)Landroid/graphics/drawable/Drawable;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    return-object v1

    .line 39
    :cond_1
    iget-object v1, p0, La/i2;->X:La/EW;

    .line 40
    .line 41
    const/4 v5, 0x0

    .line 42
    if-nez v1, :cond_2

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_2
    const v1, 0x7f080072

    .line 46
    .line 47
    .line 48
    if-ne p2, v1, :cond_3

    .line 49
    .line 50
    new-instance v5, Landroid/graphics/drawable/LayerDrawable;

    .line 51
    .line 52
    const/4 p2, 0x2

    .line 53
    new-array p2, p2, [Landroid/graphics/drawable/Drawable;

    .line 54
    .line 55
    const v1, 0x7f080071

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0, p1, v1}, La/i2;->Q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    const/4 v6, 0x0

    .line 63
    aput-object v1, p2, v6

    .line 64
    .line 65
    const v1, 0x7f080073

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0, p1, v1}, La/i2;->Q(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    aput-object v1, p2, v2

    .line 73
    .line 74
    invoke-direct {v5, p2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 75
    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_3
    const v1, 0x7f080095

    .line 79
    .line 80
    .line 81
    if-ne p2, v1, :cond_4

    .line 82
    .line 83
    const p2, 0x7f07003b

    .line 84
    .line 85
    .line 86
    :goto_0
    invoke-static {p0, p1, p2}, La/EW;->e(La/i2;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    goto :goto_1

    .line 91
    :cond_4
    const v1, 0x7f080094

    .line 92
    .line 93
    .line 94
    if-ne p2, v1, :cond_5

    .line 95
    .line 96
    const p2, 0x7f07003c

    .line 97
    .line 98
    .line 99
    goto :goto_0

    .line 100
    :cond_5
    const v1, 0x7f080096

    .line 101
    .line 102
    .line 103
    if-ne p2, v1, :cond_6

    .line 104
    .line 105
    const p2, 0x7f07003d

    .line 106
    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_6
    :goto_1
    if-eqz v5, :cond_7

    .line 110
    .line 111
    iget p2, v0, Landroid/util/TypedValue;->changingConfigurations:I

    .line 112
    .line 113
    invoke-virtual {v5, p2}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p0, p1, v3, v4, v5}, La/i2;->h(Landroid/content/Context;JLandroid/graphics/drawable/Drawable;)V

    .line 117
    .line 118
    .line 119
    :cond_7
    return-object v5
.end method

.method public final w(Ljava/lang/String;La/xr;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/i2;->h:La/LC;

    if-nez v0, :cond_0

    new-instance v0, La/LC;

    invoke-direct {v0}, La/LC;-><init>()V

    iput-object v0, p0, La/i2;->h:La/LC;

    :cond_0
    iget-object v0, p0, La/i2;->h:La/LC;

    invoke-virtual {v0, p1, p2}, La/LC;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
