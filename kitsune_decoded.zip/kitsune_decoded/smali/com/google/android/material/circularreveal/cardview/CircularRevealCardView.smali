.class public Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;
.super Lcom/google/android/material/card/MaterialCardView;
.source "SourceFile"

# interfaces
.implements La/De;


# instance fields
.field public final H:La/kS;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/card/MaterialCardView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, La/kS;

    invoke-direct {p1, p0}, La/kS;-><init>(La/AK;)V

    iput-object p1, p0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .locals 8

    .line 1
    iget-object v0, p0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    .line 2
    .line 3
    if-eqz v0, :cond_4

    .line 4
    .line 5
    iget-object v1, v0, La/kS;->e:La/xb;

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    iget v1, v1, La/xb;->p:F

    .line 11
    .line 12
    const v3, 0x7f7fffff    # Float.MAX_VALUE

    .line 13
    .line 14
    .line 15
    cmpl-float v1, v1, v3

    .line 16
    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    goto :goto_1

    .line 22
    :cond_1
    :goto_0
    move v1, v2

    .line 23
    :goto_1
    xor-int/2addr v1, v2

    .line 24
    iget-object v7, v0, La/kS;->p:Landroid/graphics/Paint;

    .line 25
    .line 26
    iget-object v2, v0, La/kS;->w:La/AK;

    .line 27
    .line 28
    iget-object v3, v0, La/kS;->h:Landroid/view/View;

    .line 29
    .line 30
    check-cast v2, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 31
    .line 32
    if-eqz v1, :cond_2

    .line 33
    .line 34
    invoke-super {v2, p1}, Landroid/widget/FrameLayout;->draw(Landroid/graphics/Canvas;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v7}, Landroid/graphics/Paint;->getColor()I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    invoke-static {v1}, Landroid/graphics/Color;->alpha(I)I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_3

    .line 46
    .line 47
    :goto_2
    const/4 v1, 0x0

    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    int-to-float v5, v2

    .line 54
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    int-to-float v6, v2

    .line 59
    move-object v2, p1

    .line 60
    move v3, v1

    .line 61
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 62
    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_2
    invoke-super {v2, p1}, Landroid/widget/FrameLayout;->draw(Landroid/graphics/Canvas;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v7}, Landroid/graphics/Paint;->getColor()I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    invoke-static {v1}, Landroid/graphics/Color;->alpha(I)I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_3

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_3
    :goto_3
    iget-object v1, v0, La/kS;->i:Landroid/graphics/drawable/Drawable;

    .line 80
    .line 81
    if-eqz v1, :cond_5

    .line 82
    .line 83
    iget-object v2, v0, La/kS;->e:La/xb;

    .line 84
    .line 85
    if-eqz v2, :cond_5

    .line 86
    .line 87
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    iget-object v2, v0, La/kS;->e:La/xb;

    .line 92
    .line 93
    iget v2, v2, La/xb;->w:F

    .line 94
    .line 95
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 96
    .line 97
    .line 98
    move-result v3

    .line 99
    int-to-float v3, v3

    .line 100
    const/high16 v4, 0x40000000    # 2.0f

    .line 101
    .line 102
    div-float/2addr v3, v4

    .line 103
    sub-float/2addr v2, v3

    .line 104
    iget-object v3, v0, La/kS;->e:La/xb;

    .line 105
    .line 106
    iget v3, v3, La/xb;->h:F

    .line 107
    .line 108
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    int-to-float v1, v1

    .line 113
    div-float/2addr v1, v4

    .line 114
    sub-float/2addr v3, v1

    .line 115
    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 116
    .line 117
    .line 118
    iget-object v0, v0, La/kS;->i:Landroid/graphics/drawable/Drawable;

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 121
    .line 122
    .line 123
    neg-float v0, v2

    .line 124
    neg-float v1, v3

    .line 125
    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 126
    .line 127
    .line 128
    goto :goto_4

    .line 129
    :cond_4
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->draw(Landroid/graphics/Canvas;)V

    .line 130
    .line 131
    .line 132
    :cond_5
    :goto_4
    return-void
.end method

.method public final e(La/xb;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    iput-object p1, v0, La/kS;->e:La/xb;

    .line 7
    .line 8
    goto :goto_1

    .line 9
    :cond_0
    iget-object v1, v0, La/kS;->e:La/xb;

    .line 10
    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    new-instance v1, La/xb;

    .line 14
    .line 15
    invoke-direct {v1, p1}, La/xb;-><init>(La/xb;)V

    .line 16
    .line 17
    .line 18
    iput-object v1, v0, La/kS;->e:La/xb;

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget v2, p1, La/xb;->w:F

    .line 22
    .line 23
    iget v3, p1, La/xb;->h:F

    .line 24
    .line 25
    iget v4, p1, La/xb;->p:F

    .line 26
    .line 27
    iput v2, v1, La/xb;->w:F

    .line 28
    .line 29
    iput v3, v1, La/xb;->h:F

    .line 30
    .line 31
    iput v4, v1, La/xb;->p:F

    .line 32
    .line 33
    :goto_0
    iget v1, p1, La/xb;->p:F

    .line 34
    .line 35
    iget v2, p1, La/xb;->w:F

    .line 36
    .line 37
    iget p1, p1, La/xb;->h:F

    .line 38
    .line 39
    iget-object v3, v0, La/kS;->h:Landroid/view/View;

    .line 40
    .line 41
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    int-to-float v4, v4

    .line 46
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    int-to-float v3, v3

    .line 51
    invoke-static {v2, p1, v4, v3}, La/rE;->u(FFFF)F

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    const v2, 0x38d1b717    # 1.0E-4f

    .line 56
    .line 57
    .line 58
    add-float/2addr v1, v2

    .line 59
    cmpl-float p1, v1, p1

    .line 60
    .line 61
    if-ltz p1, :cond_2

    .line 62
    .line 63
    iget-object p1, v0, La/kS;->e:La/xb;

    .line 64
    .line 65
    const v1, 0x7f7fffff    # Float.MAX_VALUE

    .line 66
    .line 67
    .line 68
    iput v1, p1, La/xb;->p:F

    .line 69
    .line 70
    :cond_2
    :goto_1
    iget-object p1, v0, La/kS;->h:Landroid/view/View;

    .line 71
    .line 72
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 73
    .line 74
    .line 75
    return-void
.end method

.method public final isOpaque()Z
    .locals 4

    .line 1
    iget-object v0, p0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    iget-object v1, v0, La/kS;->w:La/AK;

    .line 6
    .line 7
    check-cast v1, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;

    .line 8
    .line 9
    invoke-super {v1}, Landroid/widget/FrameLayout;->isOpaque()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz v1, :cond_2

    .line 15
    .line 16
    iget-object v0, v0, La/kS;->e:La/xb;

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    iget v0, v0, La/xb;->p:F

    .line 22
    .line 23
    const v3, 0x7f7fffff    # Float.MAX_VALUE

    .line 24
    .line 25
    .line 26
    cmpl-float v0, v0, v3

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move v0, v2

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    :goto_0
    move v0, v1

    .line 34
    :goto_1
    xor-int/2addr v0, v1

    .line 35
    if-nez v0, :cond_2

    .line 36
    .line 37
    move v2, v1

    .line 38
    :cond_2
    return v2

    .line 39
    :cond_3
    invoke-super {p0}, Landroid/widget/FrameLayout;->isOpaque()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    return v0
.end method

.method public final p()La/xb;
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/google/android/material/circularreveal/cardview/CircularRevealCardView;->H:La/kS;

    .line 2
    .line 3
    iget-object v1, v0, La/kS;->e:La/xb;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    new-instance v2, La/xb;

    .line 10
    .line 11
    invoke-direct {v2, v1}, La/xb;-><init>(La/xb;)V

    .line 12
    .line 13
    .line 14
    iget v1, v2, La/xb;->p:F

    .line 15
    .line 16
    const v3, 0x7f7fffff    # Float.MAX_VALUE

    .line 17
    .line 18
    .line 19
    cmpl-float v1, v1, v3

    .line 20
    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    iget v1, v2, La/xb;->w:F

    .line 24
    .line 25
    iget v3, v2, La/xb;->h:F

    .line 26
    .line 27
    iget-object v0, v0, La/kS;->h:Landroid/view/View;

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    int-to-float v4, v4

    .line 34
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    int-to-float v0, v0

    .line 39
    invoke-static {v1, v3, v4, v0}, La/rE;->u(FFFF)F

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    iput v0, v2, La/xb;->p:F

    .line 44
    .line 45
    :cond_1
    move-object v0, v2

    .line 46
    :goto_0
    return-object v0
.end method
