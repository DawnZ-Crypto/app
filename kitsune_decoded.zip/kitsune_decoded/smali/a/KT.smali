.class public final La/KT;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e:[S

.field public final h:I

.field public final synthetic i:La/FR;

.field public final p:[I

.field public w:I


# direct methods
.method public constructor <init>(La/FR;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/KT;->i:La/FR;

    const/4 p1, 0x0

    iput p1, p0, La/KT;->h:I

    iput p1, p0, La/KT;->w:I

    const p1, 0x8000

    new-array p1, p1, [I

    iput-object p1, p0, La/KT;->p:[I

    const/4 v0, -0x1

    invoke-static {p1, v0}, Ljava/util/Arrays;->fill([II)V

    const/high16 p1, 0x10000

    new-array p1, p1, [S

    iput-object p1, p0, La/KT;->e:[S

    return-void
.end method


# virtual methods
.method public final h([BIIIILa/eF;)Z
    .locals 7

    .line 1
    iput p5, p6, La/eF;->p:I

    .line 2
    .line 3
    invoke-virtual {p0, p2, p1}, La/KT;->w(I[B)V

    .line 4
    .line 5
    .line 6
    invoke-static {p2, p1}, La/wg;->h(I[B)I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const v1, -0x61c8864f

    .line 11
    .line 12
    .line 13
    mul-int/2addr v0, v1

    .line 14
    ushr-int/lit8 v0, v0, 0x11

    .line 15
    .line 16
    iget-object v1, p0, La/KT;->p:[I

    .line 17
    .line 18
    aget v0, v1, v0

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    move v2, v1

    .line 22
    :goto_0
    iget-object v3, p0, La/KT;->i:La/FR;

    .line 23
    .line 24
    iget v3, v3, La/FR;->w:I

    .line 25
    .line 26
    if-ge v2, v3, :cond_2

    .line 27
    .line 28
    const v3, 0xffff

    .line 29
    .line 30
    .line 31
    sub-int v4, p2, v3

    .line 32
    .line 33
    iget v5, p0, La/KT;->h:I

    .line 34
    .line 35
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-lt v0, v4, :cond_2

    .line 40
    .line 41
    if-le v0, p2, :cond_0

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_0
    invoke-static {p1, v0, p2}, La/kW;->i([BII)Z

    .line 45
    .line 46
    .line 47
    move-result v4

    .line 48
    if-eqz v4, :cond_1

    .line 49
    .line 50
    add-int/lit8 v4, v0, 0x4

    .line 51
    .line 52
    add-int/lit8 v6, p2, 0x4

    .line 53
    .line 54
    invoke-static {v4, v6, p4, p1}, La/kW;->w(III[B)I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    add-int/lit8 v4, v4, 0x4

    .line 59
    .line 60
    invoke-static {p1, v0, p2, v5, p3}, La/kW;->h([BIIII)I

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    add-int/2addr v4, v5

    .line 65
    iget v6, p6, La/eF;->p:I

    .line 66
    .line 67
    if-le v4, v6, :cond_1

    .line 68
    .line 69
    iput v4, p6, La/eF;->p:I

    .line 70
    .line 71
    sub-int v4, v0, v5

    .line 72
    .line 73
    iput v4, p6, La/eF;->h:I

    .line 74
    .line 75
    sub-int v4, p2, v5

    .line 76
    .line 77
    iput v4, p6, La/eF;->w:I

    .line 78
    .line 79
    :cond_1
    and-int v4, v0, v3

    .line 80
    .line 81
    iget-object v5, p0, La/KT;->e:[S

    .line 82
    .line 83
    aget-short v4, v5, v4

    .line 84
    .line 85
    and-int/2addr v3, v4

    .line 86
    sub-int/2addr v0, v3

    .line 87
    add-int/lit8 v2, v2, 0x1

    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_2
    :goto_1
    iget p1, p6, La/eF;->p:I

    .line 91
    .line 92
    if-le p1, p5, :cond_3

    .line 93
    .line 94
    const/4 v1, 0x1

    .line 95
    :cond_3
    return v1
.end method

.method public final w(I[B)V
    .locals 6

    .line 1
    :goto_0
    iget v0, p0, La/KT;->w:I

    .line 2
    .line 3
    if-ge v0, p1, :cond_1

    .line 4
    .line 5
    invoke-static {v0, p2}, La/wg;->h(I[B)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, -0x61c8864f

    .line 10
    .line 11
    .line 12
    mul-int/2addr v1, v2

    .line 13
    ushr-int/lit8 v1, v1, 0x11

    .line 14
    .line 15
    iget-object v2, p0, La/KT;->p:[I

    .line 16
    .line 17
    aget v3, v2, v1

    .line 18
    .line 19
    sub-int v3, v0, v3

    .line 20
    .line 21
    const/high16 v4, 0x10000

    .line 22
    .line 23
    const v5, 0xffff

    .line 24
    .line 25
    .line 26
    if-lt v3, v4, :cond_0

    .line 27
    .line 28
    move v3, v5

    .line 29
    :cond_0
    and-int v4, v0, v5

    .line 30
    .line 31
    int-to-short v3, v3

    .line 32
    iget-object v5, p0, La/KT;->e:[S

    .line 33
    .line 34
    aput-short v3, v5, v4

    .line 35
    .line 36
    aput v0, v2, v1

    .line 37
    .line 38
    iget v0, p0, La/KT;->w:I

    .line 39
    .line 40
    add-int/lit8 v0, v0, 0x1

    .line 41
    .line 42
    iput v0, p0, La/KT;->w:I

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    return-void
.end method
