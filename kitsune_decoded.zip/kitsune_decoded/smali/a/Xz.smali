.class public final La/Xz;
.super La/Cl;
.source "SourceFile"


# instance fields
.field public final synthetic X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;


# direct methods
.method public constructor <init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/Xz;->X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    invoke-direct {p0, p1, p2}, La/Cl;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;)V

    return-void
.end method


# virtual methods
.method public final O()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    iget-object v1, p0, La/Xz;->X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v1, v0}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v1, v0}, Landroid/view/View;->setScaleY(F)V

    invoke-virtual {v1, v0}, Landroid/view/View;->setScaleX(F)V

    return-void
.end method

.method public final Q(Landroid/animation/Animator;)V
    .locals 2

    .line 1
    iget-object v0, p0, La/Cl;->e:La/ze;

    .line 2
    .line 3
    iget-object v1, v0, La/ze;->K:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Landroid/animation/Animator;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/animation/Animator;->cancel()V

    .line 10
    .line 11
    .line 12
    :cond_0
    iput-object p1, v0, La/ze;->K:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object p1, p0, La/Xz;->X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x2

    .line 21
    iput v0, p1, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->s:I

    .line 22
    .line 23
    return-void
.end method

.method public final V()Z
    .locals 4

    .line 1
    sget-object v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->G:La/LJ;

    .line 2
    .line 3
    iget-object v0, p0, La/Xz;->X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    iget v0, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->s:I

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    const/4 v1, 0x2

    .line 16
    if-ne v0, v1, :cond_1

    .line 17
    .line 18
    :goto_0
    move v2, v3

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    if-eq v0, v3, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    :goto_1
    return v2
.end method

.method public final X()V
    .locals 0

    .line 1
    return-void
.end method

.method public final i()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, La/Cl;->e:La/ze;

    .line 3
    .line 4
    iput-object v0, v1, La/ze;->K:Ljava/lang/Object;

    .line 5
    .line 6
    iget-object v0, p0, La/Xz;->X:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    iput v1, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->s:I

    .line 10
    .line 11
    return-void
.end method

.method public final p()I
    .locals 1

    .line 1
    const v0, 0x7f02001c

    return v0
.end method
