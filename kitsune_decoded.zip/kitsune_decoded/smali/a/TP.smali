.class public final La/TP;
.super La/sa;
.source "SourceFile"


# instance fields
.field public final synthetic h:La/cT;


# direct methods
.method public constructor <init>(La/cT;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/TP;->h:La/cT;

    invoke-direct {p0}, La/sa;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(I)La/sH;
    .locals 2

    .line 1
    const/4 v0, 0x2

    iget-object v1, p0, La/TP;->h:La/cT;

    if-ne p1, v0, :cond_0

    iget p1, v1, La/cT;->M:I

    goto :goto_0

    :cond_0
    iget p1, v1, La/cT;->T:I

    :goto_0
    const/high16 v0, -0x80000000

    if-ne p1, v0, :cond_1

    const/4 p1, 0x0

    return-object p1

    :cond_1
    invoke-virtual {p0, p1}, La/TP;->w(I)La/sH;

    move-result-object p1

    return-object p1
.end method

.method public final p(IILandroid/os/Bundle;)Z
    .locals 6

    .line 1
    iget-object v0, p0, La/TP;->h:La/cT;

    .line 2
    .line 3
    iget-object v1, v0, La/cT;->V:Landroid/view/View;

    .line 4
    .line 5
    const/4 v2, -0x1

    .line 6
    if-eq p1, v2, :cond_a

    .line 7
    .line 8
    const/4 p3, 0x1

    .line 9
    if-eq p2, p3, :cond_9

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    const/high16 v3, -0x80000000

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    if-eq p2, v2, :cond_6

    .line 16
    .line 17
    const/16 v2, 0x40

    .line 18
    .line 19
    const/high16 v5, 0x10000

    .line 20
    .line 21
    if-eq p2, v2, :cond_3

    .line 22
    .line 23
    const/16 v2, 0x80

    .line 24
    .line 25
    if-eq p2, v2, :cond_1

    .line 26
    .line 27
    check-cast v0, La/ku;

    .line 28
    .line 29
    const/16 v1, 0x10

    .line 30
    .line 31
    if-ne p2, v1, :cond_b

    .line 32
    .line 33
    iget-object p2, v0, La/ku;->y:Lcom/google/android/material/chip/Chip;

    .line 34
    .line 35
    if-nez p1, :cond_0

    .line 36
    .line 37
    invoke-virtual {p2}, Landroid/view/View;->performClick()Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    goto/16 :goto_2

    .line 42
    .line 43
    :cond_0
    if-ne p1, p3, :cond_b

    .line 44
    .line 45
    invoke-virtual {p2, v4}, Landroid/view/View;->playSoundEffect(I)V

    .line 46
    .line 47
    .line 48
    goto :goto_2

    .line 49
    :cond_1
    iget p2, v0, La/cT;->M:I

    .line 50
    .line 51
    if-ne p2, p1, :cond_2

    .line 52
    .line 53
    iput v3, v0, La/cT;->M:I

    .line 54
    .line 55
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0, p1, v5}, La/cT;->y(II)V

    .line 59
    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    :goto_0
    move p3, v4

    .line 63
    :goto_1
    move v4, p3

    .line 64
    goto :goto_2

    .line 65
    :cond_3
    iget-object p2, v0, La/cT;->O:Landroid/view/accessibility/AccessibilityManager;

    .line 66
    .line 67
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    if-eqz v2, :cond_2

    .line 72
    .line 73
    invoke-virtual {p2}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z

    .line 74
    .line 75
    .line 76
    move-result p2

    .line 77
    if-nez p2, :cond_4

    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_4
    iget p2, v0, La/cT;->M:I

    .line 81
    .line 82
    if-eq p2, p1, :cond_2

    .line 83
    .line 84
    if-eq p2, v3, :cond_5

    .line 85
    .line 86
    iput v3, v0, La/cT;->M:I

    .line 87
    .line 88
    iget-object v2, v0, La/cT;->V:Landroid/view/View;

    .line 89
    .line 90
    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0, p2, v5}, La/cT;->y(II)V

    .line 94
    .line 95
    .line 96
    :cond_5
    iput p1, v0, La/cT;->M:I

    .line 97
    .line 98
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    .line 99
    .line 100
    .line 101
    const p2, 0x8000

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0, p1, p2}, La/cT;->y(II)V

    .line 105
    .line 106
    .line 107
    goto :goto_1

    .line 108
    :cond_6
    iget p2, v0, La/cT;->T:I

    .line 109
    .line 110
    if-eq p2, p1, :cond_7

    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_7
    iput v3, v0, La/cT;->T:I

    .line 114
    .line 115
    move-object p2, v0

    .line 116
    check-cast p2, La/ku;

    .line 117
    .line 118
    if-ne p1, p3, :cond_8

    .line 119
    .line 120
    iget-object p2, p2, La/ku;->y:Lcom/google/android/material/chip/Chip;

    .line 121
    .line 122
    iput-boolean v4, p2, Lcom/google/android/material/chip/Chip;->H:Z

    .line 123
    .line 124
    invoke-virtual {p2}, Landroid/view/View;->refreshDrawableState()V

    .line 125
    .line 126
    .line 127
    :cond_8
    const/16 p2, 0x8

    .line 128
    .line 129
    invoke-virtual {v0, p1, p2}, La/cT;->y(II)V

    .line 130
    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_9
    invoke-virtual {v0, p1}, La/cT;->m(I)Z

    .line 134
    .line 135
    .line 136
    move-result v4

    .line 137
    goto :goto_2

    .line 138
    :cond_a
    sget-object p1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 139
    .line 140
    invoke-static {v1, p2, p3}, La/Tl;->I(Landroid/view/View;ILandroid/os/Bundle;)Z

    .line 141
    .line 142
    .line 143
    move-result v4

    .line 144
    :cond_b
    :goto_2
    return v4
.end method

.method public final w(I)La/sH;
    .locals 1

    .line 1
    iget-object v0, p0, La/TP;->h:La/cT;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La/cT;->M(I)La/sH;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, La/sH;->w:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 8
    .line 9
    invoke-static {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    new-instance v0, La/sH;

    .line 14
    .line 15
    invoke-direct {v0, p1}, La/sH;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 16
    .line 17
    .line 18
    return-object v0
.end method
