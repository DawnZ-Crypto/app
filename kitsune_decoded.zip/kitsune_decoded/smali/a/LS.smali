.class public interface abstract La/LS;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/RH;
