.class public final Landroidx/core/app/RemoteActionCompat;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/WW;


# instance fields
.field public Q:Z

.field public e:Landroid/app/PendingIntent;

.field public h:Ljava/lang/CharSequence;

.field public i:Z

.field public p:Ljava/lang/CharSequence;

.field public w:Landroidx/core/graphics/drawable/IconCompat;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
