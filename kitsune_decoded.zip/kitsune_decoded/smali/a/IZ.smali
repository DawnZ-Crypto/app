.class public final La/IZ;
.super La/oW;
.source "SourceFile"


# static fields
.field public static final L:La/un;

.field public static final R:La/IZ;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/IZ;

    .line 2
    .line 3
    invoke-direct {v0}, La/ET;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/IZ;->R:La/IZ;

    .line 7
    .line 8
    new-instance v0, La/un;

    .line 9
    .line 10
    const v1, 0x7f120121

    .line 11
    .line 12
    .line 13
    invoke-direct {v0, v1}, La/un;-><init>(I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, La/IZ;->L:La/un;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final T()I
    .locals 1

    .line 1
    const v0, 0x7f08011e

    return v0
.end method

.method public final y()La/un;
    .locals 1

    .line 1
    sget-object v0, La/IZ;->L:La/un;

    return-object v0
.end method
