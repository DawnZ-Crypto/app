.class public final La/y0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final p:La/y0;


# instance fields
.field public final h:La/A8;

.field public final w:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, La/y0;

    .line 7
    .line 8
    invoke-static {v0}, La/ar;->sa(Ljava/util/ArrayList;)Ljava/util/Set;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {v1, v0, v2}, La/y0;-><init>(Ljava/util/Set;La/A8;)V

    .line 14
    .line 15
    .line 16
    sput-object v1, La/y0;->p:La/y0;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>(Ljava/util/Set;La/A8;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/y0;->w:Ljava/util/Set;

    iput-object p2, p0, La/y0;->h:La/A8;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    instance-of v0, p1, La/y0;

    if-eqz v0, :cond_0

    check-cast p1, La/y0;

    iget-object v0, p1, La/y0;->w:Ljava/util/Set;

    iget-object v1, p0, La/y0;->w:Ljava/util/Set;

    invoke-static {v0, v1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p1, p1, La/y0;->h:La/A8;

    iget-object v0, p0, La/y0;->h:La/A8;

    invoke-static {p1, v0}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, La/y0;->w:Ljava/util/Set;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/lit16 v0, v0, 0x5ed

    mul-int/lit8 v0, v0, 0x29

    iget-object v1, p0, La/y0;->h:La/A8;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v0, v1

    return v0
.end method
