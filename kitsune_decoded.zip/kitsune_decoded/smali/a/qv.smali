.class public final La/qv;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/YK;


# instance fields
.field public final e:Ljava/lang/String;

.field public final h:I

.field public final p:I

.field public final w:La/kU;


# direct methods
.method public constructor <init>(La/kU;IILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/qv;->w:La/kU;

    iput p2, p0, La/qv;->p:I

    iput p3, p0, La/qv;->h:I

    iput-object p4, p0, La/qv;->e:Ljava/lang/String;

    return-void
.end method
