.class public Lcom/topjohnwu/magisk/core/Receiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# static fields
.field public static final synthetic w:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 8

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/topjohnwu/magisk/core/Receiver;->w(Landroid/content/Context;Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-nez v0, :cond_1

    .line 12
    .line 13
    return-void

    .line 14
    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    sget-object v2, La/Qr;->K:La/Qr;

    .line 19
    .line 20
    sget-object v3, La/nZ;->X:La/nZ;

    .line 21
    .line 22
    const/4 v4, -0x1

    .line 23
    const-string v5, "android.intent.extra.UID"

    .line 24
    .line 25
    const/4 v6, 0x1

    .line 26
    const/4 v7, 0x0

    .line 27
    sparse-switch v1, :sswitch_data_0

    .line 28
    .line 29
    .line 30
    goto/16 :goto_5

    .line 31
    .line 32
    :sswitch_0
    const-string p2, "android.intent.action.MY_PACKAGE_REPLACED"

    .line 33
    .line 34
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result p2

    .line 38
    if-nez p2, :cond_2

    .line 39
    .line 40
    goto/16 :goto_5

    .line 41
    .line 42
    :cond_2
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 43
    .line 44
    .line 45
    move-result-object p2

    .line 46
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {p2, v0}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-static {p2, p1}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    if-eqz p1, :cond_e

    .line 63
    .line 64
    sget-object p1, La/Ed;->w:La/Yi;

    .line 65
    .line 66
    sget-object p1, La/uv;->w:Landroid/content/Context;

    .line 67
    .line 68
    if-eqz p1, :cond_3

    .line 69
    .line 70
    move-object v7, p1

    .line 71
    :cond_3
    invoke-virtual {v7}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-virtual {p1, p2}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    const p2, 0x10008000

    .line 84
    .line 85
    .line 86
    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 87
    .line 88
    .line 89
    const/4 p2, 0x0

    .line 90
    const/high16 v0, 0xc000000

    .line 91
    .line 92
    invoke-static {v7, p2, p1, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 97
    .line 98
    const/16 v0, 0x1a

    .line 99
    .line 100
    const v1, 0x7f08010e

    .line 101
    .line 102
    .line 103
    if-lt p2, v0, :cond_4

    .line 104
    .line 105
    invoke-static {v7}, La/p;->h(Landroid/content/Context;)Landroid/app/Notification$Builder;

    .line 106
    .line 107
    .line 108
    move-result-object p2

    .line 109
    invoke-static {v7, v1}, La/rE;->x(Landroid/content/Context;I)Landroid/graphics/Bitmap;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-static {v0}, Landroid/graphics/drawable/Icon;->createWithBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-virtual {p2, v0}, Landroid/app/Notification$Builder;->setSmallIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    .line 118
    .line 119
    .line 120
    move-result-object p2

    .line 121
    goto :goto_0

    .line 122
    :cond_4
    new-instance p2, Landroid/app/Notification$Builder;

    .line 123
    .line 124
    invoke-direct {p2, v7}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p2, v6}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 128
    .line 129
    .line 130
    move-result-object p2

    .line 131
    invoke-virtual {p2, v1}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 132
    .line 133
    .line 134
    move-result-object p2

    .line 135
    :goto_0
    invoke-virtual {p2, p1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    const p2, 0x7f1201a4

    .line 140
    .line 141
    .line 142
    invoke-virtual {v7, p2}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    .line 143
    .line 144
    .line 145
    move-result-object p2

    .line 146
    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    const p2, 0x7f1201a3

    .line 151
    .line 152
    .line 153
    invoke-virtual {v7, p2}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    invoke-virtual {p1, v6}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-static {}, La/Ed;->w()Landroid/app/NotificationManager;

    .line 166
    .line 167
    .line 168
    move-result-object p2

    .line 169
    const/4 v0, 0x4

    .line 170
    invoke-virtual {p1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    invoke-virtual {p2, v0, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 175
    .line 176
    .line 177
    goto/16 :goto_5

    .line 178
    .line 179
    :sswitch_1
    const-string p1, "android.intent.action.PACKAGE_FULLY_REMOVED"

    .line 180
    .line 181
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result p1

    .line 185
    if-nez p1, :cond_5

    .line 186
    .line 187
    goto/16 :goto_5

    .line 188
    .line 189
    :cond_5
    const-string p1, "android.intent.extra.PACKAGE_NAME"

    .line 190
    .line 191
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    if-nez p1, :cond_7

    .line 196
    .line 197
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    if-eqz p1, :cond_6

    .line 202
    .line 203
    invoke-virtual {p1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    goto :goto_1

    .line 208
    :cond_6
    move-object p1, v7

    .line 209
    :cond_7
    :goto_1
    if-eqz p1, :cond_e

    .line 210
    .line 211
    const-string p2, "magisk --denylist rm "

    .line 212
    .line 213
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object p1

    .line 217
    filled-new-array {p1}, [Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    invoke-static {p1}, La/Id;->w([Ljava/lang/String;)La/x6;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    invoke-virtual {p1, v7}, La/TZ;->B1(La/Le;)V

    .line 226
    .line 227
    .line 228
    goto/16 :goto_5

    .line 229
    .line 230
    :sswitch_2
    const-string p2, "android.intent.action.LOCALE_CHANGED"

    .line 231
    .line 232
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result p2

    .line 236
    if-nez p2, :cond_8

    .line 237
    .line 238
    goto/16 :goto_5

    .line 239
    .line 240
    :cond_8
    invoke-static {p1}, La/rE;->ZZ(Landroid/content/Context;)V

    .line 241
    .line 242
    .line 243
    goto/16 :goto_5

    .line 244
    .line 245
    :sswitch_3
    const-string p1, "android.intent.action.PACKAGE_REPLACED"

    .line 246
    .line 247
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result p1

    .line 251
    if-eqz p1, :cond_e

    .line 252
    .line 253
    sget-object p1, La/Dp;->w:La/Dp;

    .line 254
    .line 255
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 256
    .line 257
    .line 258
    sget-object v0, La/Dp;->h:[La/KG;

    .line 259
    .line 260
    const/16 v1, 0xb

    .line 261
    .line 262
    aget-object v0, v0, v1

    .line 263
    .line 264
    sget-object v1, La/Dp;->L:La/SH;

    .line 265
    .line 266
    invoke-virtual {v1, p1, v0}, La/SH;->r(La/dN;La/KG;)Ljava/lang/Boolean;

    .line 267
    .line 268
    .line 269
    move-result-object p1

    .line 270
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 271
    .line 272
    .line 273
    move-result p1

    .line 274
    if-eqz p1, :cond_e

    .line 275
    .line 276
    invoke-virtual {p2, v5, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 277
    .line 278
    .line 279
    move-result p1

    .line 280
    if-ne p1, v4, :cond_9

    .line 281
    .line 282
    move-object p1, v7

    .line 283
    goto :goto_2

    .line 284
    :cond_9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    :goto_2
    if-eqz p1, :cond_e

    .line 289
    .line 290
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 291
    .line 292
    .line 293
    move-result p1

    .line 294
    new-instance p2, La/BU;

    .line 295
    .line 296
    invoke-direct {p2, p0, p1, v7}, La/BU;-><init>(Lcom/topjohnwu/magisk/core/Receiver;ILa/hu;)V

    .line 297
    .line 298
    .line 299
    invoke-static {v3, v3, v6}, La/rE;->n(La/oj;La/oj;Z)La/oj;

    .line 300
    .line 301
    .line 302
    move-result-object p1

    .line 303
    sget-object v0, La/Th;->w:La/Fu;

    .line 304
    .line 305
    if-eq p1, v0, :cond_a

    .line 306
    .line 307
    invoke-interface {p1, v2}, La/oj;->f(La/sE;)La/ol;

    .line 308
    .line 309
    .line 310
    move-result-object v1

    .line 311
    if-nez v1, :cond_a

    .line 312
    .line 313
    invoke-interface {p1, v0}, La/oj;->I(La/oj;)La/oj;

    .line 314
    .line 315
    .line 316
    move-result-object p1

    .line 317
    :cond_a
    new-instance v0, La/ve;

    .line 318
    .line 319
    invoke-direct {v0, p1, v6}, La/N;-><init>(La/oj;Z)V

    .line 320
    .line 321
    .line 322
    :goto_3
    invoke-virtual {v0, v6, v0, p2}, La/N;->Z(ILa/N;La/Wb;)V

    .line 323
    .line 324
    .line 325
    goto :goto_5

    .line 326
    :sswitch_4
    const-string p1, "android.intent.action.UID_REMOVED"

    .line 327
    .line 328
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 329
    .line 330
    .line 331
    move-result p1

    .line 332
    if-nez p1, :cond_b

    .line 333
    .line 334
    goto :goto_5

    .line 335
    :cond_b
    invoke-virtual {p2, v5, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 336
    .line 337
    .line 338
    move-result p1

    .line 339
    if-ne p1, v4, :cond_c

    .line 340
    .line 341
    move-object p1, v7

    .line 342
    goto :goto_4

    .line 343
    :cond_c
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 344
    .line 345
    .line 346
    move-result-object p1

    .line 347
    :goto_4
    if-eqz p1, :cond_e

    .line 348
    .line 349
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 350
    .line 351
    .line 352
    move-result p1

    .line 353
    new-instance p2, La/BU;

    .line 354
    .line 355
    invoke-direct {p2, p0, p1, v7}, La/BU;-><init>(Lcom/topjohnwu/magisk/core/Receiver;ILa/hu;)V

    .line 356
    .line 357
    .line 358
    invoke-static {v3, v3, v6}, La/rE;->n(La/oj;La/oj;Z)La/oj;

    .line 359
    .line 360
    .line 361
    move-result-object p1

    .line 362
    sget-object v0, La/Th;->w:La/Fu;

    .line 363
    .line 364
    if-eq p1, v0, :cond_d

    .line 365
    .line 366
    invoke-interface {p1, v2}, La/oj;->f(La/sE;)La/ol;

    .line 367
    .line 368
    .line 369
    move-result-object v1

    .line 370
    if-nez v1, :cond_d

    .line 371
    .line 372
    invoke-interface {p1, v0}, La/oj;->I(La/oj;)La/oj;

    .line 373
    .line 374
    .line 375
    move-result-object p1

    .line 376
    :cond_d
    new-instance v0, La/ve;

    .line 377
    .line 378
    invoke-direct {v0, p1, v6}, La/N;-><init>(La/oj;Z)V

    .line 379
    .line 380
    .line 381
    goto :goto_3

    .line 382
    :cond_e
    :goto_5
    return-void

    .line 383
    :sswitch_data_0
    .sparse-switch
        -0x6849e2b4 -> :sswitch_4
        -0x304ed112 -> :sswitch_3
        -0x122164c -> :sswitch_2
        0x5e33a4ad -> :sswitch_1
        0x6789a577 -> :sswitch_0
    .end sparse-switch
.end method

.method public final w(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-static {p1}, La/C8;->p(Landroid/content/Context;)V

    return-void
.end method
