.class public final La/Ct;
.super Landroid/hardware/biometrics/BiometricPrompt$AuthenticationCallback;
.source "SourceFile"


# instance fields
.field public final synthetic w:La/BF;


# direct methods
.method public constructor <init>(La/BF;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/Ct;->w:La/BF;

    invoke-direct {p0}, Landroid/hardware/biometrics/BiometricPrompt$AuthenticationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAuthenticationError(ILjava/lang/CharSequence;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/Ct;->w:La/BF;

    invoke-virtual {v0, p1, p2}, La/BF;->w(ILjava/lang/CharSequence;)V

    return-void
.end method

.method public onAuthenticationFailed()V
    .locals 2

    .line 1
    iget-object v0, p0, La/Ct;->w:La/BF;

    .line 2
    .line 3
    check-cast v0, La/Oy;

    .line 4
    .line 5
    iget-object v0, v0, La/Oy;->w:Ljava/lang/ref/WeakReference;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, La/TO;

    .line 18
    .line 19
    iget-boolean v1, v1, La/TO;->z:Z

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, La/TO;

    .line 28
    .line 29
    iget-object v1, v0, La/TO;->v:La/bc;

    .line 30
    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    new-instance v1, La/bc;

    .line 34
    .line 35
    invoke-direct {v1}, Landroidx/lifecycle/h;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object v1, v0, La/TO;->v:La/bc;

    .line 39
    .line 40
    :cond_0
    iget-object v0, v0, La/TO;->v:La/bc;

    .line 41
    .line 42
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 43
    .line 44
    invoke-static {v0, v1}, La/TO;->R(La/bc;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_1
    return-void
.end method

.method public onAuthenticationHelp(ILjava/lang/CharSequence;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onAuthenticationSucceeded(Landroid/hardware/biometrics/BiometricPrompt$AuthenticationResult;)V
    .locals 4

    .line 1
    const/16 v0, 0x1e

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz p1, :cond_4

    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/hardware/biometrics/BiometricPrompt$AuthenticationResult;->getCryptoObject()Landroid/hardware/biometrics/BiometricPrompt$CryptoObject;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    if-nez v2, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {v2}, La/QT;->e(Landroid/hardware/biometrics/BiometricPrompt$CryptoObject;)Ljavax/crypto/Cipher;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    if-eqz v3, :cond_1

    .line 18
    .line 19
    new-instance v1, La/kQ;

    .line 20
    .line 21
    invoke-direct {v1, v3}, La/kQ;-><init>(Ljavax/crypto/Cipher;)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_1
    invoke-static {v2}, La/QT;->Q(Landroid/hardware/biometrics/BiometricPrompt$CryptoObject;)Ljava/security/Signature;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    if-eqz v3, :cond_2

    .line 30
    .line 31
    new-instance v1, La/kQ;

    .line 32
    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-direct {v1, v2, v3}, La/kQ;-><init>(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_2
    invoke-static {v2}, La/QT;->i(Landroid/hardware/biometrics/BiometricPrompt$CryptoObject;)Ljavax/crypto/Mac;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    if-eqz v3, :cond_3

    .line 43
    .line 44
    new-instance v1, La/kQ;

    .line 45
    .line 46
    invoke-direct {v1, v3}, La/kQ;-><init>(Ljavax/crypto/Mac;)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_3
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 51
    .line 52
    if-lt v3, v0, :cond_4

    .line 53
    .line 54
    invoke-static {v2}, La/BO;->h(Landroid/hardware/biometrics/BiometricPrompt$CryptoObject;)Landroid/security/identity/IdentityCredential;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    if-eqz v2, :cond_4

    .line 59
    .line 60
    new-instance v1, La/kQ;

    .line 61
    .line 62
    invoke-direct {v1, v2}, La/kQ;-><init>(Landroid/security/identity/IdentityCredential;)V

    .line 63
    .line 64
    .line 65
    :cond_4
    :goto_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 66
    .line 67
    const/4 v3, -0x1

    .line 68
    if-lt v2, v0, :cond_5

    .line 69
    .line 70
    if-eqz p1, :cond_7

    .line 71
    .line 72
    invoke-static {p1}, La/GC;->w(Landroid/hardware/biometrics/BiometricPrompt$AuthenticationResult;)I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    goto :goto_1

    .line 77
    :cond_5
    const/16 p1, 0x1d

    .line 78
    .line 79
    if-ne v2, p1, :cond_6

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_6
    const/4 v3, 0x2

    .line 83
    :cond_7
    :goto_1
    new-instance p1, La/Z1;

    .line 84
    .line 85
    invoke-direct {p1, v1, v3}, La/Z1;-><init>(La/kQ;I)V

    .line 86
    .line 87
    .line 88
    iget-object v0, p0, La/Ct;->w:La/BF;

    .line 89
    .line 90
    invoke-virtual {v0, p1}, La/BF;->h(La/Z1;)V

    .line 91
    .line 92
    .line 93
    return-void
.end method
