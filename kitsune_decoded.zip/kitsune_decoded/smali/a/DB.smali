.class public final La/DB;
.super La/F;
.source "SourceFile"


# instance fields
.field public K:Ljava/util/Vector;

.field public X:Ljava/util/Hashtable;


# direct methods
.method public static T(La/k;)La/DB;
    .locals 9

    .line 1
    instance-of v0, p0, La/DB;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p0, La/DB;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    if-eqz p0, :cond_c

    .line 10
    .line 11
    new-instance v1, La/DB;

    .line 12
    .line 13
    invoke-static {p0}, La/k;->q(Ljava/lang/Object;)La/k;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    new-instance v2, Ljava/util/Hashtable;

    .line 21
    .line 22
    invoke-direct {v2}, Ljava/util/Hashtable;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v2, v1, La/DB;->X:Ljava/util/Hashtable;

    .line 26
    .line 27
    new-instance v2, Ljava/util/Vector;

    .line 28
    .line 29
    invoke-direct {v2}, Ljava/util/Vector;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v2, v1, La/DB;->K:Ljava/util/Vector;

    .line 33
    .line 34
    invoke-virtual {p0}, La/k;->size()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_b

    .line 39
    .line 40
    invoke-virtual {p0}, La/k;->E()Ljava/util/Enumeration;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    :goto_0
    invoke-interface {p0}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_a

    .line 49
    .line 50
    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    sget-object v3, La/wV;->L:La/H;

    .line 55
    .line 56
    instance-of v3, v2, La/wV;

    .line 57
    .line 58
    if-eqz v3, :cond_1

    .line 59
    .line 60
    check-cast v2, La/wV;

    .line 61
    .line 62
    goto/16 :goto_4

    .line 63
    .line 64
    :cond_1
    if-eqz v2, :cond_7

    .line 65
    .line 66
    new-instance v3, La/wV;

    .line 67
    .line 68
    invoke-static {v2}, La/k;->q(Ljava/lang/Object;)La/k;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v2}, La/k;->size()I

    .line 76
    .line 77
    .line 78
    move-result v4

    .line 79
    const/4 v5, 0x1

    .line 80
    const/4 v6, 0x0

    .line 81
    const/4 v7, 0x2

    .line 82
    if-ne v4, v7, :cond_2

    .line 83
    .line 84
    invoke-virtual {v2, v6}, La/k;->F(I)La/m;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    invoke-static {v4}, La/H;->q(Ljava/lang/Object;)La/H;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    iput-object v4, v3, La/wV;->X:La/H;

    .line 93
    .line 94
    iput-boolean v6, v3, La/wV;->K:Z

    .line 95
    .line 96
    invoke-virtual {v2, v5}, La/k;->F(I)La/m;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-static {v2}, La/z;->l(Ljava/lang/Object;)La/z;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    iput-object v2, v3, La/wV;->R:La/z;

    .line 105
    .line 106
    goto :goto_3

    .line 107
    :cond_2
    invoke-virtual {v2}, La/k;->size()I

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    const/4 v8, 0x3

    .line 112
    if-ne v4, v8, :cond_6

    .line 113
    .line 114
    invoke-virtual {v2, v6}, La/k;->F(I)La/m;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    invoke-static {v4}, La/H;->q(Ljava/lang/Object;)La/H;

    .line 119
    .line 120
    .line 121
    move-result-object v4

    .line 122
    iput-object v4, v3, La/wV;->X:La/H;

    .line 123
    .line 124
    invoke-virtual {v2, v5}, La/k;->F(I)La/m;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    sget-object v5, La/M;->K:La/O;

    .line 129
    .line 130
    if-eqz v4, :cond_5

    .line 131
    .line 132
    instance-of v5, v4, La/M;

    .line 133
    .line 134
    if-eqz v5, :cond_3

    .line 135
    .line 136
    goto :goto_1

    .line 137
    :cond_3
    instance-of v5, v4, [B

    .line 138
    .line 139
    if-eqz v5, :cond_4

    .line 140
    .line 141
    check-cast v4, [B

    .line 142
    .line 143
    :try_start_0
    sget-object v5, La/M;->K:La/O;

    .line 144
    .line 145
    invoke-virtual {v5, v4}, La/iP;->Q([B)La/Y;

    .line 146
    .line 147
    .line 148
    move-result-object v4

    .line 149
    check-cast v4, La/M;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 150
    .line 151
    goto :goto_2

    .line 152
    :catch_0
    move-exception p0

    .line 153
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 154
    .line 155
    new-instance v1, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    const-string v2, "failed to construct boolean from byte[]: "

    .line 158
    .line 159
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object p0

    .line 166
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 167
    .line 168
    .line 169
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object p0

    .line 173
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    throw v0

    .line 177
    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 178
    .line 179
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    const-string v1, "illegal object in getInstance: "

    .line 188
    .line 189
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    throw p0

    .line 197
    :cond_5
    :goto_1
    check-cast v4, La/M;

    .line 198
    .line 199
    :goto_2
    invoke-virtual {v4}, La/M;->W()Z

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    iput-boolean v4, v3, La/wV;->K:Z

    .line 204
    .line 205
    invoke-virtual {v2, v7}, La/k;->F(I)La/m;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    invoke-static {v2}, La/z;->l(Ljava/lang/Object;)La/z;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    iput-object v2, v3, La/wV;->R:La/z;

    .line 214
    .line 215
    :goto_3
    move-object v2, v3

    .line 216
    goto :goto_4

    .line 217
    :cond_6
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 218
    .line 219
    new-instance v0, Ljava/lang/StringBuilder;

    .line 220
    .line 221
    const-string v1, "Bad sequence size: "

    .line 222
    .line 223
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v2}, La/k;->size()I

    .line 227
    .line 228
    .line 229
    move-result v1

    .line 230
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 231
    .line 232
    .line 233
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    throw p0

    .line 241
    :cond_7
    move-object v2, v0

    .line 242
    :goto_4
    iget-object v3, v1, La/DB;->X:Ljava/util/Hashtable;

    .line 243
    .line 244
    iget-object v4, v2, La/wV;->X:La/H;

    .line 245
    .line 246
    invoke-virtual {v3, v4}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    iget-object v4, v2, La/wV;->X:La/H;

    .line 251
    .line 252
    if-eqz v3, :cond_9

    .line 253
    .line 254
    const-string v3, "org.bouncycastle.x509.ignore_repeated_extensions"

    .line 255
    .line 256
    invoke-static {v3}, La/Mz;->h(Ljava/lang/String;)Z

    .line 257
    .line 258
    .line 259
    move-result v3

    .line 260
    if-eqz v3, :cond_8

    .line 261
    .line 262
    goto :goto_5

    .line 263
    :cond_8
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 264
    .line 265
    new-instance v0, Ljava/lang/StringBuilder;

    .line 266
    .line 267
    const-string v1, "repeated extension found: "

    .line 268
    .line 269
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 273
    .line 274
    .line 275
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    throw p0

    .line 283
    :cond_9
    :goto_5
    iget-object v3, v1, La/DB;->X:Ljava/util/Hashtable;

    .line 284
    .line 285
    invoke-virtual {v3, v4, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    iget-object v2, v1, La/DB;->K:Ljava/util/Vector;

    .line 289
    .line 290
    invoke-virtual {v2, v4}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    goto/16 :goto_0

    .line 294
    .line 295
    :cond_a
    return-object v1

    .line 296
    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 297
    .line 298
    const-string v0, "empty extension sequence found"

    .line 299
    .line 300
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    throw p0

    .line 304
    :cond_c
    return-object v0
.end method


# virtual methods
.method public final i()La/Y;
    .locals 4

    .line 1
    new-instance v0, La/y;

    .line 2
    .line 3
    iget-object v1, p0, La/DB;->K:Ljava/util/Vector;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    invoke-direct {v0, v2}, La/y;-><init>(I)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    :goto_0
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, La/H;

    .line 27
    .line 28
    iget-object v3, p0, La/DB;->X:Ljava/util/Hashtable;

    .line 29
    .line 30
    invoke-virtual {v3, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    check-cast v2, La/wV;

    .line 35
    .line 36
    invoke-virtual {v0, v2}, La/y;->w(La/m;)V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    new-instance v1, La/os;

    .line 41
    .line 42
    invoke-direct {v1, v0}, La/k;-><init>(La/y;)V

    .line 43
    .line 44
    .line 45
    const/4 v0, -0x1

    .line 46
    iput v0, v1, La/os;->R:I

    .line 47
    .line 48
    return-object v1
.end method
