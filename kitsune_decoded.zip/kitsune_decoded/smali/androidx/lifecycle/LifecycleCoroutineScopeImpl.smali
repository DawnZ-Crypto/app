.class public final Landroidx/lifecycle/LifecycleCoroutineScopeImpl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;
.implements La/wE;


# instance fields
.field public final K:La/oj;

.field public final X:La/GK;


# direct methods
.method public constructor <init>(La/GK;La/oj;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->X:La/GK;

    .line 5
    .line 6
    iput-object p2, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->K:La/oj;

    .line 7
    .line 8
    check-cast p1, Landroidx/lifecycle/w;

    .line 9
    .line 10
    iget-object p1, p1, Landroidx/lifecycle/w;->e:La/m2;

    .line 11
    .line 12
    sget-object v0, La/m2;->X:La/m2;

    .line 13
    .line 14
    if-ne p1, v0, :cond_0

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    invoke-static {p2, p1}, La/rE;->m(La/oj;Ljava/util/concurrent/CancellationException;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 1

    .line 1
    iget-object p1, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->X:La/GK;

    .line 2
    .line 3
    move-object p2, p1

    .line 4
    check-cast p2, Landroidx/lifecycle/w;

    .line 5
    .line 6
    iget-object p2, p2, Landroidx/lifecycle/w;->e:La/m2;

    .line 7
    .line 8
    sget-object v0, La/m2;->X:La/m2;

    .line 9
    .line 10
    invoke-virtual {p2, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 11
    .line 12
    .line 13
    move-result p2

    .line 14
    if-gtz p2, :cond_0

    .line 15
    .line 16
    invoke-virtual {p1, p0}, La/GK;->h(La/IQ;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    iget-object p2, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->K:La/oj;

    .line 21
    .line 22
    invoke-static {p2, p1}, La/rE;->m(La/oj;Ljava/util/concurrent/CancellationException;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method

.method public final U()La/oj;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/LifecycleCoroutineScopeImpl;->K:La/oj;

    return-object v0
.end method
