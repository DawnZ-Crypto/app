.class public interface abstract La/JZ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Cloneable;"
    }
.end annotation


# virtual methods
.method public abstract I()La/JZ;
.end method

.method public abstract T()La/EW;
.end method

.method public abstract cancel()V
.end method

.method public abstract f()Z
.end method

.method public abstract h(La/GG;)V
.end method
