.class public final La/qt;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final D:Z

.field public E:I

.field public F:Landroid/widget/ListAdapter;

.field public final H:I

.field public I:Landroid/widget/Button;

.field public K:Landroid/widget/Button;

.field public L:I

.field public M:Landroid/widget/Button;

.field public O:I

.field public final P:I

.field public Q:Landroidx/appcompat/app/AlertController$RecycleListView;

.field public R:Landroidx/core/widget/NestedScrollView;

.field public final S:I

.field public T:Ljava/lang/CharSequence;

.field public V:Z

.field public W:Landroid/widget/TextView;

.field public X:Landroid/view/View;

.field public final Y:La/YO;

.field public d:Landroid/graphics/drawable/Drawable;

.field public final e:I

.field public f:Landroid/widget/ImageView;

.field public final h:La/eU;

.field public i:Ljava/lang/CharSequence;

.field public l:Landroid/widget/TextView;

.field public m:Landroid/os/Message;

.field public final p:Landroid/view/Window;

.field public q:Landroid/view/View;

.field public final u:La/JO;

.field public final w:Landroid/content/Context;

.field public y:Landroid/graphics/drawable/Drawable;

.field public final z:I


# direct methods
.method public constructor <init>(Landroid/content/Context;La/eU;Landroid/view/Window;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, La/qt;->V:Z

    .line 6
    .line 7
    iput v0, p0, La/qt;->L:I

    .line 8
    .line 9
    const/4 v1, -0x1

    .line 10
    iput v1, p0, La/qt;->E:I

    .line 11
    .line 12
    new-instance v1, La/JO;

    .line 13
    .line 14
    invoke-direct {v1, v0, p0}, La/JO;-><init>(ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, La/qt;->u:La/JO;

    .line 18
    .line 19
    iput-object p1, p0, La/qt;->w:Landroid/content/Context;

    .line 20
    .line 21
    iput-object p2, p0, La/qt;->h:La/eU;

    .line 22
    .line 23
    iput-object p3, p0, La/qt;->p:Landroid/view/Window;

    .line 24
    .line 25
    new-instance p3, La/YO;

    .line 26
    .line 27
    invoke-direct {p3}, Landroid/os/Handler;-><init>()V

    .line 28
    .line 29
    .line 30
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 31
    .line 32
    invoke-direct {v1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iput-object v1, p3, La/YO;->w:Ljava/lang/ref/WeakReference;

    .line 36
    .line 37
    iput-object p3, p0, La/qt;->Y:La/YO;

    .line 38
    .line 39
    sget-object p3, La/Zn;->i:[I

    .line 40
    .line 41
    const v1, 0x7f04002e

    .line 42
    .line 43
    .line 44
    const/4 v2, 0x0

    .line 45
    invoke-virtual {p1, v2, p3, v1, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-virtual {p1, v0, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    iput p3, p0, La/qt;->S:I

    .line 54
    .line 55
    const/4 p3, 0x2

    .line 56
    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 57
    .line 58
    .line 59
    const/4 p3, 0x4

    .line 60
    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 61
    .line 62
    .line 63
    move-result p3

    .line 64
    iput p3, p0, La/qt;->H:I

    .line 65
    .line 66
    const/4 p3, 0x5

    .line 67
    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 68
    .line 69
    .line 70
    const/4 p3, 0x7

    .line 71
    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 72
    .line 73
    .line 74
    move-result p3

    .line 75
    iput p3, p0, La/qt;->z:I

    .line 76
    .line 77
    const/4 p3, 0x3

    .line 78
    invoke-virtual {p1, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 79
    .line 80
    .line 81
    move-result p3

    .line 82
    iput p3, p0, La/qt;->P:I

    .line 83
    .line 84
    const/4 p3, 0x6

    .line 85
    const/4 v1, 0x1

    .line 86
    invoke-virtual {p1, p3, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 87
    .line 88
    .line 89
    move-result p3

    .line 90
    iput-boolean p3, p0, La/qt;->D:Z

    .line 91
    .line 92
    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 93
    .line 94
    .line 95
    move-result p3

    .line 96
    iput p3, p0, La/qt;->e:I

    .line 97
    .line 98
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p2}, La/eU;->M()La/Js;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-virtual {p1, v1}, La/Js;->V(I)Z

    .line 106
    .line 107
    .line 108
    return-void
.end method

.method public static h(Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    .locals 2

    .line 1
    if-nez p0, :cond_1

    instance-of p0, p1, Landroid/view/ViewStub;

    if-eqz p0, :cond_0

    check-cast p1, Landroid/view/ViewStub;

    invoke-virtual {p1}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object p1

    :cond_0
    check-cast p1, Landroid/view/ViewGroup;

    return-object p1

    :cond_1
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_2

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2
    instance-of p1, p0, Landroid/view/ViewStub;

    if-eqz p1, :cond_3

    check-cast p0, Landroid/view/ViewStub;

    invoke-virtual {p0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object p0

    :cond_3
    check-cast p0, Landroid/view/ViewGroup;

    return-object p0
.end method

.method public static w(Landroid/view/View;)Z
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->onCheckIsTextEditor()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    const/4 v2, 0x0

    if-nez v0, :cond_1

    return v2

    :cond_1
    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    :cond_2
    if-lez v0, :cond_3

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, La/qt;->w(Landroid/view/View;)Z

    move-result v3

    if-eqz v3, :cond_2

    return v1

    :cond_3
    return v2
.end method
