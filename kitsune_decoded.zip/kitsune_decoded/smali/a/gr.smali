.class public interface abstract La/gr;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract w(La/b7;)La/vL;
.end method
