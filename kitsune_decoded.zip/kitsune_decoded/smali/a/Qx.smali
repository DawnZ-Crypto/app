.class public final La/Qx;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/ty;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "La/Qx;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La/jS;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, La/jS;-><init>(I)V

    sput-object v0, La/Qx;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public final bridge synthetic h(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Landroid/net/Uri;

    invoke-virtual {p0, p1}, La/Qx;->w(Landroid/net/Uri;)V

    return-void
.end method

.method public final p()V
    .locals 0

    .line 1
    return-void
.end method

.method public final w(Landroid/net/Uri;)V
    .locals 1

    .line 1
    sget-object v0, La/YJ;->S:La/bc;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La/bc;->I(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    .line 1
    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
