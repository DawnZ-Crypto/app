.class public interface abstract La/WV;
.super Ljava/lang/Object;
.source "SourceFile"
