.class public final Lcom/topjohnwu/magisk/ui/superuser/SuperuserFragment;
.super La/zZ;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/zZ<",
        "La/tW;",
        ">;"
    }
.end annotation


# instance fields
.field public final xF:La/Y0;

.field public final y6:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, La/zZ;-><init>()V

    const v0, 0x7f0c003a

    iput v0, p0, Lcom/topjohnwu/magisk/ui/superuser/SuperuserFragment;->y6:I

    new-instance v0, La/Vn;

    const/16 v1, 0x8

    invoke-direct {v0, p0, v1}, La/Vn;-><init>(La/yN;I)V

    invoke-static {v0}, La/A8;->C(La/Lc;)La/Y0;

    move-result-object v0

    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/superuser/SuperuserFragment;->xF:La/Y0;

    return-void
.end method


# virtual methods
.method public final C()V
    .locals 3

    .line 1
    invoke-super {p0}, La/zZ;->C()V

    invoke-virtual {p0}, La/zZ;->G()La/o5;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/zr;->f()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f120182

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    :goto_0
    return-void
.end method

.method public final bridge synthetic F9(Landroidx/databinding/w;)V
    .locals 0

    .line 1
    check-cast p1, La/tW;

    return-void
.end method

.method public final Pc()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/superuser/SuperuserFragment;->y6:I

    return v0
.end method

.method public final V()La/hb;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/superuser/SuperuserFragment;->xF:La/Y0;

    .line 2
    .line 3
    invoke-interface {v0}, La/Y0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La/RW;

    .line 8
    .line 9
    return-object v0
.end method

.method public final g(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2}, La/zZ;->g(Landroid/view/View;Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/zZ;->B1:Landroidx/databinding/w;

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    const/4 p1, 0x0

    .line 10
    :goto_0
    check-cast p1, La/tW;

    .line 11
    .line 12
    iget-object p1, p1, La/tW;->t:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    const p2, 0x7f0700af

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x5

    .line 18
    invoke-static {p1, p2, v0}, La/rx;->Q(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 19
    .line 20
    .line 21
    invoke-static {p1}, La/rx;->X(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1}, La/rx;->S(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method
