.class public final La/Hj;
.super La/j;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(IIILa/m;I)V
    .locals 0

    iput p5, p0, La/Hj;->d:I

    .line 1
    invoke-direct {p0, p1, p2, p3, p4}, La/j;-><init>(IIILa/m;)V

    return-void
.end method

.method public synthetic constructor <init>(IILa/m;Z)V
    .locals 0

    iput p2, p0, La/Hj;->d:I

    .line 2
    invoke-direct {p0, p4, p1, p3}, La/j;-><init>(ZILa/m;)V

    return-void
.end method

.method public constructor <init>(La/m;)V
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, La/Hj;->d:I

    const/4 v1, 0x0

    .line 3
    invoke-direct {p0, v0, v1, p1}, La/j;-><init>(ZILa/m;)V

    return-void
.end method


# virtual methods
.method public final F(La/Y;)La/k;
    .locals 2

    .line 1
    iget v0, p0, La/Hj;->d:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    new-instance v0, La/Dz;

    .line 8
    .line 9
    invoke-direct {v0, p1}, La/k;-><init>(La/m;)V

    .line 10
    .line 11
    .line 12
    iput v1, v0, La/Dz;->R:I

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_0
    new-instance v0, La/os;

    .line 16
    .line 17
    invoke-direct {v0, p1}, La/k;-><init>(La/m;)V

    .line 18
    .line 19
    .line 20
    iput v1, v0, La/os;->R:I

    .line 21
    .line 22
    return-object v0

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final K(Z)I
    .locals 4

    .line 1
    iget v0, p0, La/Hj;->d:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget v2, p0, La/j;->R:I

    .line 5
    .line 6
    iget-object v3, p0, La/j;->L:La/m;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    invoke-interface {v3}, La/m;->i()La/Y;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, La/Y;->f()La/Y;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p0}, La/j;->q()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    invoke-virtual {v0, v3}, La/Y;->K(Z)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v3, :cond_0

    .line 28
    .line 29
    invoke-static {v0}, La/sR;->Q(I)I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    add-int/2addr v0, v3

    .line 34
    :cond_0
    if-eqz p1, :cond_1

    .line 35
    .line 36
    invoke-static {v2}, La/sR;->O(I)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    :cond_1
    add-int/2addr v0, v1

    .line 41
    return v0

    .line 42
    :pswitch_0
    invoke-interface {v3}, La/m;->i()La/Y;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v0}, La/Y;->d()La/Y;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {p0}, La/j;->q()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    invoke-virtual {v0, v3}, La/Y;->K(Z)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v3, :cond_2

    .line 59
    .line 60
    invoke-static {v0}, La/sR;->Q(I)I

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    add-int/2addr v0, v3

    .line 65
    :cond_2
    if-eqz p1, :cond_3

    .line 66
    .line 67
    invoke-static {v2}, La/sR;->O(I)I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    :cond_3
    add-int/2addr v0, v1

    .line 72
    return v0

    .line 73
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final d()La/Y;
    .locals 1

    .line 1
    iget v0, p0, La/Hj;->d:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, La/j;->d()La/Y;

    move-result-object v0

    return-object v0

    :pswitch_0
    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final f()La/Y;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final m(La/sR;Z)V
    .locals 5

    .line 1
    iget v0, p0, La/Hj;->d:I

    .line 2
    .line 3
    iget v1, p0, La/j;->R:I

    .line 4
    .line 5
    iget v2, p0, La/j;->K:I

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, p0, La/j;->L:La/m;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    invoke-interface {v4}, La/m;->i()La/Y;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0}, La/Y;->f()La/Y;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {p0}, La/j;->q()Z

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    if-eqz p2, :cond_2

    .line 26
    .line 27
    if-nez v4, :cond_0

    .line 28
    .line 29
    invoke-virtual {v0}, La/Y;->y()Z

    .line 30
    .line 31
    .line 32
    move-result p2

    .line 33
    if-eqz p2, :cond_1

    .line 34
    .line 35
    :cond_0
    or-int/lit8 v2, v2, 0x20

    .line 36
    .line 37
    :cond_1
    invoke-virtual {p1, v2, v1}, La/sR;->R(II)V

    .line 38
    .line 39
    .line 40
    :cond_2
    if-eqz v4, :cond_3

    .line 41
    .line 42
    invoke-virtual {v0, v3}, La/Y;->K(Z)I

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    invoke-virtual {p1, p2}, La/sR;->T(I)V

    .line 47
    .line 48
    .line 49
    :cond_3
    invoke-virtual {p1}, La/sR;->i()La/gG;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-virtual {v0, p1, v4}, La/Y;->m(La/sR;Z)V

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :pswitch_0
    invoke-interface {v4}, La/m;->i()La/Y;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v0}, La/Y;->d()La/Y;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {p0}, La/j;->q()Z

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    if-eqz p2, :cond_6

    .line 70
    .line 71
    if-nez v4, :cond_4

    .line 72
    .line 73
    invoke-virtual {v0}, La/Y;->y()Z

    .line 74
    .line 75
    .line 76
    move-result p2

    .line 77
    if-eqz p2, :cond_5

    .line 78
    .line 79
    :cond_4
    or-int/lit8 v2, v2, 0x20

    .line 80
    .line 81
    :cond_5
    invoke-virtual {p1, v2, v1}, La/sR;->R(II)V

    .line 82
    .line 83
    .line 84
    :cond_6
    if-eqz v4, :cond_7

    .line 85
    .line 86
    invoke-virtual {v0, v3}, La/Y;->K(Z)I

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    invoke-virtual {p1, p2}, La/sR;->T(I)V

    .line 91
    .line 92
    .line 93
    :cond_7
    invoke-virtual {p1}, La/sR;->p()La/Gm;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-virtual {v0, p1, v4}, La/Y;->m(La/sR;Z)V

    .line 98
    .line 99
    .line 100
    return-void

    .line 101
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y()Z
    .locals 4

    .line 1
    iget v0, p0, La/Hj;->d:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, La/j;->L:La/m;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, La/j;->q()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v3}, La/m;->i()La/Y;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0}, La/Y;->f()La/Y;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, La/Y;->y()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move v1, v2

    .line 32
    :cond_1
    :goto_0
    return v1

    .line 33
    :pswitch_0
    invoke-virtual {p0}, La/j;->q()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_3

    .line 38
    .line 39
    invoke-interface {v3}, La/m;->i()La/Y;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0}, La/Y;->d()La/Y;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v0}, La/Y;->y()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_2
    move v1, v2

    .line 55
    :cond_3
    :goto_1
    return v1

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
