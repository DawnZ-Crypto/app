.class public final La/X6;
.super La/if;
.source "SourceFile"


# instance fields
.field public final L:La/uE;

.field public d:J

.field public f:Z

.field public final synthetic l:La/Ae;


# direct methods
.method public constructor <init>(La/Ae;La/uE;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/X6;->l:La/Ae;

    invoke-direct {p0, p1}, La/if;-><init>(La/Ae;)V

    iput-object p2, p0, La/X6;->L:La/uE;

    const-wide/16 p1, -0x1

    iput-wide p1, p0, La/X6;->d:J

    const/4 p1, 0x1

    iput-boolean p1, p0, La/X6;->f:Z

    return-void
.end method


# virtual methods
.method public final M(La/WI;J)J
    .locals 10

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v2, p2, v0

    .line 4
    .line 5
    if-ltz v2, :cond_a

    .line 6
    .line 7
    iget-boolean v2, p0, La/if;->K:Z

    .line 8
    .line 9
    xor-int/lit8 v2, v2, 0x1

    .line 10
    .line 11
    if-eqz v2, :cond_9

    .line 12
    .line 13
    iget-boolean v2, p0, La/X6;->f:Z

    .line 14
    .line 15
    const-wide/16 v3, -0x1

    .line 16
    .line 17
    if-nez v2, :cond_0

    .line 18
    .line 19
    return-wide v3

    .line 20
    :cond_0
    iget-wide v5, p0, La/X6;->d:J

    .line 21
    .line 22
    cmp-long v2, v5, v0

    .line 23
    .line 24
    iget-object v7, p0, La/X6;->l:La/Ae;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    cmp-long v2, v5, v3

    .line 29
    .line 30
    if-nez v2, :cond_6

    .line 31
    .line 32
    :cond_1
    const-string v2, "expected chunk size and optional extensions but was \""

    .line 33
    .line 34
    cmp-long v5, v5, v3

    .line 35
    .line 36
    if-eqz v5, :cond_2

    .line 37
    .line 38
    iget-object v5, v7, La/Ae;->p:La/wI;

    .line 39
    .line 40
    invoke-interface {v5}, La/wI;->o()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    :cond_2
    :try_start_0
    iget-object v5, v7, La/Ae;->p:La/wI;

    .line 44
    .line 45
    invoke-interface {v5}, La/wI;->rV()J

    .line 46
    .line 47
    .line 48
    move-result-wide v5

    .line 49
    iput-wide v5, p0, La/X6;->d:J

    .line 50
    .line 51
    iget-object v5, v7, La/Ae;->p:La/wI;

    .line 52
    .line 53
    invoke-interface {v5}, La/wI;->o()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    invoke-static {v5}, La/ge;->Yo(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    iget-wide v8, p0, La/X6;->d:J

    .line 66
    .line 67
    cmp-long v6, v8, v0

    .line 68
    .line 69
    if-ltz v6, :cond_8

    .line 70
    .line 71
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 72
    .line 73
    .line 74
    move-result v6

    .line 75
    if-lez v6, :cond_3

    .line 76
    .line 77
    const-string v6, ";"

    .line 78
    .line 79
    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 80
    .line 81
    .line 82
    move-result v6
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 83
    if-eqz v6, :cond_8

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :catch_0
    move-exception p1

    .line 87
    goto/16 :goto_3

    .line 88
    .line 89
    :cond_3
    :goto_0
    iget-wide v5, p0, La/X6;->d:J

    .line 90
    .line 91
    cmp-long v0, v5, v0

    .line 92
    .line 93
    if-nez v0, :cond_5

    .line 94
    .line 95
    const/4 v0, 0x0

    .line 96
    iput-boolean v0, p0, La/X6;->f:Z

    .line 97
    .line 98
    iget-object v0, v7, La/Ae;->Q:La/Ns;

    .line 99
    .line 100
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    new-instance v1, La/zV;

    .line 104
    .line 105
    invoke-direct {v1}, La/zV;-><init>()V

    .line 106
    .line 107
    .line 108
    :goto_1
    iget-object v2, v0, La/Ns;->w:La/wI;

    .line 109
    .line 110
    iget-wide v5, v0, La/Ns;->h:J

    .line 111
    .line 112
    invoke-interface {v2, v5, v6}, La/wI;->W(J)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    iget-wide v5, v0, La/Ns;->h:J

    .line 117
    .line 118
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 119
    .line 120
    .line 121
    move-result v8

    .line 122
    int-to-long v8, v8

    .line 123
    sub-long/2addr v5, v8

    .line 124
    iput-wide v5, v0, La/Ns;->h:J

    .line 125
    .line 126
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    if-nez v5, :cond_4

    .line 131
    .line 132
    invoke-virtual {v1}, La/zV;->e()La/Sa;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    iget-object v1, v7, La/Ae;->w:La/qU;

    .line 137
    .line 138
    iget-object v1, v1, La/qU;->F:La/ah;

    .line 139
    .line 140
    iget-object v2, p0, La/X6;->L:La/uE;

    .line 141
    .line 142
    invoke-static {v1, v2, v0}, La/MT;->h(La/ah;La/uE;La/Sa;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {p0}, La/if;->w()V

    .line 146
    .line 147
    .line 148
    goto :goto_2

    .line 149
    :cond_4
    invoke-virtual {v1, v2}, La/zV;->h(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    goto :goto_1

    .line 153
    :cond_5
    :goto_2
    iget-boolean v0, p0, La/X6;->f:Z

    .line 154
    .line 155
    if-nez v0, :cond_6

    .line 156
    .line 157
    return-wide v3

    .line 158
    :cond_6
    iget-wide v0, p0, La/X6;->d:J

    .line 159
    .line 160
    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 161
    .line 162
    .line 163
    move-result-wide p2

    .line 164
    invoke-super {p0, p1, p2, p3}, La/if;->M(La/WI;J)J

    .line 165
    .line 166
    .line 167
    move-result-wide p1

    .line 168
    cmp-long p3, p1, v3

    .line 169
    .line 170
    if-eqz p3, :cond_7

    .line 171
    .line 172
    iget-wide v0, p0, La/X6;->d:J

    .line 173
    .line 174
    sub-long/2addr v0, p1

    .line 175
    iput-wide v0, p0, La/X6;->d:J

    .line 176
    .line 177
    return-wide p1

    .line 178
    :cond_7
    iget-object p1, v7, La/Ae;->h:La/A6;

    .line 179
    .line 180
    invoke-virtual {p1}, La/A6;->T()V

    .line 181
    .line 182
    .line 183
    new-instance p1, Ljava/net/ProtocolException;

    .line 184
    .line 185
    const-string p2, "unexpected end of stream"

    .line 186
    .line 187
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {p0}, La/if;->w()V

    .line 191
    .line 192
    .line 193
    throw p1

    .line 194
    :cond_8
    :try_start_1
    new-instance p1, Ljava/net/ProtocolException;

    .line 195
    .line 196
    new-instance p2, Ljava/lang/StringBuilder;

    .line 197
    .line 198
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget-wide v0, p0, La/X6;->d:J

    .line 202
    .line 203
    invoke-virtual {p2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 207
    .line 208
    .line 209
    const/16 p3, 0x22

    .line 210
    .line 211
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object p2

    .line 218
    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    throw p1
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    .line 222
    :goto_3
    new-instance p2, Ljava/net/ProtocolException;

    .line 223
    .line 224
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object p1

    .line 228
    invoke-direct {p2, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    throw p2

    .line 232
    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 233
    .line 234
    const-string p2, "closed"

    .line 235
    .line 236
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object p2

    .line 240
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    throw p1

    .line 244
    :cond_a
    const-string p1, "byteCount < 0: "

    .line 245
    .line 246
    invoke-static {p1, p2, p3}, La/zq;->X(Ljava/lang/String;J)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object p1

    .line 250
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 251
    .line 252
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    throw p2
.end method

.method public final close()V
    .locals 2

    .line 1
    iget-boolean v0, p0, La/if;->K:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-boolean v0, p0, La/X6;->f:Z

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 11
    .line 12
    const/16 v1, 0x64

    .line 13
    .line 14
    :try_start_0
    invoke-static {p0, v1, v0}, La/kD;->f(La/Xg;ILjava/util/concurrent/TimeUnit;)Z

    .line 15
    .line 16
    .line 17
    move-result v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    :catch_0
    iget-object v0, p0, La/X6;->l:La/Ae;

    .line 21
    .line 22
    iget-object v0, v0, La/Ae;->h:La/A6;

    .line 23
    .line 24
    invoke-virtual {v0}, La/A6;->T()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, La/if;->w()V

    .line 28
    .line 29
    .line 30
    :cond_1
    const/4 v0, 0x1

    .line 31
    iput-boolean v0, p0, La/if;->K:Z

    .line 32
    .line 33
    return-void
.end method
