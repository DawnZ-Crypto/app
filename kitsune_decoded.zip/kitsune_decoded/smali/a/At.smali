.class public abstract La/At;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# instance fields
.field public K:[I

.field public L:[I

.field public R:[Ljava/lang/String;

.field public X:I

.field public d:Z

.field public f:I


# virtual methods
.method public abstract I()La/AN;
.end method

.method public final T()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, La/At;->X:I

    iget-object v1, p0, La/At;->K:[I

    iget-object v2, p0, La/At;->R:[Ljava/lang/String;

    iget-object v3, p0, La/At;->L:[I

    invoke-static {v0, v1, v3, v2}, La/rE;->rV(I[I[I[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public abstract U()La/AN;
.end method

.method public abstract ZU(Ljava/lang/String;)La/AN;
.end method

.method public abstract f(Ljava/lang/String;)La/AN;
.end method

.method public abstract h()La/AN;
.end method

.method public abstract mh(J)La/AN;
.end method

.method public abstract w()La/AN;
.end method

.method public final x()I
    .locals 2

    .line 1
    iget v0, p0, La/At;->X:I

    if-eqz v0, :cond_0

    iget-object v1, p0, La/At;->K:[I

    add-int/lit8 v0, v0, -0x1

    aget v0, v1, v0

    return v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "JsonWriter is closed."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
