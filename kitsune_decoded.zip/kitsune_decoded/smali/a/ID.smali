.class public abstract La/ID;
.super La/rx;
.source "SourceFile"
