.class final Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;
.implements La/Ch;


# instance fields
.field public final K:La/AJ;

.field public final synthetic L:Landroidx/activity/h;

.field public R:La/W9;

.field public final X:La/GK;


# direct methods
.method public constructor <init>(Landroidx/activity/h;La/GK;La/rN;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->L:Landroidx/activity/h;

    iput-object p2, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->X:La/GK;

    iput-object p3, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->K:La/AJ;

    invoke-virtual {p2, p0}, La/GK;->w(La/IQ;)V

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 3

    .line 1
    sget-object p1, La/cw;->ON_START:La/cw;

    .line 2
    .line 3
    if-ne p2, p1, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->L:Landroidx/activity/h;

    .line 6
    .line 7
    iget-object p2, p1, Landroidx/activity/h;->h:La/qP;

    .line 8
    .line 9
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->K:La/AJ;

    .line 10
    .line 11
    invoke-virtual {p2, v0}, La/qP;->i(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    new-instance p2, La/W9;

    .line 15
    .line 16
    invoke-direct {p2, p1, v0}, La/W9;-><init>(Landroidx/activity/h;La/AJ;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, v0, La/AJ;->h:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 20
    .line 21
    invoke-virtual {v1, p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1}, Landroidx/activity/h;->e()V

    .line 25
    .line 26
    .line 27
    new-instance v1, La/aq;

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    invoke-direct {v1, v2, p1}, La/aq;-><init>(ILandroidx/activity/h;)V

    .line 31
    .line 32
    .line 33
    iput-object v1, v0, La/AJ;->p:La/Lc;

    .line 34
    .line 35
    iput-object p2, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->R:La/W9;

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    sget-object p1, La/cw;->ON_STOP:La/cw;

    .line 39
    .line 40
    if-ne p2, p1, :cond_1

    .line 41
    .line 42
    iget-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->R:La/W9;

    .line 43
    .line 44
    if-eqz p1, :cond_2

    .line 45
    .line 46
    invoke-virtual {p1}, La/W9;->cancel()V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    sget-object p1, La/cw;->ON_DESTROY:La/cw;

    .line 51
    .line 52
    if-ne p2, p1, :cond_2

    .line 53
    .line 54
    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->cancel()V

    .line 55
    .line 56
    .line 57
    :cond_2
    :goto_0
    return-void
.end method

.method public final cancel()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->X:La/GK;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, La/GK;->h(La/IQ;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->K:La/AJ;

    .line 7
    .line 8
    iget-object v0, v0, La/AJ;->h:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 9
    .line 10
    invoke-virtual {v0, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->R:La/W9;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0}, La/W9;->cancel()V

    .line 18
    .line 19
    .line 20
    :cond_0
    const/4 v0, 0x0

    .line 21
    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->R:La/W9;

    .line 22
    .line 23
    return-void
.end method
