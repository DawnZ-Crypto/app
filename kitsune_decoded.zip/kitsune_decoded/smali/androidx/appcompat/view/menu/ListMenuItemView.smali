.class public Landroidx/appcompat/view/menu/ListMenuItemView;
.super Landroid/widget/LinearLayout;
.source "SourceFile"

# interfaces
.implements La/ja;
.implements Landroid/widget/AbsListView$SelectionBoundsAdjuster;


# instance fields
.field public final D:Z

.field public final E:Landroid/graphics/drawable/Drawable;

.field public F:Landroid/widget/LinearLayout;

.field public final H:Landroid/content/Context;

.field public K:La/HN;

.field public L:Landroid/widget/RadioButton;

.field public final P:Landroid/graphics/drawable/Drawable;

.field public R:Landroid/widget/ImageView;

.field public final S:I

.field public U:Z

.field public W:Landroid/widget/ImageView;

.field public d:Landroid/widget/TextView;

.field public f:Landroid/widget/CheckBox;

.field public l:Landroid/widget/TextView;

.field public q:Landroid/widget/ImageView;

.field public u:Landroid/view/LayoutInflater;

.field public z:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sget-object v1, La/Zn;->d:[I

    .line 9
    .line 10
    const v2, 0x7f0402de

    .line 11
    .line 12
    .line 13
    invoke-static {v0, p2, v1, v2}, La/yW;->D(Landroid/content/Context;Landroid/util/AttributeSet;[II)La/yW;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    const/4 v0, 0x5

    .line 18
    invoke-virtual {p2, v0}, La/yW;->f(I)Landroid/graphics/drawable/Drawable;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Landroid/graphics/drawable/Drawable;

    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    const/4 v1, -0x1

    .line 26
    invoke-virtual {p2, v0, v1}, La/yW;->E(II)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iput v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->S:I

    .line 31
    .line 32
    const/4 v0, 0x7

    .line 33
    const/4 v1, 0x0

    .line 34
    invoke-virtual {p2, v0, v1}, La/yW;->K(IZ)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    iput-boolean v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->z:Z

    .line 39
    .line 40
    iput-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/content/Context;

    .line 41
    .line 42
    const/16 v0, 0x8

    .line 43
    .line 44
    invoke-virtual {p2, v0}, La/yW;->f(I)Landroid/graphics/drawable/Drawable;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->P:Landroid/graphics/drawable/Drawable;

    .line 49
    .line 50
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    const v0, 0x1010129

    .line 55
    .line 56
    .line 57
    filled-new-array {v0}, [I

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    const v2, 0x7f0401a8

    .line 62
    .line 63
    .line 64
    const/4 v3, 0x0

    .line 65
    invoke-virtual {p1, v3, v0, v2, v1}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    iput-boolean v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->D:Z

    .line 74
    .line 75
    invoke-virtual {p2}, La/yW;->Y()V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 79
    .line 80
    .line 81
    return-void
.end method


# virtual methods
.method public final adjustListItemSelectionBounds(Landroid/graphics/Rect;)V
    .locals 4

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->q:Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->q:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    iget v1, p1, Landroid/graphics/Rect;->top:I

    iget-object v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->q:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v2

    iget v3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v2, v3

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v2, v0

    add-int/2addr v2, v1

    iput v2, p1, Landroid/graphics/Rect;->top:I

    :cond_0
    return-void
.end method

.method public final onFinishInflate()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/widget/LinearLayout;->onFinishInflate()V

    .line 2
    .line 3
    .line 4
    sget-object v0, La/sI;->w:Ljava/util/WeakHashMap;

    .line 5
    .line 6
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->E:Landroid/graphics/drawable/Drawable;

    .line 7
    .line 8
    invoke-static {p0, v0}, La/Tl;->L(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    .line 9
    .line 10
    .line 11
    const v0, 0x7f09026b

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Landroid/widget/TextView;

    .line 19
    .line 20
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 21
    .line 22
    const/4 v1, -0x1

    .line 23
    iget v2, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->S:I

    .line 24
    .line 25
    if-eq v2, v1, :cond_0

    .line 26
    .line 27
    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->H:Landroid/content/Context;

    .line 28
    .line 29
    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V

    .line 30
    .line 31
    .line 32
    :cond_0
    const v0, 0x7f090215

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    check-cast v0, Landroid/widget/TextView;

    .line 40
    .line 41
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->l:Landroid/widget/TextView;

    .line 42
    .line 43
    const v0, 0x7f09023b

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Landroid/widget/ImageView;

    .line 51
    .line 52
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->W:Landroid/widget/ImageView;

    .line 53
    .line 54
    if-eqz v0, :cond_1

    .line 55
    .line 56
    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->P:Landroid/graphics/drawable/Drawable;

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 59
    .line 60
    .line 61
    :cond_1
    const v0, 0x7f090101

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    check-cast v0, Landroid/widget/ImageView;

    .line 69
    .line 70
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->q:Landroid/widget/ImageView;

    .line 71
    .line 72
    const v0, 0x7f090099

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Landroid/widget/LinearLayout;

    .line 80
    .line 81
    iput-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/LinearLayout;

    .line 82
    .line 83
    return-void
.end method

.method public final onMeasure(II)V
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->z:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iget-object v1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    iget v0, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v0, :cond_0

    iget v2, v1, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-gtz v2, :cond_0

    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->width:I

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    return-void
.end method

.method public final p()La/HN;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    return-object v0
.end method

.method public final w(La/HN;)V
    .locals 12

    .line 1
    iput-object p1, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 2
    .line 3
    invoke-virtual {p1}, La/HN;->isVisible()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x8

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    move v0, v2

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move v0, v1

    .line 15
    :goto_0
    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p1, La/HN;->i:Ljava/lang/CharSequence;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 23
    .line 24
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2

    .line 34
    .line 35
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 36
    .line 37
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 38
    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_1
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 42
    .line 43
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eq v0, v1, :cond_2

    .line 48
    .line 49
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->d:Landroid/widget/TextView;

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 52
    .line 53
    .line 54
    :cond_2
    :goto_1
    invoke-virtual {p1}, La/HN;->isCheckable()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    const/4 v3, 0x4

    .line 59
    const/4 v4, 0x1

    .line 60
    if-nez v0, :cond_3

    .line 61
    .line 62
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 63
    .line 64
    if-nez v5, :cond_3

    .line 65
    .line 66
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 67
    .line 68
    if-nez v5, :cond_3

    .line 69
    .line 70
    goto/16 :goto_6

    .line 71
    .line 72
    :cond_3
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 73
    .line 74
    iget v5, v5, La/HN;->E:I

    .line 75
    .line 76
    and-int/2addr v5, v3

    .line 77
    if-eqz v5, :cond_4

    .line 78
    .line 79
    move v5, v4

    .line 80
    goto :goto_2

    .line 81
    :cond_4
    move v5, v2

    .line 82
    :goto_2
    const/4 v6, -0x1

    .line 83
    if-eqz v5, :cond_8

    .line 84
    .line 85
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 86
    .line 87
    if-nez v5, :cond_7

    .line 88
    .line 89
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 90
    .line 91
    if-nez v5, :cond_5

    .line 92
    .line 93
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 94
    .line 95
    .line 96
    move-result-object v5

    .line 97
    invoke-static {v5}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    iput-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 102
    .line 103
    :cond_5
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 104
    .line 105
    const v7, 0x7f0c0011

    .line 106
    .line 107
    .line 108
    invoke-virtual {v5, v7, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 109
    .line 110
    .line 111
    move-result-object v5

    .line 112
    check-cast v5, Landroid/widget/RadioButton;

    .line 113
    .line 114
    iput-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 115
    .line 116
    iget-object v7, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/LinearLayout;

    .line 117
    .line 118
    if-eqz v7, :cond_6

    .line 119
    .line 120
    invoke-virtual {v7, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 121
    .line 122
    .line 123
    goto :goto_3

    .line 124
    :cond_6
    invoke-virtual {p0, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 125
    .line 126
    .line 127
    :cond_7
    :goto_3
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 128
    .line 129
    iget-object v6, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 130
    .line 131
    goto :goto_5

    .line 132
    :cond_8
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 133
    .line 134
    if-nez v5, :cond_b

    .line 135
    .line 136
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 137
    .line 138
    if-nez v5, :cond_9

    .line 139
    .line 140
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    invoke-static {v5}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 145
    .line 146
    .line 147
    move-result-object v5

    .line 148
    iput-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 149
    .line 150
    :cond_9
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 151
    .line 152
    const v7, 0x7f0c000e

    .line 153
    .line 154
    .line 155
    invoke-virtual {v5, v7, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 156
    .line 157
    .line 158
    move-result-object v5

    .line 159
    check-cast v5, Landroid/widget/CheckBox;

    .line 160
    .line 161
    iput-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 162
    .line 163
    iget-object v7, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/LinearLayout;

    .line 164
    .line 165
    if-eqz v7, :cond_a

    .line 166
    .line 167
    invoke-virtual {v7, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 168
    .line 169
    .line 170
    goto :goto_4

    .line 171
    :cond_a
    invoke-virtual {p0, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 172
    .line 173
    .line 174
    :cond_b
    :goto_4
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 175
    .line 176
    iget-object v6, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 177
    .line 178
    :goto_5
    if-eqz v0, :cond_d

    .line 179
    .line 180
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 181
    .line 182
    invoke-virtual {v0}, La/HN;->isChecked()Z

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    invoke-virtual {v5, v0}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 190
    .line 191
    .line 192
    move-result v0

    .line 193
    if-eqz v0, :cond_c

    .line 194
    .line 195
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 196
    .line 197
    .line 198
    :cond_c
    if-eqz v6, :cond_f

    .line 199
    .line 200
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    .line 201
    .line 202
    .line 203
    move-result v0

    .line 204
    if-eq v0, v1, :cond_f

    .line 205
    .line 206
    invoke-virtual {v6, v1}, Landroid/view/View;->setVisibility(I)V

    .line 207
    .line 208
    .line 209
    goto :goto_6

    .line 210
    :cond_d
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->f:Landroid/widget/CheckBox;

    .line 211
    .line 212
    if-eqz v0, :cond_e

    .line 213
    .line 214
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 215
    .line 216
    .line 217
    :cond_e
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->L:Landroid/widget/RadioButton;

    .line 218
    .line 219
    if-eqz v0, :cond_f

    .line 220
    .line 221
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 222
    .line 223
    .line 224
    :cond_f
    :goto_6
    iget-object v0, p1, La/HN;->y:La/pY;

    .line 225
    .line 226
    invoke-virtual {v0}, La/pY;->K()Z

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    if-eqz v0, :cond_11

    .line 231
    .line 232
    iget-object v0, p1, La/HN;->y:La/pY;

    .line 233
    .line 234
    invoke-virtual {v0}, La/pY;->y()Z

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    if-eqz v0, :cond_10

    .line 239
    .line 240
    iget-char v0, p1, La/HN;->I:C

    .line 241
    .line 242
    goto :goto_7

    .line 243
    :cond_10
    iget-char v0, p1, La/HN;->O:C

    .line 244
    .line 245
    :goto_7
    if-eqz v0, :cond_11

    .line 246
    .line 247
    move v0, v4

    .line 248
    goto :goto_8

    .line 249
    :cond_11
    move v0, v2

    .line 250
    :goto_8
    iget-object v5, p1, La/HN;->y:La/pY;

    .line 251
    .line 252
    invoke-virtual {v5}, La/pY;->y()Z

    .line 253
    .line 254
    .line 255
    if-eqz v0, :cond_13

    .line 256
    .line 257
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 258
    .line 259
    iget-object v5, v0, La/HN;->y:La/pY;

    .line 260
    .line 261
    invoke-virtual {v5}, La/pY;->K()Z

    .line 262
    .line 263
    .line 264
    move-result v5

    .line 265
    if-eqz v5, :cond_13

    .line 266
    .line 267
    iget-object v5, v0, La/HN;->y:La/pY;

    .line 268
    .line 269
    invoke-virtual {v5}, La/pY;->y()Z

    .line 270
    .line 271
    .line 272
    move-result v5

    .line 273
    if-eqz v5, :cond_12

    .line 274
    .line 275
    iget-char v0, v0, La/HN;->I:C

    .line 276
    .line 277
    goto :goto_9

    .line 278
    :cond_12
    iget-char v0, v0, La/HN;->O:C

    .line 279
    .line 280
    :goto_9
    if-eqz v0, :cond_13

    .line 281
    .line 282
    move v0, v2

    .line 283
    goto :goto_a

    .line 284
    :cond_13
    move v0, v1

    .line 285
    :goto_a
    if-nez v0, :cond_1b

    .line 286
    .line 287
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->l:Landroid/widget/TextView;

    .line 288
    .line 289
    iget-object v6, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 290
    .line 291
    iget-object v7, v6, La/HN;->y:La/pY;

    .line 292
    .line 293
    invoke-virtual {v7}, La/pY;->y()Z

    .line 294
    .line 295
    .line 296
    move-result v7

    .line 297
    if-eqz v7, :cond_14

    .line 298
    .line 299
    iget-char v7, v6, La/HN;->I:C

    .line 300
    .line 301
    goto :goto_b

    .line 302
    :cond_14
    iget-char v7, v6, La/HN;->O:C

    .line 303
    .line 304
    :goto_b
    if-nez v7, :cond_15

    .line 305
    .line 306
    const-string v3, ""

    .line 307
    .line 308
    goto/16 :goto_f

    .line 309
    .line 310
    :cond_15
    iget-object v8, v6, La/HN;->y:La/pY;

    .line 311
    .line 312
    iget-object v9, v8, La/pY;->w:Landroid/content/Context;

    .line 313
    .line 314
    invoke-virtual {v9}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 315
    .line 316
    .line 317
    move-result-object v9

    .line 318
    new-instance v10, Ljava/lang/StringBuilder;

    .line 319
    .line 320
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 321
    .line 322
    .line 323
    iget-object v11, v8, La/pY;->w:Landroid/content/Context;

    .line 324
    .line 325
    invoke-static {v11}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 326
    .line 327
    .line 328
    move-result-object v11

    .line 329
    invoke-virtual {v11}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    .line 330
    .line 331
    .line 332
    move-result v11

    .line 333
    if-eqz v11, :cond_16

    .line 334
    .line 335
    const v11, 0x7f120011

    .line 336
    .line 337
    .line 338
    invoke-virtual {v9, v11}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v11

    .line 342
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    :cond_16
    invoke-virtual {v8}, La/pY;->y()Z

    .line 346
    .line 347
    .line 348
    move-result v8

    .line 349
    if-eqz v8, :cond_17

    .line 350
    .line 351
    iget v6, v6, La/HN;->M:I

    .line 352
    .line 353
    goto :goto_c

    .line 354
    :cond_17
    iget v6, v6, La/HN;->V:I

    .line 355
    .line 356
    :goto_c
    const v8, 0x7f12000d

    .line 357
    .line 358
    .line 359
    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v8

    .line 363
    const/high16 v11, 0x10000

    .line 364
    .line 365
    invoke-static {v10, v6, v11, v8}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 366
    .line 367
    .line 368
    const v8, 0x7f120009

    .line 369
    .line 370
    .line 371
    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v8

    .line 375
    const/16 v11, 0x1000

    .line 376
    .line 377
    invoke-static {v10, v6, v11, v8}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 378
    .line 379
    .line 380
    const v8, 0x7f120008

    .line 381
    .line 382
    .line 383
    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object v8

    .line 387
    const/4 v11, 0x2

    .line 388
    invoke-static {v10, v6, v11, v8}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 389
    .line 390
    .line 391
    const v8, 0x7f12000e

    .line 392
    .line 393
    .line 394
    invoke-virtual {v9, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v8

    .line 398
    invoke-static {v10, v6, v4, v8}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 399
    .line 400
    .line 401
    const v4, 0x7f120010

    .line 402
    .line 403
    .line 404
    invoke-virtual {v9, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v4

    .line 408
    invoke-static {v10, v6, v3, v4}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 409
    .line 410
    .line 411
    const v3, 0x7f12000c

    .line 412
    .line 413
    .line 414
    invoke-virtual {v9, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v3

    .line 418
    invoke-static {v10, v6, v1, v3}, La/HN;->p(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    .line 419
    .line 420
    .line 421
    if-eq v7, v1, :cond_1a

    .line 422
    .line 423
    const/16 v3, 0xa

    .line 424
    .line 425
    if-eq v7, v3, :cond_19

    .line 426
    .line 427
    const/16 v3, 0x20

    .line 428
    .line 429
    if-eq v7, v3, :cond_18

    .line 430
    .line 431
    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 432
    .line 433
    .line 434
    goto :goto_e

    .line 435
    :cond_18
    const v3, 0x7f12000f

    .line 436
    .line 437
    .line 438
    :goto_d
    invoke-virtual {v9, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 439
    .line 440
    .line 441
    move-result-object v3

    .line 442
    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 443
    .line 444
    .line 445
    goto :goto_e

    .line 446
    :cond_19
    const v3, 0x7f12000b

    .line 447
    .line 448
    .line 449
    goto :goto_d

    .line 450
    :cond_1a
    const v3, 0x7f12000a

    .line 451
    .line 452
    .line 453
    goto :goto_d

    .line 454
    :goto_e
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 455
    .line 456
    .line 457
    move-result-object v3

    .line 458
    :goto_f
    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 459
    .line 460
    .line 461
    :cond_1b
    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->l:Landroid/widget/TextView;

    .line 462
    .line 463
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 464
    .line 465
    .line 466
    move-result v3

    .line 467
    if-eq v3, v0, :cond_1c

    .line 468
    .line 469
    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->l:Landroid/widget/TextView;

    .line 470
    .line 471
    invoke-virtual {v3, v0}, Landroid/view/View;->setVisibility(I)V

    .line 472
    .line 473
    .line 474
    :cond_1c
    invoke-virtual {p1}, La/HN;->getIcon()Landroid/graphics/drawable/Drawable;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->K:La/HN;

    .line 479
    .line 480
    iget-object v3, v3, La/HN;->y:La/pY;

    .line 481
    .line 482
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 483
    .line 484
    .line 485
    iget-boolean v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->U:Z

    .line 486
    .line 487
    if-nez v3, :cond_1d

    .line 488
    .line 489
    iget-boolean v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->z:Z

    .line 490
    .line 491
    if-nez v4, :cond_1d

    .line 492
    .line 493
    goto :goto_13

    .line 494
    :cond_1d
    iget-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 495
    .line 496
    if-nez v4, :cond_1e

    .line 497
    .line 498
    if-nez v0, :cond_1e

    .line 499
    .line 500
    iget-boolean v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->z:Z

    .line 501
    .line 502
    if-nez v5, :cond_1e

    .line 503
    .line 504
    goto :goto_13

    .line 505
    :cond_1e
    if-nez v4, :cond_21

    .line 506
    .line 507
    iget-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 508
    .line 509
    if-nez v4, :cond_1f

    .line 510
    .line 511
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 512
    .line 513
    .line 514
    move-result-object v4

    .line 515
    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 516
    .line 517
    .line 518
    move-result-object v4

    .line 519
    iput-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 520
    .line 521
    :cond_1f
    iget-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->u:Landroid/view/LayoutInflater;

    .line 522
    .line 523
    const v5, 0x7f0c000f

    .line 524
    .line 525
    .line 526
    invoke-virtual {v4, v5, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 527
    .line 528
    .line 529
    move-result-object v4

    .line 530
    check-cast v4, Landroid/widget/ImageView;

    .line 531
    .line 532
    iput-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 533
    .line 534
    iget-object v5, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->F:Landroid/widget/LinearLayout;

    .line 535
    .line 536
    if-eqz v5, :cond_20

    .line 537
    .line 538
    invoke-virtual {v5, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 539
    .line 540
    .line 541
    goto :goto_10

    .line 542
    :cond_20
    invoke-virtual {p0, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 543
    .line 544
    .line 545
    :cond_21
    :goto_10
    if-nez v0, :cond_23

    .line 546
    .line 547
    iget-boolean v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->z:Z

    .line 548
    .line 549
    if-eqz v4, :cond_22

    .line 550
    .line 551
    goto :goto_11

    .line 552
    :cond_22
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 553
    .line 554
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 555
    .line 556
    .line 557
    goto :goto_13

    .line 558
    :cond_23
    :goto_11
    iget-object v4, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 559
    .line 560
    if-eqz v3, :cond_24

    .line 561
    .line 562
    goto :goto_12

    .line 563
    :cond_24
    const/4 v0, 0x0

    .line 564
    :goto_12
    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 565
    .line 566
    .line 567
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 568
    .line 569
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 570
    .line 571
    .line 572
    move-result v0

    .line 573
    if-eqz v0, :cond_25

    .line 574
    .line 575
    iget-object v0, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->R:Landroid/widget/ImageView;

    .line 576
    .line 577
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 578
    .line 579
    .line 580
    :cond_25
    :goto_13
    invoke-virtual {p1}, La/HN;->isEnabled()Z

    .line 581
    .line 582
    .line 583
    move-result v0

    .line 584
    invoke-virtual {p0, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 585
    .line 586
    .line 587
    invoke-virtual {p1}, La/HN;->hasSubMenu()Z

    .line 588
    .line 589
    .line 590
    move-result v0

    .line 591
    iget-object v3, p0, Landroidx/appcompat/view/menu/ListMenuItemView;->W:Landroid/widget/ImageView;

    .line 592
    .line 593
    if-eqz v3, :cond_27

    .line 594
    .line 595
    if-eqz v0, :cond_26

    .line 596
    .line 597
    move v1, v2

    .line 598
    :cond_26
    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 599
    .line 600
    .line 601
    :cond_27
    iget-object p1, p1, La/HN;->L:Ljava/lang/CharSequence;

    .line 602
    .line 603
    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 604
    .line 605
    .line 606
    return-void
.end method
