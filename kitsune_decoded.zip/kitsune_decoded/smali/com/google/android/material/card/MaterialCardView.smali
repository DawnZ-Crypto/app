.class public Lcom/google/android/material/card/MaterialCardView;
.super La/dl;
.source "SourceFile"

# interfaces
.implements Landroid/widget/Checkable;
.implements La/Io;


# static fields
.field public static final E:[I

.field public static final S:[I


# instance fields
.field public F:Z

.field public final W:La/K0;

.field public final q:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const v0, 0x101009f

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/card/MaterialCardView;->E:[I

    const v0, 0x10100a0

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/google/android/material/card/MaterialCardView;->S:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 12

    .line 1
    const v3, 0x7f04030a

    .line 2
    .line 3
    .line 4
    const v0, 0x7f13043b

    .line 5
    .line 6
    .line 7
    invoke-static {p1, p2, v3, v0}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {p0, p1, p2}, La/dl;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 12
    .line 13
    .line 14
    const/4 p1, 0x0

    .line 15
    iput-boolean p1, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    .line 16
    .line 17
    const/4 v6, 0x1

    .line 18
    iput-boolean v6, p0, Lcom/google/android/material/card/MaterialCardView;->q:Z

    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sget-object v2, La/tS;->W:[I

    .line 25
    .line 26
    const v4, 0x7f13043b

    .line 27
    .line 28
    .line 29
    new-array v5, p1, [I

    .line 30
    .line 31
    move-object v1, p2

    .line 32
    invoke-static/range {v0 .. v5}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    new-instance v1, La/K0;

    .line 37
    .line 38
    invoke-direct {v1, p0, p2}, La/K0;-><init>(Lcom/google/android/material/card/MaterialCardView;Landroid/util/AttributeSet;)V

    .line 39
    .line 40
    .line 41
    iput-object v1, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 42
    .line 43
    iget-object p2, p0, La/dl;->f:La/dh;

    .line 44
    .line 45
    iget-object p2, p2, La/dh;->K:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p2, Landroid/graphics/drawable/Drawable;

    .line 48
    .line 49
    check-cast p2, La/pS;

    .line 50
    .line 51
    iget-object p2, p2, La/pS;->O:Landroid/content/res/ColorStateList;

    .line 52
    .line 53
    iget-object v2, v1, La/K0;->p:La/ex;

    .line 54
    .line 55
    invoke-virtual {v2, p2}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 56
    .line 57
    .line 58
    iget-object p2, p0, La/dl;->L:Landroid/graphics/Rect;

    .line 59
    .line 60
    iget v3, p2, Landroid/graphics/Rect;->left:I

    .line 61
    .line 62
    iget v4, p2, Landroid/graphics/Rect;->top:I

    .line 63
    .line 64
    iget v5, p2, Landroid/graphics/Rect;->right:I

    .line 65
    .line 66
    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    .line 67
    .line 68
    iget-object v7, v1, La/K0;->h:Landroid/graphics/Rect;

    .line 69
    .line 70
    invoke-virtual {v7, v3, v4, v5, p2}, Landroid/graphics/Rect;->set(IIII)V

    .line 71
    .line 72
    .line 73
    iget-object p2, v1, La/K0;->w:Lcom/google/android/material/card/MaterialCardView;

    .line 74
    .line 75
    iget-boolean v3, p2, La/dl;->R:Z

    .line 76
    .line 77
    const/4 v4, 0x0

    .line 78
    if-eqz v3, :cond_0

    .line 79
    .line 80
    invoke-virtual {v2}, La/ex;->m()Z

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    if-nez v3, :cond_0

    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_0
    invoke-virtual {v1}, La/K0;->X()Z

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    if-eqz v3, :cond_1

    .line 92
    .line 93
    :goto_0
    invoke-virtual {v1}, La/K0;->w()F

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    goto :goto_1

    .line 98
    :cond_1
    move v3, v4

    .line 99
    :goto_1
    iget-object v5, p2, La/dl;->f:La/dh;

    .line 100
    .line 101
    iget-boolean v8, p2, La/dl;->R:Z

    .line 102
    .line 103
    if-eqz v8, :cond_2

    .line 104
    .line 105
    iget-boolean v8, p2, La/dl;->K:Z

    .line 106
    .line 107
    if-eqz v8, :cond_2

    .line 108
    .line 109
    const-wide/high16 v8, 0x3ff0000000000000L    # 1.0

    .line 110
    .line 111
    sget-wide v10, La/K0;->S:D

    .line 112
    .line 113
    sub-double/2addr v8, v10

    .line 114
    iget-object v4, v5, La/dh;->K:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v4, Landroid/graphics/drawable/Drawable;

    .line 117
    .line 118
    check-cast v4, La/pS;

    .line 119
    .line 120
    iget v4, v4, La/pS;->w:F

    .line 121
    .line 122
    float-to-double v10, v4

    .line 123
    mul-double/2addr v8, v10

    .line 124
    double-to-float v4, v8

    .line 125
    :cond_2
    sub-float/2addr v3, v4

    .line 126
    float-to-int v3, v3

    .line 127
    iget v4, v7, Landroid/graphics/Rect;->left:I

    .line 128
    .line 129
    add-int/2addr v4, v3

    .line 130
    iget v8, v7, Landroid/graphics/Rect;->top:I

    .line 131
    .line 132
    add-int/2addr v8, v3

    .line 133
    iget v9, v7, Landroid/graphics/Rect;->right:I

    .line 134
    .line 135
    add-int/2addr v9, v3

    .line 136
    iget v7, v7, Landroid/graphics/Rect;->bottom:I

    .line 137
    .line 138
    add-int/2addr v7, v3

    .line 139
    iget-object v3, p2, La/dl;->L:Landroid/graphics/Rect;

    .line 140
    .line 141
    invoke-virtual {v3, v4, v8, v9, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 142
    .line 143
    .line 144
    iget-object v3, v5, La/dh;->R:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v3, La/dl;

    .line 147
    .line 148
    iget-boolean v3, v3, La/dl;->K:Z

    .line 149
    .line 150
    if-nez v3, :cond_3

    .line 151
    .line 152
    invoke-virtual {v5, p1, p1, p1, p1}, La/dh;->D(IIII)V

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_3
    iget-object v3, v5, La/dh;->K:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast v3, Landroid/graphics/drawable/Drawable;

    .line 159
    .line 160
    check-cast v3, La/pS;

    .line 161
    .line 162
    iget v4, v3, La/pS;->i:F

    .line 163
    .line 164
    invoke-virtual {v5}, La/dh;->F()Z

    .line 165
    .line 166
    .line 167
    move-result v7

    .line 168
    iget v3, v3, La/pS;->w:F

    .line 169
    .line 170
    invoke-static {v4, v3, v7}, La/f4;->w(FFZ)F

    .line 171
    .line 172
    .line 173
    move-result v7

    .line 174
    float-to-double v7, v7

    .line 175
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 176
    .line 177
    .line 178
    move-result-wide v7

    .line 179
    double-to-int v7, v7

    .line 180
    invoke-virtual {v5}, La/dh;->F()Z

    .line 181
    .line 182
    .line 183
    move-result v8

    .line 184
    invoke-static {v4, v3, v8}, La/f4;->h(FFZ)F

    .line 185
    .line 186
    .line 187
    move-result v3

    .line 188
    float-to-double v3, v3

    .line 189
    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    .line 190
    .line 191
    .line 192
    move-result-wide v3

    .line 193
    double-to-int v3, v3

    .line 194
    invoke-virtual {v5, v7, v3, v7, v3}, La/dh;->D(IIII)V

    .line 195
    .line 196
    .line 197
    :goto_2
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 198
    .line 199
    .line 200
    move-result-object v3

    .line 201
    const/16 v4, 0xb

    .line 202
    .line 203
    invoke-static {v3, v0, v4}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 204
    .line 205
    .line 206
    move-result-object v3

    .line 207
    iput-object v3, v1, La/K0;->y:Landroid/content/res/ColorStateList;

    .line 208
    .line 209
    if-nez v3, :cond_4

    .line 210
    .line 211
    const/4 v3, -0x1

    .line 212
    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 213
    .line 214
    .line 215
    move-result-object v3

    .line 216
    iput-object v3, v1, La/K0;->y:Landroid/content/res/ColorStateList;

    .line 217
    .line 218
    :cond_4
    const/16 v3, 0xc

    .line 219
    .line 220
    invoke-virtual {v0, v3, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    iput v3, v1, La/K0;->O:I

    .line 225
    .line 226
    invoke-virtual {v0, p1, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 227
    .line 228
    .line 229
    move-result v3

    .line 230
    iput-boolean v3, v1, La/K0;->f:Z

    .line 231
    .line 232
    invoke-virtual {p2, v3}, Landroid/view/View;->setLongClickable(Z)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    const/4 v4, 0x6

    .line 240
    invoke-static {v3, v0, v4}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 241
    .line 242
    .line 243
    move-result-object v3

    .line 244
    iput-object v3, v1, La/K0;->T:Landroid/content/res/ColorStateList;

    .line 245
    .line 246
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 247
    .line 248
    .line 249
    move-result-object v3

    .line 250
    const/4 v4, 0x2

    .line 251
    invoke-static {v3, v0, v4}, La/rx;->t(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    .line 252
    .line 253
    .line 254
    move-result-object v3

    .line 255
    if-eqz v3, :cond_5

    .line 256
    .line 257
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 258
    .line 259
    .line 260
    move-result-object v3

    .line 261
    iput-object v3, v1, La/K0;->I:Landroid/graphics/drawable/Drawable;

    .line 262
    .line 263
    iget-object v4, v1, La/K0;->T:Landroid/content/res/ColorStateList;

    .line 264
    .line 265
    invoke-static {v3, v4}, La/YU;->O(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {p2}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    invoke-virtual {v1, v3, p1}, La/K0;->i(ZZ)V

    .line 273
    .line 274
    .line 275
    goto :goto_3

    .line 276
    :cond_5
    sget-object v3, La/K0;->H:Landroid/graphics/drawable/ColorDrawable;

    .line 277
    .line 278
    iput-object v3, v1, La/K0;->I:Landroid/graphics/drawable/Drawable;

    .line 279
    .line 280
    :goto_3
    iget-object v3, v1, La/K0;->R:Landroid/graphics/drawable/LayerDrawable;

    .line 281
    .line 282
    if-eqz v3, :cond_6

    .line 283
    .line 284
    const v4, 0x7f090194

    .line 285
    .line 286
    .line 287
    iget-object v5, v1, La/K0;->I:Landroid/graphics/drawable/Drawable;

    .line 288
    .line 289
    invoke-virtual {v3, v4, v5}, Landroid/graphics/drawable/LayerDrawable;->setDrawableByLayerId(ILandroid/graphics/drawable/Drawable;)Z

    .line 290
    .line 291
    .line 292
    :cond_6
    const/4 v3, 0x5

    .line 293
    invoke-virtual {v0, v3, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    iput v3, v1, La/K0;->Q:I

    .line 298
    .line 299
    const/4 v3, 0x4

    .line 300
    invoke-virtual {v0, v3, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 301
    .line 302
    .line 303
    move-result v3

    .line 304
    iput v3, v1, La/K0;->i:I

    .line 305
    .line 306
    const/4 v3, 0x3

    .line 307
    const v4, 0x800035

    .line 308
    .line 309
    .line 310
    invoke-virtual {v0, v3, v4}, Landroid/content/res/TypedArray;->getInteger(II)I

    .line 311
    .line 312
    .line 313
    move-result v3

    .line 314
    iput v3, v1, La/K0;->X:I

    .line 315
    .line 316
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 317
    .line 318
    .line 319
    move-result-object v3

    .line 320
    const/4 v4, 0x7

    .line 321
    invoke-static {v3, v0, v4}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 322
    .line 323
    .line 324
    move-result-object v3

    .line 325
    iput-object v3, v1, La/K0;->M:Landroid/content/res/ColorStateList;

    .line 326
    .line 327
    if-nez v3, :cond_7

    .line 328
    .line 329
    const v3, 0x7f040101

    .line 330
    .line 331
    .line 332
    invoke-static {p2, v3}, La/rE;->o(Landroid/view/View;I)I

    .line 333
    .line 334
    .line 335
    move-result v3

    .line 336
    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 337
    .line 338
    .line 339
    move-result-object v3

    .line 340
    iput-object v3, v1, La/K0;->M:Landroid/content/res/ColorStateList;

    .line 341
    .line 342
    :cond_7
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 343
    .line 344
    .line 345
    move-result-object v3

    .line 346
    invoke-static {v3, v0, v6}, La/rx;->v(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    .line 347
    .line 348
    .line 349
    move-result-object v3

    .line 350
    if-nez v3, :cond_8

    .line 351
    .line 352
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 353
    .line 354
    .line 355
    move-result-object v3

    .line 356
    :cond_8
    iget-object p1, v1, La/K0;->e:La/ex;

    .line 357
    .line 358
    invoke-virtual {p1, v3}, La/ex;->K(Landroid/content/res/ColorStateList;)V

    .line 359
    .line 360
    .line 361
    sget-object v3, La/J3;->w:[I

    .line 362
    .line 363
    iget-object v3, v1, La/K0;->K:Landroid/graphics/drawable/RippleDrawable;

    .line 364
    .line 365
    if-eqz v3, :cond_9

    .line 366
    .line 367
    iget-object v4, v1, La/K0;->M:Landroid/content/res/ColorStateList;

    .line 368
    .line 369
    invoke-virtual {v3, v4}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    .line 370
    .line 371
    .line 372
    :cond_9
    iget-object v3, p2, La/dl;->f:La/dh;

    .line 373
    .line 374
    iget-object v3, v3, La/dh;->R:Ljava/lang/Object;

    .line 375
    .line 376
    check-cast v3, La/dl;

    .line 377
    .line 378
    invoke-virtual {v3}, Landroid/view/View;->getElevation()F

    .line 379
    .line 380
    .line 381
    move-result v3

    .line 382
    invoke-virtual {v2, v3}, La/ex;->y(F)V

    .line 383
    .line 384
    .line 385
    iget v3, v1, La/K0;->O:I

    .line 386
    .line 387
    int-to-float v3, v3

    .line 388
    iget-object v4, v1, La/K0;->y:Landroid/content/res/ColorStateList;

    .line 389
    .line 390
    iget-object v5, p1, La/ex;->X:La/JP;

    .line 391
    .line 392
    iput v3, v5, La/JP;->M:F

    .line 393
    .line 394
    invoke-virtual {p1}, La/ex;->invalidateSelf()V

    .line 395
    .line 396
    .line 397
    iget-object v3, p1, La/ex;->X:La/JP;

    .line 398
    .line 399
    iget-object v5, v3, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 400
    .line 401
    if-eq v5, v4, :cond_a

    .line 402
    .line 403
    iput-object v4, v3, La/JP;->e:Landroid/content/res/ColorStateList;

    .line 404
    .line 405
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 406
    .line 407
    .line 408
    move-result-object v3

    .line 409
    invoke-virtual {p1, v3}, La/ex;->onStateChange([I)Z

    .line 410
    .line 411
    .line 412
    :cond_a
    invoke-virtual {v1, v2}, La/K0;->e(Landroid/graphics/drawable/Drawable;)La/zA;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    invoke-super {p2, v2}, Landroid/widget/FrameLayout;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v1}, La/K0;->O()Z

    .line 420
    .line 421
    .line 422
    move-result v2

    .line 423
    if-eqz v2, :cond_b

    .line 424
    .line 425
    invoke-virtual {v1}, La/K0;->p()Landroid/graphics/drawable/LayerDrawable;

    .line 426
    .line 427
    .line 428
    move-result-object p1

    .line 429
    :cond_b
    iput-object p1, v1, La/K0;->V:Landroid/graphics/drawable/Drawable;

    .line 430
    .line 431
    invoke-virtual {v1, p1}, La/K0;->e(Landroid/graphics/drawable/Drawable;)La/zA;

    .line 432
    .line 433
    .line 434
    move-result-object p1

    .line 435
    invoke-virtual {p2, p1}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 436
    .line 437
    .line 438
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 439
    .line 440
    .line 441
    return-void
.end method


# virtual methods
.method public final h(La/c9;)V
    .locals 3

    .line 1
    new-instance v0, Landroid/graphics/RectF;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 7
    .line 8
    iget-object v2, v1, La/K0;->p:La/ex;

    .line 9
    .line 10
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v0, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1, v0}, La/c9;->i(Landroid/graphics/RectF;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p0, v0}, Landroid/view/View;->setClipToOutline(Z)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1, p1}, La/K0;->Q(La/c9;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final isChecked()Z
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    return v0
.end method

.method public final onAttachedToWindow()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 5
    .line 6
    invoke-virtual {v0}, La/K0;->V()V

    .line 7
    .line 8
    .line 9
    iget-object v0, v0, La/K0;->p:La/ex;

    .line 10
    .line 11
    invoke-static {p0, v0}, La/rx;->GI(Landroid/view/View;La/ex;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final onCreateDrawableState(I)[I
    .locals 1

    .line 1
    add-int/lit8 p1, p1, 0x3

    .line 2
    .line 3
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onCreateDrawableState(I)[I

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-boolean v0, v0, La/K0;->f:Z

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object v0, Lcom/google/android/material/card/MaterialCardView;->E:[I

    .line 16
    .line 17
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 18
    .line 19
    .line 20
    :cond_0
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    sget-object v0, Lcom/google/android/material/card/MaterialCardView;->S:[I

    .line 27
    .line 28
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 29
    .line 30
    .line 31
    :cond_1
    return-object p1
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    const-string v0, "androidx.cardview.widget.CardView"

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    const-string v0, "androidx.cardview.widget.CardView"

    .line 5
    .line 6
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-boolean v0, v0, La/K0;->f:Z

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x0

    .line 20
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->isChecked()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public final onMeasure(II)V
    .locals 18

    .line 1
    invoke-super/range {p0 .. p2}, La/dl;->onMeasure(II)V

    .line 2
    .line 3
    .line 4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    move-object/from16 v2, p0

    .line 13
    .line 14
    iget-object v3, v2, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 15
    .line 16
    iget-object v4, v3, La/K0;->R:Landroid/graphics/drawable/LayerDrawable;

    .line 17
    .line 18
    if-eqz v4, :cond_8

    .line 19
    .line 20
    iget-object v4, v3, La/K0;->w:Lcom/google/android/material/card/MaterialCardView;

    .line 21
    .line 22
    iget-boolean v5, v4, La/dl;->K:Z

    .line 23
    .line 24
    if-eqz v5, :cond_2

    .line 25
    .line 26
    iget-object v5, v4, La/dl;->f:La/dh;

    .line 27
    .line 28
    iget-object v5, v5, La/dh;->K:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v5, Landroid/graphics/drawable/Drawable;

    .line 31
    .line 32
    check-cast v5, La/pS;

    .line 33
    .line 34
    iget v5, v5, La/pS;->i:F

    .line 35
    .line 36
    const/high16 v6, 0x3fc00000    # 1.5f

    .line 37
    .line 38
    mul-float/2addr v5, v6

    .line 39
    invoke-virtual {v3}, La/K0;->X()Z

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    const/4 v7, 0x0

    .line 44
    if-eqz v6, :cond_0

    .line 45
    .line 46
    invoke-virtual {v3}, La/K0;->w()F

    .line 47
    .line 48
    .line 49
    move-result v6

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move v6, v7

    .line 52
    :goto_0
    add-float/2addr v5, v6

    .line 53
    const/high16 v6, 0x40000000    # 2.0f

    .line 54
    .line 55
    mul-float/2addr v5, v6

    .line 56
    float-to-double v8, v5

    .line 57
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 58
    .line 59
    .line 60
    move-result-wide v8

    .line 61
    double-to-int v5, v8

    .line 62
    iget-object v8, v4, La/dl;->f:La/dh;

    .line 63
    .line 64
    iget-object v8, v8, La/dh;->K:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v8, Landroid/graphics/drawable/Drawable;

    .line 67
    .line 68
    check-cast v8, La/pS;

    .line 69
    .line 70
    iget v8, v8, La/pS;->i:F

    .line 71
    .line 72
    invoke-virtual {v3}, La/K0;->X()Z

    .line 73
    .line 74
    .line 75
    move-result v9

    .line 76
    if-eqz v9, :cond_1

    .line 77
    .line 78
    invoke-virtual {v3}, La/K0;->w()F

    .line 79
    .line 80
    .line 81
    move-result v7

    .line 82
    :cond_1
    add-float/2addr v8, v7

    .line 83
    mul-float/2addr v8, v6

    .line 84
    float-to-double v6, v8

    .line 85
    invoke-static {v6, v7}, Ljava/lang/Math;->ceil(D)D

    .line 86
    .line 87
    .line 88
    move-result-wide v6

    .line 89
    double-to-int v6, v6

    .line 90
    goto :goto_1

    .line 91
    :cond_2
    const/4 v5, 0x0

    .line 92
    move v6, v5

    .line 93
    :goto_1
    iget v7, v3, La/K0;->X:I

    .line 94
    .line 95
    const v8, 0x800005

    .line 96
    .line 97
    .line 98
    and-int v9, v7, v8

    .line 99
    .line 100
    if-ne v9, v8, :cond_3

    .line 101
    .line 102
    iget v9, v3, La/K0;->i:I

    .line 103
    .line 104
    sub-int v9, v0, v9

    .line 105
    .line 106
    iget v10, v3, La/K0;->Q:I

    .line 107
    .line 108
    sub-int/2addr v9, v10

    .line 109
    sub-int/2addr v9, v6

    .line 110
    goto :goto_2

    .line 111
    :cond_3
    iget v9, v3, La/K0;->i:I

    .line 112
    .line 113
    :goto_2
    and-int/lit8 v10, v7, 0x50

    .line 114
    .line 115
    const/16 v11, 0x50

    .line 116
    .line 117
    if-ne v10, v11, :cond_4

    .line 118
    .line 119
    iget v10, v3, La/K0;->i:I

    .line 120
    .line 121
    :goto_3
    move/from16 v17, v10

    .line 122
    .line 123
    goto :goto_4

    .line 124
    :cond_4
    iget v10, v3, La/K0;->i:I

    .line 125
    .line 126
    sub-int v10, v1, v10

    .line 127
    .line 128
    iget v12, v3, La/K0;->Q:I

    .line 129
    .line 130
    sub-int/2addr v10, v12

    .line 131
    sub-int/2addr v10, v5

    .line 132
    goto :goto_3

    .line 133
    :goto_4
    and-int v10, v7, v8

    .line 134
    .line 135
    if-ne v10, v8, :cond_5

    .line 136
    .line 137
    iget v0, v3, La/K0;->i:I

    .line 138
    .line 139
    goto :goto_5

    .line 140
    :cond_5
    iget v8, v3, La/K0;->i:I

    .line 141
    .line 142
    sub-int/2addr v0, v8

    .line 143
    iget v8, v3, La/K0;->Q:I

    .line 144
    .line 145
    sub-int/2addr v0, v8

    .line 146
    sub-int/2addr v0, v6

    .line 147
    :goto_5
    and-int/lit8 v6, v7, 0x50

    .line 148
    .line 149
    if-ne v6, v11, :cond_6

    .line 150
    .line 151
    iget v6, v3, La/K0;->i:I

    .line 152
    .line 153
    sub-int/2addr v1, v6

    .line 154
    iget v6, v3, La/K0;->Q:I

    .line 155
    .line 156
    sub-int/2addr v1, v6

    .line 157
    sub-int/2addr v1, v5

    .line 158
    :goto_6
    move v15, v1

    .line 159
    goto :goto_7

    .line 160
    :cond_6
    iget v1, v3, La/K0;->i:I

    .line 161
    .line 162
    goto :goto_6

    .line 163
    :goto_7
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 164
    .line 165
    invoke-static {v4}, La/XC;->e(Landroid/view/View;)I

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    const/4 v4, 0x1

    .line 170
    if-ne v1, v4, :cond_7

    .line 171
    .line 172
    move v14, v0

    .line 173
    move/from16 v16, v9

    .line 174
    .line 175
    goto :goto_8

    .line 176
    :cond_7
    move/from16 v16, v0

    .line 177
    .line 178
    move v14, v9

    .line 179
    :goto_8
    iget-object v12, v3, La/K0;->R:Landroid/graphics/drawable/LayerDrawable;

    .line 180
    .line 181
    const/4 v13, 0x2

    .line 182
    invoke-virtual/range {v12 .. v17}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 183
    .line 184
    .line 185
    :cond_8
    return-void
.end method

.method public final setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    invoke-virtual {p0, p1}, Lcom/google/android/material/card/MaterialCardView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    .line 1
    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->q:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 6
    .line 7
    iget-boolean v1, v0, La/K0;->d:Z

    .line 8
    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    const-string v1, "MaterialCardView"

    .line 12
    .line 13
    const-string v2, "Setting a custom background is not supported."

    .line 14
    .line 15
    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 16
    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    iput-boolean v1, v0, La/K0;->d:Z

    .line 20
    .line 21
    :cond_0
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 22
    .line 23
    .line 24
    :cond_1
    return-void
.end method

.method public final setChecked(Z)V
    .locals 1

    iget-boolean v0, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    if-eq v0, p1, :cond_0

    invoke-virtual {p0}, Lcom/google/android/material/card/MaterialCardView;->toggle()V

    :cond_0
    return-void
.end method

.method public final setClickable(Z)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setClickable(Z)V

    iget-object p1, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, La/K0;->V()V

    :cond_0
    return-void
.end method

.method public final toggle()V
    .locals 9

    .line 1
    iget-object v0, p0, Lcom/google/android/material/card/MaterialCardView;->W:La/K0;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-boolean v1, v0, La/K0;->f:Z

    .line 6
    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_1

    .line 14
    .line 15
    iget-boolean v1, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    xor-int/2addr v1, v2

    .line 19
    iput-boolean v1, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 22
    .line 23
    .line 24
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 25
    .line 26
    const/16 v3, 0x1a

    .line 27
    .line 28
    if-le v1, v3, :cond_0

    .line 29
    .line 30
    iget-object v1, v0, La/K0;->K:Landroid/graphics/drawable/RippleDrawable;

    .line 31
    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iget v3, v1, Landroid/graphics/Rect;->bottom:I

    .line 39
    .line 40
    iget-object v4, v0, La/K0;->K:Landroid/graphics/drawable/RippleDrawable;

    .line 41
    .line 42
    iget v5, v1, Landroid/graphics/Rect;->left:I

    .line 43
    .line 44
    iget v6, v1, Landroid/graphics/Rect;->top:I

    .line 45
    .line 46
    iget v7, v1, Landroid/graphics/Rect;->right:I

    .line 47
    .line 48
    add-int/lit8 v8, v3, -0x1

    .line 49
    .line 50
    invoke-virtual {v4, v5, v6, v7, v8}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 51
    .line 52
    .line 53
    iget-object v4, v0, La/K0;->K:Landroid/graphics/drawable/RippleDrawable;

    .line 54
    .line 55
    iget v5, v1, Landroid/graphics/Rect;->left:I

    .line 56
    .line 57
    iget v6, v1, Landroid/graphics/Rect;->top:I

    .line 58
    .line 59
    iget v1, v1, Landroid/graphics/Rect;->right:I

    .line 60
    .line 61
    invoke-virtual {v4, v5, v6, v1, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 62
    .line 63
    .line 64
    :cond_0
    iget-boolean v1, p0, Lcom/google/android/material/card/MaterialCardView;->F:Z

    .line 65
    .line 66
    invoke-virtual {v0, v1, v2}, La/K0;->i(ZZ)V

    .line 67
    .line 68
    .line 69
    :cond_1
    return-void
.end method
