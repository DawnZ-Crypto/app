.class public interface abstract La/gX;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/ol;


# static fields
.field public static final synthetic I:I
