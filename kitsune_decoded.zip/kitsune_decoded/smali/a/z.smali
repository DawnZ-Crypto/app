.class public abstract La/z;
.super La/Y;
.source "SourceFile"

# interfaces
.implements La/P;


# static fields
.field public static final K:La/O;

.field public static final R:[B


# instance fields
.field public final X:[B


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, La/O;

    const/16 v1, 0xe

    const-class v2, La/z;

    const/4 v3, 0x4

    invoke-direct {v0, v3, v1, v2}, La/O;-><init>(IILjava/lang/Class;)V

    sput-object v0, La/z;->K:La/O;

    const/4 v0, 0x0

    new-array v0, v0, [B

    sput-object v0, La/z;->R:[B

    return-void
.end method

.method public constructor <init>([B)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    iput-object p1, p0, La/z;->X:[B

    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 10
    .line 11
    const-string v0, "\'string\' cannot be null"

    .line 12
    .line 13
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    throw p1
.end method

.method public static l(Ljava/lang/Object;)La/z;
    .locals 3

    .line 1
    if-eqz p0, :cond_3

    instance-of v0, p0, La/z;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    instance-of v0, p0, La/m;

    if-eqz v0, :cond_1

    move-object v0, p0

    check-cast v0, La/m;

    invoke-interface {v0}, La/m;->i()La/Y;

    move-result-object v0

    instance-of v1, v0, La/z;

    if-eqz v1, :cond_2

    check-cast v0, La/z;

    return-object v0

    :cond_1
    instance-of v0, p0, [B

    if-eqz v0, :cond_2

    :try_start_0
    sget-object v0, La/z;->K:La/O;

    check-cast p0, [B

    invoke-virtual {v0, p0}, La/iP;->Q([B)La/Y;

    move-result-object p0

    check-cast p0, La/z;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "failed to construct OCTET STRING from byte[]: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    :goto_0
    check-cast p0, La/z;

    return-object p0
.end method


# virtual methods
.method public final T(La/Y;)Z
    .locals 1

    .line 1
    instance-of v0, p1, La/z;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return p1

    .line 7
    :cond_0
    check-cast p1, La/z;

    .line 8
    .line 9
    iget-object p1, p1, La/z;->X:[B

    .line 10
    .line 11
    iget-object v0, p0, La/z;->X:[B

    .line 12
    .line 13
    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1
.end method

.method public d()La/Y;
    .locals 2

    .line 1
    new-instance v0, La/kV;

    .line 2
    .line 3
    iget-object v1, p0, La/z;->X:[B

    .line 4
    .line 5
    invoke-direct {v0, v1}, La/z;-><init>([B)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final e()Ljava/io/InputStream;
    .locals 2

    .line 1
    new-instance v0, Ljava/io/ByteArrayInputStream;

    iget-object v1, p0, La/z;->X:[B

    invoke-direct {v0, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    return-object v0
.end method

.method public f()La/Y;
    .locals 2

    .line 1
    new-instance v0, La/kV;

    .line 2
    .line 3
    iget-object v1, p0, La/z;->X:[B

    .line 4
    .line 5
    invoke-direct {v0, v1}, La/z;-><init>([B)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final h()La/Y;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, La/z;->X:[B

    invoke-static {v0}, La/rx;->Z([B)I

    move-result v0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    sget-object v0, La/gU;->w:La/RO;

    .line 2
    .line 3
    iget-object v0, p0, La/z;->X:[B

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    invoke-static {v0, v1}, La/gU;->w([BI)[B

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {v0}, La/mb;->w([B)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "#"

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method
