.class public final Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final X:[La/Tw;


# direct methods
.method public constructor <init>([La/Tw;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;->X:[La/Tw;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 2

    .line 1
    new-instance p1, La/r2;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, La/r2;-><init>(I)V

    iget-object p1, p0, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;->X:[La/Tw;

    array-length v0, p1

    const/4 v1, 0x0

    if-gtz v0, :cond_1

    array-length v0, p1

    if-gtz v0, :cond_0

    return-void

    :cond_0
    aget-object p1, p1, p2

    throw v1

    :cond_1
    aget-object p1, p1, p2

    throw v1
.end method
