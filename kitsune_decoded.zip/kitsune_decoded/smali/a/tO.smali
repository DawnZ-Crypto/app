.class public final La/tO;
.super La/eh;
.source "SourceFile"


# instance fields
.field public final synthetic w:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, La/tO;->w:I

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final p(La/At;Ljava/lang/Object;)V
    .locals 5

    .line 1
    iget v0, p0, La/tO;->w:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "Numeric values must be finite, but was "

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p2, Ljava/lang/Short;

    .line 10
    .line 11
    invoke-virtual {p2}, Ljava/lang/Short;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result p2

    .line 15
    int-to-long v0, p2

    .line 16
    invoke-virtual {p1, v0, v1}, La/At;->mh(J)La/AN;

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    check-cast p2, Ljava/lang/Long;

    .line 21
    .line 22
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    invoke-virtual {p1, v0, v1}, La/At;->mh(J)La/AN;

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_1
    check-cast p2, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    int-to-long v0, p2

    .line 37
    invoke-virtual {p1, v0, v1}, La/At;->mh(J)La/AN;

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_2
    check-cast p2, Ljava/lang/Float;

    .line 42
    .line 43
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    check-cast p1, La/AN;

    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    const-string v3, "-Infinity"

    .line 59
    .line 60
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    if-nez v3, :cond_1

    .line 65
    .line 66
    const-string v3, "Infinity"

    .line 67
    .line 68
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-nez v3, :cond_1

    .line 73
    .line 74
    const-string v3, "NaN"

    .line 75
    .line 76
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    if-nez v3, :cond_1

    .line 81
    .line 82
    iget-boolean p2, p1, La/At;->d:Z

    .line 83
    .line 84
    if-eqz p2, :cond_0

    .line 85
    .line 86
    iput-boolean v1, p1, La/At;->d:Z

    .line 87
    .line 88
    invoke-virtual {p1, v0}, La/AN;->f(Ljava/lang/String;)La/AN;

    .line 89
    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_0
    invoke-virtual {p1}, La/AN;->Pb()V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p1}, La/AN;->rZ()V

    .line 96
    .line 97
    .line 98
    iget-object p2, p1, La/AN;->l:La/cI;

    .line 99
    .line 100
    invoke-interface {p2, v0}, La/cI;->c(Ljava/lang/String;)La/cI;

    .line 101
    .line 102
    .line 103
    iget-object p2, p1, La/At;->L:[I

    .line 104
    .line 105
    iget p1, p1, La/At;->X:I

    .line 106
    .line 107
    add-int/lit8 p1, p1, -0x1

    .line 108
    .line 109
    aget v0, p2, p1

    .line 110
    .line 111
    add-int/lit8 v0, v0, 0x1

    .line 112
    .line 113
    aput v0, p2, p1

    .line 114
    .line 115
    :goto_0
    return-void

    .line 116
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 117
    .line 118
    new-instance v0, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p2

    .line 130
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    throw p1

    .line 134
    :pswitch_3
    check-cast p2, Ljava/lang/Double;

    .line 135
    .line 136
    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    .line 137
    .line 138
    .line 139
    move-result-wide v3

    .line 140
    check-cast p1, La/AN;

    .line 141
    .line 142
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    .line 144
    .line 145
    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    .line 146
    .line 147
    .line 148
    move-result p2

    .line 149
    if-nez p2, :cond_3

    .line 150
    .line 151
    invoke-static {v3, v4}, Ljava/lang/Double;->isInfinite(D)Z

    .line 152
    .line 153
    .line 154
    move-result p2

    .line 155
    if-nez p2, :cond_3

    .line 156
    .line 157
    iget-boolean p2, p1, La/At;->d:Z

    .line 158
    .line 159
    if-eqz p2, :cond_2

    .line 160
    .line 161
    iput-boolean v1, p1, La/At;->d:Z

    .line 162
    .line 163
    invoke-static {v3, v4}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p2

    .line 167
    invoke-virtual {p1, p2}, La/AN;->f(Ljava/lang/String;)La/AN;

    .line 168
    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_2
    invoke-virtual {p1}, La/AN;->Pb()V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p1}, La/AN;->rZ()V

    .line 175
    .line 176
    .line 177
    iget-object p2, p1, La/AN;->l:La/cI;

    .line 178
    .line 179
    invoke-static {v3, v4}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    invoke-interface {p2, v0}, La/cI;->c(Ljava/lang/String;)La/cI;

    .line 184
    .line 185
    .line 186
    iget-object p2, p1, La/At;->L:[I

    .line 187
    .line 188
    iget p1, p1, La/At;->X:I

    .line 189
    .line 190
    add-int/lit8 p1, p1, -0x1

    .line 191
    .line 192
    aget v0, p2, p1

    .line 193
    .line 194
    add-int/lit8 v0, v0, 0x1

    .line 195
    .line 196
    aput v0, p2, p1

    .line 197
    .line 198
    :goto_1
    return-void

    .line 199
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 200
    .line 201
    new-instance p2, Ljava/lang/StringBuilder;

    .line 202
    .line 203
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {p2, v3, v4}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 207
    .line 208
    .line 209
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object p2

    .line 213
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    throw p1

    .line 217
    :pswitch_4
    check-cast p2, Ljava/lang/Character;

    .line 218
    .line 219
    invoke-virtual {p2}, Ljava/lang/Character;->toString()Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object p2

    .line 223
    invoke-virtual {p1, p2}, La/At;->ZU(Ljava/lang/String;)La/AN;

    .line 224
    .line 225
    .line 226
    return-void

    .line 227
    :pswitch_5
    check-cast p2, Ljava/lang/Byte;

    .line 228
    .line 229
    invoke-virtual {p2}, Ljava/lang/Byte;->intValue()I

    .line 230
    .line 231
    .line 232
    move-result p2

    .line 233
    and-int/lit16 p2, p2, 0xff

    .line 234
    .line 235
    int-to-long v0, p2

    .line 236
    invoke-virtual {p1, v0, v1}, La/At;->mh(J)La/AN;

    .line 237
    .line 238
    .line 239
    return-void

    .line 240
    :pswitch_6
    check-cast p2, Ljava/lang/Boolean;

    .line 241
    .line 242
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 243
    .line 244
    .line 245
    move-result p2

    .line 246
    check-cast p1, La/AN;

    .line 247
    .line 248
    iget-boolean v0, p1, La/At;->d:Z

    .line 249
    .line 250
    if-nez v0, :cond_5

    .line 251
    .line 252
    invoke-virtual {p1}, La/AN;->Pb()V

    .line 253
    .line 254
    .line 255
    invoke-virtual {p1}, La/AN;->rZ()V

    .line 256
    .line 257
    .line 258
    if-eqz p2, :cond_4

    .line 259
    .line 260
    const-string p2, "true"

    .line 261
    .line 262
    goto :goto_2

    .line 263
    :cond_4
    const-string p2, "false"

    .line 264
    .line 265
    :goto_2
    iget-object v0, p1, La/AN;->l:La/cI;

    .line 266
    .line 267
    invoke-interface {v0, p2}, La/cI;->c(Ljava/lang/String;)La/cI;

    .line 268
    .line 269
    .line 270
    iget-object p2, p1, La/At;->L:[I

    .line 271
    .line 272
    iget p1, p1, La/At;->X:I

    .line 273
    .line 274
    add-int/lit8 p1, p1, -0x1

    .line 275
    .line 276
    aget v0, p2, p1

    .line 277
    .line 278
    add-int/lit8 v0, v0, 0x1

    .line 279
    .line 280
    aput v0, p2, p1

    .line 281
    .line 282
    return-void

    .line 283
    :cond_5
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 284
    .line 285
    new-instance v0, Ljava/lang/StringBuilder;

    .line 286
    .line 287
    const-string v1, "Boolean cannot be used as a map key in JSON at path "

    .line 288
    .line 289
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    invoke-virtual {p1}, La/At;->T()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 297
    .line 298
    .line 299
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object p1

    .line 303
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    throw p2

    .line 307
    :pswitch_7
    check-cast p2, Ljava/lang/String;

    .line 308
    .line 309
    invoke-virtual {p1, p2}, La/At;->ZU(Ljava/lang/String;)La/AN;

    .line 310
    .line 311
    .line 312
    return-void

    .line 313
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    iget v0, p0, La/tO;->w:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "JsonAdapter(Short)"

    return-object v0

    :pswitch_0
    const-string v0, "JsonAdapter(Long)"

    return-object v0

    :pswitch_1
    const-string v0, "JsonAdapter(Integer)"

    return-object v0

    :pswitch_2
    const-string v0, "JsonAdapter(Float)"

    return-object v0

    :pswitch_3
    const-string v0, "JsonAdapter(Double)"

    return-object v0

    :pswitch_4
    const-string v0, "JsonAdapter(Character)"

    return-object v0

    :pswitch_5
    const-string v0, "JsonAdapter(Byte)"

    return-object v0

    :pswitch_6
    const-string v0, "JsonAdapter(Boolean)"

    return-object v0

    :pswitch_7
    const-string v0, "JsonAdapter(String)"

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(La/SN;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, La/tO;->w:I

    .line 2
    .line 3
    const-string v1, " at path "

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    const/16 v0, -0x8000

    .line 11
    .line 12
    const/16 v1, 0x7fff

    .line 13
    .line 14
    const-string v2, "a short"

    .line 15
    .line 16
    invoke-static {p1, v2, v0, v1}, La/rx;->eH(La/SN;Ljava/lang/String;II)I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    int-to-short p1, p1

    .line 21
    invoke-static {p1}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    return-object p1

    .line 26
    :pswitch_0
    check-cast p1, La/bL;

    .line 27
    .line 28
    iget v0, p1, La/bL;->l:I

    .line 29
    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-virtual {p1}, La/bL;->Gy()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    :cond_0
    const/16 v4, 0x10

    .line 37
    .line 38
    if-ne v0, v4, :cond_1

    .line 39
    .line 40
    iput v3, p1, La/bL;->l:I

    .line 41
    .line 42
    iget-object v0, p1, La/SN;->L:[I

    .line 43
    .line 44
    iget v1, p1, La/SN;->X:I

    .line 45
    .line 46
    sub-int/2addr v1, v2

    .line 47
    aget v3, v0, v1

    .line 48
    .line 49
    add-int/2addr v3, v2

    .line 50
    aput v3, v0, v1

    .line 51
    .line 52
    iget-wide v0, p1, La/bL;->W:J

    .line 53
    .line 54
    goto/16 :goto_4

    .line 55
    .line 56
    :cond_1
    const/16 v4, 0x11

    .line 57
    .line 58
    const-string v5, "Expected a long but was "

    .line 59
    .line 60
    const/16 v6, 0xb

    .line 61
    .line 62
    if-ne v0, v4, :cond_2

    .line 63
    .line 64
    iget v0, p1, La/bL;->q:I

    .line 65
    .line 66
    int-to-long v7, v0

    .line 67
    iget-object v0, p1, La/bL;->f:La/WI;

    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    sget-object v4, La/kg;->w:Ljava/nio/charset/Charset;

    .line 73
    .line 74
    invoke-virtual {v0, v7, v8, v4}, La/WI;->lI(JLjava/nio/charset/Charset;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iput-object v0, p1, La/bL;->F:Ljava/lang/String;

    .line 79
    .line 80
    goto :goto_3

    .line 81
    :cond_2
    const/16 v4, 0x9

    .line 82
    .line 83
    if-eq v0, v4, :cond_5

    .line 84
    .line 85
    const/16 v7, 0x8

    .line 86
    .line 87
    if-ne v0, v7, :cond_3

    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_3
    if-ne v0, v6, :cond_4

    .line 91
    .line 92
    goto :goto_3

    .line 93
    :cond_4
    new-instance v0, La/P5;

    .line 94
    .line 95
    new-instance v2, Ljava/lang/StringBuilder;

    .line 96
    .line 97
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1}, La/bL;->B1()I

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    invoke-static {v3}, La/zq;->H(I)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {p1}, La/SN;->f()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    throw v0

    .line 129
    :cond_5
    :goto_0
    if-ne v0, v4, :cond_6

    .line 130
    .line 131
    sget-object v0, La/bL;->S:La/xi;

    .line 132
    .line 133
    :goto_1
    invoke-virtual {p1, v0}, La/bL;->yd(La/xi;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    goto :goto_2

    .line 138
    :cond_6
    sget-object v0, La/bL;->E:La/xi;

    .line 139
    .line 140
    goto :goto_1

    .line 141
    :goto_2
    iput-object v0, p1, La/bL;->F:Ljava/lang/String;

    .line 142
    .line 143
    :try_start_0
    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 144
    .line 145
    .line 146
    move-result-wide v7

    .line 147
    iput v3, p1, La/bL;->l:I

    .line 148
    .line 149
    iget-object v0, p1, La/SN;->L:[I

    .line 150
    .line 151
    iget v4, p1, La/SN;->X:I

    .line 152
    .line 153
    sub-int/2addr v4, v2

    .line 154
    aget v9, v0, v4

    .line 155
    .line 156
    add-int/2addr v9, v2

    .line 157
    aput v9, v0, v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 158
    .line 159
    move-wide v0, v7

    .line 160
    goto :goto_4

    .line 161
    :catch_0
    :goto_3
    iput v6, p1, La/bL;->l:I

    .line 162
    .line 163
    :try_start_1
    new-instance v0, Ljava/math/BigDecimal;

    .line 164
    .line 165
    iget-object v4, p1, La/bL;->F:Ljava/lang/String;

    .line 166
    .line 167
    invoke-direct {v0, v4}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0}, Ljava/math/BigDecimal;->longValueExact()J

    .line 171
    .line 172
    .line 173
    move-result-wide v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ArithmeticException; {:try_start_1 .. :try_end_1} :catch_1

    .line 174
    const/4 v4, 0x0

    .line 175
    iput-object v4, p1, La/bL;->F:Ljava/lang/String;

    .line 176
    .line 177
    iput v3, p1, La/bL;->l:I

    .line 178
    .line 179
    iget-object v3, p1, La/SN;->L:[I

    .line 180
    .line 181
    iget p1, p1, La/SN;->X:I

    .line 182
    .line 183
    sub-int/2addr p1, v2

    .line 184
    aget v4, v3, p1

    .line 185
    .line 186
    add-int/2addr v4, v2

    .line 187
    aput v4, v3, p1

    .line 188
    .line 189
    :goto_4
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    return-object p1

    .line 194
    :catch_1
    new-instance v0, La/P5;

    .line 195
    .line 196
    new-instance v2, Ljava/lang/StringBuilder;

    .line 197
    .line 198
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget-object v3, p1, La/bL;->F:Ljava/lang/String;

    .line 202
    .line 203
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 207
    .line 208
    .line 209
    invoke-virtual {p1}, La/SN;->f()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object p1

    .line 220
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    throw v0

    .line 224
    :pswitch_1
    invoke-virtual {p1}, La/SN;->mh()I

    .line 225
    .line 226
    .line 227
    move-result p1

    .line 228
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    return-object p1

    .line 233
    :pswitch_2
    invoke-virtual {p1}, La/SN;->x()D

    .line 234
    .line 235
    .line 236
    move-result-wide v2

    .line 237
    double-to-float v0, v2

    .line 238
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    .line 240
    .line 241
    invoke-static {v0}, Ljava/lang/Float;->isInfinite(F)Z

    .line 242
    .line 243
    .line 244
    move-result v2

    .line 245
    if-nez v2, :cond_7

    .line 246
    .line 247
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    return-object p1

    .line 252
    :cond_7
    new-instance v2, La/P5;

    .line 253
    .line 254
    new-instance v3, Ljava/lang/StringBuilder;

    .line 255
    .line 256
    const-string v4, "JSON forbids NaN and infinities: "

    .line 257
    .line 258
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 262
    .line 263
    .line 264
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {p1}, La/SN;->f()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 272
    .line 273
    .line 274
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    invoke-direct {v2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    throw v2

    .line 282
    :pswitch_3
    invoke-virtual {p1}, La/SN;->x()D

    .line 283
    .line 284
    .line 285
    move-result-wide v0

    .line 286
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 287
    .line 288
    .line 289
    move-result-object p1

    .line 290
    return-object p1

    .line 291
    :pswitch_4
    invoke-virtual {p1}, La/SN;->rZ()Ljava/lang/String;

    .line 292
    .line 293
    .line 294
    move-result-object v0

    .line 295
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 296
    .line 297
    .line 298
    move-result v1

    .line 299
    if-gt v1, v2, :cond_8

    .line 300
    .line 301
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    .line 302
    .line 303
    .line 304
    move-result p1

    .line 305
    invoke-static {p1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    return-object p1

    .line 310
    :cond_8
    new-instance v1, La/P5;

    .line 311
    .line 312
    const/4 v4, 0x3

    .line 313
    new-array v4, v4, [Ljava/lang/Object;

    .line 314
    .line 315
    const-string v5, "a char"

    .line 316
    .line 317
    aput-object v5, v4, v3

    .line 318
    .line 319
    new-instance v3, Ljava/lang/StringBuilder;

    .line 320
    .line 321
    const-string v5, "\""

    .line 322
    .line 323
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 327
    .line 328
    .line 329
    const/16 v0, 0x22

    .line 330
    .line 331
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 332
    .line 333
    .line 334
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v0

    .line 338
    aput-object v0, v4, v2

    .line 339
    .line 340
    const/4 v0, 0x2

    .line 341
    invoke-virtual {p1}, La/SN;->f()Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object p1

    .line 345
    aput-object p1, v4, v0

    .line 346
    .line 347
    const-string p1, "Expected %s but was %s at path %s"

    .line 348
    .line 349
    invoke-static {p1, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object p1

    .line 353
    invoke-direct {v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    throw v1

    .line 357
    :pswitch_5
    const/16 v0, -0x80

    .line 358
    .line 359
    const/16 v1, 0xff

    .line 360
    .line 361
    const-string v2, "a byte"

    .line 362
    .line 363
    invoke-static {p1, v2, v0, v1}, La/rx;->eH(La/SN;Ljava/lang/String;II)I

    .line 364
    .line 365
    .line 366
    move-result p1

    .line 367
    int-to-byte p1, p1

    .line 368
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 369
    .line 370
    .line 371
    move-result-object p1

    .line 372
    return-object p1

    .line 373
    :pswitch_6
    check-cast p1, La/bL;

    .line 374
    .line 375
    iget v0, p1, La/bL;->l:I

    .line 376
    .line 377
    if-nez v0, :cond_9

    .line 378
    .line 379
    invoke-virtual {p1}, La/bL;->Gy()I

    .line 380
    .line 381
    .line 382
    move-result v0

    .line 383
    :cond_9
    const/4 v4, 0x5

    .line 384
    if-ne v0, v4, :cond_a

    .line 385
    .line 386
    iput v3, p1, La/bL;->l:I

    .line 387
    .line 388
    iget-object v0, p1, La/SN;->L:[I

    .line 389
    .line 390
    iget p1, p1, La/SN;->X:I

    .line 391
    .line 392
    sub-int/2addr p1, v2

    .line 393
    aget v1, v0, p1

    .line 394
    .line 395
    add-int/2addr v1, v2

    .line 396
    aput v1, v0, p1

    .line 397
    .line 398
    goto :goto_5

    .line 399
    :cond_a
    const/4 v4, 0x6

    .line 400
    if-ne v0, v4, :cond_b

    .line 401
    .line 402
    iput v3, p1, La/bL;->l:I

    .line 403
    .line 404
    iget-object v0, p1, La/SN;->L:[I

    .line 405
    .line 406
    iget p1, p1, La/SN;->X:I

    .line 407
    .line 408
    sub-int/2addr p1, v2

    .line 409
    aget v1, v0, p1

    .line 410
    .line 411
    add-int/2addr v1, v2

    .line 412
    aput v1, v0, p1

    .line 413
    .line 414
    move v2, v3

    .line 415
    :goto_5
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 416
    .line 417
    .line 418
    move-result-object p1

    .line 419
    return-object p1

    .line 420
    :cond_b
    new-instance v0, La/P5;

    .line 421
    .line 422
    new-instance v2, Ljava/lang/StringBuilder;

    .line 423
    .line 424
    const-string v3, "Expected a boolean but was "

    .line 425
    .line 426
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 427
    .line 428
    .line 429
    invoke-virtual {p1}, La/bL;->B1()I

    .line 430
    .line 431
    .line 432
    move-result v3

    .line 433
    invoke-static {v3}, La/zq;->H(I)Ljava/lang/String;

    .line 434
    .line 435
    .line 436
    move-result-object v3

    .line 437
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 441
    .line 442
    .line 443
    invoke-virtual {p1}, La/SN;->f()Ljava/lang/String;

    .line 444
    .line 445
    .line 446
    move-result-object p1

    .line 447
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 448
    .line 449
    .line 450
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 451
    .line 452
    .line 453
    move-result-object p1

    .line 454
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 455
    .line 456
    .line 457
    throw v0

    .line 458
    :pswitch_7
    invoke-virtual {p1}, La/SN;->rZ()Ljava/lang/String;

    .line 459
    .line 460
    .line 461
    move-result-object p1

    .line 462
    return-object p1

    .line 463
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
