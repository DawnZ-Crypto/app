.class public final synthetic La/Ee;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic K:Ljava/lang/Object;

.field public final synthetic L:Ljava/lang/Object;

.field public final synthetic R:Ljava/lang/Object;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La/Ee;->X:I

    iput-object p2, p0, La/Ee;->K:Ljava/lang/Object;

    iput-object p3, p0, La/Ee;->R:Ljava/lang/Object;

    iput-object p4, p0, La/Ee;->L:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(La/lp;Landroid/view/View;La/HO;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    iput v0, p0, La/Ee;->X:I

    iput-object p1, p0, La/Ee;->L:Ljava/lang/Object;

    iput-object p2, p0, La/Ee;->K:Ljava/lang/Object;

    iput-object p3, p0, La/Ee;->R:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, La/Ee;->X:I

    .line 2
    .line 3
    iget-object v1, p0, La/Ee;->L:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, La/Ee;->R:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, La/Ee;->K:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast v3, La/eA;

    .line 13
    .line 14
    check-cast v2, La/GG;

    .line 15
    .line 16
    check-cast v1, Ljava/lang/Throwable;

    .line 17
    .line 18
    iget-object v0, v3, La/eA;->p:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-interface {v2, v1}, La/GG;->h(Ljava/lang/Throwable;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_0
    check-cast v3, La/eA;

    .line 25
    .line 26
    check-cast v2, La/GG;

    .line 27
    .line 28
    check-cast v1, La/NN;

    .line 29
    .line 30
    iget-object v0, v3, La/eA;->p:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, La/VG;

    .line 33
    .line 34
    iget-object v3, v0, La/VG;->K:La/JZ;

    .line 35
    .line 36
    invoke-interface {v3}, La/JZ;->f()Z

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    if-eqz v3, :cond_0

    .line 41
    .line 42
    new-instance v0, Ljava/io/IOException;

    .line 43
    .line 44
    const-string v1, "Canceled"

    .line 45
    .line 46
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-interface {v2, v0}, La/GG;->h(Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    invoke-interface {v2, v0, v1}, La/GG;->w(La/JZ;La/NN;)V

    .line 54
    .line 55
    .line 56
    :goto_0
    return-void

    .line 57
    :pswitch_1
    check-cast v3, La/iS;

    .line 58
    .line 59
    check-cast v2, Ljava/util/concurrent/Executor;

    .line 60
    .line 61
    check-cast v1, La/Le;

    .line 62
    .line 63
    sget-object v0, La/iS;->l:Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-virtual {v3}, La/iS;->lI()La/DF;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-eqz v1, :cond_2

    .line 70
    .line 71
    if-nez v2, :cond_1

    .line 72
    .line 73
    invoke-interface {v1, v0}, La/Le;->h(La/y4;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_1
    new-instance v3, La/lw;

    .line 78
    .line 79
    const/16 v4, 0xf

    .line 80
    .line 81
    invoke-direct {v3, v0, v4, v1}, La/lw;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 85
    .line 86
    .line 87
    :cond_2
    :goto_1
    return-void

    .line 88
    :pswitch_2
    check-cast v1, La/lp;

    .line 89
    .line 90
    check-cast v3, Landroid/view/View;

    .line 91
    .line 92
    check-cast v2, La/HO;

    .line 93
    .line 94
    iget-object v0, v1, La/lp;->w:Landroid/view/ViewGroup;

    .line 95
    .line 96
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v2}, La/iP;->p()V

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :pswitch_3
    check-cast v3, La/lF;

    .line 104
    .line 105
    check-cast v2, Landroid/view/View;

    .line 106
    .line 107
    check-cast v1, Landroid/graphics/Rect;

    .line 108
    .line 109
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    invoke-static {v2, v1}, La/lF;->X(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :pswitch_4
    check-cast v3, Ljava/util/List;

    .line 117
    .line 118
    check-cast v2, La/Ra;

    .line 119
    .line 120
    check-cast v1, La/lp;

    .line 121
    .line 122
    invoke-interface {v3, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_3

    .line 127
    .line 128
    invoke-interface {v3, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    iget-object v0, v2, La/Ra;->p:La/zr;

    .line 135
    .line 136
    iget-object v0, v0, La/zr;->B:Landroid/view/View;

    .line 137
    .line 138
    iget v1, v2, La/Ra;->w:I

    .line 139
    .line 140
    invoke-static {v1, v0}, La/zq;->w(ILandroid/view/View;)V

    .line 141
    .line 142
    .line 143
    :cond_3
    return-void

    .line 144
    nop

    .line 145
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
