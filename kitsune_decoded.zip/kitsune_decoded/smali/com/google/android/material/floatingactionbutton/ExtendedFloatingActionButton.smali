.class public Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
.super Lcom/google/android/material/button/MaterialButton;
.source "SourceFile"

# interfaces
.implements La/Mu;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;
    }
.end annotation


# static fields
.field public static final FL:La/LJ;

.field public static final G:La/LJ;

.field public static final Pc:La/LJ;

.field public static final rV:La/LJ;


# instance fields
.field public B:Z

.field public final C:La/Pf;

.field public J:I

.field public N:Landroid/content/res/ColorStateList;

.field public b:I

.field public c:Z

.field public g:I

.field public final j:La/JX;

.field public final n:La/Xz;

.field public o:I

.field public final r:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;

.field public s:I

.field public final t:La/JX;

.field public final x:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, La/LJ;

    const-class v1, Ljava/lang/Float;

    const-string v2, "width"

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, La/LJ;-><init>(Ljava/lang/Class;Ljava/lang/String;I)V

    sput-object v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->G:La/LJ;

    new-instance v0, La/LJ;

    const-string v2, "height"

    const/16 v3, 0x9

    invoke-direct {v0, v1, v2, v3}, La/LJ;-><init>(Ljava/lang/Class;Ljava/lang/String;I)V

    sput-object v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->Pc:La/LJ;

    new-instance v0, La/LJ;

    const-string v2, "paddingStart"

    const/16 v3, 0xa

    invoke-direct {v0, v1, v2, v3}, La/LJ;-><init>(Ljava/lang/Class;Ljava/lang/String;I)V

    sput-object v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->FL:La/LJ;

    new-instance v0, La/LJ;

    const-string v2, "paddingEnd"

    const/16 v3, 0xb

    invoke-direct {v0, v1, v2, v3}, La/LJ;-><init>(Ljava/lang/Class;Ljava/lang/String;I)V

    sput-object v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->rV:La/LJ;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p2

    .line 4
    .line 5
    const v8, 0x7f0401dc

    .line 6
    .line 7
    .line 8
    const v9, 0x7f13044b

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p1

    .line 12
    .line 13
    invoke-static {v1, v7, v8, v9}, La/rx;->xK(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1, v7, v8}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 18
    .line 19
    .line 20
    const/4 v10, 0x0

    .line 21
    iput v10, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->s:I

    .line 22
    .line 23
    new-instance v1, La/ze;

    .line 24
    .line 25
    const/16 v11, 0x19

    .line 26
    .line 27
    invoke-direct {v1, v11}, La/ze;-><init>(I)V

    .line 28
    .line 29
    .line 30
    new-instance v12, La/Xz;

    .line 31
    .line 32
    invoke-direct {v12, v0, v1}, La/Xz;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;)V

    .line 33
    .line 34
    .line 35
    iput-object v12, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->n:La/Xz;

    .line 36
    .line 37
    new-instance v13, La/Pf;

    .line 38
    .line 39
    invoke-direct {v13, v0, v1}, La/Pf;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;)V

    .line 40
    .line 41
    .line 42
    iput-object v13, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->C:La/Pf;

    .line 43
    .line 44
    const/4 v14, 0x1

    .line 45
    iput-boolean v14, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->c:Z

    .line 46
    .line 47
    iput-boolean v10, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->B:Z

    .line 48
    .line 49
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 50
    .line 51
    .line 52
    move-result-object v15

    .line 53
    new-instance v1, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;

    .line 54
    .line 55
    invoke-direct {v1, v15, v7}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 56
    .line 57
    .line 58
    iput-object v1, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->r:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;

    .line 59
    .line 60
    sget-object v3, La/tS;->M:[I

    .line 61
    .line 62
    const v5, 0x7f13044b

    .line 63
    .line 64
    .line 65
    new-array v6, v10, [I

    .line 66
    .line 67
    move-object v1, v15

    .line 68
    move-object/from16 v2, p2

    .line 69
    .line 70
    move v4, v8

    .line 71
    invoke-static/range {v1 .. v6}, La/fe;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    const/4 v2, 0x5

    .line 76
    invoke-static {v15, v1, v2}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    const/4 v3, 0x4

    .line 81
    invoke-static {v15, v1, v3}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    const/4 v4, 0x2

    .line 86
    invoke-static {v15, v1, v4}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    const/4 v6, 0x6

    .line 91
    invoke-static {v15, v1, v6}, La/tX;->w(Landroid/content/Context;Landroid/content/res/TypedArray;I)La/tX;

    .line 92
    .line 93
    .line 94
    move-result-object v6

    .line 95
    const/4 v8, -0x1

    .line 96
    invoke-virtual {v1, v10, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 97
    .line 98
    .line 99
    move-result v8

    .line 100
    iput v8, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->x:I

    .line 101
    .line 102
    const/4 v8, 0x3

    .line 103
    invoke-virtual {v1, v8, v14}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 104
    .line 105
    .line 106
    move-result v8

    .line 107
    invoke-static/range {p0 .. p0}, La/XC;->Q(Landroid/view/View;)I

    .line 108
    .line 109
    .line 110
    move-result v9

    .line 111
    iput v9, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->g:I

    .line 112
    .line 113
    invoke-static/range {p0 .. p0}, La/XC;->i(Landroid/view/View;)I

    .line 114
    .line 115
    .line 116
    move-result v9

    .line 117
    iput v9, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->o:I

    .line 118
    .line 119
    new-instance v9, La/ze;

    .line 120
    .line 121
    invoke-direct {v9, v11}, La/ze;-><init>(I)V

    .line 122
    .line 123
    .line 124
    new-instance v11, La/JX;

    .line 125
    .line 126
    new-instance v10, La/gD;

    .line 127
    .line 128
    invoke-direct {v10, v0, v14}, La/gD;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;I)V

    .line 129
    .line 130
    .line 131
    new-instance v4, La/dh;

    .line 132
    .line 133
    const/16 v14, 0xd

    .line 134
    .line 135
    invoke-direct {v4, v0, v10, v14}, La/dh;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 136
    .line 137
    .line 138
    new-instance v14, La/yW;

    .line 139
    .line 140
    const/16 v7, 0xa

    .line 141
    .line 142
    invoke-direct {v14, v7, v0, v4, v10}, La/yW;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    const/4 v7, 0x1

    .line 146
    if-eq v8, v7, :cond_1

    .line 147
    .line 148
    const/4 v7, 0x2

    .line 149
    if-eq v8, v7, :cond_0

    .line 150
    .line 151
    move-object v10, v14

    .line 152
    :goto_0
    const/4 v4, 0x1

    .line 153
    goto :goto_1

    .line 154
    :cond_0
    move-object v10, v4

    .line 155
    goto :goto_0

    .line 156
    :cond_1
    move v4, v7

    .line 157
    :goto_1
    invoke-direct {v11, v0, v9, v10, v4}, La/JX;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;La/jh;Z)V

    .line 158
    .line 159
    .line 160
    iput-object v11, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->t:La/JX;

    .line 161
    .line 162
    new-instance v4, La/JX;

    .line 163
    .line 164
    new-instance v7, La/gD;

    .line 165
    .line 166
    const/4 v8, 0x0

    .line 167
    invoke-direct {v7, v0, v8}, La/gD;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;I)V

    .line 168
    .line 169
    .line 170
    invoke-direct {v4, v0, v9, v7, v8}, La/JX;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;La/ze;La/jh;Z)V

    .line 171
    .line 172
    .line 173
    iput-object v4, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->j:La/JX;

    .line 174
    .line 175
    iput-object v2, v12, La/Cl;->Q:La/tX;

    .line 176
    .line 177
    iput-object v3, v13, La/Cl;->Q:La/tX;

    .line 178
    .line 179
    iput-object v5, v11, La/Cl;->Q:La/tX;

    .line 180
    .line 181
    iput-object v6, v4, La/Cl;->Q:La/tX;

    .line 182
    .line 183
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    .line 184
    .line 185
    .line 186
    sget-object v1, La/c9;->m:La/tw;

    .line 187
    .line 188
    move-object/from16 v2, p2

    .line 189
    .line 190
    const v3, 0x7f0401dc

    .line 191
    .line 192
    .line 193
    const v4, 0x7f13044b

    .line 194
    .line 195
    .line 196
    invoke-static {v15, v2, v3, v4, v1}, La/c9;->p(Landroid/content/Context;Landroid/util/AttributeSet;IILa/cv;)La/as;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-virtual {v1}, La/as;->w()La/c9;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->h(La/c9;)V

    .line 205
    .line 206
    .line 207
    invoke-virtual/range {p0 .. p0}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    iput-object v1, v0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->N:Landroid/content/res/ColorStateList;

    .line 212
    .line 213
    return-void
.end method


# virtual methods
.method public final K(Landroid/content/res/ColorStateList;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/Button;->setTextColor(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public final m()I
    .locals 2

    .line 1
    iget v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->x:I

    .line 2
    .line 3
    if-gez v0, :cond_0

    .line 4
    .line 5
    sget-object v0, La/sI;->w:Ljava/util/WeakHashMap;

    .line 6
    .line 7
    invoke-static {p0}, La/XC;->Q(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-static {p0}, La/XC;->i(Landroid/view/View;)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    mul-int/lit8 v0, v0, 0x2

    .line 20
    .line 21
    iget v1, p0, Lcom/google/android/material/button/MaterialButton;->S:I

    .line 22
    .line 23
    add-int/2addr v0, v1

    .line 24
    :cond_0
    return v0
.end method

.method public final onAttachedToWindow()V
    .locals 1

    .line 1
    invoke-super {p0}, Lcom/google/android/material/button/MaterialButton;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->c:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->F:Landroid/graphics/drawable/Drawable;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->c:Z

    .line 24
    .line 25
    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->j:La/JX;

    .line 26
    .line 27
    invoke-virtual {v0}, La/JX;->O()V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method public final setPadding(IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/Button;->setPadding(IIII)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->c:Z

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    iget-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->B:Z

    .line 9
    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    sget-object p1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 13
    .line 14
    invoke-static {p0}, La/XC;->Q(Landroid/view/View;)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    iput p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->g:I

    .line 19
    .line 20
    invoke-static {p0}, La/XC;->i(Landroid/view/View;)I

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    iput p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->o:I

    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final setPaddingRelative(IIII)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/Button;->setPaddingRelative(IIII)V

    iget-boolean p2, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->c:Z

    if-eqz p2, :cond_0

    iget-boolean p2, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->B:Z

    if-nez p2, :cond_0

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->g:I

    iput p3, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->o:I

    :cond_0
    return-void
.end method

.method public final setTextColor(I)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/Button;->setTextColor(I)V

    .line 1
    invoke-virtual {p0}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    move-result-object p1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->N:Landroid/content/res/ColorStateList;

    return-void
.end method

.method public final setTextColor(Landroid/content/res/ColorStateList;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/widget/Button;->setTextColor(Landroid/content/res/ColorStateList;)V

    .line 2
    invoke-virtual {p0}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    move-result-object p1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->N:Landroid/content/res/ColorStateList;

    return-void
.end method

.method public final w()La/AC;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->r:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$ExtendedFloatingActionButtonBehavior;

    return-object v0
.end method

.method public final y(I)V
    .locals 3

    .line 1
    const/4 v0, 0x2

    .line 2
    if-eqz p1, :cond_3

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eq p1, v1, :cond_2

    .line 6
    .line 7
    if-eq p1, v0, :cond_1

    .line 8
    .line 9
    const/4 v1, 0x3

    .line 10
    if-ne p1, v1, :cond_0

    .line 11
    .line 12
    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->t:La/JX;

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 16
    .line 17
    const-string v1, "Unknown strategy type: "

    .line 18
    .line 19
    invoke-static {v1, p1}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw v0

    .line 27
    :cond_1
    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->j:La/JX;

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_2
    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->C:La/Pf;

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_3
    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->n:La/Xz;

    .line 34
    .line 35
    :goto_0
    invoke-virtual {v1}, La/Cl;->V()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_4

    .line 40
    .line 41
    return-void

    .line 42
    :cond_4
    sget-object v2, La/sI;->w:Ljava/util/WeakHashMap;

    .line 43
    .line 44
    invoke-static {p0}, La/AM;->p(Landroid/view/View;)Z

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-nez v2, :cond_5

    .line 49
    .line 50
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    .line 51
    .line 52
    .line 53
    goto :goto_4

    .line 54
    :cond_5
    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-nez v2, :cond_9

    .line 59
    .line 60
    if-ne p1, v0, :cond_7

    .line 61
    .line 62
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    if-eqz p1, :cond_6

    .line 67
    .line 68
    iget v0, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 69
    .line 70
    iput v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->b:I

    .line 71
    .line 72
    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 73
    .line 74
    :goto_1
    iput p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->J:I

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_6
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    iput p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->b:I

    .line 82
    .line 83
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    goto :goto_1

    .line 88
    :cond_7
    :goto_2
    const/4 p1, 0x0

    .line 89
    invoke-virtual {p0, p1, p1}, Landroid/view/View;->measure(II)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1}, La/Cl;->w()Landroid/animation/AnimatorSet;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    new-instance v0, La/um;

    .line 97
    .line 98
    invoke-direct {v0, v1}, La/um;-><init>(La/Cl;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 102
    .line 103
    .line 104
    iget-object v0, v1, La/Cl;->p:Ljava/util/ArrayList;

    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    if-eqz v1, :cond_8

    .line 115
    .line 116
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    check-cast v1, Landroid/animation/Animator$AnimatorListener;

    .line 121
    .line 122
    invoke-virtual {p1, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 123
    .line 124
    .line 125
    goto :goto_3

    .line 126
    :cond_8
    invoke-virtual {p1}, Landroid/animation/Animator;->start()V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :cond_9
    :goto_4
    invoke-virtual {v1}, La/Cl;->O()V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v1}, La/Cl;->X()V

    .line 134
    .line 135
    .line 136
    return-void
.end method
