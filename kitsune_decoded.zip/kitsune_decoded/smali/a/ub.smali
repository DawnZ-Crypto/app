.class public final La/ub;
.super La/c;
.source "SourceFile"


# instance fields
.field public h:Ljava/lang/String;

.field public final p:Ljava/lang/StringBuilder;

.field public final w:La/Vr;


# direct methods
.method public constructor <init>(CII)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/Vr;

    .line 5
    .line 6
    invoke-direct {v0}, La/QW;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La/ub;->w:La/Vr;

    .line 10
    .line 11
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v1, p0, La/ub;->p:Ljava/lang/StringBuilder;

    .line 17
    .line 18
    iput-char p1, v0, La/Vr;->Q:C

    .line 19
    .line 20
    iput p2, v0, La/Vr;->X:I

    .line 21
    .line 22
    iput p3, v0, La/Vr;->O:I

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final X(La/dW;)La/d6;
    .locals 6

    .line 1
    check-cast p1, La/Nl;

    .line 2
    .line 3
    iget v0, p1, La/Nl;->i:I

    .line 4
    .line 5
    iget v1, p1, La/Nl;->h:I

    .line 6
    .line 7
    iget-object v2, p1, La/Nl;->w:Ljava/lang/CharSequence;

    .line 8
    .line 9
    iget p1, p1, La/Nl;->X:I

    .line 10
    .line 11
    const/4 v3, 0x4

    .line 12
    iget-object v4, p0, La/ub;->w:La/Vr;

    .line 13
    .line 14
    if-ge p1, v3, :cond_1

    .line 15
    .line 16
    iget-char p1, v4, La/Vr;->Q:C

    .line 17
    .line 18
    iget v3, v4, La/Vr;->X:I

    .line 19
    .line 20
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    invoke-static {p1, v2, v0, v5}, La/fe;->FL(CLjava/lang/CharSequence;II)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    sub-int/2addr p1, v0

    .line 29
    if-ge p1, v3, :cond_0

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    add-int/2addr v0, p1

    .line 33
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    invoke-static {v2, v0, p1}, La/fe;->rC(Ljava/lang/CharSequence;II)I

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-ne p1, v0, :cond_1

    .line 46
    .line 47
    new-instance p1, La/d6;

    .line 48
    .line 49
    const/4 v0, -0x1

    .line 50
    const/4 v1, 0x1

    .line 51
    invoke-direct {p1, v0, v0, v1}, La/d6;-><init>(IIZ)V

    .line 52
    .line 53
    .line 54
    return-object p1

    .line 55
    :cond_1
    :goto_0
    iget p1, v4, La/Vr;->O:I

    .line 56
    .line 57
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    :goto_1
    if-lez p1, :cond_2

    .line 62
    .line 63
    if-ge v1, v0, :cond_2

    .line 64
    .line 65
    invoke-interface {v2, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 66
    .line 67
    .line 68
    move-result v3

    .line 69
    const/16 v4, 0x20

    .line 70
    .line 71
    if-ne v3, v4, :cond_2

    .line 72
    .line 73
    add-int/lit8 v1, v1, 0x1

    .line 74
    .line 75
    add-int/lit8 p1, p1, -0x1

    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_2
    invoke-static {v1}, La/d6;->w(I)La/d6;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    return-object p1
.end method

.method public final e()La/qB;
    .locals 1

    .line 1
    iget-object v0, p0, La/ub;->w:La/Vr;

    return-object v0
.end method

.method public final p()V
    .locals 2

    .line 1
    iget-object v0, p0, La/ub;->h:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, La/M1;->w(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v1, p0, La/ub;->w:La/Vr;

    .line 12
    .line 13
    iput-object v0, v1, La/Vr;->V:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v0, p0, La/ub;->p:Ljava/lang/StringBuilder;

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, v1, La/Vr;->I:Ljava/lang/String;

    .line 22
    .line 23
    return-void
.end method

.method public final w(Ljava/lang/CharSequence;)V
    .locals 1

    .line 1
    iget-object v0, p0, La/ub;->h:Ljava/lang/String;

    if-nez v0, :cond_0

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La/ub;->h:Ljava/lang/String;

    goto :goto_0

    :cond_0
    iget-object v0, p0, La/ub;->p:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    const/16 p1, 0xa

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_0
    return-void
.end method
