.class public final La/oE;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic K:Ljava/lang/Object;

.field public final synthetic X:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, La/oE;->X:I

    .line 5
    .line 6
    iput-object p2, p0, La/oE;->K:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method private h()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v0, Landroidx/databinding/w;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput-boolean v1, v0, Landroidx/databinding/w;->R:Z

    .line 8
    .line 9
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    :cond_0
    :goto_0
    sget-object v0, Landroidx/databinding/w;->s:Ljava/lang/ref/ReferenceQueue;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    instance-of v1, v0, La/Cj;

    .line 19
    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    check-cast v0, La/Cj;

    .line 23
    .line 24
    invoke-virtual {v0}, La/Cj;->w()Z

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, Landroidx/databinding/w;

    .line 31
    .line 32
    iget-object v0, v0, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 33
    .line 34
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_2

    .line 39
    .line 40
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v0, Landroidx/databinding/w;

    .line 43
    .line 44
    iget-object v0, v0, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 45
    .line 46
    sget-object v1, Landroidx/databinding/w;->j:La/wX;

    .line 47
    .line 48
    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v0, Landroidx/databinding/w;

    .line 54
    .line 55
    iget-object v0, v0, Landroidx/databinding/w;->f:Landroid/view/View;

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_2
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v0, Landroidx/databinding/w;

    .line 64
    .line 65
    invoke-virtual {v0}, Landroidx/databinding/w;->V()V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :catchall_0
    move-exception v0

    .line 70
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 71
    throw v0
.end method

.method private p()V
    .locals 4

    .line 1
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/h;

    iget-object v0, v0, Landroidx/lifecycle/h;->w:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La/oE;->K:Ljava/lang/Object;

    check-cast v1, Landroidx/lifecycle/h;

    iget-object v1, v1, Landroidx/lifecycle/h;->Q:Ljava/lang/Object;

    iget-object v2, p0, La/oE;->K:Ljava/lang/Object;

    check-cast v2, Landroidx/lifecycle/h;

    sget-object v3, Landroidx/lifecycle/h;->M:Ljava/lang/Object;

    iput-object v3, v2, Landroidx/lifecycle/h;->Q:Ljava/lang/Object;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    check-cast v0, Landroidx/lifecycle/h;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/h;->I(Ljava/lang/Object;)V

    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method


# virtual methods
.method public final run()V
    .locals 15

    .line 1
    iget v0, p0, La/oE;->X:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, La/Zh;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    invoke-static {}, La/uv;->w()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    const-string v1, "pm uninstall "

    .line 24
    .line 25
    invoke-static {v1, v0}, La/zq;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    filled-new-array {v0}, [Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, La/Id;->w([Ljava/lang/String;)La/x6;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v0}, La/x6;->f()La/y4;

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_0
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Lcom/google/android/material/textfield/TextInputLayout;

    .line 44
    .line 45
    iget-object v0, v0, Lcom/google/android/material/textfield/TextInputLayout;->L:La/h9;

    .line 46
    .line 47
    iget-object v0, v0, La/h9;->l:Lcom/google/android/material/internal/CheckableImageButton;

    .line 48
    .line 49
    invoke-virtual {v0}, Landroid/view/View;->performClick()Z

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :pswitch_1
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, La/Dt;

    .line 59
    .line 60
    iput-boolean v2, v0, La/Dt;->p:Z

    .line 61
    .line 62
    iget-object v1, v0, La/Dt;->i:La/AC;

    .line 63
    .line 64
    check-cast v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    .line 65
    .line 66
    iget-object v1, v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:La/w1;

    .line 67
    .line 68
    if-eqz v1, :cond_0

    .line 69
    .line 70
    invoke-virtual {v1}, La/w1;->Q()Z

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    if-eqz v1, :cond_0

    .line 75
    .line 76
    iget v1, v0, La/Dt;->h:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, La/Dt;->w(I)V

    .line 79
    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_0
    iget-object v1, v0, La/Dt;->i:La/AC;

    .line 83
    .line 84
    check-cast v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    .line 85
    .line 86
    iget v2, v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n:I

    .line 87
    .line 88
    const/4 v3, 0x2

    .line 89
    if-ne v2, v3, :cond_1

    .line 90
    .line 91
    iget v0, v0, La/Dt;->h:I

    .line 92
    .line 93
    invoke-virtual {v1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(I)V

    .line 94
    .line 95
    .line 96
    :cond_1
    :goto_0
    return-void

    .line 97
    :pswitch_2
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, La/u3;

    .line 100
    .line 101
    iget-object v0, v0, La/u3;->w:La/cO;

    .line 102
    .line 103
    iget-object v0, v0, La/cO;->V:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 104
    .line 105
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 110
    .line 111
    .line 112
    :try_start_0
    iget-object v3, p0, La/oE;->K:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v3, La/u3;

    .line 115
    .line 116
    invoke-virtual {v3}, La/u3;->w()Z

    .line 117
    .line 118
    .line 119
    move-result v3
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 120
    if-nez v3, :cond_2

    .line 121
    .line 122
    :goto_1
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 123
    .line 124
    .line 125
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v0, La/u3;

    .line 128
    .line 129
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    goto/16 :goto_8

    .line 133
    .line 134
    :cond_2
    :try_start_1
    iget-object v3, p0, La/oE;->K:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v3, La/u3;

    .line 137
    .line 138
    iget-object v3, v3, La/u3;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 139
    .line 140
    invoke-virtual {v3, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 141
    .line 142
    .line 143
    move-result v2

    .line 144
    if-nez v2, :cond_3

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_3
    iget-object v2, p0, La/oE;->K:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast v2, La/u3;

    .line 150
    .line 151
    iget-object v2, v2, La/u3;->w:La/cO;

    .line 152
    .line 153
    invoke-virtual {v2}, La/cO;->Q()La/Af;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-interface {v2}, La/Af;->N()La/V1;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    invoke-interface {v2}, La/V1;->rC()Z

    .line 162
    .line 163
    .line 164
    move-result v2

    .line 165
    if-eqz v2, :cond_4

    .line 166
    .line 167
    goto :goto_1

    .line 168
    :cond_4
    iget-object v2, p0, La/oE;->K:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast v2, La/u3;

    .line 171
    .line 172
    iget-object v2, v2, La/u3;->w:La/cO;

    .line 173
    .line 174
    invoke-virtual {v2}, La/cO;->Q()La/Af;

    .line 175
    .line 176
    .line 177
    move-result-object v2

    .line 178
    invoke-interface {v2}, La/Af;->N()La/V1;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    invoke-interface {v2}, La/V1;->t()V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 183
    .line 184
    .line 185
    :try_start_2
    invoke-virtual {p0}, La/oE;->w()La/L0;

    .line 186
    .line 187
    .line 188
    move-result-object v3

    .line 189
    invoke-interface {v2}, La/V1;->P()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 190
    .line 191
    .line 192
    :try_start_3
    invoke-interface {v2}, La/V1;->O()V
    :try_end_3
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 193
    .line 194
    .line 195
    :goto_2
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 196
    .line 197
    .line 198
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v0, La/u3;

    .line 201
    .line 202
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 203
    .line 204
    .line 205
    goto :goto_5

    .line 206
    :catchall_0
    move-exception v1

    .line 207
    goto :goto_9

    .line 208
    :catch_0
    move-exception v2

    .line 209
    goto :goto_3

    .line 210
    :catch_1
    move-exception v2

    .line 211
    goto :goto_4

    .line 212
    :catchall_1
    move-exception v3

    .line 213
    :try_start_4
    invoke-interface {v2}, La/V1;->O()V

    .line 214
    .line 215
    .line 216
    throw v3
    :try_end_4
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 217
    :goto_3
    :try_start_5
    const-string v3, "ROOM"

    .line 218
    .line 219
    const-string v4, "Cannot run invalidation tracker. Is the db closed?"

    .line 220
    .line 221
    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 222
    .line 223
    .line 224
    sget-object v3, La/UK;->X:La/UK;

    .line 225
    .line 226
    goto :goto_2

    .line 227
    :goto_4
    const-string v3, "ROOM"

    .line 228
    .line 229
    const-string v4, "Cannot run invalidation tracker. Is the db closed?"

    .line 230
    .line 231
    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 232
    .line 233
    .line 234
    sget-object v3, La/UK;->X:La/UK;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 235
    .line 236
    goto :goto_2

    .line 237
    :goto_5
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 238
    .line 239
    .line 240
    move-result v0

    .line 241
    xor-int/2addr v0, v1

    .line 242
    if-eqz v0, :cond_6

    .line 243
    .line 244
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v0, La/u3;

    .line 247
    .line 248
    iget-object v1, v0, La/u3;->V:La/U6;

    .line 249
    .line 250
    monitor-enter v1

    .line 251
    :try_start_6
    iget-object v0, v0, La/u3;->V:La/U6;

    .line 252
    .line 253
    invoke-virtual {v0}, La/U6;->iterator()Ljava/util/Iterator;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    :goto_6
    move-object v2, v0

    .line 258
    check-cast v2, La/Tp;

    .line 259
    .line 260
    invoke-virtual {v2}, La/Tp;->hasNext()Z

    .line 261
    .line 262
    .line 263
    move-result v4

    .line 264
    if-eqz v4, :cond_5

    .line 265
    .line 266
    invoke-virtual {v2}, La/Tp;->next()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v2

    .line 270
    check-cast v2, Ljava/util/Map$Entry;

    .line 271
    .line 272
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v2

    .line 276
    check-cast v2, La/g9;

    .line 277
    .line 278
    invoke-virtual {v2, v3}, La/g9;->w(Ljava/util/Set;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 279
    .line 280
    .line 281
    goto :goto_6

    .line 282
    :catchall_2
    move-exception v0

    .line 283
    goto :goto_7

    .line 284
    :cond_5
    monitor-exit v1

    .line 285
    goto :goto_8

    .line 286
    :goto_7
    monitor-exit v1

    .line 287
    throw v0

    .line 288
    :cond_6
    :goto_8
    return-void

    .line 289
    :goto_9
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 290
    .line 291
    .line 292
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 293
    .line 294
    check-cast v0, La/u3;

    .line 295
    .line 296
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 297
    .line 298
    .line 299
    throw v1

    .line 300
    :pswitch_3
    invoke-direct {p0}, La/oE;->p()V

    .line 301
    .line 302
    .line 303
    return-void

    .line 304
    :pswitch_4
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 305
    .line 306
    check-cast v0, La/ef;

    .line 307
    .line 308
    invoke-virtual {v0, v1}, La/ef;->E(Z)Z

    .line 309
    .line 310
    .line 311
    return-void

    .line 312
    :pswitch_5
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 313
    .line 314
    check-cast v0, La/XM;

    .line 315
    .line 316
    iget-object v1, v0, La/XM;->Pb:La/wH;

    .line 317
    .line 318
    iget-object v0, v0, La/XM;->Qg:Landroid/app/Dialog;

    .line 319
    .line 320
    invoke-virtual {v1, v0}, La/wH;->onDismiss(Landroid/content/DialogInterface;)V

    .line 321
    .line 322
    .line 323
    return-void

    .line 324
    :pswitch_6
    invoke-direct {p0}, La/oE;->h()V

    .line 325
    .line 326
    .line 327
    return-void

    .line 328
    :pswitch_7
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 329
    .line 330
    check-cast v0, La/w1;

    .line 331
    .line 332
    invoke-virtual {v0, v2}, La/w1;->y(I)V

    .line 333
    .line 334
    .line 335
    return-void

    .line 336
    :pswitch_8
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 337
    .line 338
    check-cast v0, La/Bo;

    .line 339
    .line 340
    iget-boolean v1, v0, La/Bo;->P:Z

    .line 341
    .line 342
    if-nez v1, :cond_7

    .line 343
    .line 344
    goto/16 :goto_b

    .line 345
    .line 346
    :cond_7
    iget-boolean v1, v0, La/Bo;->H:Z

    .line 347
    .line 348
    if-eqz v1, :cond_8

    .line 349
    .line 350
    iput-boolean v2, v0, La/Bo;->H:Z

    .line 351
    .line 352
    iget-object v1, v0, La/Bo;->X:La/qs;

    .line 353
    .line 354
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 355
    .line 356
    .line 357
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 358
    .line 359
    .line 360
    move-result-wide v3

    .line 361
    iput-wide v3, v1, La/qs;->i:J

    .line 362
    .line 363
    const-wide/16 v5, -0x1

    .line 364
    .line 365
    iput-wide v5, v1, La/qs;->X:J

    .line 366
    .line 367
    iput-wide v3, v1, La/qs;->Q:J

    .line 368
    .line 369
    const/high16 v3, 0x3f000000    # 0.5f

    .line 370
    .line 371
    iput v3, v1, La/qs;->O:F

    .line 372
    .line 373
    :cond_8
    iget-object v1, v0, La/Bo;->X:La/qs;

    .line 374
    .line 375
    iget-wide v3, v1, La/qs;->X:J

    .line 376
    .line 377
    const-wide/16 v5, 0x0

    .line 378
    .line 379
    cmp-long v3, v3, v5

    .line 380
    .line 381
    if-lez v3, :cond_9

    .line 382
    .line 383
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 384
    .line 385
    .line 386
    move-result-wide v3

    .line 387
    iget-wide v7, v1, La/qs;->X:J

    .line 388
    .line 389
    iget v9, v1, La/qs;->V:I

    .line 390
    .line 391
    int-to-long v9, v9

    .line 392
    add-long/2addr v7, v9

    .line 393
    cmp-long v3, v3, v7

    .line 394
    .line 395
    if-lez v3, :cond_9

    .line 396
    .line 397
    goto :goto_a

    .line 398
    :cond_9
    invoke-virtual {v0}, La/Bo;->Q()Z

    .line 399
    .line 400
    .line 401
    move-result v3

    .line 402
    if-nez v3, :cond_a

    .line 403
    .line 404
    :goto_a
    iput-boolean v2, v0, La/Bo;->P:Z

    .line 405
    .line 406
    goto :goto_b

    .line 407
    :cond_a
    iget-boolean v3, v0, La/Bo;->z:Z

    .line 408
    .line 409
    if-eqz v3, :cond_b

    .line 410
    .line 411
    iput-boolean v2, v0, La/Bo;->z:Z

    .line 412
    .line 413
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 414
    .line 415
    .line 416
    move-result-wide v9

    .line 417
    const/4 v11, 0x3

    .line 418
    const/4 v12, 0x0

    .line 419
    const/4 v13, 0x0

    .line 420
    const/4 v14, 0x0

    .line 421
    move-wide v7, v9

    .line 422
    invoke-static/range {v7 .. v14}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 423
    .line 424
    .line 425
    move-result-object v2

    .line 426
    iget-object v3, v0, La/Bo;->R:Landroid/view/View;

    .line 427
    .line 428
    invoke-virtual {v3, v2}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 429
    .line 430
    .line 431
    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    .line 432
    .line 433
    .line 434
    :cond_b
    iget-wide v2, v1, La/qs;->Q:J

    .line 435
    .line 436
    cmp-long v2, v2, v5

    .line 437
    .line 438
    if-eqz v2, :cond_c

    .line 439
    .line 440
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 441
    .line 442
    .line 443
    move-result-wide v2

    .line 444
    invoke-virtual {v1, v2, v3}, La/qs;->w(J)F

    .line 445
    .line 446
    .line 447
    move-result v4

    .line 448
    const/high16 v5, -0x3f800000    # -4.0f

    .line 449
    .line 450
    mul-float/2addr v5, v4

    .line 451
    mul-float/2addr v5, v4

    .line 452
    const/high16 v6, 0x40800000    # 4.0f

    .line 453
    .line 454
    mul-float/2addr v4, v6

    .line 455
    add-float/2addr v4, v5

    .line 456
    iget-wide v5, v1, La/qs;->Q:J

    .line 457
    .line 458
    sub-long v5, v2, v5

    .line 459
    .line 460
    iput-wide v2, v1, La/qs;->Q:J

    .line 461
    .line 462
    long-to-float v2, v5

    .line 463
    mul-float/2addr v2, v4

    .line 464
    iget v1, v1, La/qs;->e:F

    .line 465
    .line 466
    mul-float/2addr v2, v1

    .line 467
    float-to-int v1, v2

    .line 468
    iget-object v2, v0, La/Bo;->Y:Landroid/widget/ListView;

    .line 469
    .line 470
    invoke-static {v2, v1}, La/qZ;->h(Landroid/widget/ListView;I)V

    .line 471
    .line 472
    .line 473
    iget-object v0, v0, La/Bo;->R:Landroid/view/View;

    .line 474
    .line 475
    sget-object v1, La/sI;->w:Ljava/util/WeakHashMap;

    .line 476
    .line 477
    invoke-static {v0, p0}, La/Tl;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 478
    .line 479
    .line 480
    :goto_b
    return-void

    .line 481
    :cond_c
    new-instance v0, Ljava/lang/RuntimeException;

    .line 482
    .line 483
    const-string v1, "Cannot compute scroll delta before calling start()"

    .line 484
    .line 485
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 486
    .line 487
    .line 488
    throw v0

    .line 489
    :pswitch_9
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 490
    .line 491
    check-cast v0, La/So;

    .line 492
    .line 493
    invoke-virtual {v0}, La/zr;->R()Landroid/content/Context;

    .line 494
    .line 495
    .line 496
    move-result-object v2

    .line 497
    if-nez v2, :cond_d

    .line 498
    .line 499
    const-string v0, "FingerprintFragment"

    .line 500
    .line 501
    const-string v1, "Not resetting the dialog. Context is null."

    .line 502
    .line 503
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 504
    .line 505
    .line 506
    goto :goto_c

    .line 507
    :cond_d
    iget-object v3, v0, La/So;->an:La/TO;

    .line 508
    .line 509
    invoke-virtual {v3, v1}, La/TO;->y(I)V

    .line 510
    .line 511
    .line 512
    iget-object v0, v0, La/So;->an:La/TO;

    .line 513
    .line 514
    const v1, 0x7f12004e

    .line 515
    .line 516
    .line 517
    invoke-virtual {v2, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object v1

    .line 521
    invoke-virtual {v0, v1}, La/TO;->m(Ljava/lang/CharSequence;)V

    .line 522
    .line 523
    .line 524
    :goto_c
    return-void

    .line 525
    :pswitch_a
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 526
    .line 527
    check-cast v0, La/Vw;

    .line 528
    .line 529
    invoke-virtual {v0, v1}, La/Vw;->w(Z)V

    .line 530
    .line 531
    .line 532
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 533
    .line 534
    .line 535
    return-void

    .line 536
    :pswitch_b
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 537
    .line 538
    check-cast v0, La/ug;

    .line 539
    .line 540
    iget-object v1, v0, La/ug;->R:Landroid/view/Window$Callback;

    .line 541
    .line 542
    invoke-virtual {v0}, La/ug;->r()La/pY;

    .line 543
    .line 544
    .line 545
    move-result-object v0

    .line 546
    instance-of v3, v0, La/pY;

    .line 547
    .line 548
    const/4 v4, 0x0

    .line 549
    if-eqz v3, :cond_e

    .line 550
    .line 551
    move-object v3, v0

    .line 552
    goto :goto_d

    .line 553
    :cond_e
    move-object v3, v4

    .line 554
    :goto_d
    if-eqz v3, :cond_f

    .line 555
    .line 556
    invoke-virtual {v3}, La/pY;->F()V

    .line 557
    .line 558
    .line 559
    :cond_f
    :try_start_7
    invoke-virtual {v0}, La/pY;->clear()V

    .line 560
    .line 561
    .line 562
    invoke-interface {v1, v2, v0}, Landroid/view/Window$Callback;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    .line 563
    .line 564
    .line 565
    move-result v5

    .line 566
    if-eqz v5, :cond_10

    .line 567
    .line 568
    invoke-interface {v1, v2, v4, v0}, Landroid/view/Window$Callback;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    .line 569
    .line 570
    .line 571
    move-result v1

    .line 572
    if-nez v1, :cond_11

    .line 573
    .line 574
    goto :goto_e

    .line 575
    :catchall_3
    move-exception v0

    .line 576
    goto :goto_f

    .line 577
    :cond_10
    :goto_e
    invoke-virtual {v0}, La/pY;->clear()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 578
    .line 579
    .line 580
    :cond_11
    if-eqz v3, :cond_12

    .line 581
    .line 582
    invoke-virtual {v3}, La/pY;->q()V

    .line 583
    .line 584
    .line 585
    :cond_12
    return-void

    .line 586
    :goto_f
    if-eqz v3, :cond_13

    .line 587
    .line 588
    invoke-virtual {v3}, La/pY;->q()V

    .line 589
    .line 590
    .line 591
    :cond_13
    throw v0

    .line 592
    :pswitch_c
    :try_start_8
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 593
    .line 594
    check-cast v0, Landroidx/activity/w;

    .line 595
    .line 596
    invoke-static {v0}, Landroidx/activity/w;->T(Landroidx/activity/w;)V
    :try_end_8
    .catch Ljava/lang/IllegalStateException; {:try_start_8 .. :try_end_8} :catch_3
    .catch Ljava/lang/NullPointerException; {:try_start_8 .. :try_end_8} :catch_2

    .line 597
    .line 598
    .line 599
    goto :goto_12

    .line 600
    :catch_2
    move-exception v0

    .line 601
    goto :goto_10

    .line 602
    :catch_3
    move-exception v0

    .line 603
    goto :goto_11

    .line 604
    :goto_10
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 605
    .line 606
    .line 607
    move-result-object v1

    .line 608
    const-string v2, "Attempt to invoke virtual method \'android.os.Handler android.app.FragmentHostCallback.getHandler()\' on a null object reference"

    .line 609
    .line 610
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 611
    .line 612
    .line 613
    move-result v1

    .line 614
    if-eqz v1, :cond_14

    .line 615
    .line 616
    goto :goto_12

    .line 617
    :cond_14
    throw v0

    .line 618
    :goto_11
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 619
    .line 620
    .line 621
    move-result-object v1

    .line 622
    const-string v2, "Can not perform this action after onSaveInstanceState"

    .line 623
    .line 624
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 625
    .line 626
    .line 627
    move-result v1

    .line 628
    if-eqz v1, :cond_15

    .line 629
    .line 630
    :goto_12
    return-void

    .line 631
    :cond_15
    throw v0

    .line 632
    nop

    .line 633
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w()La/L0;
    .locals 4

    .line 1
    iget-object v0, p0, La/oE;->K:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, La/u3;

    .line 4
    .line 5
    new-instance v1, La/L0;

    .line 6
    .line 7
    invoke-direct {v1}, La/L0;-><init>()V

    .line 8
    .line 9
    .line 10
    iget-object v0, v0, La/u3;->w:La/cO;

    .line 11
    .line 12
    new-instance v2, La/YV;

    .line 13
    .line 14
    const-string v3, "SELECT * FROM room_table_modification_log WHERE invalidated = 1;"

    .line 15
    .line 16
    invoke-direct {v2, v3}, La/YV;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, La/cO;->w()V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, La/cO;->Q()La/Af;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-interface {v3}, La/Af;->N()La/V1;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    invoke-interface {v3}, La/V1;->rC()Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-nez v3, :cond_1

    .line 35
    .line 36
    iget-object v3, v0, La/cO;->I:Ljava/lang/ThreadLocal;

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    if-nez v3, :cond_0

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    const-string v1, "Cannot access database on a different coroutine context inherited from a suspending transaction."

    .line 48
    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    throw v0

    .line 57
    :cond_1
    :goto_0
    invoke-virtual {v0}, La/cO;->Q()La/Af;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-interface {v0}, La/Af;->N()La/V1;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-interface {v0, v2}, La/V1;->G(La/pv;)Landroid/database/Cursor;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    :goto_1
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    if-eqz v2, :cond_2

    .line 74
    .line 75
    const/4 v2, 0x0

    .line 76
    invoke-interface {v0, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    invoke-virtual {v1, v2}, La/L0;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 85
    .line 86
    .line 87
    goto :goto_1

    .line 88
    :catchall_0
    move-exception v1

    .line 89
    goto :goto_3

    .line 90
    :cond_2
    const/4 v2, 0x0

    .line 91
    invoke-static {v0, v2}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 92
    .line 93
    .line 94
    invoke-static {v1}, La/rE;->I(La/L0;)La/L0;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    iget-object v1, v0, La/L0;->X:La/N1;

    .line 99
    .line 100
    invoke-virtual {v1}, La/N1;->isEmpty()Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    xor-int/lit8 v1, v1, 0x1

    .line 105
    .line 106
    if-eqz v1, :cond_5

    .line 107
    .line 108
    iget-object v1, p0, La/oE;->K:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, La/u3;

    .line 111
    .line 112
    iget-object v1, v1, La/u3;->X:La/Oq;

    .line 113
    .line 114
    const-string v2, "Required value was null."

    .line 115
    .line 116
    if-eqz v1, :cond_4

    .line 117
    .line 118
    iget-object v1, p0, La/oE;->K:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v1, La/u3;

    .line 121
    .line 122
    iget-object v1, v1, La/u3;->X:La/Oq;

    .line 123
    .line 124
    if-eqz v1, :cond_3

    .line 125
    .line 126
    invoke-interface {v1}, La/Oq;->k()I

    .line 127
    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 131
    .line 132
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    throw v0

    .line 140
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 141
    .line 142
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw v0

    .line 150
    :cond_5
    :goto_2
    return-object v0

    .line 151
    :goto_3
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 152
    :catchall_1
    move-exception v2

    .line 153
    invoke-static {v0, v1}, La/rE;->L(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 154
    .line 155
    .line 156
    throw v2
.end method
