.class public final La/Ns;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public h:J

.field public final w:La/wI;


# direct methods
.method public constructor <init>(La/wI;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/Ns;->w:La/wI;

    const-wide/32 v0, 0x40000

    iput-wide v0, p0, La/Ns;->h:J

    return-void
.end method
