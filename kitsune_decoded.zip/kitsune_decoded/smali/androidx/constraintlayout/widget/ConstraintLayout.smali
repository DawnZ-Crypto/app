.class public Landroidx/constraintlayout/widget/ConstraintLayout;
.super Landroid/view/ViewGroup;
.source "SourceFile"


# instance fields
.field public D:I

.field public E:La/O8;

.field public F:I

.field public H:Ljava/util/HashMap;

.field public final K:Landroid/util/SparseArray;

.field public final L:La/p3;

.field public final P:La/ka;

.field public final R:Ljava/util/ArrayList;

.field public S:I

.field public W:I

.field public d:I

.field public f:I

.field public l:I

.field public q:Z

.field public u:I

.field public final z:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    new-instance p1, La/p3;

    invoke-direct {p1}, La/p3;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    const/16 v0, 0x101

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->S:I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->H:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->z:Landroid/util/SparseArray;

    new-instance v0, La/ka;

    invoke-direct {v0, p0, p0}, La/ka;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->P:La/ka;

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->D:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->u:I

    invoke-virtual {p0, p2, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->V(Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1

    .line 2
    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    new-instance p1, La/p3;

    invoke-direct {p1}, La/p3;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    const/16 v0, 0x101

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->S:I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->H:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->z:Landroid/util/SparseArray;

    new-instance v0, La/ka;

    invoke-direct {v0, p0, p0}, La/ka;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->P:La/ka;

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->D:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->u:I

    invoke-virtual {p0, p2, p3}, Landroidx/constraintlayout/widget/ConstraintLayout;->V(Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public static X()La/rS;
    .locals 8

    .line 1
    new-instance v0, La/rS;

    .line 2
    .line 3
    const/4 v1, -0x2

    .line 4
    invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    .line 5
    .line 6
    .line 7
    const/4 v1, -0x1

    .line 8
    iput v1, v0, La/rS;->w:I

    .line 9
    .line 10
    iput v1, v0, La/rS;->h:I

    .line 11
    .line 12
    const/high16 v2, -0x40800000    # -1.0f

    .line 13
    .line 14
    iput v2, v0, La/rS;->p:F

    .line 15
    .line 16
    const/4 v3, 0x1

    .line 17
    iput-boolean v3, v0, La/rS;->e:Z

    .line 18
    .line 19
    iput v1, v0, La/rS;->i:I

    .line 20
    .line 21
    iput v1, v0, La/rS;->Q:I

    .line 22
    .line 23
    iput v1, v0, La/rS;->X:I

    .line 24
    .line 25
    iput v1, v0, La/rS;->O:I

    .line 26
    .line 27
    iput v1, v0, La/rS;->V:I

    .line 28
    .line 29
    iput v1, v0, La/rS;->I:I

    .line 30
    .line 31
    iput v1, v0, La/rS;->M:I

    .line 32
    .line 33
    iput v1, v0, La/rS;->T:I

    .line 34
    .line 35
    iput v1, v0, La/rS;->m:I

    .line 36
    .line 37
    iput v1, v0, La/rS;->y:I

    .line 38
    .line 39
    iput v1, v0, La/rS;->K:I

    .line 40
    .line 41
    iput v1, v0, La/rS;->R:I

    .line 42
    .line 43
    const/4 v4, 0x0

    .line 44
    iput v4, v0, La/rS;->L:I

    .line 45
    .line 46
    const/4 v5, 0x0

    .line 47
    iput v5, v0, La/rS;->d:F

    .line 48
    .line 49
    iput v1, v0, La/rS;->f:I

    .line 50
    .line 51
    iput v1, v0, La/rS;->l:I

    .line 52
    .line 53
    iput v1, v0, La/rS;->W:I

    .line 54
    .line 55
    iput v1, v0, La/rS;->q:I

    .line 56
    .line 57
    const/high16 v5, -0x80000000

    .line 58
    .line 59
    iput v5, v0, La/rS;->F:I

    .line 60
    .line 61
    iput v5, v0, La/rS;->E:I

    .line 62
    .line 63
    iput v5, v0, La/rS;->S:I

    .line 64
    .line 65
    iput v5, v0, La/rS;->H:I

    .line 66
    .line 67
    iput v5, v0, La/rS;->z:I

    .line 68
    .line 69
    iput v5, v0, La/rS;->P:I

    .line 70
    .line 71
    iput v5, v0, La/rS;->D:I

    .line 72
    .line 73
    iput v4, v0, La/rS;->Y:I

    .line 74
    .line 75
    const/high16 v6, 0x3f000000    # 0.5f

    .line 76
    .line 77
    iput v6, v0, La/rS;->u:F

    .line 78
    .line 79
    iput v6, v0, La/rS;->U:F

    .line 80
    .line 81
    const/4 v7, 0x0

    .line 82
    iput-object v7, v0, La/rS;->k:Ljava/lang/String;

    .line 83
    .line 84
    iput v2, v0, La/rS;->v:F

    .line 85
    .line 86
    iput v2, v0, La/rS;->s:F

    .line 87
    .line 88
    iput v4, v0, La/rS;->j:I

    .line 89
    .line 90
    iput v4, v0, La/rS;->t:I

    .line 91
    .line 92
    iput v4, v0, La/rS;->n:I

    .line 93
    .line 94
    iput v4, v0, La/rS;->C:I

    .line 95
    .line 96
    iput v4, v0, La/rS;->x:I

    .line 97
    .line 98
    iput v4, v0, La/rS;->g:I

    .line 99
    .line 100
    iput v4, v0, La/rS;->o:I

    .line 101
    .line 102
    iput v4, v0, La/rS;->r:I

    .line 103
    .line 104
    const/high16 v2, 0x3f800000    # 1.0f

    .line 105
    .line 106
    iput v2, v0, La/rS;->c:F

    .line 107
    .line 108
    iput v2, v0, La/rS;->B:F

    .line 109
    .line 110
    iput v1, v0, La/rS;->Z:I

    .line 111
    .line 112
    iput v1, v0, La/rS;->N:I

    .line 113
    .line 114
    iput v1, v0, La/rS;->b:I

    .line 115
    .line 116
    iput-boolean v4, v0, La/rS;->J:Z

    .line 117
    .line 118
    iput-boolean v4, v0, La/rS;->G:Z

    .line 119
    .line 120
    iput-object v7, v0, La/rS;->Pc:Ljava/lang/String;

    .line 121
    .line 122
    iput v4, v0, La/rS;->FL:I

    .line 123
    .line 124
    iput-boolean v3, v0, La/rS;->rV:Z

    .line 125
    .line 126
    iput-boolean v3, v0, La/rS;->rC:Z

    .line 127
    .line 128
    iput-boolean v4, v0, La/rS;->p7:Z

    .line 129
    .line 130
    iput-boolean v4, v0, La/rS;->F9:Z

    .line 131
    .line 132
    iput-boolean v4, v0, La/rS;->eH:Z

    .line 133
    .line 134
    iput v1, v0, La/rS;->mh:I

    .line 135
    .line 136
    iput v1, v0, La/rS;->ZU:I

    .line 137
    .line 138
    iput v1, v0, La/rS;->rZ:I

    .line 139
    .line 140
    iput v1, v0, La/rS;->B1:I

    .line 141
    .line 142
    iput v5, v0, La/rS;->y6:I

    .line 143
    .line 144
    iput v5, v0, La/rS;->xF:I

    .line 145
    .line 146
    iput v6, v0, La/rS;->Pb:F

    .line 147
    .line 148
    new-instance v1, La/c6;

    .line 149
    .line 150
    invoke-direct {v1}, La/c6;-><init>()V

    .line 151
    .line 152
    .line 153
    iput-object v1, v0, La/rS;->Gy:La/c6;

    .line 154
    .line 155
    return-object v0
.end method


# virtual methods
.method public final I(I)V
    .locals 9

    .line 1
    new-instance v0, La/mR;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v2, Landroid/util/SparseArray;

    .line 11
    .line 12
    invoke-direct {v2}, Landroid/util/SparseArray;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v2, v0, La/mR;->w:Landroid/util/SparseArray;

    .line 16
    .line 17
    new-instance v2, Landroid/util/SparseArray;

    .line 18
    .line 19
    invoke-direct {v2}, Landroid/util/SparseArray;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object v2, v0, La/mR;->h:Landroid/util/SparseArray;

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {v2, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    :try_start_0
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    const/4 v3, 0x0

    .line 37
    :goto_0
    const/4 v4, 0x1

    .line 38
    if-eq v2, v4, :cond_7

    .line 39
    .line 40
    if-eqz v2, :cond_5

    .line 41
    .line 42
    const/4 v5, 0x2

    .line 43
    if-eq v2, v5, :cond_0

    .line 44
    .line 45
    goto/16 :goto_3

    .line 46
    .line 47
    :cond_0
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    const/4 v7, 0x4

    .line 56
    const/4 v8, 0x3

    .line 57
    sparse-switch v6, :sswitch_data_0

    .line 58
    .line 59
    .line 60
    goto :goto_1

    .line 61
    :sswitch_0
    const-string v4, "Variant"

    .line 62
    .line 63
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-eqz v2, :cond_1

    .line 68
    .line 69
    move v4, v8

    .line 70
    goto :goto_2

    .line 71
    :catch_0
    move-exception p1

    .line 72
    goto :goto_4

    .line 73
    :catch_1
    move-exception p1

    .line 74
    goto :goto_5

    .line 75
    :sswitch_1
    const-string v4, "layoutDescription"

    .line 76
    .line 77
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    if-eqz v2, :cond_1

    .line 82
    .line 83
    const/4 v4, 0x0

    .line 84
    goto :goto_2

    .line 85
    :sswitch_2
    const-string v6, "StateSet"

    .line 86
    .line 87
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    if-eqz v2, :cond_1

    .line 92
    .line 93
    goto :goto_2

    .line 94
    :sswitch_3
    const-string v4, "State"

    .line 95
    .line 96
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    if-eqz v2, :cond_1

    .line 101
    .line 102
    move v4, v5

    .line 103
    goto :goto_2

    .line 104
    :sswitch_4
    const-string v4, "ConstraintSet"

    .line 105
    .line 106
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    if-eqz v2, :cond_1

    .line 111
    .line 112
    move v4, v7

    .line 113
    goto :goto_2

    .line 114
    :cond_1
    :goto_1
    const/4 v4, -0x1

    .line 115
    :goto_2
    if-eq v4, v5, :cond_4

    .line 116
    .line 117
    if-eq v4, v8, :cond_3

    .line 118
    .line 119
    if-eq v4, v7, :cond_2

    .line 120
    .line 121
    goto :goto_3

    .line 122
    :cond_2
    invoke-virtual {v0, v1, p1}, La/mR;->w(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 123
    .line 124
    .line 125
    goto :goto_3

    .line 126
    :cond_3
    new-instance v2, La/GL;

    .line 127
    .line 128
    invoke-direct {v2, v1, p1}, La/GL;-><init>(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 129
    .line 130
    .line 131
    if-eqz v3, :cond_6

    .line 132
    .line 133
    iget-object v4, v3, La/JE;->p:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v4, Ljava/util/ArrayList;

    .line 136
    .line 137
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    goto :goto_3

    .line 141
    :cond_4
    new-instance v3, La/JE;

    .line 142
    .line 143
    invoke-direct {v3, v1, p1}, La/JE;-><init>(Landroid/content/Context;Landroid/content/res/XmlResourceParser;)V

    .line 144
    .line 145
    .line 146
    iget-object v2, v0, La/mR;->w:Landroid/util/SparseArray;

    .line 147
    .line 148
    iget v4, v3, La/JE;->w:I

    .line 149
    .line 150
    invoke-virtual {v2, v4, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    goto :goto_3

    .line 154
    :cond_5
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    :cond_6
    :goto_3
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    .line 158
    .line 159
    .line 160
    move-result v2
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 161
    goto :goto_0

    .line 162
    :goto_4
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 163
    .line 164
    .line 165
    goto :goto_6

    .line 166
    :goto_5
    invoke-virtual {p1}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    .line 167
    .line 168
    .line 169
    :cond_7
    :goto_6
    return-void

    .line 170
    nop

    .line 171
    :sswitch_data_0
    .sparse-switch
        -0x50764adb -> :sswitch_4
        0x4c7d471 -> :sswitch_3
        0x526c4e31 -> :sswitch_2
        0x62ce7272 -> :sswitch_1
        0x7155a865 -> :sswitch_0
    .end sparse-switch
.end method

.method public final M(La/p3;III)V
    .locals 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v3

    invoke-static/range {p3 .. p3}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v4

    invoke-static/range {p4 .. p4}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v5

    invoke-static/range {p4 .. p4}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v7

    const/4 v8, 0x0

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    add-int v10, v7, v9

    .line 1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v11

    invoke-static {v8, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v12

    invoke-static {v8, v12}, Ljava/lang/Math;->max(II)I

    move-result v12

    add-int/2addr v12, v11

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingStart()I

    move-result v11

    invoke-static {v8, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingEnd()I

    move-result v13

    invoke-static {v8, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    add-int/2addr v13, v11

    if-lez v13, :cond_0

    move v12, v13

    :cond_0
    iget-object v11, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->P:La/ka;

    .line 2
    iput v7, v11, La/ka;->w:I

    .line 3
    iput v9, v11, La/ka;->h:I

    iput v12, v11, La/ka;->p:I

    iput v10, v11, La/ka;->e:I

    move/from16 v9, p3

    iput v9, v11, La/ka;->i:I

    move/from16 v9, p4

    iput v9, v11, La/ka;->Q:I

    .line 4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingStart()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingEnd()I

    move-result v13

    invoke-static {v8, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    const/4 v14, 0x1

    if-gtz v9, :cond_2

    if-lez v13, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    goto :goto_1

    .line 5
    :cond_2
    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v15

    invoke-virtual {v15}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v15

    iget v15, v15, Landroid/content/pm/ApplicationInfo;->flags:I

    const/high16 v16, 0x400000

    and-int v15, v15, v16

    if-eqz v15, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getLayoutDirection()I

    move-result v15

    if-ne v14, v15, :cond_3

    move v9, v13

    :cond_3
    :goto_1
    sub-int/2addr v4, v12

    sub-int/2addr v6, v10

    .line 6
    iget v10, v11, La/ka;->e:I

    iget v11, v11, La/ka;->p:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v12

    const/high16 v15, 0x40000000    # 2.0f

    const/high16 v13, -0x80000000

    if-eq v3, v13, :cond_7

    if-eqz v3, :cond_5

    if-eq v3, v15, :cond_4

    move/from16 v17, v8

    goto :goto_4

    :cond_4
    iget v14, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    sub-int/2addr v14, v11

    invoke-static {v14, v4}, Ljava/lang/Math;->min(II)I

    move-result v14

    move/from16 v17, v14

    const/4 v14, 0x1

    goto :goto_4

    :cond_5
    if-nez v12, :cond_6

    :goto_2
    iget v14, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    invoke-static {v8, v14}, Ljava/lang/Math;->max(II)I

    move-result v14

    move/from16 v17, v14

    :goto_3
    const/4 v14, 0x2

    goto :goto_4

    :cond_6
    move/from16 v17, v8

    goto :goto_3

    :cond_7
    if-nez v12, :cond_8

    goto :goto_2

    :cond_8
    move/from16 v17, v4

    goto :goto_3

    :goto_4
    if-eq v5, v13, :cond_c

    if-eqz v5, :cond_a

    if-eq v5, v15, :cond_9

    move v13, v8

    :goto_5
    const/4 v12, 0x1

    goto :goto_8

    :cond_9
    iget v12, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    sub-int/2addr v12, v10

    invoke-static {v12, v6}, Ljava/lang/Math;->min(II)I

    move-result v12

    move v13, v12

    goto :goto_5

    :cond_a
    if-nez v12, :cond_b

    :goto_6
    iget v12, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    invoke-static {v8, v12}, Ljava/lang/Math;->max(II)I

    move-result v12

    move v13, v12

    :goto_7
    const/4 v12, 0x2

    goto :goto_8

    :cond_b
    move v13, v8

    goto :goto_7

    :cond_c
    if-nez v12, :cond_d

    goto :goto_6

    :cond_d
    move v13, v6

    goto :goto_7

    :goto_8
    invoke-virtual/range {p1 .. p1}, La/c6;->K()I

    move-result v15

    iget-object v8, v1, La/p3;->MX:La/pF;

    move/from16 v19, v6

    move/from16 v6, v17

    if-ne v6, v15, :cond_e

    invoke-virtual/range {p1 .. p1}, La/c6;->T()I

    move-result v15

    if-eq v13, v15, :cond_f

    :cond_e
    const/4 v15, 0x1

    goto :goto_a

    :cond_f
    :goto_9
    const/4 v15, 0x0

    goto :goto_b

    .line 7
    :goto_a
    iput-boolean v15, v8, La/pF;->p:Z

    goto :goto_9

    .line 8
    :goto_b
    iput v15, v1, La/c6;->G:I

    .line 9
    iput v15, v1, La/c6;->Pc:I

    iget v15, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    sub-int/2addr v15, v11

    move-object/from16 v17, v8

    .line 10
    iget-object v8, v1, La/c6;->P:[I

    move/from16 v20, v4

    const/4 v4, 0x0

    aput v15, v8, v4

    iget v15, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    sub-int/2addr v15, v10

    const/16 v18, 0x1

    .line 11
    aput v15, v8, v18

    .line 12
    iput v4, v1, La/c6;->rV:I

    .line 13
    iput v4, v1, La/c6;->rC:I

    .line 14
    invoke-virtual {v1, v14}, La/c6;->s(I)V

    invoke-virtual {v1, v6}, La/c6;->t(I)V

    invoke-virtual {v1, v12}, La/c6;->j(I)V

    invoke-virtual {v1, v13}, La/c6;->v(I)V

    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    sub-int/2addr v6, v11

    if-gez v6, :cond_10

    .line 15
    iput v4, v1, La/c6;->rV:I

    goto :goto_c

    :cond_10
    iput v6, v1, La/c6;->rV:I

    :goto_c
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    sub-int/2addr v6, v10

    if-gez v6, :cond_11

    .line 16
    iput v4, v1, La/c6;->rC:I

    goto :goto_d

    :cond_11
    iput v6, v1, La/c6;->rC:I

    .line 17
    :goto_d
    iput v9, v1, La/p3;->C6:I

    iput v7, v1, La/p3;->nA:I

    iget-object v4, v1, La/p3;->NE:La/yW;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    iget-object v6, v1, La/p3;->Qg:La/ka;

    .line 19
    iget-object v7, v1, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    invoke-virtual/range {p1 .. p1}, La/c6;->K()I

    move-result v9

    invoke-virtual/range {p1 .. p1}, La/c6;->T()I

    move-result v10

    const/16 v11, 0x80

    invoke-static {v2, v11}, La/fe;->d(II)Z

    move-result v11

    const/16 v12, 0x40

    if-nez v11, :cond_13

    invoke-static {v2, v12}, La/fe;->d(II)Z

    move-result v2

    if-eqz v2, :cond_12

    goto :goto_e

    :cond_12
    const/4 v2, 0x0

    goto :goto_f

    :cond_13
    :goto_e
    const/4 v2, 0x1

    :goto_f
    const/4 v13, 0x3

    if-eqz v2, :cond_1c

    const/4 v15, 0x0

    :goto_10
    if-ge v15, v7, :cond_1c

    iget-object v12, v1, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, La/c6;

    .line 20
    iget-object v14, v12, La/c6;->HF:[I

    const/16 v18, 0x0

    .line 21
    aget v0, v14, v18

    if-ne v0, v13, :cond_14

    const/4 v0, 0x1

    :goto_11
    const/16 v21, 0x1

    goto :goto_12

    :cond_14
    const/4 v0, 0x0

    goto :goto_11

    .line 22
    :goto_12
    aget v14, v14, v21

    if-ne v14, v13, :cond_15

    const/4 v14, 0x1

    goto :goto_13

    :cond_15
    const/4 v14, 0x0

    :goto_13
    if-eqz v0, :cond_16

    if-eqz v14, :cond_16

    .line 23
    iget v0, v12, La/c6;->b:F

    const/4 v14, 0x0

    cmpl-float v0, v0, v14

    if-lez v0, :cond_16

    const/4 v0, 0x1

    goto :goto_14

    :cond_16
    const/4 v0, 0x0

    .line 24
    :goto_14
    invoke-virtual {v12}, La/c6;->q()Z

    move-result v14

    if-eqz v14, :cond_18

    if-eqz v0, :cond_18

    :cond_17
    :goto_15
    const/high16 v0, 0x40000000    # 2.0f

    const/4 v2, 0x0

    goto :goto_16

    :cond_18
    invoke-virtual {v12}, La/c6;->F()Z

    move-result v14

    if-eqz v14, :cond_19

    if-eqz v0, :cond_19

    goto :goto_15

    :cond_19
    instance-of v0, v12, La/yp;

    if-eqz v0, :cond_1a

    goto :goto_15

    :cond_1a
    invoke-virtual {v12}, La/c6;->q()Z

    move-result v0

    if-nez v0, :cond_17

    invoke-virtual {v12}, La/c6;->F()Z

    move-result v0

    if-eqz v0, :cond_1b

    goto :goto_15

    :cond_1b
    add-int/lit8 v15, v15, 0x1

    move-object/from16 v0, p0

    const/16 v12, 0x40

    goto :goto_10

    :cond_1c
    const/high16 v0, 0x40000000    # 2.0f

    :goto_16
    if-ne v3, v0, :cond_1d

    if-eq v5, v0, :cond_1e

    :cond_1d
    if-eqz v11, :cond_1f

    :cond_1e
    const/4 v0, 0x1

    goto :goto_17

    :cond_1f
    const/4 v0, 0x0

    :goto_17
    and-int/2addr v0, v2

    if-eqz v0, :cond_3e

    const/4 v12, 0x0

    .line 25
    aget v14, v8, v12

    move/from16 v12, v20

    .line 26
    invoke-static {v14, v12}, Ljava/lang/Math;->min(II)I

    move-result v12

    const/4 v14, 0x1

    .line 27
    aget v8, v8, v14

    move/from16 v15, v19

    .line 28
    invoke-static {v8, v15}, Ljava/lang/Math;->min(II)I

    move-result v8

    const/high16 v15, 0x40000000    # 2.0f

    if-ne v3, v15, :cond_20

    invoke-virtual/range {p1 .. p1}, La/c6;->K()I

    move-result v13

    if-eq v13, v12, :cond_20

    invoke-virtual {v1, v12}, La/c6;->t(I)V

    .line 29
    iget-object v12, v1, La/p3;->MX:La/pF;

    iput-boolean v14, v12, La/pF;->h:Z

    :cond_20
    if-ne v5, v15, :cond_21

    .line 30
    invoke-virtual/range {p1 .. p1}, La/c6;->T()I

    move-result v12

    if-eq v12, v8, :cond_21

    invoke-virtual {v1, v8}, La/c6;->v(I)V

    .line 31
    iget-object v8, v1, La/p3;->MX:La/pF;

    iput-boolean v14, v8, La/pF;->h:Z

    :cond_21
    if-ne v3, v15, :cond_37

    if-ne v5, v15, :cond_37

    and-int/lit8 v8, v11, 0x1

    move-object/from16 v12, v17

    .line 32
    iget-boolean v11, v12, La/pF;->h:Z

    .line 33
    iget-object v13, v12, La/pF;->w:La/p3;

    if-nez v11, :cond_23

    iget-boolean v11, v12, La/pF;->p:Z

    if-eqz v11, :cond_22

    goto :goto_18

    :cond_22
    const/4 v15, 0x0

    goto :goto_1a

    :cond_23
    :goto_18
    iget-object v11, v13, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_19
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_24

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La/c6;

    invoke-virtual {v14}, La/c6;->V()V

    const/4 v15, 0x0

    iput-boolean v15, v14, La/c6;->w:Z

    iget-object v2, v14, La/c6;->e:La/Hm;

    invoke-virtual {v2}, La/Hm;->y()V

    iget-object v2, v14, La/c6;->i:La/is;

    invoke-virtual {v2}, La/is;->m()V

    goto :goto_19

    :cond_24
    const/4 v15, 0x0

    invoke-virtual {v13}, La/c6;->V()V

    iput-boolean v15, v13, La/c6;->w:Z

    iget-object v2, v13, La/c6;->e:La/Hm;

    invoke-virtual {v2}, La/Hm;->y()V

    iget-object v2, v13, La/c6;->i:La/is;

    invoke-virtual {v2}, La/is;->m()V

    iput-boolean v15, v12, La/pF;->p:Z

    :goto_1a
    iget-object v2, v12, La/pF;->e:La/p3;

    invoke-virtual {v12, v2}, La/pF;->h(La/p3;)V

    .line 34
    iput v15, v13, La/c6;->G:I

    .line 35
    iput v15, v13, La/c6;->Pc:I

    .line 36
    invoke-virtual {v13, v15}, La/c6;->M(I)I

    move-result v2

    const/4 v11, 0x1

    invoke-virtual {v13, v11}, La/c6;->M(I)I

    move-result v14

    iget-boolean v11, v12, La/pF;->h:Z

    if-eqz v11, :cond_25

    invoke-virtual {v12}, La/pF;->p()V

    :cond_25
    invoke-virtual {v13}, La/c6;->R()I

    move-result v11

    invoke-virtual {v13}, La/c6;->L()I

    move-result v15

    move/from16 v20, v0

    iget-object v0, v13, La/c6;->e:La/Hm;

    iget-object v0, v0, La/zm;->O:La/KE;

    invoke-virtual {v0, v11}, La/KE;->e(I)V

    iget-object v0, v13, La/c6;->i:La/is;

    iget-object v0, v0, La/zm;->O:La/KE;

    invoke-virtual {v0, v15}, La/KE;->e(I)V

    invoke-virtual {v12}, La/pF;->X()V

    iget-object v0, v12, La/pF;->i:Ljava/util/ArrayList;

    move-object/from16 v21, v6

    const/4 v6, 0x2

    if-eq v2, v6, :cond_28

    if-ne v14, v6, :cond_26

    goto :goto_1b

    :cond_26
    move/from16 v22, v9

    :cond_27
    const/4 v6, 0x1

    goto :goto_1d

    :cond_28
    :goto_1b
    if-eqz v8, :cond_2a

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_29
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v22

    if-eqz v22, :cond_2a

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v22

    check-cast v22, La/zm;

    invoke-virtual/range {v22 .. v22}, La/zm;->M()Z

    move-result v22

    if-nez v22, :cond_29

    const/4 v8, 0x0

    :cond_2a
    if-eqz v8, :cond_2b

    const/4 v6, 0x2

    if-ne v2, v6, :cond_2b

    const/4 v6, 0x1

    invoke-virtual {v13, v6}, La/c6;->s(I)V

    move/from16 v22, v9

    const/4 v6, 0x0

    invoke-virtual {v12, v13, v6}, La/pF;->e(La/p3;I)I

    move-result v9

    invoke-virtual {v13, v9}, La/c6;->t(I)V

    iget-object v6, v13, La/c6;->e:La/Hm;

    iget-object v6, v6, La/zm;->i:La/xf;

    invoke-virtual {v13}, La/c6;->K()I

    move-result v9

    invoke-virtual {v6, v9}, La/xf;->e(I)V

    goto :goto_1c

    :cond_2b
    move/from16 v22, v9

    :goto_1c
    if-eqz v8, :cond_27

    const/4 v6, 0x2

    if-ne v14, v6, :cond_27

    const/4 v6, 0x1

    invoke-virtual {v13, v6}, La/c6;->j(I)V

    invoke-virtual {v12, v13, v6}, La/pF;->e(La/p3;I)I

    move-result v8

    invoke-virtual {v13, v8}, La/c6;->v(I)V

    iget-object v8, v13, La/c6;->i:La/is;

    iget-object v8, v8, La/zm;->i:La/xf;

    invoke-virtual {v13}, La/c6;->T()I

    move-result v9

    invoke-virtual {v8, v9}, La/xf;->e(I)V

    :goto_1d
    iget-object v8, v13, La/c6;->HF:[I

    move/from16 v23, v10

    const/4 v9, 0x0

    aget v10, v8, v9

    if-eq v10, v6, :cond_2d

    const/4 v6, 0x4

    if-ne v10, v6, :cond_2c

    goto :goto_1e

    :cond_2c
    const/4 v6, 0x0

    goto :goto_1f

    :cond_2d
    :goto_1e
    invoke-virtual {v13}, La/c6;->K()I

    move-result v6

    add-int/2addr v6, v11

    iget-object v9, v13, La/c6;->e:La/Hm;

    iget-object v9, v9, La/zm;->V:La/KE;

    invoke-virtual {v9, v6}, La/KE;->e(I)V

    iget-object v9, v13, La/c6;->e:La/Hm;

    iget-object v9, v9, La/zm;->i:La/xf;

    sub-int/2addr v6, v11

    invoke-virtual {v9, v6}, La/xf;->e(I)V

    invoke-virtual {v12}, La/pF;->X()V

    const/4 v6, 0x1

    aget v8, v8, v6

    if-eq v8, v6, :cond_2e

    const/4 v6, 0x4

    if-ne v8, v6, :cond_2f

    :cond_2e
    invoke-virtual {v13}, La/c6;->T()I

    move-result v6

    add-int/2addr v6, v15

    iget-object v8, v13, La/c6;->i:La/is;

    iget-object v8, v8, La/zm;->V:La/KE;

    invoke-virtual {v8, v6}, La/KE;->e(I)V

    iget-object v8, v13, La/c6;->i:La/is;

    iget-object v8, v8, La/zm;->i:La/xf;

    sub-int/2addr v6, v15

    invoke-virtual {v8, v6}, La/xf;->e(I)V

    :cond_2f
    invoke-virtual {v12}, La/pF;->X()V

    const/4 v6, 0x1

    :goto_1f
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_20
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_31

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La/zm;

    iget-object v10, v9, La/zm;->h:La/c6;

    if-ne v10, v13, :cond_30

    iget-boolean v10, v9, La/zm;->X:Z

    if-nez v10, :cond_30

    goto :goto_20

    :cond_30
    invoke-virtual {v9}, La/zm;->i()V

    goto :goto_20

    :cond_31
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_32
    :goto_21
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La/zm;

    if-nez v6, :cond_33

    iget-object v9, v8, La/zm;->h:La/c6;

    if-ne v9, v13, :cond_33

    goto :goto_21

    :cond_33
    iget-object v9, v8, La/zm;->O:La/KE;

    iget-boolean v9, v9, La/KE;->I:Z

    if-nez v9, :cond_34

    :goto_22
    const/4 v0, 0x0

    goto :goto_23

    :cond_34
    iget-object v9, v8, La/zm;->V:La/KE;

    iget-boolean v9, v9, La/KE;->I:Z

    if-nez v9, :cond_35

    instance-of v9, v8, La/nm;

    if-nez v9, :cond_35

    goto :goto_22

    :cond_35
    iget-object v9, v8, La/zm;->i:La/xf;

    iget-boolean v9, v9, La/KE;->I:Z

    if-nez v9, :cond_32

    instance-of v9, v8, La/Xc;

    if-nez v9, :cond_32

    instance-of v8, v8, La/nm;

    if-nez v8, :cond_32

    goto :goto_22

    :cond_36
    const/4 v0, 0x1

    :goto_23
    invoke-virtual {v13, v2}, La/c6;->s(I)V

    invoke-virtual {v13, v14}, La/c6;->j(I)V

    move v6, v0

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v2, 0x2

    goto/16 :goto_27

    :cond_37
    move/from16 v20, v0

    move-object/from16 v21, v6

    move/from16 v22, v9

    move/from16 v23, v10

    move-object/from16 v12, v17

    .line 37
    iget-boolean v0, v12, La/pF;->h:Z

    .line 38
    iget-object v2, v12, La/pF;->w:La/p3;

    if-eqz v0, :cond_39

    iget-object v0, v2, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_24
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_38

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/c6;

    invoke-virtual {v6}, La/c6;->V()V

    const/4 v8, 0x0

    iput-boolean v8, v6, La/c6;->w:Z

    iget-object v9, v6, La/c6;->e:La/Hm;

    iget-object v10, v9, La/zm;->i:La/xf;

    iput-boolean v8, v10, La/KE;->I:Z

    iput-boolean v8, v9, La/zm;->X:Z

    invoke-virtual {v9}, La/Hm;->y()V

    iget-object v6, v6, La/c6;->i:La/is;

    iget-object v9, v6, La/zm;->i:La/xf;

    iput-boolean v8, v9, La/KE;->I:Z

    iput-boolean v8, v6, La/zm;->X:Z

    invoke-virtual {v6}, La/is;->m()V

    goto :goto_24

    :cond_38
    const/4 v8, 0x0

    invoke-virtual {v2}, La/c6;->V()V

    iput-boolean v8, v2, La/c6;->w:Z

    iget-object v0, v2, La/c6;->e:La/Hm;

    iget-object v6, v0, La/zm;->i:La/xf;

    iput-boolean v8, v6, La/KE;->I:Z

    iput-boolean v8, v0, La/zm;->X:Z

    invoke-virtual {v0}, La/Hm;->y()V

    iget-object v0, v2, La/c6;->i:La/is;

    iget-object v6, v0, La/zm;->i:La/xf;

    iput-boolean v8, v6, La/KE;->I:Z

    iput-boolean v8, v0, La/zm;->X:Z

    invoke-virtual {v0}, La/is;->m()V

    invoke-virtual {v12}, La/pF;->p()V

    goto :goto_25

    :cond_39
    const/4 v8, 0x0

    :goto_25
    iget-object v0, v12, La/pF;->e:La/p3;

    invoke-virtual {v12, v0}, La/pF;->h(La/p3;)V

    .line 39
    iput v8, v2, La/c6;->G:I

    .line 40
    iput v8, v2, La/c6;->Pc:I

    .line 41
    iget-object v0, v2, La/c6;->e:La/Hm;

    iget-object v0, v0, La/zm;->O:La/KE;

    invoke-virtual {v0, v8}, La/KE;->e(I)V

    iget-object v0, v2, La/c6;->i:La/is;

    iget-object v0, v0, La/zm;->O:La/KE;

    invoke-virtual {v0, v8}, La/KE;->e(I)V

    const/high16 v0, 0x40000000    # 2.0f

    if-ne v3, v0, :cond_3a

    .line 42
    invoke-virtual {v1, v8, v11}, La/p3;->r(IZ)Z

    move-result v2

    const/4 v6, 0x1

    and-int/2addr v2, v6

    move v8, v2

    move v2, v6

    goto :goto_26

    :cond_3a
    const/4 v6, 0x1

    move v8, v6

    const/4 v2, 0x0

    :goto_26
    if-ne v5, v0, :cond_3b

    invoke-virtual {v1, v6, v11}, La/p3;->r(IZ)Z

    move-result v9

    and-int v6, v8, v9

    add-int/lit8 v2, v2, 0x1

    goto :goto_27

    :cond_3b
    move v6, v8

    :goto_27
    if-eqz v6, :cond_3f

    if-ne v3, v0, :cond_3c

    const/4 v3, 0x1

    goto :goto_28

    :cond_3c
    const/4 v3, 0x0

    :goto_28
    if-ne v5, v0, :cond_3d

    const/4 v0, 0x1

    goto :goto_29

    :cond_3d
    const/4 v0, 0x0

    :goto_29
    invoke-virtual {v1, v3, v0}, La/p3;->n(ZZ)V

    goto :goto_2a

    :cond_3e
    move/from16 v20, v0

    move-object/from16 v21, v6

    move/from16 v22, v9

    move/from16 v23, v10

    const/4 v2, 0x0

    const/4 v6, 0x0

    :cond_3f
    :goto_2a
    if-eqz v6, :cond_40

    const/4 v0, 0x2

    if-eq v2, v0, :cond_69

    .line 43
    :cond_40
    iget v0, v1, La/p3;->N3:I

    if-lez v7, :cond_4f

    .line 44
    iget-object v2, v1, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v3, 0x40

    invoke-virtual {v1, v3}, La/p3;->B(I)Z

    move-result v3

    .line 45
    iget-object v5, v1, La/p3;->Qg:La/ka;

    const/4 v15, 0x0

    :goto_2b
    if-ge v15, v2, :cond_4d

    .line 46
    iget-object v6, v1, La/tz;->Gy:Ljava/util/ArrayList;

    invoke-virtual {v6, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, La/c6;

    instance-of v8, v6, La/Ou;

    if-eqz v8, :cond_41

    :goto_2c
    const/4 v8, 0x3

    const/4 v10, 0x0

    goto/16 :goto_31

    :cond_41
    instance-of v8, v6, La/SD;

    if-eqz v8, :cond_42

    goto :goto_2c

    .line 47
    :cond_42
    iget-boolean v8, v6, La/c6;->u:Z

    if-eqz v8, :cond_43

    goto :goto_2c

    :cond_43
    if-eqz v3, :cond_44

    .line 48
    iget-object v8, v6, La/c6;->e:La/Hm;

    if-eqz v8, :cond_44

    iget-object v9, v6, La/c6;->i:La/is;

    if-eqz v9, :cond_44

    iget-object v8, v8, La/zm;->i:La/xf;

    iget-boolean v8, v8, La/KE;->I:Z

    if-eqz v8, :cond_44

    iget-object v8, v9, La/zm;->i:La/xf;

    iget-boolean v8, v8, La/KE;->I:Z

    if-eqz v8, :cond_44

    goto :goto_2c

    :cond_44
    const/4 v8, 0x0

    invoke-virtual {v6, v8}, La/c6;->M(I)I

    move-result v9

    const/4 v8, 0x1

    invoke-virtual {v6, v8}, La/c6;->M(I)I

    move-result v10

    const/4 v11, 0x3

    if-ne v9, v11, :cond_45

    iget v12, v6, La/c6;->L:I

    if-eq v12, v8, :cond_45

    if-ne v10, v11, :cond_45

    iget v11, v6, La/c6;->d:I

    if-eq v11, v8, :cond_45

    move v11, v8

    goto :goto_2d

    :cond_45
    const/4 v11, 0x0

    :goto_2d
    if-nez v11, :cond_4a

    invoke-virtual {v1, v8}, La/p3;->B(I)Z

    move-result v12

    if-eqz v12, :cond_4a

    instance-of v8, v6, La/yp;

    if-nez v8, :cond_4a

    const/4 v8, 0x3

    if-ne v9, v8, :cond_46

    iget v12, v6, La/c6;->L:I

    if-nez v12, :cond_46

    if-eq v10, v8, :cond_46

    invoke-virtual {v6}, La/c6;->q()Z

    move-result v12

    if-nez v12, :cond_46

    const/4 v11, 0x1

    :cond_46
    if-ne v10, v8, :cond_47

    iget v12, v6, La/c6;->d:I

    if-nez v12, :cond_47

    if-eq v9, v8, :cond_47

    invoke-virtual {v6}, La/c6;->q()Z

    move-result v12

    if-nez v12, :cond_47

    const/4 v11, 0x1

    :cond_47
    if-eq v9, v8, :cond_49

    if-ne v10, v8, :cond_48

    goto :goto_2f

    :cond_48
    :goto_2e
    const/4 v10, 0x0

    goto :goto_30

    :cond_49
    :goto_2f
    iget v9, v6, La/c6;->b:F

    const/4 v10, 0x0

    cmpl-float v9, v9, v10

    if-lez v9, :cond_4b

    goto :goto_31

    :cond_4a
    const/4 v8, 0x3

    goto :goto_2e

    :cond_4b
    :goto_30
    if-eqz v11, :cond_4c

    goto :goto_31

    :cond_4c
    const/4 v9, 0x0

    invoke-virtual {v4, v9, v6, v5}, La/yW;->P(ILa/c6;La/ka;)Z

    :goto_31
    add-int/lit8 v15, v15, 0x1

    goto/16 :goto_2b

    .line 49
    :cond_4d
    iget-object v2, v5, La/ka;->X:Ljava/lang/Object;

    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 50
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v15, 0x0

    :goto_32
    if-ge v15, v3, :cond_4e

    invoke-virtual {v2, v15}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    add-int/lit8 v15, v15, 0x1

    goto :goto_32

    .line 51
    :cond_4e
    iget-object v2, v2, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    .line 52
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_4f

    const/4 v15, 0x0

    :goto_33
    if-ge v15, v3, :cond_4f

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/Sc;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v15, v15, 0x1

    goto :goto_33

    .line 53
    :cond_4f
    invoke-virtual {v4, v1}, La/yW;->v(La/p3;)V

    iget-object v2, v4, La/yW;->K:Ljava/lang/Object;

    check-cast v2, Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    move/from16 v3, v22

    move/from16 v5, v23

    const/4 v15, 0x0

    if-lez v7, :cond_50

    invoke-virtual {v4, v1, v15, v3, v5}, La/yW;->k(La/p3;III)V

    :cond_50
    if-lez v2, :cond_68

    .line 54
    iget-object v6, v1, La/c6;->HF:[I

    aget v7, v6, v15

    const/4 v8, 0x2

    if-ne v7, v8, :cond_51

    const/4 v7, 0x1

    :goto_34
    const/4 v9, 0x1

    goto :goto_35

    :cond_51
    move v7, v15

    goto :goto_34

    .line 55
    :goto_35
    aget v6, v6, v9

    if-ne v6, v8, :cond_52

    const/4 v6, 0x1

    goto :goto_36

    :cond_52
    move v6, v15

    .line 56
    :goto_36
    invoke-virtual/range {p1 .. p1}, La/c6;->K()I

    move-result v8

    iget-object v9, v4, La/yW;->L:Ljava/lang/Object;

    check-cast v9, La/p3;

    .line 57
    iget v9, v9, La/c6;->rV:I

    .line 58
    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-virtual/range {p1 .. p1}, La/c6;->T()I

    move-result v9

    iget-object v10, v4, La/yW;->L:Ljava/lang/Object;

    check-cast v10, La/p3;

    .line 59
    iget v10, v10, La/c6;->rC:I

    .line 60
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v10, v15

    move v11, v10

    :goto_37
    if-ge v10, v2, :cond_58

    iget-object v13, v4, La/yW;->K:Ljava/lang/Object;

    check-cast v13, Ljava/util/ArrayList;

    invoke-virtual {v13, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/c6;

    instance-of v14, v13, La/yp;

    if-nez v14, :cond_53

    move/from16 v16, v0

    move-object/from16 v0, v21

    goto/16 :goto_39

    :cond_53
    invoke-virtual {v13}, La/c6;->K()I

    move-result v14

    invoke-virtual {v13}, La/c6;->T()I

    move-result v15

    move/from16 v16, v0

    move-object/from16 v0, v21

    const/4 v12, 0x1

    invoke-virtual {v4, v12, v13, v0}, La/yW;->P(ILa/c6;La/ka;)Z

    move-result v19

    or-int v11, v11, v19

    invoke-virtual {v13}, La/c6;->K()I

    move-result v12

    move/from16 v19, v11

    invoke-virtual {v13}, La/c6;->T()I

    move-result v11

    if-eq v12, v14, :cond_55

    invoke-virtual {v13, v12}, La/c6;->t(I)V

    if-eqz v7, :cond_54

    .line 61
    invoke-virtual {v13}, La/c6;->R()I

    move-result v12

    iget v14, v13, La/c6;->Z:I

    add-int/2addr v12, v14

    if-le v12, v8, :cond_54

    invoke-virtual {v13}, La/c6;->R()I

    move-result v12

    iget v14, v13, La/c6;->Z:I

    add-int/2addr v12, v14

    const/4 v14, 0x4

    .line 62
    invoke-virtual {v13, v14}, La/c6;->I(I)La/bM;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, La/bM;->i()I

    move-result v14

    add-int/2addr v14, v12

    invoke-static {v8, v14}, Ljava/lang/Math;->max(II)I

    move-result v8

    :cond_54
    const/16 v19, 0x1

    :cond_55
    if-eq v11, v15, :cond_57

    invoke-virtual {v13, v11}, La/c6;->v(I)V

    if-eqz v6, :cond_56

    .line 63
    invoke-virtual {v13}, La/c6;->L()I

    move-result v11

    iget v12, v13, La/c6;->N:I

    add-int/2addr v11, v12

    if-le v11, v9, :cond_56

    invoke-virtual {v13}, La/c6;->L()I

    move-result v11

    iget v12, v13, La/c6;->N:I

    add-int/2addr v11, v12

    const/4 v12, 0x5

    .line 64
    invoke-virtual {v13, v12}, La/c6;->I(I)La/bM;

    move-result-object v12

    invoke-virtual {v12}, La/bM;->i()I

    move-result v12

    add-int/2addr v12, v11

    invoke-static {v9, v12}, Ljava/lang/Math;->max(II)I

    move-result v9

    :cond_56
    const/4 v15, 0x1

    goto :goto_38

    :cond_57
    move/from16 v15, v19

    :goto_38
    check-cast v13, La/yp;

    .line 65
    iget-boolean v11, v13, La/yp;->nA:Z

    or-int/2addr v11, v15

    :goto_39
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v21, v0

    move/from16 v0, v16

    const/4 v15, 0x0

    goto/16 :goto_37

    :cond_58
    move/from16 v16, v0

    move-object/from16 v0, v21

    const/4 v10, 0x0

    :goto_3a
    const/4 v15, 0x2

    if-ge v10, v15, :cond_67

    move v12, v11

    const/4 v11, 0x0

    :goto_3b
    if-ge v11, v2, :cond_65

    .line 66
    iget-object v13, v4, La/yW;->K:Ljava/lang/Object;

    check-cast v13, Ljava/util/ArrayList;

    invoke-virtual {v13, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, La/c6;

    instance-of v14, v13, La/mD;

    if-eqz v14, :cond_59

    instance-of v14, v13, La/yp;

    if-eqz v14, :cond_5d

    :cond_59
    instance-of v14, v13, La/Ou;

    if-eqz v14, :cond_5a

    goto :goto_3c

    .line 67
    :cond_5a
    iget v14, v13, La/c6;->mh:I

    const/16 v15, 0x8

    if-ne v14, v15, :cond_5b

    goto :goto_3c

    :cond_5b
    if-eqz v20, :cond_5c

    .line 68
    iget-object v14, v13, La/c6;->e:La/Hm;

    iget-object v14, v14, La/zm;->i:La/xf;

    iget-boolean v14, v14, La/KE;->I:Z

    if-eqz v14, :cond_5c

    iget-object v14, v13, La/c6;->i:La/is;

    iget-object v14, v14, La/zm;->i:La/xf;

    iget-boolean v14, v14, La/KE;->I:Z

    if-eqz v14, :cond_5c

    goto :goto_3c

    :cond_5c
    instance-of v14, v13, La/yp;

    if-eqz v14, :cond_5e

    :cond_5d
    :goto_3c
    move-object/from16 v21, v0

    move/from16 v19, v2

    const/4 v14, 0x4

    const/4 v15, 0x5

    goto/16 :goto_41

    :cond_5e
    invoke-virtual {v13}, La/c6;->K()I

    move-result v14

    invoke-virtual {v13}, La/c6;->T()I

    move-result v15

    move/from16 v19, v2

    .line 69
    iget v2, v13, La/c6;->FL:I

    const/4 v1, 0x1

    if-ne v10, v1, :cond_5f

    const/4 v1, 0x2

    .line 70
    :cond_5f
    invoke-virtual {v4, v1, v13, v0}, La/yW;->P(ILa/c6;La/ka;)Z

    move-result v1

    or-int/2addr v1, v12

    invoke-virtual {v13}, La/c6;->K()I

    move-result v12

    move-object/from16 v21, v0

    invoke-virtual {v13}, La/c6;->T()I

    move-result v0

    if-eq v12, v14, :cond_61

    invoke-virtual {v13, v12}, La/c6;->t(I)V

    if-eqz v7, :cond_60

    .line 71
    invoke-virtual {v13}, La/c6;->R()I

    move-result v1

    iget v12, v13, La/c6;->Z:I

    add-int/2addr v1, v12

    if-le v1, v8, :cond_60

    invoke-virtual {v13}, La/c6;->R()I

    move-result v1

    iget v12, v13, La/c6;->Z:I

    add-int/2addr v1, v12

    const/4 v14, 0x4

    .line 72
    invoke-virtual {v13, v14}, La/c6;->I(I)La/bM;

    move-result-object v12

    invoke-virtual {v12}, La/bM;->i()I

    move-result v12

    add-int/2addr v12, v1

    invoke-static {v8, v12}, Ljava/lang/Math;->max(II)I

    move-result v8

    goto :goto_3d

    :cond_60
    const/4 v14, 0x4

    :goto_3d
    const/4 v1, 0x1

    goto :goto_3e

    :cond_61
    const/4 v14, 0x4

    :goto_3e
    if-eq v0, v15, :cond_63

    invoke-virtual {v13, v0}, La/c6;->v(I)V

    if-eqz v6, :cond_62

    .line 73
    invoke-virtual {v13}, La/c6;->L()I

    move-result v0

    iget v1, v13, La/c6;->N:I

    add-int/2addr v0, v1

    if-le v0, v9, :cond_62

    invoke-virtual {v13}, La/c6;->L()I

    move-result v0

    iget v1, v13, La/c6;->N:I

    add-int/2addr v0, v1

    const/4 v15, 0x5

    .line 74
    invoke-virtual {v13, v15}, La/c6;->I(I)La/bM;

    move-result-object v1

    invoke-virtual {v1}, La/bM;->i()I

    move-result v1

    add-int/2addr v1, v0

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v9

    goto :goto_3f

    :cond_62
    const/4 v15, 0x5

    :goto_3f
    const/4 v1, 0x1

    goto :goto_40

    :cond_63
    const/4 v15, 0x5

    .line 75
    :goto_40
    iget-boolean v0, v13, La/c6;->Y:Z

    if-eqz v0, :cond_64

    .line 76
    iget v0, v13, La/c6;->FL:I

    if-eq v2, v0, :cond_64

    const/4 v12, 0x1

    goto :goto_41

    :cond_64
    move v12, v1

    :goto_41
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v1, p1

    move/from16 v2, v19

    move-object/from16 v0, v21

    const/4 v15, 0x2

    goto/16 :goto_3b

    :cond_65
    move-object/from16 v21, v0

    move/from16 v19, v2

    const/4 v14, 0x4

    const/4 v15, 0x5

    if-eqz v12, :cond_66

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, p1

    const/4 v1, 0x1

    .line 77
    invoke-virtual {v4, v0, v10, v3, v5}, La/yW;->k(La/p3;III)V

    move-object v1, v0

    move/from16 v2, v19

    move-object/from16 v0, v21

    const/4 v11, 0x0

    goto/16 :goto_3a

    :cond_66
    move-object/from16 v0, p1

    :goto_42
    move/from16 v1, v16

    goto :goto_44

    :cond_67
    :goto_43
    move-object v0, v1

    goto :goto_42

    :cond_68
    move/from16 v16, v0

    goto :goto_43

    .line 78
    :goto_44
    iput v1, v0, La/p3;->N3:I

    const/16 v1, 0x200

    invoke-virtual {v0, v1}, La/p3;->B(I)Z

    move-result v0

    sput-boolean v0, La/sQ;->R:Z

    :cond_69
    return-void
.end method

.method public final O(Landroid/view/View;)La/c6;
    .locals 1

    .line 1
    if-ne p1, p0, :cond_0

    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    return-object p1

    :cond_0
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, La/rS;

    if-eqz v0, :cond_1

    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    check-cast p1, La/rS;

    iget-object p1, p1, La/rS;->Gy:La/c6;

    return-object p1

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v0, v0, La/rS;

    if-eqz v0, :cond_2

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    return-object p1
.end method

.method public final T(Ljava/lang/String;Ljava/lang/Integer;)V
    .locals 2

    .line 1
    instance-of v0, p1, Ljava/lang/String;

    if-eqz v0, :cond_2

    instance-of v0, p2, Ljava/lang/Integer;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->H:Ljava/util/HashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->H:Ljava/util/HashMap;

    :cond_0
    const-string v0, "/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    :cond_1
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->H:Ljava/util/HashMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public final V(Landroid/util/AttributeSet;I)V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    .line 2
    .line 3
    iput-object p0, v0, La/c6;->eH:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->P:La/ka;

    .line 6
    .line 7
    iput-object v1, v0, La/p3;->Qg:La/ka;

    .line 8
    .line 9
    iget-object v2, v0, La/p3;->MX:La/pF;

    .line 10
    .line 11
    iput-object v1, v2, La/pF;->Q:La/ka;

    .line 12
    .line 13
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1, v2, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    .line 24
    .line 25
    if-eqz p1, :cond_8

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    sget-object v3, La/dp;->h:[I

    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    invoke-virtual {v2, p1, v3, p2, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    .line 39
    .line 40
    .line 41
    move-result p2

    .line 42
    move v2, v4

    .line 43
    :goto_0
    if-ge v2, p2, :cond_7

    .line 44
    .line 45
    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getIndex(I)I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    const/16 v5, 0x10

    .line 50
    .line 51
    if-ne v3, v5, :cond_0

    .line 52
    .line 53
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    .line 54
    .line 55
    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:I

    .line 60
    .line 61
    goto :goto_2

    .line 62
    :cond_0
    const/16 v5, 0x11

    .line 63
    .line 64
    if-ne v3, v5, :cond_1

    .line 65
    .line 66
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    .line 67
    .line 68
    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    .line 73
    .line 74
    goto :goto_2

    .line 75
    :cond_1
    const/16 v5, 0xe

    .line 76
    .line 77
    if-ne v3, v5, :cond_2

    .line 78
    .line 79
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    .line 80
    .line 81
    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_2
    const/16 v5, 0xf

    .line 89
    .line 90
    if-ne v3, v5, :cond_3

    .line 91
    .line 92
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    .line 93
    .line 94
    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    .line 95
    .line 96
    .line 97
    move-result v3

    .line 98
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_3
    const/16 v5, 0x71

    .line 102
    .line 103
    if-ne v3, v5, :cond_4

    .line 104
    .line 105
    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    .line 106
    .line 107
    invoke-virtual {p1, v3, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_4
    const/16 v5, 0x38

    .line 115
    .line 116
    if-ne v3, v5, :cond_5

    .line 117
    .line 118
    invoke-virtual {p1, v3, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 119
    .line 120
    .line 121
    move-result v3

    .line 122
    if-eqz v3, :cond_6

    .line 123
    .line 124
    :try_start_0
    invoke-virtual {p0, v3}, Landroidx/constraintlayout/widget/ConstraintLayout;->I(I)V
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_1

    .line 125
    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_5
    const/16 v5, 0x22

    .line 129
    .line 130
    if-ne v3, v5, :cond_6

    .line 131
    .line 132
    invoke-virtual {p1, v3, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 133
    .line 134
    .line 135
    move-result v3

    .line 136
    :try_start_1
    new-instance v5, La/O8;

    .line 137
    .line 138
    invoke-direct {v5}, La/O8;-><init>()V

    .line 139
    .line 140
    .line 141
    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    .line 142
    .line 143
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 144
    .line 145
    .line 146
    move-result-object v6

    .line 147
    invoke-virtual {v5, v6, v3}, La/O8;->i(Landroid/content/Context;I)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    .line 148
    .line 149
    .line 150
    goto :goto_1

    .line 151
    :catch_0
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    .line 152
    .line 153
    :goto_1
    iput v3, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->S:I

    .line 154
    .line 155
    :catch_1
    :cond_6
    :goto_2
    add-int/lit8 v2, v2, 0x1

    .line 156
    .line 157
    goto :goto_0

    .line 158
    :cond_7
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 159
    .line 160
    .line 161
    :cond_8
    iget p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    .line 162
    .line 163
    iput p1, v0, La/p3;->N3:I

    .line 164
    .line 165
    const/16 p1, 0x200

    .line 166
    .line 167
    invoke-virtual {v0, p1}, La/p3;->B(I)Z

    .line 168
    .line 169
    .line 170
    move-result p1

    .line 171
    sput-boolean p1, La/sQ;->R:Z

    .line 172
    .line 173
    return-void
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 0

    instance-of p1, p1, La/rS;

    return p1
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    const/4 v1, 0x0

    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_0

    move v4, v1

    :goto_0
    if-ge v4, v3, :cond_0

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La/Sc;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v4

    move v5, v1

    :goto_1
    if-ge v5, v4, :cond_3

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v7

    const/16 v8, 0x8

    if-ne v7, v8, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_2

    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_2

    check-cast v6, Ljava/lang/String;

    const-string v7, ","

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    array-length v7, v6

    const/4 v8, 0x4

    if-ne v7, v8, :cond_2

    aget-object v7, v6, v1

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x1

    aget-object v8, v6, v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x2

    aget-object v9, v6, v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/4 v10, 0x3

    aget-object v6, v6, v10

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    int-to-float v7, v7

    const/high16 v10, 0x44870000    # 1080.0f

    div-float/2addr v7, v10

    mul-float/2addr v7, v2

    float-to-int v7, v7

    int-to-float v8, v8

    const/high16 v11, 0x44f00000    # 1920.0f

    div-float/2addr v8, v11

    mul-float/2addr v8, v3

    float-to-int v8, v8

    int-to-float v9, v9

    div-float/2addr v9, v10

    mul-float/2addr v9, v2

    float-to-int v9, v9

    int-to-float v6, v6

    div-float/2addr v6, v11

    mul-float/2addr v6, v3

    float-to-int v6, v6

    new-instance v15, Landroid/graphics/Paint;

    invoke-direct {v15}, Landroid/graphics/Paint;-><init>()V

    const/high16 v10, -0x10000

    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v14, v7

    int-to-float v13, v8

    add-int/2addr v7, v9

    int-to-float v7, v7

    move-object/from16 v10, p1

    move v11, v14

    move v12, v13

    move v9, v13

    move v13, v7

    move/from16 v16, v14

    move v14, v9

    move-object/from16 v17, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/2addr v8, v6

    int-to-float v6, v8

    move v11, v7

    move v12, v9

    move v14, v6

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move/from16 v13, v16

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move/from16 v11, v16

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const v8, -0xff0100

    invoke-virtual {v15, v8}, Landroid/graphics/Paint;->setColor(I)V

    move v12, v9

    move v13, v7

    move v14, v6

    move-object v8, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1

    :cond_3
    return-void
.end method

.method public final forceLayout()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 3
    .line 4
    invoke-super {p0}, Landroid/view/ViewGroup;->forceLayout()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    invoke-static {}, Landroidx/constraintlayout/widget/ConstraintLayout;->X()La/rS;

    move-result-object v0

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 12

    .line 1
    new-instance v0, La/rS;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    .line 2
    invoke-direct {v0, v1, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, -0x1

    iput v2, v0, La/rS;->w:I

    iput v2, v0, La/rS;->h:I

    const/high16 v3, -0x40800000    # -1.0f

    iput v3, v0, La/rS;->p:F

    const/4 v4, 0x1

    iput-boolean v4, v0, La/rS;->e:Z

    iput v2, v0, La/rS;->i:I

    iput v2, v0, La/rS;->Q:I

    iput v2, v0, La/rS;->X:I

    iput v2, v0, La/rS;->O:I

    iput v2, v0, La/rS;->V:I

    iput v2, v0, La/rS;->I:I

    iput v2, v0, La/rS;->M:I

    iput v2, v0, La/rS;->T:I

    iput v2, v0, La/rS;->m:I

    iput v2, v0, La/rS;->y:I

    iput v2, v0, La/rS;->K:I

    iput v2, v0, La/rS;->R:I

    const/4 v5, 0x0

    iput v5, v0, La/rS;->L:I

    const/4 v6, 0x0

    iput v6, v0, La/rS;->d:F

    iput v2, v0, La/rS;->f:I

    iput v2, v0, La/rS;->l:I

    iput v2, v0, La/rS;->W:I

    iput v2, v0, La/rS;->q:I

    const/high16 v7, -0x80000000

    iput v7, v0, La/rS;->F:I

    iput v7, v0, La/rS;->E:I

    iput v7, v0, La/rS;->S:I

    iput v7, v0, La/rS;->H:I

    iput v7, v0, La/rS;->z:I

    iput v7, v0, La/rS;->P:I

    iput v7, v0, La/rS;->D:I

    iput v5, v0, La/rS;->Y:I

    const/high16 v8, 0x3f000000    # 0.5f

    iput v8, v0, La/rS;->u:F

    iput v8, v0, La/rS;->U:F

    const/4 v9, 0x0

    iput-object v9, v0, La/rS;->k:Ljava/lang/String;

    iput v3, v0, La/rS;->v:F

    iput v3, v0, La/rS;->s:F

    iput v5, v0, La/rS;->j:I

    iput v5, v0, La/rS;->t:I

    iput v5, v0, La/rS;->n:I

    iput v5, v0, La/rS;->C:I

    iput v5, v0, La/rS;->x:I

    iput v5, v0, La/rS;->g:I

    iput v5, v0, La/rS;->o:I

    iput v5, v0, La/rS;->r:I

    const/high16 v3, 0x3f800000    # 1.0f

    iput v3, v0, La/rS;->c:F

    iput v3, v0, La/rS;->B:F

    iput v2, v0, La/rS;->Z:I

    iput v2, v0, La/rS;->N:I

    iput v2, v0, La/rS;->b:I

    iput-boolean v5, v0, La/rS;->J:Z

    iput-boolean v5, v0, La/rS;->G:Z

    iput-object v9, v0, La/rS;->Pc:Ljava/lang/String;

    iput v5, v0, La/rS;->FL:I

    iput-boolean v4, v0, La/rS;->rV:Z

    iput-boolean v4, v0, La/rS;->rC:Z

    iput-boolean v5, v0, La/rS;->p7:Z

    iput-boolean v5, v0, La/rS;->F9:Z

    iput-boolean v5, v0, La/rS;->eH:Z

    iput v2, v0, La/rS;->mh:I

    iput v2, v0, La/rS;->ZU:I

    iput v2, v0, La/rS;->rZ:I

    iput v2, v0, La/rS;->B1:I

    iput v7, v0, La/rS;->y6:I

    iput v7, v0, La/rS;->xF:I

    iput v8, v0, La/rS;->Pb:F

    new-instance v3, La/c6;

    invoke-direct {v3}, La/c6;-><init>()V

    iput-object v3, v0, La/rS;->Gy:La/c6;

    sget-object v3, La/dp;->h:[I

    invoke-virtual {v1, p1, v3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v1

    move v3, v5

    :goto_0
    if-ge v3, v1, :cond_1

    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v7

    sget-object v8, La/PI;->w:Landroid/util/SparseIntArray;

    invoke-virtual {v8, v7}, Landroid/util/SparseIntArray;->get(I)I

    move-result v8

    const-string v9, "ConstraintLayout"

    const/4 v10, 0x2

    const/4 v11, -0x2

    packed-switch v8, :pswitch_data_0

    packed-switch v8, :pswitch_data_1

    packed-switch v8, :pswitch_data_2

    goto/16 :goto_2

    :pswitch_0
    iget-boolean v8, v0, La/rS;->e:Z

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    iput-boolean v7, v0, La/rS;->e:Z

    goto/16 :goto_2

    :pswitch_1
    iget v8, v0, La/rS;->FL:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->FL:I

    goto/16 :goto_2

    :pswitch_2
    invoke-static {v0, p1, v7, v4}, La/O8;->X(Ljava/lang/Object;Landroid/content/res/TypedArray;II)V

    goto/16 :goto_2

    :pswitch_3
    invoke-static {v0, p1, v7, v5}, La/O8;->X(Ljava/lang/Object;Landroid/content/res/TypedArray;II)V

    goto/16 :goto_2

    :pswitch_4
    iget v8, v0, La/rS;->D:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->D:I

    goto/16 :goto_2

    :pswitch_5
    iget v8, v0, La/rS;->Y:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->Y:I

    goto/16 :goto_2

    :pswitch_6
    iget v8, v0, La/rS;->K:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->K:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->K:I

    goto/16 :goto_2

    :pswitch_7
    iget v8, v0, La/rS;->y:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->y:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->y:I

    goto/16 :goto_2

    :pswitch_8
    invoke-virtual {p1, v7}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    iput-object v7, v0, La/rS;->Pc:Ljava/lang/String;

    goto/16 :goto_2

    :pswitch_9
    iget v8, v0, La/rS;->N:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v7

    iput v7, v0, La/rS;->N:I

    goto/16 :goto_2

    :pswitch_a
    iget v8, v0, La/rS;->Z:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v7

    iput v7, v0, La/rS;->Z:I

    goto/16 :goto_2

    :pswitch_b
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->t:I

    goto/16 :goto_2

    :pswitch_c
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->j:I

    goto/16 :goto_2

    :pswitch_d
    iget v8, v0, La/rS;->s:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    iput v7, v0, La/rS;->s:F

    goto/16 :goto_2

    :pswitch_e
    iget v8, v0, La/rS;->v:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    iput v7, v0, La/rS;->v:F

    goto/16 :goto_2

    :pswitch_f
    invoke-virtual {p1, v7}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v0, v7}, La/O8;->O(La/rS;Ljava/lang/String;)V

    goto/16 :goto_2

    :pswitch_10
    iget v8, v0, La/rS;->B:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    iput v7, v0, La/rS;->B:F

    iput v10, v0, La/rS;->C:I

    goto/16 :goto_2

    :pswitch_11
    :try_start_0
    iget v8, v0, La/rS;->r:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iput v8, v0, La/rS;->r:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_2

    :catch_0
    iget v8, v0, La/rS;->r:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    if-ne v7, v11, :cond_0

    iput v11, v0, La/rS;->r:I

    goto/16 :goto_2

    :pswitch_12
    :try_start_1
    iget v8, v0, La/rS;->g:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iput v8, v0, La/rS;->g:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto/16 :goto_2

    :catch_1
    iget v8, v0, La/rS;->g:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    if-ne v7, v11, :cond_0

    iput v11, v0, La/rS;->g:I

    goto/16 :goto_2

    :pswitch_13
    iget v8, v0, La/rS;->c:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    iput v7, v0, La/rS;->c:F

    iput v10, v0, La/rS;->n:I

    goto/16 :goto_2

    :pswitch_14
    :try_start_2
    iget v8, v0, La/rS;->o:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iput v8, v0, La/rS;->o:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    goto/16 :goto_2

    :catch_2
    iget v8, v0, La/rS;->o:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    if-ne v7, v11, :cond_0

    iput v11, v0, La/rS;->o:I

    goto/16 :goto_2

    :pswitch_15
    :try_start_3
    iget v8, v0, La/rS;->x:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v8

    iput v8, v0, La/rS;->x:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto/16 :goto_2

    :catch_3
    iget v8, v0, La/rS;->x:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    if-ne v7, v11, :cond_0

    iput v11, v0, La/rS;->x:I

    goto/16 :goto_2

    :pswitch_16
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->C:I

    if-ne v7, v4, :cond_0

    const-string v7, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."

    :goto_1
    invoke-static {v9, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_2

    :pswitch_17
    invoke-virtual {p1, v7, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->n:I

    if-ne v7, v4, :cond_0

    const-string v7, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."

    goto :goto_1

    :pswitch_18
    iget v8, v0, La/rS;->U:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    iput v7, v0, La/rS;->U:F

    goto/16 :goto_2

    :pswitch_19
    iget v8, v0, La/rS;->u:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    iput v7, v0, La/rS;->u:F

    goto/16 :goto_2

    :pswitch_1a
    iget-boolean v8, v0, La/rS;->G:Z

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    iput-boolean v7, v0, La/rS;->G:Z

    goto/16 :goto_2

    :pswitch_1b
    iget-boolean v8, v0, La/rS;->J:Z

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    iput-boolean v7, v0, La/rS;->J:Z

    goto/16 :goto_2

    :pswitch_1c
    iget v8, v0, La/rS;->P:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->P:I

    goto/16 :goto_2

    :pswitch_1d
    iget v8, v0, La/rS;->z:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->z:I

    goto/16 :goto_2

    :pswitch_1e
    iget v8, v0, La/rS;->H:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->H:I

    goto/16 :goto_2

    :pswitch_1f
    iget v8, v0, La/rS;->S:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->S:I

    goto/16 :goto_2

    :pswitch_20
    iget v8, v0, La/rS;->E:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->E:I

    goto/16 :goto_2

    :pswitch_21
    iget v8, v0, La/rS;->F:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->F:I

    goto/16 :goto_2

    :pswitch_22
    iget v8, v0, La/rS;->q:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->q:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->q:I

    goto/16 :goto_2

    :pswitch_23
    iget v8, v0, La/rS;->W:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->W:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->W:I

    goto/16 :goto_2

    :pswitch_24
    iget v8, v0, La/rS;->l:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->l:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->l:I

    goto/16 :goto_2

    :pswitch_25
    iget v8, v0, La/rS;->f:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->f:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->f:I

    goto/16 :goto_2

    :pswitch_26
    iget v8, v0, La/rS;->m:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->m:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->m:I

    goto/16 :goto_2

    :pswitch_27
    iget v8, v0, La/rS;->T:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->T:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->T:I

    goto/16 :goto_2

    :pswitch_28
    iget v8, v0, La/rS;->M:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->M:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->M:I

    goto/16 :goto_2

    :pswitch_29
    iget v8, v0, La/rS;->I:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->I:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->I:I

    goto/16 :goto_2

    :pswitch_2a
    iget v8, v0, La/rS;->V:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->V:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->V:I

    goto/16 :goto_2

    :pswitch_2b
    iget v8, v0, La/rS;->O:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->O:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->O:I

    goto/16 :goto_2

    :pswitch_2c
    iget v8, v0, La/rS;->X:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->X:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->X:I

    goto/16 :goto_2

    :pswitch_2d
    iget v8, v0, La/rS;->Q:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->Q:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->Q:I

    goto :goto_2

    :pswitch_2e
    iget v8, v0, La/rS;->i:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->i:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->i:I

    goto :goto_2

    :pswitch_2f
    iget v8, v0, La/rS;->p:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    iput v7, v0, La/rS;->p:F

    goto :goto_2

    :pswitch_30
    iget v8, v0, La/rS;->h:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v7

    iput v7, v0, La/rS;->h:I

    goto :goto_2

    :pswitch_31
    iget v8, v0, La/rS;->w:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v7

    iput v7, v0, La/rS;->w:I

    goto :goto_2

    :pswitch_32
    iget v8, v0, La/rS;->d:F

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v7

    const/high16 v8, 0x43b40000    # 360.0f

    rem-float/2addr v7, v8

    iput v7, v0, La/rS;->d:F

    cmpg-float v9, v7, v6

    if-gez v9, :cond_0

    sub-float v7, v8, v7

    rem-float/2addr v7, v8

    iput v7, v0, La/rS;->d:F

    goto :goto_2

    :pswitch_33
    iget v8, v0, La/rS;->L:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v7

    iput v7, v0, La/rS;->L:I

    goto :goto_2

    :pswitch_34
    iget v8, v0, La/rS;->R:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    iput v8, v0, La/rS;->R:I

    if-ne v8, v2, :cond_0

    invoke-virtual {p1, v7, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->R:I

    goto :goto_2

    :pswitch_35
    iget v8, v0, La/rS;->b:I

    invoke-virtual {p1, v7, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    iput v7, v0, La/rS;->b:I

    :cond_0
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-virtual {v0}, La/rS;->w()V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_35
        :pswitch_34
        :pswitch_33
        :pswitch_32
        :pswitch_31
        :pswitch_30
        :pswitch_2f
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x2c
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x40
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 7

    new-instance v0, La/rS;

    .line 3
    invoke-direct {v0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, -0x1

    iput p1, v0, La/rS;->w:I

    iput p1, v0, La/rS;->h:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, v0, La/rS;->p:F

    const/4 v2, 0x1

    iput-boolean v2, v0, La/rS;->e:Z

    iput p1, v0, La/rS;->i:I

    iput p1, v0, La/rS;->Q:I

    iput p1, v0, La/rS;->X:I

    iput p1, v0, La/rS;->O:I

    iput p1, v0, La/rS;->V:I

    iput p1, v0, La/rS;->I:I

    iput p1, v0, La/rS;->M:I

    iput p1, v0, La/rS;->T:I

    iput p1, v0, La/rS;->m:I

    iput p1, v0, La/rS;->y:I

    iput p1, v0, La/rS;->K:I

    iput p1, v0, La/rS;->R:I

    const/4 v3, 0x0

    iput v3, v0, La/rS;->L:I

    const/4 v4, 0x0

    iput v4, v0, La/rS;->d:F

    iput p1, v0, La/rS;->f:I

    iput p1, v0, La/rS;->l:I

    iput p1, v0, La/rS;->W:I

    iput p1, v0, La/rS;->q:I

    const/high16 v4, -0x80000000

    iput v4, v0, La/rS;->F:I

    iput v4, v0, La/rS;->E:I

    iput v4, v0, La/rS;->S:I

    iput v4, v0, La/rS;->H:I

    iput v4, v0, La/rS;->z:I

    iput v4, v0, La/rS;->P:I

    iput v4, v0, La/rS;->D:I

    iput v3, v0, La/rS;->Y:I

    const/high16 v5, 0x3f000000    # 0.5f

    iput v5, v0, La/rS;->u:F

    iput v5, v0, La/rS;->U:F

    const/4 v6, 0x0

    iput-object v6, v0, La/rS;->k:Ljava/lang/String;

    iput v1, v0, La/rS;->v:F

    iput v1, v0, La/rS;->s:F

    iput v3, v0, La/rS;->j:I

    iput v3, v0, La/rS;->t:I

    iput v3, v0, La/rS;->n:I

    iput v3, v0, La/rS;->C:I

    iput v3, v0, La/rS;->x:I

    iput v3, v0, La/rS;->g:I

    iput v3, v0, La/rS;->o:I

    iput v3, v0, La/rS;->r:I

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, v0, La/rS;->c:F

    iput v1, v0, La/rS;->B:F

    iput p1, v0, La/rS;->Z:I

    iput p1, v0, La/rS;->N:I

    iput p1, v0, La/rS;->b:I

    iput-boolean v3, v0, La/rS;->J:Z

    iput-boolean v3, v0, La/rS;->G:Z

    iput-object v6, v0, La/rS;->Pc:Ljava/lang/String;

    iput v3, v0, La/rS;->FL:I

    iput-boolean v2, v0, La/rS;->rV:Z

    iput-boolean v2, v0, La/rS;->rC:Z

    iput-boolean v3, v0, La/rS;->p7:Z

    iput-boolean v3, v0, La/rS;->F9:Z

    iput-boolean v3, v0, La/rS;->eH:Z

    iput p1, v0, La/rS;->mh:I

    iput p1, v0, La/rS;->ZU:I

    iput p1, v0, La/rS;->rZ:I

    iput p1, v0, La/rS;->B1:I

    iput v4, v0, La/rS;->y6:I

    iput v4, v0, La/rS;->xF:I

    iput v5, v0, La/rS;->Pb:F

    new-instance p1, La/c6;

    invoke-direct {p1}, La/c6;-><init>()V

    iput-object p1, v0, La/rS;->Gy:La/c6;

    return-object v0
.end method

.method public final m(La/c6;La/rS;Landroid/util/SparseArray;II)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 2
    .line 3
    invoke-virtual {v0, p4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/view/View;

    .line 8
    .line 9
    invoke-virtual {p3, p4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p3

    .line 13
    check-cast p3, La/c6;

    .line 14
    .line 15
    if-eqz p3, :cond_1

    .line 16
    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 20
    .line 21
    .line 22
    move-result-object p4

    .line 23
    instance-of p4, p4, La/rS;

    .line 24
    .line 25
    if-eqz p4, :cond_1

    .line 26
    .line 27
    const/4 p4, 0x1

    .line 28
    iput-boolean p4, p2, La/rS;->p7:Z

    .line 29
    .line 30
    const/4 v1, 0x6

    .line 31
    if-ne p5, v1, :cond_0

    .line 32
    .line 33
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, La/rS;

    .line 38
    .line 39
    iput-boolean p4, v0, La/rS;->p7:Z

    .line 40
    .line 41
    iget-object v0, v0, La/rS;->Gy:La/c6;

    .line 42
    .line 43
    iput-boolean p4, v0, La/c6;->Y:Z

    .line 44
    .line 45
    :cond_0
    invoke-virtual {p1, v1}, La/c6;->I(I)La/bM;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-virtual {p3, p5}, La/c6;->I(I)La/bM;

    .line 50
    .line 51
    .line 52
    move-result-object p3

    .line 53
    iget p5, p2, La/rS;->Y:I

    .line 54
    .line 55
    iget p2, p2, La/rS;->D:I

    .line 56
    .line 57
    invoke-virtual {v0, p3, p5, p2, p4}, La/bM;->h(La/bM;IIZ)Z

    .line 58
    .line 59
    .line 60
    iput-boolean p4, p1, La/c6;->Y:Z

    .line 61
    .line 62
    const/4 p2, 0x3

    .line 63
    invoke-virtual {p1, p2}, La/c6;->I(I)La/bM;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    invoke-virtual {p2}, La/bM;->I()V

    .line 68
    .line 69
    .line 70
    const/4 p2, 0x5

    .line 71
    invoke-virtual {p1, p2}, La/c6;->I(I)La/bM;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {p1}, La/bM;->I()V

    .line 76
    .line 77
    .line 78
    :cond_1
    return-void
.end method

.method public onLayout(ZIIII)V
    .locals 4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result p2

    const/4 p3, 0x0

    move p4, p3

    :goto_0
    if-ge p4, p1, :cond_1

    invoke-virtual {p0, p4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p5

    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, La/rS;

    iget-object v1, v0, La/rS;->Gy:La/c6;

    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/16 v3, 0x8

    if-ne v2, v3, :cond_0

    iget-boolean v2, v0, La/rS;->F9:Z

    if-nez v2, :cond_0

    iget-boolean v0, v0, La/rS;->eH:Z

    if-nez v0, :cond_0

    if-nez p2, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v1}, La/c6;->R()I

    move-result v0

    invoke-virtual {v1}, La/c6;->L()I

    move-result v2

    invoke-virtual {v1}, La/c6;->K()I

    move-result v3

    add-int/2addr v3, v0

    invoke-virtual {v1}, La/c6;->T()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    :goto_1
    add-int/lit8 p4, p4, 0x1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p2

    if-lez p2, :cond_2

    :goto_2
    if-ge p3, p2, :cond_2

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, La/Sc;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 p3, p3, 0x1

    goto :goto_2

    :cond_2
    return-void
.end method

.method public onMeasure(II)V
    .locals 25

    .line 1
    move-object/from16 v6, p0

    .line 2
    .line 3
    move/from16 v7, p1

    .line 4
    .line 5
    move/from16 v8, p2

    .line 6
    .line 7
    iget v0, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->D:I

    .line 8
    .line 9
    if-ne v0, v7, :cond_0

    .line 10
    .line 11
    iget v0, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->u:I

    .line 12
    .line 13
    :cond_0
    iget-boolean v0, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 14
    .line 15
    const/4 v9, 0x0

    .line 16
    const/4 v10, 0x1

    .line 17
    if-nez v0, :cond_2

    .line 18
    .line 19
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    move v1, v9

    .line 24
    :goto_0
    if-ge v1, v0, :cond_2

    .line 25
    .line 26
    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v2}, Landroid/view/View;->isLayoutRequested()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_1

    .line 35
    .line 36
    iput-boolean v10, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_2
    :goto_1
    iput v7, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->D:I

    .line 43
    .line 44
    iput v8, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->u:I

    .line 45
    .line 46
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    .line 55
    .line 56
    const/high16 v1, 0x400000

    .line 57
    .line 58
    and-int/2addr v0, v1

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getLayoutDirection()I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-ne v10, v0, :cond_3

    .line 66
    .line 67
    move v0, v10

    .line 68
    goto :goto_2

    .line 69
    :cond_3
    move v0, v9

    .line 70
    :goto_2
    iget-object v11, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    .line 71
    .line 72
    iput-boolean v0, v11, La/p3;->Tr:Z

    .line 73
    .line 74
    iget-boolean v0, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 75
    .line 76
    if-eqz v0, :cond_4b

    .line 77
    .line 78
    iput-boolean v9, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 79
    .line 80
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    move v1, v9

    .line 85
    :goto_3
    if-ge v1, v0, :cond_5

    .line 86
    .line 87
    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-virtual {v2}, Landroid/view/View;->isLayoutRequested()Z

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    if-eqz v2, :cond_4

    .line 96
    .line 97
    move v12, v10

    .line 98
    goto :goto_4

    .line 99
    :cond_4
    add-int/lit8 v1, v1, 0x1

    .line 100
    .line 101
    goto :goto_3

    .line 102
    :cond_5
    move v12, v9

    .line 103
    :goto_4
    if-eqz v12, :cond_4a

    .line 104
    .line 105
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    .line 106
    .line 107
    .line 108
    move-result v13

    .line 109
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 110
    .line 111
    .line 112
    move-result v14

    .line 113
    move v0, v9

    .line 114
    :goto_5
    if-ge v0, v14, :cond_7

    .line 115
    .line 116
    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    invoke-virtual {v6, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    if-nez v1, :cond_6

    .line 125
    .line 126
    goto :goto_6

    .line 127
    :cond_6
    invoke-virtual {v1}, La/c6;->z()V

    .line 128
    .line 129
    .line 130
    :goto_6
    add-int/lit8 v0, v0, 0x1

    .line 131
    .line 132
    goto :goto_5

    .line 133
    :cond_7
    const/4 v0, 0x0

    .line 134
    const/4 v15, -0x1

    .line 135
    if-eqz v13, :cond_d

    .line 136
    .line 137
    move v1, v9

    .line 138
    :goto_7
    if-ge v1, v14, :cond_d

    .line 139
    .line 140
    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 141
    .line 142
    .line 143
    move-result-object v2

    .line 144
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 157
    .line 158
    .line 159
    move-result v4

    .line 160
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    invoke-virtual {v6, v3, v4}, Landroidx/constraintlayout/widget/ConstraintLayout;->T(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 165
    .line 166
    .line 167
    const/16 v4, 0x2f

    .line 168
    .line 169
    invoke-virtual {v3, v4}, Ljava/lang/String;->indexOf(I)I

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    if-eq v4, v15, :cond_8

    .line 174
    .line 175
    add-int/lit8 v4, v4, 0x1

    .line 176
    .line 177
    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    :cond_8
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 182
    .line 183
    .line 184
    move-result v2

    .line 185
    if-nez v2, :cond_9

    .line 186
    .line 187
    :goto_8
    move-object v2, v11

    .line 188
    goto :goto_9

    .line 189
    :cond_9
    iget-object v4, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 190
    .line 191
    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    check-cast v4, Landroid/view/View;

    .line 196
    .line 197
    if-nez v4, :cond_a

    .line 198
    .line 199
    invoke-virtual {v6, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 200
    .line 201
    .line 202
    move-result-object v4

    .line 203
    if-eqz v4, :cond_a

    .line 204
    .line 205
    if-eq v4, v6, :cond_a

    .line 206
    .line 207
    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 208
    .line 209
    .line 210
    move-result-object v2

    .line 211
    if-ne v2, v6, :cond_a

    .line 212
    .line 213
    invoke-virtual {v6, v4}, Landroidx/constraintlayout/widget/ConstraintLayout;->onViewAdded(Landroid/view/View;)V

    .line 214
    .line 215
    .line 216
    :cond_a
    if-ne v4, v6, :cond_b

    .line 217
    .line 218
    goto :goto_8

    .line 219
    :cond_b
    if-nez v4, :cond_c

    .line 220
    .line 221
    move-object v2, v0

    .line 222
    goto :goto_9

    .line 223
    :cond_c
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    check-cast v2, La/rS;

    .line 228
    .line 229
    iget-object v2, v2, La/rS;->Gy:La/c6;

    .line 230
    .line 231
    :goto_9
    iput-object v3, v2, La/c6;->ZU:Ljava/lang/String;
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 232
    .line 233
    :catch_0
    add-int/lit8 v1, v1, 0x1

    .line 234
    .line 235
    goto :goto_7

    .line 236
    :cond_d
    iget v1, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->S:I

    .line 237
    .line 238
    if-eq v1, v15, :cond_e

    .line 239
    .line 240
    move v1, v9

    .line 241
    :goto_a
    if-ge v1, v14, :cond_e

    .line 242
    .line 243
    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 244
    .line 245
    .line 246
    move-result-object v2

    .line 247
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 248
    .line 249
    .line 250
    add-int/lit8 v1, v1, 0x1

    .line 251
    .line 252
    goto :goto_a

    .line 253
    :cond_e
    iget-object v1, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->E:La/O8;

    .line 254
    .line 255
    if-eqz v1, :cond_f

    .line 256
    .line 257
    invoke-virtual {v1, v6}, La/O8;->w(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    .line 258
    .line 259
    .line 260
    :cond_f
    iget-object v1, v11, La/tz;->Gy:Ljava/util/ArrayList;

    .line 261
    .line 262
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 263
    .line 264
    .line 265
    iget-object v1, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    .line 266
    .line 267
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 268
    .line 269
    .line 270
    move-result v2

    .line 271
    if-lez v2, :cond_17

    .line 272
    .line 273
    move v3, v9

    .line 274
    :goto_b
    if-ge v3, v2, :cond_17

    .line 275
    .line 276
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v4

    .line 280
    check-cast v4, La/Sc;

    .line 281
    .line 282
    invoke-virtual {v4}, Landroid/view/View;->isInEditMode()Z

    .line 283
    .line 284
    .line 285
    move-result v16

    .line 286
    if-eqz v16, :cond_10

    .line 287
    .line 288
    iget-object v15, v4, La/Sc;->f:Ljava/lang/String;

    .line 289
    .line 290
    invoke-virtual {v4, v15}, La/Sc;->V(Ljava/lang/String;)V

    .line 291
    .line 292
    .line 293
    :cond_10
    iget-object v15, v4, La/Sc;->d:La/vZ;

    .line 294
    .line 295
    if-nez v15, :cond_11

    .line 296
    .line 297
    move-object/from16 v19, v1

    .line 298
    .line 299
    const/4 v9, 0x2

    .line 300
    goto/16 :goto_10

    .line 301
    .line 302
    :cond_11
    iput v9, v15, La/vZ;->NE:I

    .line 303
    .line 304
    iget-object v15, v15, La/vZ;->Gy:[La/c6;

    .line 305
    .line 306
    invoke-static {v15, v0}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    .line 307
    .line 308
    .line 309
    move v15, v9

    .line 310
    :goto_c
    iget v0, v4, La/Sc;->R:I

    .line 311
    .line 312
    if-ge v15, v0, :cond_16

    .line 313
    .line 314
    iget-object v0, v4, La/Sc;->K:[I

    .line 315
    .line 316
    aget v0, v0, v15

    .line 317
    .line 318
    iget-object v9, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 319
    .line 320
    invoke-virtual {v9, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v9

    .line 324
    check-cast v9, Landroid/view/View;

    .line 325
    .line 326
    if-nez v9, :cond_12

    .line 327
    .line 328
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    iget-object v5, v4, La/Sc;->W:Ljava/util/HashMap;

    .line 333
    .line 334
    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v0

    .line 338
    check-cast v0, Ljava/lang/String;

    .line 339
    .line 340
    invoke-virtual {v4, v6, v0}, La/Sc;->Q(Landroidx/constraintlayout/widget/ConstraintLayout;Ljava/lang/String;)I

    .line 341
    .line 342
    .line 343
    move-result v10

    .line 344
    if-eqz v10, :cond_12

    .line 345
    .line 346
    iget-object v9, v4, La/Sc;->K:[I

    .line 347
    .line 348
    aput v10, v9, v15

    .line 349
    .line 350
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 351
    .line 352
    .line 353
    move-result-object v9

    .line 354
    invoke-virtual {v5, v9, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    iget-object v0, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 358
    .line 359
    invoke-virtual {v0, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    move-object v9, v0

    .line 364
    check-cast v9, Landroid/view/View;

    .line 365
    .line 366
    :cond_12
    if-eqz v9, :cond_15

    .line 367
    .line 368
    iget-object v0, v4, La/Sc;->d:La/vZ;

    .line 369
    .line 370
    invoke-virtual {v6, v9}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    .line 371
    .line 372
    .line 373
    move-result-object v5

    .line 374
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 375
    .line 376
    .line 377
    if-eq v5, v0, :cond_15

    .line 378
    .line 379
    if-nez v5, :cond_13

    .line 380
    .line 381
    goto :goto_e

    .line 382
    :cond_13
    iget v9, v0, La/vZ;->NE:I

    .line 383
    .line 384
    const/4 v10, 0x1

    .line 385
    add-int/2addr v9, v10

    .line 386
    iget-object v10, v0, La/vZ;->Gy:[La/c6;

    .line 387
    .line 388
    move-object/from16 v19, v1

    .line 389
    .line 390
    array-length v1, v10

    .line 391
    if-le v9, v1, :cond_14

    .line 392
    .line 393
    array-length v1, v10

    .line 394
    const/4 v9, 0x2

    .line 395
    mul-int/2addr v1, v9

    .line 396
    invoke-static {v10, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    check-cast v1, [La/c6;

    .line 401
    .line 402
    iput-object v1, v0, La/vZ;->Gy:[La/c6;

    .line 403
    .line 404
    goto :goto_d

    .line 405
    :cond_14
    const/4 v9, 0x2

    .line 406
    :goto_d
    iget-object v1, v0, La/vZ;->Gy:[La/c6;

    .line 407
    .line 408
    iget v10, v0, La/vZ;->NE:I

    .line 409
    .line 410
    aput-object v5, v1, v10

    .line 411
    .line 412
    const/4 v1, 0x1

    .line 413
    add-int/2addr v10, v1

    .line 414
    iput v10, v0, La/vZ;->NE:I

    .line 415
    .line 416
    goto :goto_f

    .line 417
    :cond_15
    :goto_e
    move-object/from16 v19, v1

    .line 418
    .line 419
    const/4 v9, 0x2

    .line 420
    :goto_f
    add-int/lit8 v15, v15, 0x1

    .line 421
    .line 422
    move-object/from16 v1, v19

    .line 423
    .line 424
    const/4 v9, 0x0

    .line 425
    const/4 v10, 0x1

    .line 426
    goto :goto_c

    .line 427
    :cond_16
    move-object/from16 v19, v1

    .line 428
    .line 429
    const/4 v9, 0x2

    .line 430
    iget-object v0, v4, La/Sc;->d:La/vZ;

    .line 431
    .line 432
    invoke-interface {v0}, La/mD;->w()V

    .line 433
    .line 434
    .line 435
    :goto_10
    add-int/lit8 v3, v3, 0x1

    .line 436
    .line 437
    move-object/from16 v1, v19

    .line 438
    .line 439
    const/4 v0, 0x0

    .line 440
    const/4 v9, 0x0

    .line 441
    const/4 v10, 0x1

    .line 442
    const/4 v15, -0x1

    .line 443
    goto/16 :goto_b

    .line 444
    .line 445
    :cond_17
    const/4 v9, 0x2

    .line 446
    const/4 v0, 0x0

    .line 447
    :goto_11
    if-ge v0, v14, :cond_18

    .line 448
    .line 449
    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 450
    .line 451
    .line 452
    add-int/lit8 v0, v0, 0x1

    .line 453
    .line 454
    goto :goto_11

    .line 455
    :cond_18
    iget-object v10, v6, Landroidx/constraintlayout/widget/ConstraintLayout;->z:Landroid/util/SparseArray;

    .line 456
    .line 457
    invoke-virtual {v10}, Landroid/util/SparseArray;->clear()V

    .line 458
    .line 459
    .line 460
    const/4 v0, 0x0

    .line 461
    invoke-virtual {v10, v0, v11}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 462
    .line 463
    .line 464
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getId()I

    .line 465
    .line 466
    .line 467
    move-result v0

    .line 468
    invoke-virtual {v10, v0, v11}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    const/4 v0, 0x0

    .line 472
    :goto_12
    if-ge v0, v14, :cond_19

    .line 473
    .line 474
    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 475
    .line 476
    .line 477
    move-result-object v1

    .line 478
    invoke-virtual {v6, v1}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    .line 479
    .line 480
    .line 481
    move-result-object v2

    .line 482
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    .line 483
    .line 484
    .line 485
    move-result v1

    .line 486
    invoke-virtual {v10, v1, v2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 487
    .line 488
    .line 489
    add-int/lit8 v0, v0, 0x1

    .line 490
    .line 491
    goto :goto_12

    .line 492
    :cond_19
    const/4 v15, 0x0

    .line 493
    :goto_13
    if-ge v15, v14, :cond_4a

    .line 494
    .line 495
    invoke-virtual {v6, v15}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 496
    .line 497
    .line 498
    move-result-object v0

    .line 499
    invoke-virtual {v6, v0}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    .line 500
    .line 501
    .line 502
    move-result-object v5

    .line 503
    if-nez v5, :cond_1b

    .line 504
    .line 505
    :cond_1a
    :goto_14
    move v6, v9

    .line 506
    move/from16 v17, v14

    .line 507
    .line 508
    const/4 v4, 0x1

    .line 509
    const/4 v5, -0x1

    .line 510
    goto/16 :goto_2c

    .line 511
    .line 512
    :cond_1b
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 513
    .line 514
    .line 515
    move-result-object v1

    .line 516
    move-object v4, v1

    .line 517
    check-cast v4, La/rS;

    .line 518
    .line 519
    iget-object v1, v11, La/tz;->Gy:Ljava/util/ArrayList;

    .line 520
    .line 521
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 522
    .line 523
    .line 524
    iget-object v1, v5, La/c6;->B:La/c6;

    .line 525
    .line 526
    if-eqz v1, :cond_1c

    .line 527
    .line 528
    check-cast v1, La/tz;

    .line 529
    .line 530
    iget-object v1, v1, La/tz;->Gy:Ljava/util/ArrayList;

    .line 531
    .line 532
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    invoke-virtual {v5}, La/c6;->z()V

    .line 536
    .line 537
    .line 538
    :cond_1c
    iput-object v11, v5, La/c6;->B:La/c6;

    .line 539
    .line 540
    invoke-virtual {v4}, La/rS;->w()V

    .line 541
    .line 542
    .line 543
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 544
    .line 545
    .line 546
    move-result v1

    .line 547
    iput v1, v5, La/c6;->mh:I

    .line 548
    .line 549
    iput-object v0, v5, La/c6;->eH:Ljava/lang/Object;

    .line 550
    .line 551
    instance-of v1, v0, La/Sc;

    .line 552
    .line 553
    if-eqz v1, :cond_1d

    .line 554
    .line 555
    check-cast v0, La/Sc;

    .line 556
    .line 557
    iget-boolean v1, v11, La/p3;->Tr:Z

    .line 558
    .line 559
    invoke-virtual {v0, v5, v1}, La/Sc;->O(La/c6;Z)V

    .line 560
    .line 561
    .line 562
    :cond_1d
    iget-boolean v0, v4, La/rS;->F9:Z

    .line 563
    .line 564
    if-eqz v0, :cond_21

    .line 565
    .line 566
    check-cast v5, La/Ou;

    .line 567
    .line 568
    iget v0, v4, La/rS;->lI:I

    .line 569
    .line 570
    iget v1, v4, La/rS;->VQ:I

    .line 571
    .line 572
    iget v2, v4, La/rS;->HF:F

    .line 573
    .line 574
    const/high16 v3, -0x40800000    # -1.0f

    .line 575
    .line 576
    cmpl-float v4, v2, v3

    .line 577
    .line 578
    if-eqz v4, :cond_1f

    .line 579
    .line 580
    if-lez v4, :cond_1e

    .line 581
    .line 582
    iput v2, v5, La/Ou;->Gy:F

    .line 583
    .line 584
    const/4 v2, -0x1

    .line 585
    iput v2, v5, La/Ou;->NE:I

    .line 586
    .line 587
    iput v2, v5, La/Ou;->MX:I

    .line 588
    .line 589
    goto :goto_14

    .line 590
    :cond_1e
    const/4 v2, -0x1

    .line 591
    goto :goto_14

    .line 592
    :cond_1f
    const/4 v2, -0x1

    .line 593
    if-eq v0, v2, :cond_20

    .line 594
    .line 595
    if-le v0, v2, :cond_1a

    .line 596
    .line 597
    iput v3, v5, La/Ou;->Gy:F

    .line 598
    .line 599
    iput v0, v5, La/Ou;->NE:I

    .line 600
    .line 601
    iput v2, v5, La/Ou;->MX:I

    .line 602
    .line 603
    goto :goto_14

    .line 604
    :cond_20
    if-eq v1, v2, :cond_1a

    .line 605
    .line 606
    if-le v1, v2, :cond_1a

    .line 607
    .line 608
    iput v3, v5, La/Ou;->Gy:F

    .line 609
    .line 610
    iput v2, v5, La/Ou;->NE:I

    .line 611
    .line 612
    iput v1, v5, La/Ou;->MX:I

    .line 613
    .line 614
    goto :goto_14

    .line 615
    :cond_21
    iget v0, v4, La/rS;->mh:I

    .line 616
    .line 617
    iget v1, v4, La/rS;->ZU:I

    .line 618
    .line 619
    iget v2, v4, La/rS;->rZ:I

    .line 620
    .line 621
    iget v3, v4, La/rS;->B1:I

    .line 622
    .line 623
    iget v9, v4, La/rS;->y6:I

    .line 624
    .line 625
    move/from16 v17, v14

    .line 626
    .line 627
    iget v14, v4, La/rS;->xF:I

    .line 628
    .line 629
    iget v7, v4, La/rS;->Pb:F

    .line 630
    .line 631
    iget v8, v4, La/rS;->R:I

    .line 632
    .line 633
    const/4 v6, -0x1

    .line 634
    if-eq v8, v6, :cond_23

    .line 635
    .line 636
    invoke-virtual {v10, v8}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 637
    .line 638
    .line 639
    move-result-object v0

    .line 640
    move-object/from16 v21, v0

    .line 641
    .line 642
    check-cast v21, La/c6;

    .line 643
    .line 644
    if-eqz v21, :cond_22

    .line 645
    .line 646
    iget v0, v4, La/rS;->d:F

    .line 647
    .line 648
    iget v1, v4, La/rS;->L:I

    .line 649
    .line 650
    const/16 v22, 0x7

    .line 651
    .line 652
    const/16 v24, 0x0

    .line 653
    .line 654
    move-object/from16 v19, v5

    .line 655
    .line 656
    move/from16 v20, v22

    .line 657
    .line 658
    move/from16 v23, v1

    .line 659
    .line 660
    invoke-virtual/range {v19 .. v24}, La/c6;->l(ILa/c6;III)V

    .line 661
    .line 662
    .line 663
    iput v0, v5, La/c6;->D:F

    .line 664
    .line 665
    :cond_22
    move-object v14, v4

    .line 666
    move-object v1, v5

    .line 667
    const/4 v6, 0x2

    .line 668
    goto/16 :goto_1f

    .line 669
    .line 670
    :cond_23
    if-eq v0, v6, :cond_25

    .line 671
    .line 672
    invoke-virtual {v10, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 673
    .line 674
    .line 675
    move-result-object v0

    .line 676
    move-object/from16 v21, v0

    .line 677
    .line 678
    check-cast v21, La/c6;

    .line 679
    .line 680
    if-eqz v21, :cond_24

    .line 681
    .line 682
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 683
    .line 684
    move-object/from16 v19, v5

    .line 685
    .line 686
    const/4 v1, 0x2

    .line 687
    move/from16 v20, v1

    .line 688
    .line 689
    goto :goto_16

    .line 690
    :cond_24
    :goto_15
    const/4 v0, -0x1

    .line 691
    goto :goto_17

    .line 692
    :cond_25
    move v0, v6

    .line 693
    if-eq v1, v0, :cond_26

    .line 694
    .line 695
    invoke-virtual {v10, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 696
    .line 697
    .line 698
    move-result-object v0

    .line 699
    move-object/from16 v21, v0

    .line 700
    .line 701
    check-cast v21, La/c6;

    .line 702
    .line 703
    if-eqz v21, :cond_24

    .line 704
    .line 705
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 706
    .line 707
    move-object/from16 v19, v5

    .line 708
    .line 709
    const/4 v1, 0x2

    .line 710
    move/from16 v20, v1

    .line 711
    .line 712
    const/4 v1, 0x4

    .line 713
    :goto_16
    move/from16 v22, v1

    .line 714
    .line 715
    move/from16 v23, v0

    .line 716
    .line 717
    move/from16 v24, v9

    .line 718
    .line 719
    invoke-virtual/range {v19 .. v24}, La/c6;->l(ILa/c6;III)V

    .line 720
    .line 721
    .line 722
    goto :goto_15

    .line 723
    :cond_26
    :goto_17
    if-eq v2, v0, :cond_27

    .line 724
    .line 725
    invoke-virtual {v10, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 726
    .line 727
    .line 728
    move-result-object v0

    .line 729
    move-object/from16 v21, v0

    .line 730
    .line 731
    check-cast v21, La/c6;

    .line 732
    .line 733
    if-eqz v21, :cond_28

    .line 734
    .line 735
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 736
    .line 737
    move-object/from16 v19, v5

    .line 738
    .line 739
    const/4 v1, 0x4

    .line 740
    move/from16 v20, v1

    .line 741
    .line 742
    const/4 v1, 0x2

    .line 743
    goto :goto_18

    .line 744
    :cond_27
    if-eq v3, v0, :cond_28

    .line 745
    .line 746
    invoke-virtual {v10, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 747
    .line 748
    .line 749
    move-result-object v0

    .line 750
    move-object/from16 v21, v0

    .line 751
    .line 752
    check-cast v21, La/c6;

    .line 753
    .line 754
    if-eqz v21, :cond_28

    .line 755
    .line 756
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 757
    .line 758
    move-object/from16 v19, v5

    .line 759
    .line 760
    const/4 v1, 0x4

    .line 761
    move/from16 v20, v1

    .line 762
    .line 763
    :goto_18
    move/from16 v22, v1

    .line 764
    .line 765
    move/from16 v23, v0

    .line 766
    .line 767
    move/from16 v24, v14

    .line 768
    .line 769
    invoke-virtual/range {v19 .. v24}, La/c6;->l(ILa/c6;III)V

    .line 770
    .line 771
    .line 772
    :cond_28
    iget v0, v4, La/rS;->V:I

    .line 773
    .line 774
    const/4 v1, -0x1

    .line 775
    if-eq v0, v1, :cond_29

    .line 776
    .line 777
    invoke-virtual {v10, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 778
    .line 779
    .line 780
    move-result-object v0

    .line 781
    move-object/from16 v21, v0

    .line 782
    .line 783
    check-cast v21, La/c6;

    .line 784
    .line 785
    if-eqz v21, :cond_2a

    .line 786
    .line 787
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 788
    .line 789
    iget v1, v4, La/rS;->E:I

    .line 790
    .line 791
    move-object/from16 v19, v5

    .line 792
    .line 793
    const/4 v2, 0x3

    .line 794
    move/from16 v20, v2

    .line 795
    .line 796
    goto :goto_19

    .line 797
    :cond_29
    iget v0, v4, La/rS;->I:I

    .line 798
    .line 799
    const/4 v1, -0x1

    .line 800
    if-eq v0, v1, :cond_2a

    .line 801
    .line 802
    invoke-virtual {v10, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 803
    .line 804
    .line 805
    move-result-object v0

    .line 806
    move-object/from16 v21, v0

    .line 807
    .line 808
    check-cast v21, La/c6;

    .line 809
    .line 810
    if-eqz v21, :cond_2a

    .line 811
    .line 812
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 813
    .line 814
    iget v1, v4, La/rS;->E:I

    .line 815
    .line 816
    move-object/from16 v19, v5

    .line 817
    .line 818
    const/4 v2, 0x3

    .line 819
    move/from16 v20, v2

    .line 820
    .line 821
    const/4 v2, 0x5

    .line 822
    :goto_19
    move/from16 v22, v2

    .line 823
    .line 824
    move/from16 v23, v0

    .line 825
    .line 826
    move/from16 v24, v1

    .line 827
    .line 828
    invoke-virtual/range {v19 .. v24}, La/c6;->l(ILa/c6;III)V

    .line 829
    .line 830
    .line 831
    :cond_2a
    iget v0, v4, La/rS;->M:I

    .line 832
    .line 833
    const/4 v1, -0x1

    .line 834
    if-eq v0, v1, :cond_2b

    .line 835
    .line 836
    invoke-virtual {v10, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 837
    .line 838
    .line 839
    move-result-object v0

    .line 840
    move-object/from16 v21, v0

    .line 841
    .line 842
    check-cast v21, La/c6;

    .line 843
    .line 844
    if-eqz v21, :cond_2c

    .line 845
    .line 846
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 847
    .line 848
    iget v1, v4, La/rS;->H:I

    .line 849
    .line 850
    move-object/from16 v19, v5

    .line 851
    .line 852
    const/4 v2, 0x5

    .line 853
    move/from16 v20, v2

    .line 854
    .line 855
    const/4 v2, 0x3

    .line 856
    goto :goto_1a

    .line 857
    :cond_2b
    iget v0, v4, La/rS;->T:I

    .line 858
    .line 859
    const/4 v1, -0x1

    .line 860
    if-eq v0, v1, :cond_2c

    .line 861
    .line 862
    invoke-virtual {v10, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 863
    .line 864
    .line 865
    move-result-object v0

    .line 866
    move-object/from16 v21, v0

    .line 867
    .line 868
    check-cast v21, La/c6;

    .line 869
    .line 870
    if-eqz v21, :cond_2c

    .line 871
    .line 872
    iget v0, v4, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 873
    .line 874
    iget v1, v4, La/rS;->H:I

    .line 875
    .line 876
    move-object/from16 v19, v5

    .line 877
    .line 878
    const/4 v2, 0x5

    .line 879
    move/from16 v20, v2

    .line 880
    .line 881
    :goto_1a
    move/from16 v22, v2

    .line 882
    .line 883
    move/from16 v23, v0

    .line 884
    .line 885
    move/from16 v24, v1

    .line 886
    .line 887
    invoke-virtual/range {v19 .. v24}, La/c6;->l(ILa/c6;III)V

    .line 888
    .line 889
    .line 890
    :cond_2c
    iget v6, v4, La/rS;->m:I

    .line 891
    .line 892
    const/4 v8, -0x1

    .line 893
    if-eq v6, v8, :cond_2e

    .line 894
    .line 895
    const/4 v9, 0x6

    .line 896
    move-object/from16 v0, p0

    .line 897
    .line 898
    move-object v1, v5

    .line 899
    move-object v2, v4

    .line 900
    move-object v3, v10

    .line 901
    move-object v14, v4

    .line 902
    move v4, v6

    .line 903
    move-object/from16 v18, v5

    .line 904
    .line 905
    const/4 v6, 0x2

    .line 906
    :goto_1b
    move v5, v9

    .line 907
    :goto_1c
    invoke-virtual/range {v0 .. v5}, Landroidx/constraintlayout/widget/ConstraintLayout;->m(La/c6;La/rS;Landroid/util/SparseArray;II)V

    .line 908
    .line 909
    .line 910
    :cond_2d
    const/4 v0, 0x0

    .line 911
    goto :goto_1d

    .line 912
    :cond_2e
    move-object v14, v4

    .line 913
    move-object/from16 v18, v5

    .line 914
    .line 915
    const/4 v6, 0x2

    .line 916
    iget v4, v14, La/rS;->y:I

    .line 917
    .line 918
    if-eq v4, v8, :cond_2f

    .line 919
    .line 920
    move-object/from16 v0, p0

    .line 921
    .line 922
    move-object/from16 v1, v18

    .line 923
    .line 924
    move-object v2, v14

    .line 925
    move-object v3, v10

    .line 926
    const/4 v9, 0x3

    .line 927
    goto :goto_1b

    .line 928
    :cond_2f
    iget v4, v14, La/rS;->K:I

    .line 929
    .line 930
    if-eq v4, v8, :cond_2d

    .line 931
    .line 932
    move-object/from16 v0, p0

    .line 933
    .line 934
    move-object/from16 v1, v18

    .line 935
    .line 936
    move-object v2, v14

    .line 937
    move-object v3, v10

    .line 938
    const/4 v8, 0x5

    .line 939
    move v5, v8

    .line 940
    goto :goto_1c

    .line 941
    :goto_1d
    cmpl-float v1, v7, v0

    .line 942
    .line 943
    if-ltz v1, :cond_30

    .line 944
    .line 945
    move-object/from16 v1, v18

    .line 946
    .line 947
    iput v7, v1, La/c6;->p7:F

    .line 948
    .line 949
    goto :goto_1e

    .line 950
    :cond_30
    move-object/from16 v1, v18

    .line 951
    .line 952
    :goto_1e
    iget v2, v14, La/rS;->U:F

    .line 953
    .line 954
    cmpl-float v3, v2, v0

    .line 955
    .line 956
    if-ltz v3, :cond_31

    .line 957
    .line 958
    iput v2, v1, La/c6;->F9:F

    .line 959
    .line 960
    :cond_31
    :goto_1f
    if-eqz v13, :cond_33

    .line 961
    .line 962
    iget v0, v14, La/rS;->Z:I

    .line 963
    .line 964
    const/4 v2, -0x1

    .line 965
    if-ne v0, v2, :cond_32

    .line 966
    .line 967
    iget v3, v14, La/rS;->N:I

    .line 968
    .line 969
    if-eq v3, v2, :cond_33

    .line 970
    .line 971
    :cond_32
    iget v2, v14, La/rS;->N:I

    .line 972
    .line 973
    iput v0, v1, La/c6;->G:I

    .line 974
    .line 975
    iput v2, v1, La/c6;->Pc:I

    .line 976
    .line 977
    :cond_33
    iget-boolean v0, v14, La/rS;->rV:Z

    .line 978
    .line 979
    const/4 v2, 0x3

    .line 980
    const/4 v3, 0x4

    .line 981
    const/4 v4, -0x2

    .line 982
    if-nez v0, :cond_36

    .line 983
    .line 984
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 985
    .line 986
    const/4 v5, -0x1

    .line 987
    if-ne v0, v5, :cond_35

    .line 988
    .line 989
    iget-boolean v0, v14, La/rS;->J:Z

    .line 990
    .line 991
    if-eqz v0, :cond_34

    .line 992
    .line 993
    invoke-virtual {v1, v2}, La/c6;->s(I)V

    .line 994
    .line 995
    .line 996
    :goto_20
    const/4 v0, 0x2

    .line 997
    goto :goto_21

    .line 998
    :cond_34
    invoke-virtual {v1, v3}, La/c6;->s(I)V

    .line 999
    .line 1000
    .line 1001
    goto :goto_20

    .line 1002
    :goto_21
    invoke-virtual {v1, v0}, La/c6;->I(I)La/bM;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v0

    .line 1006
    iget v5, v14, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 1007
    .line 1008
    iput v5, v0, La/bM;->X:I

    .line 1009
    .line 1010
    const/4 v0, 0x4

    .line 1011
    invoke-virtual {v1, v0}, La/c6;->I(I)La/bM;

    .line 1012
    .line 1013
    .line 1014
    move-result-object v0

    .line 1015
    iget v5, v14, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 1016
    .line 1017
    iput v5, v0, La/bM;->X:I

    .line 1018
    .line 1019
    goto :goto_22

    .line 1020
    :cond_35
    invoke-virtual {v1, v2}, La/c6;->s(I)V

    .line 1021
    .line 1022
    .line 1023
    const/4 v0, 0x0

    .line 1024
    invoke-virtual {v1, v0}, La/c6;->t(I)V

    .line 1025
    .line 1026
    .line 1027
    goto :goto_22

    .line 1028
    :cond_36
    const/4 v0, 0x1

    .line 1029
    invoke-virtual {v1, v0}, La/c6;->s(I)V

    .line 1030
    .line 1031
    .line 1032
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 1033
    .line 1034
    invoke-virtual {v1, v0}, La/c6;->t(I)V

    .line 1035
    .line 1036
    .line 1037
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 1038
    .line 1039
    if-ne v0, v4, :cond_37

    .line 1040
    .line 1041
    invoke-virtual {v1, v6}, La/c6;->s(I)V

    .line 1042
    .line 1043
    .line 1044
    :cond_37
    :goto_22
    iget-boolean v0, v14, La/rS;->rC:Z

    .line 1045
    .line 1046
    if-nez v0, :cond_3a

    .line 1047
    .line 1048
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 1049
    .line 1050
    const/4 v5, -0x1

    .line 1051
    if-ne v0, v5, :cond_39

    .line 1052
    .line 1053
    iget-boolean v0, v14, La/rS;->G:Z

    .line 1054
    .line 1055
    if-eqz v0, :cond_38

    .line 1056
    .line 1057
    invoke-virtual {v1, v2}, La/c6;->j(I)V

    .line 1058
    .line 1059
    .line 1060
    :goto_23
    const/4 v0, 0x3

    .line 1061
    goto :goto_24

    .line 1062
    :cond_38
    invoke-virtual {v1, v3}, La/c6;->j(I)V

    .line 1063
    .line 1064
    .line 1065
    goto :goto_23

    .line 1066
    :goto_24
    invoke-virtual {v1, v0}, La/c6;->I(I)La/bM;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v0

    .line 1070
    iget v3, v14, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 1071
    .line 1072
    iput v3, v0, La/bM;->X:I

    .line 1073
    .line 1074
    const/4 v0, 0x5

    .line 1075
    invoke-virtual {v1, v0}, La/c6;->I(I)La/bM;

    .line 1076
    .line 1077
    .line 1078
    move-result-object v0

    .line 1079
    iget v3, v14, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 1080
    .line 1081
    iput v3, v0, La/bM;->X:I

    .line 1082
    .line 1083
    goto :goto_25

    .line 1084
    :cond_39
    invoke-virtual {v1, v2}, La/c6;->j(I)V

    .line 1085
    .line 1086
    .line 1087
    const/4 v0, 0x0

    .line 1088
    invoke-virtual {v1, v0}, La/c6;->v(I)V

    .line 1089
    .line 1090
    .line 1091
    goto :goto_25

    .line 1092
    :cond_3a
    const/4 v0, 0x1

    .line 1093
    const/4 v5, -0x1

    .line 1094
    invoke-virtual {v1, v0}, La/c6;->j(I)V

    .line 1095
    .line 1096
    .line 1097
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 1098
    .line 1099
    invoke-virtual {v1, v0}, La/c6;->v(I)V

    .line 1100
    .line 1101
    .line 1102
    iget v0, v14, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 1103
    .line 1104
    if-ne v0, v4, :cond_3b

    .line 1105
    .line 1106
    invoke-virtual {v1, v6}, La/c6;->j(I)V

    .line 1107
    .line 1108
    .line 1109
    :cond_3b
    :goto_25
    iget-object v0, v14, La/rS;->k:Ljava/lang/String;

    .line 1110
    .line 1111
    if-eqz v0, :cond_3c

    .line 1112
    .line 1113
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1114
    .line 1115
    .line 1116
    move-result v3

    .line 1117
    if-nez v3, :cond_3d

    .line 1118
    .line 1119
    :cond_3c
    const/4 v3, 0x0

    .line 1120
    goto/16 :goto_2a

    .line 1121
    .line 1122
    :cond_3d
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1123
    .line 1124
    .line 1125
    move-result v3

    .line 1126
    const/16 v4, 0x2c

    .line 1127
    .line 1128
    invoke-virtual {v0, v4}, Ljava/lang/String;->indexOf(I)I

    .line 1129
    .line 1130
    .line 1131
    move-result v4

    .line 1132
    if-lez v4, :cond_40

    .line 1133
    .line 1134
    add-int/lit8 v7, v3, -0x1

    .line 1135
    .line 1136
    if-ge v4, v7, :cond_40

    .line 1137
    .line 1138
    const/4 v7, 0x0

    .line 1139
    invoke-virtual {v0, v7, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1140
    .line 1141
    .line 1142
    move-result-object v8

    .line 1143
    const-string v7, "W"

    .line 1144
    .line 1145
    invoke-virtual {v8, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1146
    .line 1147
    .line 1148
    move-result v7

    .line 1149
    if-eqz v7, :cond_3e

    .line 1150
    .line 1151
    const/4 v7, 0x0

    .line 1152
    goto :goto_26

    .line 1153
    :cond_3e
    const-string v7, "H"

    .line 1154
    .line 1155
    invoke-virtual {v8, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1156
    .line 1157
    .line 1158
    move-result v7

    .line 1159
    if-eqz v7, :cond_3f

    .line 1160
    .line 1161
    const/4 v7, 0x1

    .line 1162
    goto :goto_26

    .line 1163
    :cond_3f
    move v7, v5

    .line 1164
    :goto_26
    add-int/lit8 v4, v4, 0x1

    .line 1165
    .line 1166
    goto :goto_27

    .line 1167
    :cond_40
    move v7, v5

    .line 1168
    const/4 v4, 0x0

    .line 1169
    :goto_27
    const/16 v8, 0x3a

    .line 1170
    .line 1171
    invoke-virtual {v0, v8}, Ljava/lang/String;->indexOf(I)I

    .line 1172
    .line 1173
    .line 1174
    move-result v8

    .line 1175
    if-ltz v8, :cond_42

    .line 1176
    .line 1177
    add-int/lit8 v3, v3, -0x1

    .line 1178
    .line 1179
    if-ge v8, v3, :cond_42

    .line 1180
    .line 1181
    invoke-virtual {v0, v4, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1182
    .line 1183
    .line 1184
    move-result-object v3

    .line 1185
    add-int/lit8 v8, v8, 0x1

    .line 1186
    .line 1187
    invoke-virtual {v0, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1188
    .line 1189
    .line 1190
    move-result-object v0

    .line 1191
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 1192
    .line 1193
    .line 1194
    move-result v4

    .line 1195
    if-lez v4, :cond_43

    .line 1196
    .line 1197
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1198
    .line 1199
    .line 1200
    move-result v4

    .line 1201
    if-lez v4, :cond_43

    .line 1202
    .line 1203
    :try_start_1
    invoke-static {v3}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 1204
    .line 1205
    .line 1206
    move-result v3

    .line 1207
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 1208
    .line 1209
    .line 1210
    move-result v0

    .line 1211
    const/4 v4, 0x0

    .line 1212
    cmpl-float v8, v3, v4

    .line 1213
    .line 1214
    if-lez v8, :cond_43

    .line 1215
    .line 1216
    cmpl-float v8, v0, v4

    .line 1217
    .line 1218
    if-lez v8, :cond_43

    .line 1219
    .line 1220
    const/4 v4, 0x1

    .line 1221
    if-ne v7, v4, :cond_41

    .line 1222
    .line 1223
    div-float/2addr v0, v3

    .line 1224
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 1225
    .line 1226
    .line 1227
    move-result v0

    .line 1228
    goto :goto_28

    .line 1229
    :cond_41
    div-float/2addr v3, v0

    .line 1230
    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    .line 1231
    .line 1232
    .line 1233
    move-result v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 1234
    :goto_28
    const/4 v3, 0x0

    .line 1235
    goto :goto_29

    .line 1236
    :cond_42
    invoke-virtual {v0, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1237
    .line 1238
    .line 1239
    move-result-object v0

    .line 1240
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1241
    .line 1242
    .line 1243
    move-result v3

    .line 1244
    if-lez v3, :cond_43

    .line 1245
    .line 1246
    :try_start_2
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 1247
    .line 1248
    .line 1249
    move-result v0
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    .line 1250
    goto :goto_28

    .line 1251
    :catch_1
    :cond_43
    const/4 v0, 0x0

    .line 1252
    goto :goto_28

    .line 1253
    :goto_29
    cmpl-float v4, v0, v3

    .line 1254
    .line 1255
    if-lez v4, :cond_44

    .line 1256
    .line 1257
    iput v0, v1, La/c6;->b:F

    .line 1258
    .line 1259
    iput v7, v1, La/c6;->J:I

    .line 1260
    .line 1261
    goto :goto_2b

    .line 1262
    :goto_2a
    iput v3, v1, La/c6;->b:F

    .line 1263
    .line 1264
    :cond_44
    :goto_2b
    iget v0, v14, La/rS;->v:F

    .line 1265
    .line 1266
    iget-object v3, v1, La/c6;->y6:[F

    .line 1267
    .line 1268
    const/4 v4, 0x0

    .line 1269
    aput v0, v3, v4

    .line 1270
    .line 1271
    iget v0, v14, La/rS;->s:F

    .line 1272
    .line 1273
    const/4 v4, 0x1

    .line 1274
    aput v0, v3, v4

    .line 1275
    .line 1276
    iget v0, v14, La/rS;->j:I

    .line 1277
    .line 1278
    iput v0, v1, La/c6;->rZ:I

    .line 1279
    .line 1280
    iget v0, v14, La/rS;->t:I

    .line 1281
    .line 1282
    iput v0, v1, La/c6;->B1:I

    .line 1283
    .line 1284
    iget v0, v14, La/rS;->FL:I

    .line 1285
    .line 1286
    if-ltz v0, :cond_45

    .line 1287
    .line 1288
    if-gt v0, v2, :cond_45

    .line 1289
    .line 1290
    iput v0, v1, La/c6;->R:I

    .line 1291
    .line 1292
    :cond_45
    iget v0, v14, La/rS;->n:I

    .line 1293
    .line 1294
    iget v2, v14, La/rS;->x:I

    .line 1295
    .line 1296
    iget v3, v14, La/rS;->o:I

    .line 1297
    .line 1298
    iget v7, v14, La/rS;->c:F

    .line 1299
    .line 1300
    iput v0, v1, La/c6;->L:I

    .line 1301
    .line 1302
    iput v2, v1, La/c6;->l:I

    .line 1303
    .line 1304
    const v2, 0x7fffffff

    .line 1305
    .line 1306
    .line 1307
    if-ne v3, v2, :cond_46

    .line 1308
    .line 1309
    const/4 v3, 0x0

    .line 1310
    :cond_46
    iput v3, v1, La/c6;->W:I

    .line 1311
    .line 1312
    iput v7, v1, La/c6;->q:F

    .line 1313
    .line 1314
    const/4 v3, 0x0

    .line 1315
    cmpl-float v8, v7, v3

    .line 1316
    .line 1317
    const/high16 v3, 0x3f800000    # 1.0f

    .line 1318
    .line 1319
    if-lez v8, :cond_47

    .line 1320
    .line 1321
    cmpg-float v7, v7, v3

    .line 1322
    .line 1323
    if-gez v7, :cond_47

    .line 1324
    .line 1325
    if-nez v0, :cond_47

    .line 1326
    .line 1327
    iput v6, v1, La/c6;->L:I

    .line 1328
    .line 1329
    :cond_47
    iget v0, v14, La/rS;->C:I

    .line 1330
    .line 1331
    iget v7, v14, La/rS;->g:I

    .line 1332
    .line 1333
    iget v8, v14, La/rS;->r:I

    .line 1334
    .line 1335
    iget v9, v14, La/rS;->B:F

    .line 1336
    .line 1337
    iput v0, v1, La/c6;->d:I

    .line 1338
    .line 1339
    iput v7, v1, La/c6;->F:I

    .line 1340
    .line 1341
    if-ne v8, v2, :cond_48

    .line 1342
    .line 1343
    const/4 v8, 0x0

    .line 1344
    :cond_48
    iput v8, v1, La/c6;->E:I

    .line 1345
    .line 1346
    iput v9, v1, La/c6;->S:F

    .line 1347
    .line 1348
    const/4 v2, 0x0

    .line 1349
    cmpl-float v2, v9, v2

    .line 1350
    .line 1351
    if-lez v2, :cond_49

    .line 1352
    .line 1353
    cmpg-float v2, v9, v3

    .line 1354
    .line 1355
    if-gez v2, :cond_49

    .line 1356
    .line 1357
    if-nez v0, :cond_49

    .line 1358
    .line 1359
    iput v6, v1, La/c6;->d:I

    .line 1360
    .line 1361
    :cond_49
    :goto_2c
    add-int/lit8 v15, v15, 0x1

    .line 1362
    .line 1363
    move/from16 v7, p1

    .line 1364
    .line 1365
    move/from16 v8, p2

    .line 1366
    .line 1367
    move v9, v6

    .line 1368
    move/from16 v14, v17

    .line 1369
    .line 1370
    move-object/from16 v6, p0

    .line 1371
    .line 1372
    goto/16 :goto_13

    .line 1373
    .line 1374
    :cond_4a
    if-eqz v12, :cond_4b

    .line 1375
    .line 1376
    iget-object v0, v11, La/p3;->NE:La/yW;

    .line 1377
    .line 1378
    invoke-virtual {v0, v11}, La/yW;->v(La/p3;)V

    .line 1379
    .line 1380
    .line 1381
    :cond_4b
    move-object/from16 v0, p0

    .line 1382
    .line 1383
    iget v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->F:I

    .line 1384
    .line 1385
    move/from16 v2, p1

    .line 1386
    .line 1387
    move/from16 v3, p2

    .line 1388
    .line 1389
    invoke-virtual {v0, v11, v1, v2, v3}, Landroidx/constraintlayout/widget/ConstraintLayout;->M(La/p3;III)V

    .line 1390
    .line 1391
    .line 1392
    invoke-virtual {v11}, La/c6;->K()I

    .line 1393
    .line 1394
    .line 1395
    move-result v1

    .line 1396
    invoke-virtual {v11}, La/c6;->T()I

    .line 1397
    .line 1398
    .line 1399
    move-result v4

    .line 1400
    iget-boolean v5, v11, La/p3;->AW:Z

    .line 1401
    .line 1402
    iget-boolean v6, v11, La/p3;->GI:Z

    .line 1403
    .line 1404
    iget-object v7, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->P:La/ka;

    .line 1405
    .line 1406
    iget v8, v7, La/ka;->e:I

    .line 1407
    .line 1408
    iget v7, v7, La/ka;->p:I

    .line 1409
    .line 1410
    add-int/2addr v1, v7

    .line 1411
    add-int/2addr v4, v8

    .line 1412
    const/4 v7, 0x0

    .line 1413
    invoke-static {v1, v2, v7}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 1414
    .line 1415
    .line 1416
    move-result v1

    .line 1417
    invoke-static {v4, v3, v7}, Landroid/view/View;->resolveSizeAndState(III)I

    .line 1418
    .line 1419
    .line 1420
    move-result v2

    .line 1421
    const v3, 0xffffff

    .line 1422
    .line 1423
    .line 1424
    and-int/2addr v1, v3

    .line 1425
    and-int/2addr v2, v3

    .line 1426
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:I

    .line 1427
    .line 1428
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    .line 1429
    .line 1430
    .line 1431
    move-result v1

    .line 1432
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->W:I

    .line 1433
    .line 1434
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    .line 1435
    .line 1436
    .line 1437
    move-result v2

    .line 1438
    const/high16 v3, 0x1000000

    .line 1439
    .line 1440
    if-eqz v5, :cond_4c

    .line 1441
    .line 1442
    or-int/2addr v1, v3

    .line 1443
    :cond_4c
    if-eqz v6, :cond_4d

    .line 1444
    .line 1445
    or-int/2addr v2, v3

    .line 1446
    :cond_4d
    invoke-virtual {v0, v1, v2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 1447
    .line 1448
    .line 1449
    return-void
.end method

.method public final onViewAdded(Landroid/view/View;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewAdded(Landroid/view/View;)V

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    move-result-object v0

    instance-of v1, p1, Landroidx/constraintlayout/widget/Guideline;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    instance-of v0, v0, La/Ou;

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, La/rS;

    new-instance v1, La/Ou;

    invoke-direct {v1}, La/Ou;-><init>()V

    iput-object v1, v0, La/rS;->Gy:La/c6;

    iput-boolean v2, v0, La/rS;->F9:Z

    iget v0, v0, La/rS;->b:I

    invoke-virtual {v1, v0}, La/Ou;->g(I)V

    :cond_0
    instance-of v0, p1, La/Sc;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, La/Sc;

    invoke-virtual {v0}, La/Sc;->T()V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, La/rS;

    iput-boolean v2, v1, La/rS;->eH:Z

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    invoke-virtual {v1, v0, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    return-void
.end method

.method public onViewRemoved(Landroid/view/View;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewRemoved(Landroid/view/View;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->O(Landroid/view/View;)La/c6;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->L:La/p3;

    .line 18
    .line 19
    iget-object v1, v1, La/tz;->Gy:Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, La/c6;->z()V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->R:Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x1

    .line 33
    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 34
    .line 35
    return-void
.end method

.method public final requestLayout()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->q:Z

    .line 3
    .line 4
    invoke-super {p0}, Landroid/view/ViewGroup;->requestLayout()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final setId(I)V
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->K:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setId(I)V

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result p1

    invoke-virtual {v1, p1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
