.class public final synthetic La/Kw;
.super La/cm;
.source "SourceFile"

# interfaces
.implements La/wv;


# static fields
.field public static final q:La/Kw;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v6, La/Kw;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    const-class v2, La/tC;

    .line 5
    .line 6
    const-string v3, "emit"

    .line 7
    .line 8
    const-string v4, "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    move-object v0, v6

    .line 12
    invoke-direct/range {v0 .. v5}, La/cm;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 13
    .line 14
    .line 15
    sput-object v6, La/Kw;->q:La/Kw;

    .line 16
    .line 17
    return-void
.end method
