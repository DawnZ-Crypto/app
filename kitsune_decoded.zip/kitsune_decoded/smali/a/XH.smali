.class public final La/XH;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public h:I

.field public w:I
