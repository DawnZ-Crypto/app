.class public final Lcom/topjohnwu/magisk/core/utils/NetworkObserver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/no;


# instance fields
.field public final X:Landroid/net/ConnectivityManager;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, La/hA;->w:Ljava/lang/Object;

    .line 5
    .line 6
    const-class v0, Landroid/net/ConnectivityManager;

    .line 7
    .line 8
    invoke-static {p1, v0}, La/Ex;->h(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroid/net/ConnectivityManager;

    .line 13
    .line 14
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;->X:Landroid/net/ConnectivityManager;

    .line 15
    .line 16
    new-instance v1, La/Z0;

    .line 17
    .line 18
    invoke-direct {v1, p0}, La/Z0;-><init>(Lcom/topjohnwu/magisk/core/utils/NetworkObserver;)V

    .line 19
    .line 20
    .line 21
    new-instance v2, La/iw;

    .line 22
    .line 23
    const/4 v3, 0x2

    .line 24
    invoke-direct {v2, v3, p0}, La/iw;-><init>(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v3, Landroid/net/NetworkRequest$Builder;

    .line 28
    .line 29
    invoke-direct {v3}, Landroid/net/NetworkRequest$Builder;-><init>()V

    .line 30
    .line 31
    .line 32
    const/16 v4, 0x10

    .line 33
    .line 34
    invoke-virtual {v3, v4}, Landroid/net/NetworkRequest$Builder;->addCapability(I)Landroid/net/NetworkRequest$Builder;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-virtual {v3}, Landroid/net/NetworkRequest$Builder;->build()Landroid/net/NetworkRequest;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-virtual {v0, v3, v1}, Landroid/net/ConnectivityManager;->registerNetworkCallback(Landroid/net/NetworkRequest;Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 43
    .line 44
    .line 45
    new-instance v0, Landroid/content/IntentFilter;

    .line 46
    .line 47
    const-string v1, "android.os.action.DEVICE_IDLE_MODE_CHANGED"

    .line 48
    .line 49
    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 57
    .line 58
    const/16 v3, 0x1a

    .line 59
    .line 60
    if-lt v1, v3, :cond_0

    .line 61
    .line 62
    invoke-static {p1, v2, v0}, La/p;->R(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_0
    invoke-virtual {p1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 67
    .line 68
    .line 69
    :goto_0
    sget-object p1, La/pL;->q:La/pL;

    .line 70
    .line 71
    iget-object p1, p1, La/pL;->f:Landroidx/lifecycle/w;

    .line 72
    .line 73
    invoke-virtual {p1, p0}, Landroidx/lifecycle/w;->w(La/IQ;)V

    .line 74
    .line 75
    .line 76
    return-void
.end method

.method public static V(Z)V
    .locals 1

    .line 1
    sget-object v0, La/Mv;->p:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 2
    .line 3
    sput-object v0, La/Mv;->e:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 4
    .line 5
    sget-object v0, La/Mv;->d:La/bc;

    .line 6
    .line 7
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {v0, p0}, La/bc;->M(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final O()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;->X:Landroid/net/ConnectivityManager;

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v0

    if-eqz v0, :cond_0

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;->V(Z)V

    return-void
.end method

.method public final synthetic X()V
    .locals 0

    .line 1
    return-void
.end method

.method public final synthetic e()V
    .locals 0

    .line 1
    return-void
.end method

.method public final synthetic h()V
    .locals 0

    .line 1
    return-void
.end method

.method public final synthetic i()V
    .locals 0

    .line 1
    return-void
.end method

.method public final p()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/topjohnwu/magisk/core/utils/NetworkObserver;->O()V

    return-void
.end method

.method public final synthetic w()V
    .locals 0

    .line 1
    return-void
.end method
