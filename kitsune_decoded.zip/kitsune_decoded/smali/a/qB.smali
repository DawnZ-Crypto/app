.class public abstract La/qB;
.super La/QW;
.source "SourceFile"


# virtual methods
.method public final e(La/QW;)V
    .locals 1

    .line 1
    instance-of v0, p1, La/qB;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iput-object p1, p0, La/QW;->w:La/QW;

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 9
    .line 10
    const-string v0, "Parent of block must also be block (can not be inline)"

    .line 11
    .line 12
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw p1
.end method

.method public final p()La/QW;
    .locals 1

    .line 1
    iget-object v0, p0, La/QW;->w:La/QW;

    .line 2
    .line 3
    check-cast v0, La/qB;

    .line 4
    .line 5
    return-object v0
.end method
