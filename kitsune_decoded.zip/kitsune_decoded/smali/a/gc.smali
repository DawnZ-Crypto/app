.class public final La/gc;
.super La/yG;
.source "SourceFile"

# interfaces
.implements La/Wb;


# instance fields
.field public synthetic d:Ljava/lang/Object;


# virtual methods
.method public final I(Ljava/lang/Object;La/hu;)La/hu;
    .locals 1

    .line 1
    new-instance v0, La/gc;

    .line 2
    .line 3
    invoke-direct {v0, p2}, La/yG;-><init>(La/hu;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, v0, La/gc;->d:Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public final O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p2, La/hu;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, La/gc;->I(Ljava/lang/Object;La/hu;)La/hu;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, La/gc;

    .line 8
    .line 9
    sget-object p2, La/rr;->w:La/rr;

    .line 10
    .line 11
    invoke-virtual {p1, p2}, La/gc;->T(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method

.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    invoke-static {p1}, La/rE;->OS(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La/gc;->d:Ljava/lang/Object;

    .line 5
    .line 6
    new-instance v0, La/WF;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {v0, p1, v1}, La/WF;-><init>(Ljava/lang/Object;La/hu;)V

    .line 10
    .line 11
    .line 12
    new-instance p1, La/Ii;

    .line 13
    .line 14
    invoke-direct {p1, v0}, La/Ii;-><init>(La/Wb;)V

    .line 15
    .line 16
    .line 17
    return-object p1
.end method
