.class Landroidx/fragment/app/Fragment$6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic X:La/zr;


# direct methods
.method public constructor <init>(La/zr;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/fragment/app/Fragment$6;->X:La/zr;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 0

    .line 1
    sget-object p1, La/cw;->ON_STOP:La/cw;

    .line 2
    .line 3
    if-ne p2, p1, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Landroidx/fragment/app/Fragment$6;->X:La/zr;

    .line 6
    .line 7
    iget-object p1, p1, La/zr;->B:Landroid/view/View;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/View;->cancelPendingInputEvents()V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method
