.class public abstract La/e0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final w:La/MG;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/MG;

    .line 2
    .line 3
    invoke-direct {v0}, La/k;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/e0;->w:La/MG;

    .line 7
    .line 8
    new-instance v0, La/OK;

    .line 9
    .line 10
    return-void
.end method
