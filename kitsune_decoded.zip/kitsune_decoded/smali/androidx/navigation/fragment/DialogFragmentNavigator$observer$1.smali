.class public final Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic X:La/cp;


# direct methods
.method public constructor <init>(La/cp;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;->X:La/cp;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 5

    .line 1
    sget-object v0, La/kB;->w:[I

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    aget p2, v0, p2

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    const/4 v1, 0x0

    .line 11
    iget-object v2, p0, Landroidx/navigation/fragment/DialogFragmentNavigator$observer$1;->X:La/cp;

    .line 12
    .line 13
    if-eq p2, v0, :cond_b

    .line 14
    .line 15
    const/4 v0, 0x2

    .line 16
    const/4 v3, 0x0

    .line 17
    if-eq p2, v0, :cond_8

    .line 18
    .line 19
    const/4 v0, 0x3

    .line 20
    if-eq p2, v0, :cond_4

    .line 21
    .line 22
    const/4 v0, 0x4

    .line 23
    if-eq p2, v0, :cond_0

    .line 24
    .line 25
    goto/16 :goto_4

    .line 26
    .line 27
    :cond_0
    check-cast p1, La/XM;

    .line 28
    .line 29
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    iget-object p2, p2, La/Ws;->Q:La/Zz;

    .line 34
    .line 35
    iget-object p2, p2, La/Zz;->X:La/Jk;

    .line 36
    .line 37
    invoke-interface {p2}, La/Jk;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p2

    .line 41
    check-cast p2, Ljava/lang/Iterable;

    .line 42
    .line 43
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    :cond_1
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    move-object v1, v0

    .line 58
    check-cast v1, La/GA;

    .line 59
    .line 60
    iget-object v1, v1, La/GA;->f:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v4, p1, La/zr;->n:Ljava/lang/String;

    .line 63
    .line 64
    invoke-static {v1, v4}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    if-eqz v1, :cond_1

    .line 69
    .line 70
    move-object v3, v0

    .line 71
    goto :goto_0

    .line 72
    :cond_2
    check-cast v3, La/GA;

    .line 73
    .line 74
    if-eqz v3, :cond_3

    .line 75
    .line 76
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 77
    .line 78
    .line 79
    move-result-object p2

    .line 80
    invoke-virtual {p2, v3}, La/Ws;->h(La/GA;)V

    .line 81
    .line 82
    .line 83
    :cond_3
    iget-object p1, p1, La/zr;->rV:Landroidx/lifecycle/w;

    .line 84
    .line 85
    invoke-virtual {p1, p0}, Landroidx/lifecycle/w;->h(La/IQ;)V

    .line 86
    .line 87
    .line 88
    goto/16 :goto_4

    .line 89
    .line 90
    :cond_4
    check-cast p1, La/XM;

    .line 91
    .line 92
    invoke-virtual {p1}, La/XM;->FL()Landroid/app/Dialog;

    .line 93
    .line 94
    .line 95
    move-result-object p2

    .line 96
    invoke-virtual {p2}, Landroid/app/Dialog;->isShowing()Z

    .line 97
    .line 98
    .line 99
    move-result p2

    .line 100
    if-nez p2, :cond_f

    .line 101
    .line 102
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    iget-object p2, p2, La/Ws;->i:La/Zz;

    .line 107
    .line 108
    iget-object p2, p2, La/Zz;->X:La/Jk;

    .line 109
    .line 110
    invoke-interface {p2}, La/Jk;->getValue()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    check-cast p2, Ljava/util/List;

    .line 115
    .line 116
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    invoke-interface {p2, v0}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    :cond_5
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 125
    .line 126
    .line 127
    move-result v3

    .line 128
    if-eqz v3, :cond_6

    .line 129
    .line 130
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    check-cast v3, La/GA;

    .line 135
    .line 136
    iget-object v3, v3, La/GA;->f:Ljava/lang/String;

    .line 137
    .line 138
    iget-object v4, p1, La/zr;->n:Ljava/lang/String;

    .line 139
    .line 140
    invoke-static {v3, v4}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v3

    .line 144
    if-eqz v3, :cond_5

    .line 145
    .line 146
    invoke-interface {v0}, Ljava/util/ListIterator;->nextIndex()I

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    goto :goto_1

    .line 151
    :cond_6
    const/4 v0, -0x1

    .line 152
    :goto_1
    invoke-static {v0, p2}, La/ar;->yV(ILjava/util/List;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v3

    .line 156
    check-cast v3, La/GA;

    .line 157
    .line 158
    invoke-static {p2}, La/ar;->Hy(Ljava/util/List;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object p2

    .line 162
    invoke-static {p2, v3}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result p2

    .line 166
    if-nez p2, :cond_7

    .line 167
    .line 168
    new-instance p2, Ljava/lang/StringBuilder;

    .line 169
    .line 170
    const-string v4, "Dialog "

    .line 171
    .line 172
    invoke-direct {p2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 176
    .line 177
    .line 178
    const-string p1, " was dismissed while it was not the top of the back stack, popping all dialogs above this dismissed dialog"

    .line 179
    .line 180
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    const-string p2, "DialogFragmentNavigator"

    .line 188
    .line 189
    invoke-static {p2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 190
    .line 191
    .line 192
    :cond_7
    if-eqz v3, :cond_f

    .line 193
    .line 194
    invoke-virtual {v2, v0, v3, v1}, La/cp;->T(ILa/GA;Z)V

    .line 195
    .line 196
    .line 197
    goto/16 :goto_4

    .line 198
    .line 199
    :cond_8
    check-cast p1, La/XM;

    .line 200
    .line 201
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 202
    .line 203
    .line 204
    move-result-object p2

    .line 205
    iget-object p2, p2, La/Ws;->Q:La/Zz;

    .line 206
    .line 207
    iget-object p2, p2, La/Zz;->X:La/Jk;

    .line 208
    .line 209
    invoke-interface {p2}, La/Jk;->getValue()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p2

    .line 213
    check-cast p2, Ljava/lang/Iterable;

    .line 214
    .line 215
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 216
    .line 217
    .line 218
    move-result-object p2

    .line 219
    :cond_9
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    if-eqz v0, :cond_a

    .line 224
    .line 225
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    move-object v1, v0

    .line 230
    check-cast v1, La/GA;

    .line 231
    .line 232
    iget-object v1, v1, La/GA;->f:Ljava/lang/String;

    .line 233
    .line 234
    iget-object v4, p1, La/zr;->n:Ljava/lang/String;

    .line 235
    .line 236
    invoke-static {v1, v4}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 237
    .line 238
    .line 239
    move-result v1

    .line 240
    if-eqz v1, :cond_9

    .line 241
    .line 242
    move-object v3, v0

    .line 243
    goto :goto_2

    .line 244
    :cond_a
    check-cast v3, La/GA;

    .line 245
    .line 246
    if-eqz v3, :cond_f

    .line 247
    .line 248
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    invoke-virtual {p1, v3}, La/Ws;->h(La/GA;)V

    .line 253
    .line 254
    .line 255
    goto :goto_4

    .line 256
    :cond_b
    check-cast p1, La/XM;

    .line 257
    .line 258
    invoke-virtual {v2}, La/Z5;->h()La/Ws;

    .line 259
    .line 260
    .line 261
    move-result-object p2

    .line 262
    iget-object p2, p2, La/Ws;->i:La/Zz;

    .line 263
    .line 264
    iget-object p2, p2, La/Zz;->X:La/Jk;

    .line 265
    .line 266
    invoke-interface {p2}, La/Jk;->getValue()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object p2

    .line 270
    check-cast p2, Ljava/lang/Iterable;

    .line 271
    .line 272
    instance-of v0, p2, Ljava/util/Collection;

    .line 273
    .line 274
    if-eqz v0, :cond_c

    .line 275
    .line 276
    move-object v0, p2

    .line 277
    check-cast v0, Ljava/util/Collection;

    .line 278
    .line 279
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 280
    .line 281
    .line 282
    move-result v0

    .line 283
    if-eqz v0, :cond_c

    .line 284
    .line 285
    goto :goto_3

    .line 286
    :cond_c
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 287
    .line 288
    .line 289
    move-result-object p2

    .line 290
    :cond_d
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 291
    .line 292
    .line 293
    move-result v0

    .line 294
    if-eqz v0, :cond_e

    .line 295
    .line 296
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v0

    .line 300
    check-cast v0, La/GA;

    .line 301
    .line 302
    iget-object v0, v0, La/GA;->f:Ljava/lang/String;

    .line 303
    .line 304
    iget-object v2, p1, La/zr;->n:Ljava/lang/String;

    .line 305
    .line 306
    invoke-static {v0, v2}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    if-eqz v0, :cond_d

    .line 311
    .line 312
    goto :goto_4

    .line 313
    :cond_e
    :goto_3
    invoke-virtual {p1, v1, v1}, La/XM;->G(ZZ)V

    .line 314
    .line 315
    .line 316
    :cond_f
    :goto_4
    return-void
.end method
