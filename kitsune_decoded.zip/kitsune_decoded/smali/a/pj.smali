.class public final La/pj;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/Zg;


# instance fields
.field public final K:I

.field public R:Ljava/lang/Integer;

.field public final X:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La/pj;->X:Ljava/lang/String;

    iput p1, p0, La/pj;->K:I

    return-void
.end method


# virtual methods
.method public final h(La/ac;I)V
    .locals 6

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    iput-object v0, p0, La/pj;->R:Ljava/lang/Integer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    monitor-exit p0

    .line 9
    new-instance v0, La/zT;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {v0, p1, p0, p2, v1}, La/zT;-><init>(La/ac;La/pj;ILa/hu;)V

    .line 13
    .line 14
    .line 15
    const/4 p1, 0x3

    .line 16
    const/4 p2, 0x1

    .line 17
    and-int/2addr p1, p2

    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    sget-object p1, La/nZ;->X:La/nZ;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    move-object p1, v1

    .line 24
    :goto_0
    const/4 v2, 0x3

    .line 25
    const/4 v3, 0x2

    .line 26
    and-int/2addr v2, v3

    .line 27
    if-eqz v2, :cond_1

    .line 28
    .line 29
    move v2, p2

    .line 30
    goto :goto_1

    .line 31
    :cond_1
    const/4 v2, 0x0

    .line 32
    :goto_1
    sget-object v4, La/nZ;->X:La/nZ;

    .line 33
    .line 34
    invoke-static {v4, p1, p2}, La/rE;->n(La/oj;La/oj;Z)La/oj;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    sget-object v4, La/Th;->w:La/Fu;

    .line 39
    .line 40
    if-eq p1, v4, :cond_2

    .line 41
    .line 42
    sget-object v5, La/Qr;->K:La/Qr;

    .line 43
    .line 44
    invoke-interface {p1, v5}, La/oj;->f(La/sE;)La/ol;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    if-nez v5, :cond_2

    .line 49
    .line 50
    invoke-interface {p1, v4}, La/oj;->I(La/oj;)La/oj;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    :cond_2
    if-eqz v2, :cond_4

    .line 55
    .line 56
    if-ne v2, v3, :cond_3

    .line 57
    .line 58
    new-instance p2, La/lc;

    .line 59
    .line 60
    invoke-direct {p2, p1, v0}, La/lc;-><init>(La/oj;La/Wb;)V

    .line 61
    .line 62
    .line 63
    goto :goto_2

    .line 64
    :cond_3
    new-instance v1, La/ve;

    .line 65
    .line 66
    invoke-direct {v1, p1, p2}, La/N;-><init>(La/oj;Z)V

    .line 67
    .line 68
    .line 69
    move-object p2, v1

    .line 70
    :goto_2
    invoke-virtual {p2, v2, p2, v0}, La/N;->Z(ILa/N;La/Wb;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_4
    throw v1

    .line 75
    :catchall_0
    move-exception p1

    .line 76
    monitor-exit p0

    .line 77
    throw p1
.end method

.method public final declared-synchronized w(La/ac;)Ljava/lang/Integer;
    .locals 2

    .line 1
    monitor-enter p0

    :try_start_0
    iget-object v0, p0, La/pj;->R:Ljava/lang/Integer;

    if-nez v0, :cond_0

    new-instance v0, La/re;

    const/4 v1, 0x0

    invoke-direct {v0, p1, p0, v1}, La/re;-><init>(La/ac;La/pj;La/hu;)V

    invoke-static {v0}, La/A8;->eH(La/Wb;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    iput-object p1, p0, La/pj;->R:Ljava/lang/Integer;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    iget-object p1, p0, La/pj;->R:Ljava/lang/Integer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :goto_1
    monitor-exit p0

    throw p1
.end method
