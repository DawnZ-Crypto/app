.class public final Lcom/topjohnwu/magisk/core/JobService;
.super La/PH;
.source "SourceFile"


# static fields
.field public static final synthetic K:I


# instance fields
.field public final X:La/gC;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La/gC;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, La/gC;-><init>(La/P7;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/JobService;->X:La/gC;

    .line 11
    .line 12
    return-void
.end method

.method public static final w(Lcom/topjohnwu/magisk/core/JobService;La/hu;)Ljava/lang/Object;
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    instance-of v0, p1, La/j6;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, La/j6;

    .line 10
    .line 11
    iget v1, v0, La/j6;->f:I

    .line 12
    .line 13
    const/high16 v2, -0x80000000

    .line 14
    .line 15
    and-int v3, v1, v2

    .line 16
    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    sub-int/2addr v1, v2

    .line 20
    iput v1, v0, La/j6;->f:I

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    new-instance v0, La/j6;

    .line 24
    .line 25
    invoke-direct {v0, p0, p1}, La/j6;-><init>(Lcom/topjohnwu/magisk/core/JobService;La/hu;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    iget-object p0, v0, La/j6;->L:Ljava/lang/Object;

    .line 29
    .line 30
    sget-object p1, La/cj;->X:La/cj;

    .line 31
    .line 32
    iget v1, v0, La/j6;->f:I

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    if-eqz v1, :cond_2

    .line 36
    .line 37
    if-ne v1, v2, :cond_1

    .line 38
    .line 39
    invoke-static {p0}, La/rE;->OS(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 44
    .line 45
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw p0

    .line 51
    :cond_2
    invoke-static {p0}, La/rE;->OS(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-static {}, La/uv;->h()La/Ot;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    iput v2, v0, La/j6;->f:I

    .line 59
    .line 60
    invoke-virtual {p0, v0}, La/Ot;->e(La/hu;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    if-ne p0, p1, :cond_3

    .line 65
    .line 66
    goto/16 :goto_5

    .line 67
    .line 68
    :cond_3
    :goto_1
    check-cast p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 69
    .line 70
    if-eqz p0, :cond_7

    .line 71
    .line 72
    sput-object p0, La/Mv;->e:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 73
    .line 74
    invoke-static {}, La/Mv;->w()La/uB;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    iget-boolean p1, p1, La/uB;->i:Z

    .line 79
    .line 80
    if-eqz p1, :cond_7

    .line 81
    .line 82
    iget-object p0, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->w:Lcom/topjohnwu/magisk/core/model/MagiskJson;

    .line 83
    .line 84
    iget p0, p0, Lcom/topjohnwu/magisk/core/model/MagiskJson;->K:I

    .line 85
    .line 86
    const/16 p1, 0x6979

    .line 87
    .line 88
    if-ge p1, p0, :cond_7

    .line 89
    .line 90
    sget-object p0, La/Ed;->w:La/Yi;

    .line 91
    .line 92
    sget-object p0, La/uv;->w:Landroid/content/Context;

    .line 93
    .line 94
    if-eqz p0, :cond_4

    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_4
    const/4 p0, 0x0

    .line 98
    :goto_2
    sget p1, Lcom/topjohnwu/magisk/core/download/DownloadService;->d:I

    .line 99
    .line 100
    new-instance p1, La/yX;

    .line 101
    .line 102
    invoke-direct {p1}, La/yX;-><init>()V

    .line 103
    .line 104
    .line 105
    invoke-static {p0, p1}, La/Qr;->u(Landroid/content/Context;La/Au;)Landroid/content/Intent;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 110
    .line 111
    const/16 v1, 0x1a

    .line 112
    .line 113
    if-lt v0, v1, :cond_5

    .line 114
    .line 115
    invoke-static {p0, p1}, La/p;->e(Landroid/content/Context;Landroid/content/Intent;)Landroid/app/PendingIntent;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    goto :goto_3

    .line 120
    :cond_5
    const/high16 v3, 0x4c000000    # 3.3554432E7f

    .line 121
    .line 122
    invoke-static {p0, v2, p1, v3}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    :goto_3
    const v3, 0x7f08010e

    .line 127
    .line 128
    .line 129
    invoke-static {p0, v3}, La/rE;->x(Landroid/content/Context;I)Landroid/graphics/Bitmap;

    .line 130
    .line 131
    .line 132
    move-result-object v4

    .line 133
    if-lt v0, v1, :cond_6

    .line 134
    .line 135
    invoke-static {p0}, La/p;->H(Landroid/content/Context;)Landroid/app/Notification$Builder;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {v4}, Landroid/graphics/drawable/Icon;->createWithBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setSmallIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    goto :goto_4

    .line 148
    :cond_6
    new-instance v0, Landroid/app/Notification$Builder;

    .line 149
    .line 150
    invoke-direct {v0, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v0, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    :goto_4
    invoke-virtual {v0, v4}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    const v1, 0x7f120092

    .line 162
    .line 163
    .line 164
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    const v1, 0x7f120093

    .line 173
    .line 174
    .line 175
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object p0

    .line 179
    invoke-virtual {v0, p0}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 180
    .line 181
    .line 182
    move-result-object p0

    .line 183
    invoke-virtual {p0, v2}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    invoke-virtual {p0, p1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    invoke-static {}, La/Ed;->w()Landroid/app/NotificationManager;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    const/4 v0, 0x5

    .line 196
    invoke-virtual {p0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 197
    .line 198
    .line 199
    move-result-object p0

    .line 200
    invoke-virtual {p1, v0, p0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 201
    .line 202
    .line 203
    :cond_7
    sget-object p1, La/rr;->w:La/rr;

    .line 204
    .line 205
    :goto_5
    return-object p1
.end method


# virtual methods
.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 3

    .line 1
    sget-object v0, La/Th;->h:La/Zs;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/JobService;->X:La/gC;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-static {v0, v1}, La/A8;->rV(La/oj;La/oj;)La/oj;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, La/rE;->w(La/oj;)La/gf;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    new-instance v1, La/oR;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-direct {v1, p0, p1, v2}, La/oR;-><init>(Lcom/topjohnwu/magisk/core/JobService;Landroid/app/job/JobParameters;La/hu;)V

    .line 20
    .line 21
    .line 22
    const/4 p1, 0x3

    .line 23
    invoke-static {v0, v2, v1, p1}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 24
    .line 25
    .line 26
    const/4 p1, 0x0

    .line 27
    return p1
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 1

    .line 1
    iget-object p1, p0, Lcom/topjohnwu/magisk/core/JobService;->X:La/gC;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p1, v0}, La/uH;->w(Ljava/util/concurrent/CancellationException;)V

    .line 5
    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    return p1
.end method
