.class public abstract La/Rk;
.super Landroid/widget/ImageButton;
.source "SourceFile"


# instance fields
.field public K:I


# virtual methods
.method public final p(IZ)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setVisibility(I)V

    if-eqz p2, :cond_0

    iput p1, p0, La/Rk;->K:I

    :cond_0
    return-void
.end method
