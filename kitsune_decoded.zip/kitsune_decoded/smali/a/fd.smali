.class public final La/fd;
.super La/c;
.source "SourceFile"


# instance fields
.field public final h:La/qB;

.field public final synthetic w:I


# direct methods
.method public constructor <init>(I)V
    .locals 1

    .line 1
    iput p1, p0, La/fd;->w:I

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p1, v0, :cond_1

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p1, v0, :cond_0

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance p1, La/v9;

    .line 13
    .line 14
    invoke-direct {p1}, La/QW;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, La/fd;->h:La/qB;

    .line 18
    .line 19
    return-void

    .line 20
    :cond_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    new-instance p1, La/Lh;

    .line 24
    .line 25
    invoke-direct {p1}, La/QW;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, La/fd;->h:La/qB;

    .line 29
    .line 30
    return-void

    .line 31
    :cond_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    new-instance p1, La/uz;

    .line 35
    .line 36
    invoke-direct {p1}, La/QW;-><init>()V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, La/fd;->h:La/qB;

    .line 40
    .line 41
    return-void
.end method

.method public static O(La/dW;I)Z
    .locals 2

    .line 1
    move-object v0, p0

    .line 2
    check-cast v0, La/Nl;

    .line 3
    .line 4
    iget-object v0, v0, La/Nl;->w:Ljava/lang/CharSequence;

    .line 5
    .line 6
    check-cast p0, La/Nl;

    .line 7
    .line 8
    iget p0, p0, La/Nl;->X:I

    .line 9
    .line 10
    const/4 v1, 0x4

    .line 11
    if-ge p0, v1, :cond_0

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-ge p1, p0, :cond_0

    .line 18
    .line 19
    invoke-interface {v0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    const/16 p1, 0x3e

    .line 24
    .line 25
    if-ne p0, p1, :cond_0

    .line 26
    .line 27
    const/4 p0, 0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 p0, 0x0

    .line 30
    :goto_0
    return p0
.end method


# virtual methods
.method public final X(La/dW;)La/d6;
    .locals 4

    .line 1
    iget v0, p0, La/fd;->w:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    return-object v1

    .line 8
    :pswitch_0
    check-cast p1, La/Nl;

    .line 9
    .line 10
    iget p1, p1, La/Nl;->h:I

    .line 11
    .line 12
    invoke-static {p1}, La/d6;->w(I)La/d6;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1

    .line 17
    :pswitch_1
    move-object v0, p1

    .line 18
    check-cast v0, La/Nl;

    .line 19
    .line 20
    iget v0, v0, La/Nl;->i:I

    .line 21
    .line 22
    invoke-static {p1, v0}, La/fd;->O(La/dW;I)Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_2

    .line 27
    .line 28
    check-cast p1, La/Nl;

    .line 29
    .line 30
    iget v1, p1, La/Nl;->p:I

    .line 31
    .line 32
    iget v2, p1, La/Nl;->X:I

    .line 33
    .line 34
    add-int/2addr v1, v2

    .line 35
    add-int/lit8 v2, v1, 0x1

    .line 36
    .line 37
    iget-object p1, p1, La/Nl;->w:Ljava/lang/CharSequence;

    .line 38
    .line 39
    add-int/lit8 v0, v0, 0x1

    .line 40
    .line 41
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-ge v0, v3, :cond_1

    .line 46
    .line 47
    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    const/16 v0, 0x9

    .line 52
    .line 53
    if-eq p1, v0, :cond_0

    .line 54
    .line 55
    const/16 v0, 0x20

    .line 56
    .line 57
    if-eq p1, v0, :cond_0

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    add-int/lit8 v2, v1, 0x2

    .line 61
    .line 62
    :cond_1
    :goto_0
    new-instance v1, La/d6;

    .line 63
    .line 64
    const/4 p1, -0x1

    .line 65
    const/4 v0, 0x0

    .line 66
    invoke-direct {v1, p1, v2, v0}, La/d6;-><init>(IIZ)V

    .line 67
    .line 68
    .line 69
    :cond_2
    return-object v1

    .line 70
    nop

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final e()La/qB;
    .locals 2

    .line 1
    iget v0, p0, La/fd;->w:I

    iget-object v1, p0, La/fd;->h:La/qB;

    packed-switch v0, :pswitch_data_0

    check-cast v1, La/Lh;

    return-object v1

    :pswitch_0
    check-cast v1, La/uz;

    return-object v1

    :pswitch_1
    check-cast v1, La/v9;

    return-object v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h(La/qB;)Z
    .locals 1

    .line 1
    iget p1, p0, La/fd;->w:I

    const/4 v0, 0x1

    packed-switch p1, :pswitch_data_0

    const/4 p1, 0x0

    return p1

    :pswitch_0
    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public final i()Z
    .locals 2

    .line 1
    iget v0, p0, La/fd;->w:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    instance-of v0, p0, La/yc;

    .line 8
    .line 9
    return v0

    .line 10
    :pswitch_0
    return v1

    .line 11
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    return-void
.end method
