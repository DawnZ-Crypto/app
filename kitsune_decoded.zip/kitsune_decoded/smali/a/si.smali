.class public final La/si;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/gr;


# instance fields
.field public final w:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, La/si;->w:Z

    return-void
.end method


# virtual methods
.method public final w(La/b7;)La/vL;
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-string v1, "Connection"

    .line 4
    .line 5
    const-string v2, "close"

    .line 6
    .line 7
    const-string v3, "HTTP "

    .line 8
    .line 9
    iget-object v4, v0, La/b7;->e:La/xw;

    .line 10
    .line 11
    iget-object v5, v0, La/b7;->i:La/EW;

    .line 12
    .line 13
    iget-object v0, v5, La/EW;->i:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, La/cc;

    .line 16
    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v6

    .line 21
    const/4 v8, 0x1

    .line 22
    const/4 v10, 0x0

    .line 23
    :try_start_0
    iget-object v11, v4, La/xw;->h:La/Qr;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_7

    .line 24
    .line 25
    iget-object v12, v4, La/xw;->e:La/DP;

    .line 26
    .line 27
    :try_start_1
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    invoke-interface {v12, v5}, La/DP;->w(La/EW;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_8

    .line 31
    .line 32
    .line 33
    :try_start_2
    iget-object v11, v5, La/EW;->p:Ljava/io/Serializable;

    .line 34
    .line 35
    check-cast v11, Ljava/lang/String;

    .line 36
    .line 37
    invoke-static {v11}, La/rx;->rC(Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result v11
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_7

    .line 41
    iget-object v13, v4, La/xw;->w:La/WO;

    .line 42
    .line 43
    iget-object v14, v4, La/xw;->h:La/Qr;

    .line 44
    .line 45
    if-eqz v11, :cond_3

    .line 46
    .line 47
    if-eqz v0, :cond_3

    .line 48
    .line 49
    :try_start_3
    const-string v11, "100-continue"

    .line 50
    .line 51
    const-string v15, "Expect"

    .line 52
    .line 53
    invoke-virtual {v5, v15}, La/EW;->Q(Ljava/lang/String;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v15

    .line 57
    invoke-static {v11, v15}, La/ge;->GI(Ljava/lang/String;Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result v11
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    .line 61
    if-eqz v11, :cond_0

    .line 62
    .line 63
    :try_start_4
    invoke-interface {v12}, La/DP;->i()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    .line 64
    .line 65
    .line 66
    :try_start_5
    invoke-virtual {v4, v8}, La/xw;->p(Z)La/Om;

    .line 67
    .line 68
    .line 69
    move-result-object v11
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_1

    .line 70
    :try_start_6
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_0

    .line 71
    .line 72
    .line 73
    move v15, v10

    .line 74
    goto :goto_1

    .line 75
    :catch_0
    move-exception v0

    .line 76
    :goto_0
    const/4 v9, 0x0

    .line 77
    goto/16 :goto_5

    .line 78
    .line 79
    :catch_1
    move-exception v0

    .line 80
    const/4 v9, 0x0

    .line 81
    const/4 v11, 0x0

    .line 82
    goto/16 :goto_5

    .line 83
    .line 84
    :catch_2
    move-exception v0

    .line 85
    move-object v11, v0

    .line 86
    :try_start_7
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v4, v11}, La/xw;->e(Ljava/io/IOException;)V

    .line 90
    .line 91
    .line 92
    throw v11
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1

    .line 93
    :cond_0
    move v15, v8

    .line 94
    const/4 v11, 0x0

    .line 95
    :goto_1
    if-nez v11, :cond_1

    .line 96
    .line 97
    :try_start_8
    iput-boolean v10, v4, La/xw;->i:Z

    .line 98
    .line 99
    iget-object v8, v5, La/EW;->i:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v8, La/cc;

    .line 102
    .line 103
    invoke-virtual {v8}, La/cc;->w()J

    .line 104
    .line 105
    .line 106
    move-result-wide v9

    .line 107
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    invoke-interface {v12, v5, v9, v10}, La/DP;->p(La/EW;J)La/id;

    .line 111
    .line 112
    .line 113
    move-result-object v8

    .line 114
    new-instance v13, La/hU;

    .line 115
    .line 116
    invoke-direct {v13, v4, v8, v9, v10}, La/hU;-><init>(La/xw;La/id;J)V

    .line 117
    .line 118
    .line 119
    new-instance v8, La/jM;

    .line 120
    .line 121
    invoke-direct {v8, v13}, La/jM;-><init>(La/id;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v0, v8}, La/cc;->p(La/cI;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v8}, La/jM;->close()V

    .line 128
    .line 129
    .line 130
    goto :goto_2

    .line 131
    :catch_3
    move-exception v0

    .line 132
    move v8, v15

    .line 133
    goto :goto_0

    .line 134
    :cond_1
    const/4 v9, 0x0

    .line 135
    invoke-virtual {v13, v4, v8, v10, v9}, La/WO;->V(La/xw;ZZLjava/io/IOException;)Ljava/io/IOException;

    .line 136
    .line 137
    .line 138
    iget-object v0, v4, La/xw;->X:La/A6;

    .line 139
    .line 140
    iget-object v0, v0, La/A6;->X:La/QO;

    .line 141
    .line 142
    if-eqz v0, :cond_2

    .line 143
    .line 144
    goto :goto_2

    .line 145
    :cond_2
    invoke-interface {v12}, La/DP;->X()La/A6;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-virtual {v0}, La/A6;->T()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_3

    .line 150
    .line 151
    .line 152
    :goto_2
    move v8, v15

    .line 153
    const/4 v9, 0x0

    .line 154
    goto :goto_3

    .line 155
    :cond_3
    const/4 v9, 0x0

    .line 156
    :try_start_9
    invoke-virtual {v13, v4, v8, v10, v9}, La/WO;->V(La/xw;ZZLjava/io/IOException;)Ljava/io/IOException;
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_6

    .line 157
    .line 158
    .line 159
    move-object v11, v9

    .line 160
    :goto_3
    :try_start_a
    invoke-interface {v12}, La/DP;->e()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_4

    .line 161
    .line 162
    .line 163
    move v10, v8

    .line 164
    move-object v8, v9

    .line 165
    goto :goto_6

    .line 166
    :catch_4
    move-exception v0

    .line 167
    move-object v10, v0

    .line 168
    :try_start_b
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v4, v10}, La/xw;->e(Ljava/io/IOException;)V

    .line 172
    .line 173
    .line 174
    throw v10
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_5

    .line 175
    :catch_5
    move-exception v0

    .line 176
    goto :goto_5

    .line 177
    :catch_6
    move-exception v0

    .line 178
    :goto_4
    move-object v11, v9

    .line 179
    goto :goto_5

    .line 180
    :catch_7
    move-exception v0

    .line 181
    const/4 v9, 0x0

    .line 182
    goto :goto_4

    .line 183
    :catch_8
    move-exception v0

    .line 184
    const/4 v9, 0x0

    .line 185
    :try_start_c
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v4, v0}, La/xw;->e(Ljava/io/IOException;)V

    .line 189
    .line 190
    .line 191
    throw v0
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_6

    .line 192
    :goto_5
    instance-of v10, v0, La/Bw;

    .line 193
    .line 194
    if-nez v10, :cond_12

    .line 195
    .line 196
    iget-boolean v10, v4, La/xw;->Q:Z

    .line 197
    .line 198
    if-eqz v10, :cond_11

    .line 199
    .line 200
    move v10, v8

    .line 201
    move-object v8, v0

    .line 202
    :goto_6
    if-nez v11, :cond_4

    .line 203
    .line 204
    const/4 v12, 0x0

    .line 205
    :try_start_d
    invoke-virtual {v4, v12}, La/xw;->p(Z)La/Om;

    .line 206
    .line 207
    .line 208
    move-result-object v11

    .line 209
    if-eqz v10, :cond_4

    .line 210
    .line 211
    iget-object v0, v4, La/xw;->h:La/Qr;

    .line 212
    .line 213
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 214
    .line 215
    .line 216
    const/4 v10, 0x0

    .line 217
    goto :goto_8

    .line 218
    :goto_7
    move-object/from16 v5, p0

    .line 219
    .line 220
    goto/16 :goto_d

    .line 221
    .line 222
    :catch_9
    move-exception v0

    .line 223
    goto :goto_7

    .line 224
    :cond_4
    :goto_8
    iput-object v5, v11, La/Om;->w:La/EW;

    .line 225
    .line 226
    iget-object v0, v4, La/xw;->X:La/A6;

    .line 227
    .line 228
    iget-object v0, v0, La/A6;->i:La/e4;

    .line 229
    .line 230
    iput-object v0, v11, La/Om;->i:La/e4;

    .line 231
    .line 232
    iput-wide v6, v11, La/Om;->M:J

    .line 233
    .line 234
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 235
    .line 236
    .line 237
    move-result-wide v12

    .line 238
    iput-wide v12, v11, La/Om;->T:J

    .line 239
    .line 240
    invoke-virtual {v11}, La/Om;->w()La/vL;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    iget v11, v0, La/vL;->L:I
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_9

    .line 245
    .line 246
    const/16 v12, 0x64

    .line 247
    .line 248
    iget-object v13, v4, La/xw;->h:La/Qr;

    .line 249
    .line 250
    if-ne v11, v12, :cond_5

    .line 251
    .line 252
    :goto_9
    const/4 v11, 0x0

    .line 253
    goto :goto_a

    .line 254
    :cond_5
    const/16 v12, 0x66

    .line 255
    .line 256
    if-gt v12, v11, :cond_7

    .line 257
    .line 258
    const/16 v12, 0xc8

    .line 259
    .line 260
    if-ge v11, v12, :cond_7

    .line 261
    .line 262
    goto :goto_9

    .line 263
    :goto_a
    :try_start_e
    invoke-virtual {v4, v11}, La/xw;->p(Z)La/Om;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    if-eqz v10, :cond_6

    .line 268
    .line 269
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    .line 271
    .line 272
    :cond_6
    iput-object v5, v0, La/Om;->w:La/EW;

    .line 273
    .line 274
    iget-object v5, v4, La/xw;->X:La/A6;

    .line 275
    .line 276
    iget-object v5, v5, La/A6;->i:La/e4;

    .line 277
    .line 278
    iput-object v5, v0, La/Om;->i:La/e4;

    .line 279
    .line 280
    iput-wide v6, v0, La/Om;->M:J

    .line 281
    .line 282
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 283
    .line 284
    .line 285
    move-result-wide v5

    .line 286
    iput-wide v5, v0, La/Om;->T:J

    .line 287
    .line 288
    invoke-virtual {v0}, La/Om;->w()La/vL;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    iget v11, v0, La/vL;->L:I

    .line 293
    .line 294
    :cond_7
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_e
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_9

    .line 295
    .line 296
    .line 297
    move-object/from16 v5, p0

    .line 298
    .line 299
    :try_start_f
    iget-boolean v6, v5, La/si;->w:Z

    .line 300
    .line 301
    if-eqz v6, :cond_8

    .line 302
    .line 303
    const/16 v6, 0x65

    .line 304
    .line 305
    if-ne v11, v6, :cond_8

    .line 306
    .line 307
    invoke-virtual {v0}, La/vL;->I()La/Om;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    sget-object v6, La/kD;->p:La/ob;

    .line 312
    .line 313
    iput-object v6, v0, La/Om;->X:La/ax;

    .line 314
    .line 315
    invoke-virtual {v0}, La/Om;->w()La/vL;

    .line 316
    .line 317
    .line 318
    move-result-object v0

    .line 319
    goto :goto_b

    .line 320
    :catch_a
    move-exception v0

    .line 321
    goto/16 :goto_d

    .line 322
    .line 323
    :cond_8
    invoke-virtual {v0}, La/vL;->I()La/Om;

    .line 324
    .line 325
    .line 326
    move-result-object v6

    .line 327
    invoke-virtual {v4, v0}, La/xw;->h(La/vL;)La/ob;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    iput-object v0, v6, La/Om;->X:La/ax;

    .line 332
    .line 333
    invoke-virtual {v6}, La/Om;->w()La/vL;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    :goto_b
    iget-object v6, v0, La/vL;->X:La/EW;

    .line 338
    .line 339
    invoke-virtual {v6, v1}, La/EW;->Q(Ljava/lang/String;)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v6

    .line 343
    invoke-static {v2, v6}, La/ge;->GI(Ljava/lang/String;Ljava/lang/String;)Z

    .line 344
    .line 345
    .line 346
    move-result v6

    .line 347
    if-nez v6, :cond_a

    .line 348
    .line 349
    iget-object v6, v0, La/vL;->f:La/Sa;

    .line 350
    .line 351
    invoke-virtual {v6, v1}, La/Sa;->h(Ljava/lang/String;)Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    if-nez v1, :cond_9

    .line 356
    .line 357
    move-object v1, v9

    .line 358
    :cond_9
    invoke-static {v2, v1}, La/ge;->GI(Ljava/lang/String;Ljava/lang/String;)Z

    .line 359
    .line 360
    .line 361
    move-result v1

    .line 362
    if-eqz v1, :cond_b

    .line 363
    .line 364
    :cond_a
    iget-object v1, v4, La/xw;->e:La/DP;

    .line 365
    .line 366
    invoke-interface {v1}, La/DP;->X()La/A6;

    .line 367
    .line 368
    .line 369
    move-result-object v1

    .line 370
    invoke-virtual {v1}, La/A6;->T()V

    .line 371
    .line 372
    .line 373
    :cond_b
    const/16 v1, 0xcc

    .line 374
    .line 375
    if-eq v11, v1, :cond_c

    .line 376
    .line 377
    const/16 v1, 0xcd

    .line 378
    .line 379
    if-ne v11, v1, :cond_f

    .line 380
    .line 381
    :cond_c
    iget-object v1, v0, La/vL;->l:La/ax;

    .line 382
    .line 383
    if-eqz v1, :cond_d

    .line 384
    .line 385
    invoke-virtual {v1}, La/ax;->w()J

    .line 386
    .line 387
    .line 388
    move-result-wide v1

    .line 389
    goto :goto_c

    .line 390
    :cond_d
    const-wide/16 v1, -0x1

    .line 391
    .line 392
    :goto_c
    const-wide/16 v6, 0x0

    .line 393
    .line 394
    cmp-long v1, v1, v6

    .line 395
    .line 396
    if-lez v1, :cond_f

    .line 397
    .line 398
    new-instance v1, Ljava/net/ProtocolException;

    .line 399
    .line 400
    new-instance v2, Ljava/lang/StringBuilder;

    .line 401
    .line 402
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 406
    .line 407
    .line 408
    const-string v3, " had non-zero Content-Length: "

    .line 409
    .line 410
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 411
    .line 412
    .line 413
    iget-object v0, v0, La/vL;->l:La/ax;

    .line 414
    .line 415
    if-eqz v0, :cond_e

    .line 416
    .line 417
    invoke-virtual {v0}, La/ax;->w()J

    .line 418
    .line 419
    .line 420
    move-result-wide v3

    .line 421
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 422
    .line 423
    .line 424
    move-result-object v9

    .line 425
    :cond_e
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 426
    .line 427
    .line 428
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v0

    .line 432
    invoke-direct {v1, v0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    throw v1
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_f} :catch_a

    .line 436
    :cond_f
    return-object v0

    .line 437
    :goto_d
    if-eqz v8, :cond_10

    .line 438
    .line 439
    invoke-static {v8, v0}, La/rE;->e(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 440
    .line 441
    .line 442
    throw v8

    .line 443
    :cond_10
    throw v0

    .line 444
    :cond_11
    move-object/from16 v5, p0

    .line 445
    .line 446
    throw v0

    .line 447
    :cond_12
    move-object/from16 v5, p0

    .line 448
    .line 449
    throw v0
.end method
