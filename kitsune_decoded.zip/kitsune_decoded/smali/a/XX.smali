.class public final La/XX;
.super La/lf;
.source "SourceFile"


# instance fields
.field public final B:Landroid/widget/ProgressBar;

.field public final N:La/JF;

.field public Z:La/JO;

.field public b:J

.field public final c:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 11

    .line 1
    const/4 v1, 0x0

    .line 2
    const/16 v0, 0x8

    .line 3
    .line 4
    const/4 v8, 0x0

    .line 5
    invoke-static {p1, v0, v8, v8}, Landroidx/databinding/w;->m(Landroid/view/View;ILa/yW;Landroid/util/SparseIntArray;)[Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v9

    .line 9
    const/4 v0, 0x1

    .line 10
    aget-object v0, v9, v0

    .line 11
    .line 12
    move-object v3, v0

    .line 13
    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 14
    .line 15
    const/4 v0, 0x5

    .line 16
    aget-object v0, v9, v0

    .line 17
    .line 18
    move-object v4, v0

    .line 19
    check-cast v4, Lcom/topjohnwu/widget/IndeterminateCheckBox;

    .line 20
    .line 21
    const/4 v0, 0x2

    .line 22
    aget-object v0, v9, v0

    .line 23
    .line 24
    move-object v5, v0

    .line 25
    check-cast v5, Landroid/widget/ImageView;

    .line 26
    .line 27
    const/4 v0, 0x3

    .line 28
    aget-object v0, v9, v0

    .line 29
    .line 30
    move-object v6, v0

    .line 31
    check-cast v6, Landroid/widget/TextView;

    .line 32
    .line 33
    const/4 v10, 0x4

    .line 34
    aget-object v0, v9, v10

    .line 35
    .line 36
    move-object v7, v0

    .line 37
    check-cast v7, Landroid/widget/TextView;

    .line 38
    .line 39
    move-object v0, p0

    .line 40
    move-object v2, p1

    .line 41
    invoke-direct/range {v0 .. v7}, La/lf;-><init>(Ljava/lang/Object;Landroid/view/View;Landroidx/constraintlayout/widget/ConstraintLayout;Lcom/topjohnwu/widget/IndeterminateCheckBox;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 42
    .line 43
    .line 44
    new-instance v0, La/JF;

    .line 45
    .line 46
    invoke-direct {v0, p0, v10}, La/JF;-><init>(Landroidx/databinding/w;I)V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, La/XX;->N:La/JF;

    .line 50
    .line 51
    const-wide/16 v0, -0x1

    .line 52
    .line 53
    iput-wide v0, p0, La/XX;->b:J

    .line 54
    .line 55
    iget-object v0, p0, La/lf;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 56
    .line 57
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iget-object v0, p0, La/lf;->n:Lcom/topjohnwu/widget/IndeterminateCheckBox;

    .line 61
    .line 62
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    iget-object v0, p0, La/lf;->C:Landroid/widget/ImageView;

    .line 66
    .line 67
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iget-object v0, p0, La/lf;->x:Landroid/widget/TextView;

    .line 71
    .line 72
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    iget-object v0, p0, La/lf;->g:Landroid/widget/TextView;

    .line 76
    .line 77
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    const/4 v0, 0x0

    .line 81
    aget-object v0, v9, v0

    .line 82
    .line 83
    check-cast v0, Lcom/google/android/material/card/MaterialCardView;

    .line 84
    .line 85
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    const/4 v0, 0x6

    .line 89
    aget-object v0, v9, v0

    .line 90
    .line 91
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 92
    .line 93
    iput-object v0, p0, La/XX;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 94
    .line 95
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    const/4 v0, 0x7

    .line 99
    aget-object v0, v9, v0

    .line 100
    .line 101
    check-cast v0, Landroid/widget/ProgressBar;

    .line 102
    .line 103
    iput-object v0, p0, La/XX;->B:Landroid/widget/ProgressBar;

    .line 104
    .line 105
    invoke-virtual {v0, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    const v0, 0x7f0900a5

    .line 109
    .line 110
    .line 111
    invoke-virtual {p1, v0, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {p0}, La/XX;->M()V

    .line 115
    .line 116
    .line 117
    return-void
.end method


# virtual methods
.method public final I()Z
    .locals 4

    .line 1
    monitor-enter p0

    :try_start_0
    iget-wide v0, p0, La/XX;->b:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_0

    monitor-exit p0

    const/4 v0, 0x1

    return v0

    :catchall_0
    move-exception v0

    goto :goto_0

    :cond_0
    monitor-exit p0

    const/4 v0, 0x0

    return v0

    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public final M()V
    .locals 2

    .line 1
    monitor-enter p0

    const-wide/16 v0, 0x20

    :try_start_0
    iput-wide v0, p0, La/XX;->b:J

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroidx/databinding/w;->R()V

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final W(I)Z
    .locals 5

    .line 1
    const/4 v0, 0x1

    if-nez p1, :cond_0

    monitor-enter p0

    :try_start_0
    iget-wide v1, p0, La/XX;->b:J

    const-wide/16 v3, 0x1

    or-long/2addr v1, v3

    iput-wide v1, p0, La/XX;->b:J

    monitor-exit p0

    return v0

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1

    :cond_0
    const/16 v1, 0x24

    if-ne p1, v1, :cond_1

    monitor-enter p0

    :try_start_1
    iget-wide v1, p0, La/XX;->b:J

    const-wide/16 v3, 0x4

    or-long/2addr v1, v3

    iput-wide v1, p0, La/XX;->b:J

    monitor-exit p0

    return v0

    :catchall_1
    move-exception p1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw p1

    :cond_1
    const/16 v1, 0xb

    if-ne p1, v1, :cond_2

    monitor-enter p0

    :try_start_2
    iget-wide v1, p0, La/XX;->b:J

    const-wide/16 v3, 0x8

    or-long/2addr v1, v3

    iput-wide v1, p0, La/XX;->b:J

    monitor-exit p0

    return v0

    :catchall_2
    move-exception p1

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    throw p1

    :cond_2
    const/4 v1, 0x5

    if-ne p1, v1, :cond_3

    monitor-enter p0

    :try_start_3
    iget-wide v1, p0, La/XX;->b:J

    const-wide/16 v3, 0x10

    or-long/2addr v1, v3

    iput-wide v1, p0, La/XX;->b:J

    monitor-exit p0

    return v0

    :catchall_3
    move-exception p1

    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    throw p1

    :cond_3
    const/4 p1, 0x0

    return p1
.end method

.method public final d(ILjava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x14

    .line 3
    .line 4
    if-ne v1, p1, :cond_0

    .line 5
    .line 6
    check-cast p2, La/Dn;

    .line 7
    .line 8
    invoke-virtual {p0, v0, p2}, Landroidx/databinding/w;->f(ILa/hc;)V

    .line 9
    .line 10
    .line 11
    iput-object p2, p0, La/lf;->o:La/Dn;

    .line 12
    .line 13
    monitor-enter p0

    .line 14
    :try_start_0
    iget-wide p1, p0, La/XX;->b:J

    .line 15
    .line 16
    const-wide/16 v2, 0x1

    .line 17
    .line 18
    or-long/2addr p1, v2

    .line 19
    iput-wide p1, p0, La/XX;->b:J

    .line 20
    .line 21
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    invoke-virtual {p0, v1}, La/sW;->Q(I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p0}, Landroidx/databinding/w;->R()V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :catchall_0
    move-exception p1

    .line 30
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    throw p1

    .line 32
    :cond_0
    const/16 v1, 0x2b

    .line 33
    .line 34
    if-ne v1, p1, :cond_1

    .line 35
    .line 36
    check-cast p2, La/JI;

    .line 37
    .line 38
    invoke-virtual {p0, p2}, La/XX;->q(La/JI;)V

    .line 39
    .line 40
    .line 41
    :goto_0
    const/4 v0, 0x1

    .line 42
    :cond_1
    return v0
.end method

.method public final i()V
    .locals 29

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    monitor-enter p0

    .line 4
    :try_start_0
    iget-wide v2, v1, La/XX;->b:J

    .line 5
    .line 6
    const-wide/16 v4, 0x0

    .line 7
    .line 8
    iput-wide v4, v1, La/XX;->b:J

    .line 9
    .line 10
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    iget-object v0, v1, La/lf;->o:La/Dn;

    .line 12
    .line 13
    iget-object v6, v1, La/lf;->r:La/JI;

    .line 14
    .line 15
    const-wide/16 v7, 0x3f

    .line 16
    .line 17
    and-long/2addr v7, v2

    .line 18
    cmp-long v7, v7, v4

    .line 19
    .line 20
    const-wide/16 v11, 0x29

    .line 21
    .line 22
    const-wide/16 v13, 0x25

    .line 23
    .line 24
    const-wide/16 v15, 0x21

    .line 25
    .line 26
    const-wide/16 v17, 0x23

    .line 27
    .line 28
    const/16 v19, 0x0

    .line 29
    .line 30
    const/16 v20, 0x0

    .line 31
    .line 32
    if-eqz v7, :cond_b

    .line 33
    .line 34
    and-long v21, v2, v17

    .line 35
    .line 36
    cmp-long v7, v21, v4

    .line 37
    .line 38
    if-eqz v7, :cond_0

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v7, v0, La/Dn;->R:Ljava/util/ArrayList;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move-object/from16 v7, v20

    .line 46
    .line 47
    :goto_0
    and-long v21, v2, v15

    .line 48
    .line 49
    cmp-long v21, v21, v4

    .line 50
    .line 51
    if-eqz v21, :cond_4

    .line 52
    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    iget-object v8, v0, La/Dn;->K:La/kr;

    .line 56
    .line 57
    iget-object v15, v1, La/XX;->Z:La/JO;

    .line 58
    .line 59
    if-nez v15, :cond_1

    .line 60
    .line 61
    new-instance v15, La/JO;

    .line 62
    .line 63
    invoke-direct {v15}, La/JO;-><init>()V

    .line 64
    .line 65
    .line 66
    iput-object v15, v1, La/XX;->Z:La/JO;

    .line 67
    .line 68
    :cond_1
    iput-object v0, v15, La/JO;->K:Ljava/lang/Object;

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_2
    move-object/from16 v8, v20

    .line 72
    .line 73
    move-object v15, v8

    .line 74
    :goto_1
    if-eqz v8, :cond_3

    .line 75
    .line 76
    iget-object v9, v8, La/kr;->L:Landroid/graphics/drawable/Drawable;

    .line 77
    .line 78
    iget-object v10, v8, La/kr;->R:Ljava/lang/String;

    .line 79
    .line 80
    iget-object v8, v8, La/kr;->X:Landroid/content/pm/ApplicationInfo;

    .line 81
    .line 82
    iget-object v8, v8, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    .line 83
    .line 84
    goto :goto_2

    .line 85
    :cond_3
    move-object/from16 v8, v20

    .line 86
    .line 87
    move-object v9, v8

    .line 88
    move-object v10, v9

    .line 89
    goto :goto_2

    .line 90
    :cond_4
    move-object/from16 v8, v20

    .line 91
    .line 92
    move-object v9, v8

    .line 93
    move-object v10, v9

    .line 94
    move-object v15, v10

    .line 95
    :goto_2
    and-long v25, v2, v13

    .line 96
    .line 97
    cmp-long v16, v25, v4

    .line 98
    .line 99
    if-eqz v16, :cond_5

    .line 100
    .line 101
    if-eqz v0, :cond_5

    .line 102
    .line 103
    iget-object v13, v0, La/Dn;->f:Ljava/lang/Boolean;

    .line 104
    .line 105
    goto :goto_3

    .line 106
    :cond_5
    move-object/from16 v13, v20

    .line 107
    .line 108
    :goto_3
    and-long v27, v2, v11

    .line 109
    .line 110
    cmp-long v14, v27, v4

    .line 111
    .line 112
    if-eqz v14, :cond_6

    .line 113
    .line 114
    if-eqz v0, :cond_6

    .line 115
    .line 116
    iget-boolean v14, v0, La/Dn;->L:Z

    .line 117
    .line 118
    :goto_4
    const-wide/16 v23, 0x31

    .line 119
    .line 120
    goto :goto_5

    .line 121
    :cond_6
    move/from16 v14, v19

    .line 122
    .line 123
    goto :goto_4

    .line 124
    :goto_5
    and-long v27, v2, v23

    .line 125
    .line 126
    cmp-long v16, v27, v4

    .line 127
    .line 128
    if-eqz v16, :cond_a

    .line 129
    .line 130
    if-eqz v0, :cond_8

    .line 131
    .line 132
    iget v11, v0, La/Dn;->d:I

    .line 133
    .line 134
    int-to-float v11, v11

    .line 135
    iget-object v0, v0, La/Dn;->R:Ljava/util/ArrayList;

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    int-to-float v0, v0

    .line 142
    div-float/2addr v11, v0

    .line 143
    const/16 v0, 0x64

    .line 144
    .line 145
    int-to-float v0, v0

    .line 146
    mul-float/2addr v11, v0

    .line 147
    invoke-static {v11}, Ljava/lang/Float;->isNaN(F)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-nez v0, :cond_7

    .line 152
    .line 153
    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    goto :goto_6

    .line 158
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 159
    .line 160
    const-string v2, "Cannot round NaN value."

    .line 161
    .line 162
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    throw v0

    .line 166
    :cond_8
    move/from16 v0, v19

    .line 167
    .line 168
    :goto_6
    if-nez v0, :cond_9

    .line 169
    .line 170
    const/16 v19, 0x1

    .line 171
    .line 172
    :cond_9
    move v11, v0

    .line 173
    move/from16 v0, v19

    .line 174
    .line 175
    goto :goto_7

    .line 176
    :cond_a
    move/from16 v0, v19

    .line 177
    .line 178
    move v11, v0

    .line 179
    goto :goto_7

    .line 180
    :cond_b
    move/from16 v0, v19

    .line 181
    .line 182
    move v11, v0

    .line 183
    move v14, v11

    .line 184
    move-object/from16 v7, v20

    .line 185
    .line 186
    move-object v8, v7

    .line 187
    move-object v9, v8

    .line 188
    move-object v10, v9

    .line 189
    move-object v13, v10

    .line 190
    move-object v15, v13

    .line 191
    :goto_7
    and-long v16, v2, v17

    .line 192
    .line 193
    cmp-long v12, v16, v4

    .line 194
    .line 195
    if-eqz v12, :cond_c

    .line 196
    .line 197
    if-eqz v6, :cond_c

    .line 198
    .line 199
    iget-object v6, v6, La/JI;->E:Landroid/util/SparseArray;

    .line 200
    .line 201
    :goto_8
    const-wide/16 v16, 0x21

    .line 202
    .line 203
    goto :goto_9

    .line 204
    :cond_c
    move-object/from16 v6, v20

    .line 205
    .line 206
    goto :goto_8

    .line 207
    :goto_9
    and-long v16, v2, v16

    .line 208
    .line 209
    cmp-long v16, v16, v4

    .line 210
    .line 211
    if-eqz v16, :cond_d

    .line 212
    .line 213
    iget-object v4, v1, La/lf;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 214
    .line 215
    invoke-virtual {v4, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 216
    .line 217
    .line 218
    iget-object v4, v1, La/lf;->C:Landroid/widget/ImageView;

    .line 219
    .line 220
    invoke-virtual {v4, v9}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 221
    .line 222
    .line 223
    iget-object v4, v1, La/lf;->x:Landroid/widget/TextView;

    .line 224
    .line 225
    invoke-static {v4, v10}, La/A8;->B1(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    .line 226
    .line 227
    .line 228
    iget-object v4, v1, La/lf;->g:Landroid/widget/TextView;

    .line 229
    .line 230
    invoke-static {v4, v8}, La/A8;->B1(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    .line 231
    .line 232
    .line 233
    :cond_d
    const-wide/16 v4, 0x25

    .line 234
    .line 235
    and-long/2addr v4, v2

    .line 236
    const-wide/16 v8, 0x0

    .line 237
    .line 238
    cmp-long v4, v4, v8

    .line 239
    .line 240
    if-eqz v4, :cond_f

    .line 241
    .line 242
    iget-object v4, v1, La/lf;->n:Lcom/topjohnwu/widget/IndeterminateCheckBox;

    .line 243
    .line 244
    invoke-virtual {v4}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->X()Ljava/lang/Boolean;

    .line 245
    .line 246
    .line 247
    move-result-object v5

    .line 248
    invoke-static {v5, v13}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    if-nez v5, :cond_f

    .line 253
    .line 254
    if-eqz v13, :cond_e

    .line 255
    .line 256
    invoke-virtual {v13}, Ljava/lang/Boolean;->booleanValue()Z

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    invoke-virtual {v4, v5}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->setChecked(Z)V

    .line 261
    .line 262
    .line 263
    goto :goto_a

    .line 264
    :cond_e
    const/4 v5, 0x1

    .line 265
    invoke-virtual {v4, v5, v5}, Lcom/topjohnwu/widget/IndeterminateCheckBox;->V(ZZ)V

    .line 266
    .line 267
    .line 268
    :cond_f
    :goto_a
    const-wide/16 v4, 0x20

    .line 269
    .line 270
    and-long/2addr v4, v2

    .line 271
    const-wide/16 v8, 0x0

    .line 272
    .line 273
    cmp-long v4, v4, v8

    .line 274
    .line 275
    if-eqz v4, :cond_10

    .line 276
    .line 277
    iget-object v4, v1, La/lf;->n:Lcom/topjohnwu/widget/IndeterminateCheckBox;

    .line 278
    .line 279
    iget-object v5, v1, La/XX;->N:La/JF;

    .line 280
    .line 281
    new-instance v8, La/Mq;

    .line 282
    .line 283
    const/4 v9, 0x4

    .line 284
    invoke-direct {v8, v9, v5}, La/Mq;-><init>(ILjava/lang/Object;)V

    .line 285
    .line 286
    .line 287
    iput-object v8, v4, Lcom/topjohnwu/widget/IndeterminateCheckBox;->B:La/Mq;

    .line 288
    .line 289
    :cond_10
    const-wide/16 v4, 0x29

    .line 290
    .line 291
    and-long/2addr v4, v2

    .line 292
    const-wide/16 v8, 0x0

    .line 293
    .line 294
    cmp-long v4, v4, v8

    .line 295
    .line 296
    if-eqz v4, :cond_11

    .line 297
    .line 298
    iget-object v4, v1, La/XX;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 299
    .line 300
    invoke-static {v4, v14}, La/rx;->cM(Landroid/view/View;Z)V

    .line 301
    .line 302
    .line 303
    :cond_11
    if-eqz v12, :cond_12

    .line 304
    .line 305
    iget-object v4, v1, La/XX;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 306
    .line 307
    invoke-static {v4, v7, v6}, La/A8;->mh(Landroidx/recyclerview/widget/RecyclerView;Ljava/util/List;Landroid/util/SparseArray;)V

    .line 308
    .line 309
    .line 310
    :cond_12
    const-wide/16 v4, 0x31

    .line 311
    .line 312
    and-long/2addr v2, v4

    .line 313
    const-wide/16 v4, 0x0

    .line 314
    .line 315
    cmp-long v2, v2, v4

    .line 316
    .line 317
    if-eqz v2, :cond_13

    .line 318
    .line 319
    iget-object v2, v1, La/XX;->B:Landroid/widget/ProgressBar;

    .line 320
    .line 321
    invoke-static {v2, v0}, La/rx;->an(Landroid/view/View;Z)V

    .line 322
    .line 323
    .line 324
    iget-object v0, v1, La/XX;->B:Landroid/widget/ProgressBar;

    .line 325
    .line 326
    invoke-virtual {v0, v11}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 327
    .line 328
    .line 329
    :cond_13
    return-void

    .line 330
    :catchall_0
    move-exception v0

    .line 331
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 332
    throw v0
.end method

.method public final q(La/JI;)V
    .locals 4

    .line 1
    const/4 v0, 0x1

    invoke-virtual {p0, v0, p1}, Landroidx/databinding/w;->f(ILa/hc;)V

    iput-object p1, p0, La/lf;->r:La/JI;

    monitor-enter p0

    :try_start_0
    iget-wide v0, p0, La/XX;->b:J

    const-wide/16 v2, 0x2

    or-long/2addr v0, v2

    iput-wide v0, p0, La/XX;->b:J

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 p1, 0x2b

    invoke-virtual {p0, p1}, La/sW;->Q(I)V

    invoke-virtual {p0}, Landroidx/databinding/w;->R()V

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final y(IILjava/lang/Object;)Z
    .locals 4

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    const/4 v1, 0x1

    .line 5
    if-eq p1, v1, :cond_0

    .line 6
    .line 7
    return v0

    .line 8
    :cond_0
    check-cast p3, La/JI;

    .line 9
    .line 10
    if-nez p2, :cond_1

    .line 11
    .line 12
    monitor-enter p0

    .line 13
    :try_start_0
    iget-wide p1, p0, La/XX;->b:J

    .line 14
    .line 15
    const-wide/16 v2, 0x2

    .line 16
    .line 17
    or-long/2addr p1, v2

    .line 18
    iput-wide p1, p0, La/XX;->b:J

    .line 19
    .line 20
    monitor-exit p0

    .line 21
    move v0, v1

    .line 22
    goto :goto_0

    .line 23
    :catchall_0
    move-exception p1

    .line 24
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p1

    .line 26
    :cond_1
    :goto_0
    return v0

    .line 27
    :cond_2
    check-cast p3, La/Dn;

    .line 28
    .line 29
    invoke-virtual {p0, p2}, La/XX;->W(I)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    return p1
.end method
