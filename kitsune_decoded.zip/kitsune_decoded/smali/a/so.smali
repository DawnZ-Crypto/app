.class public final synthetic La/so;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2

    .line 1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getFlags()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x1

    .line 6
    and-int/2addr p1, v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getFlags()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    and-int/lit8 p1, p1, 0x2

    .line 15
    .line 16
    if-eqz p1, :cond_3

    .line 17
    .line 18
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    if-ne p1, v0, :cond_2

    .line 23
    .line 24
    sget-object p1, La/uv;->w:Landroid/content/Context;

    .line 25
    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    const/4 p1, 0x0

    .line 30
    :goto_0
    const p2, 0x7f120192

    .line 31
    .line 32
    .line 33
    invoke-static {p1, p2, v1}, La/rE;->wU(Landroid/content/Context;II)V

    .line 34
    .line 35
    .line 36
    :cond_2
    sget-object p1, La/Dp;->w:La/Dp;

    .line 37
    .line 38
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    sget-object p2, La/Dp;->h:[La/KG;

    .line 42
    .line 43
    const/16 v0, 0xc

    .line 44
    .line 45
    aget-object p2, p2, v0

    .line 46
    .line 47
    sget-object v0, La/Dp;->d:La/SH;

    .line 48
    .line 49
    invoke-virtual {v0, p1, p2}, La/SH;->r(La/dN;La/KG;)Ljava/lang/Boolean;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    :cond_3
    return v1
.end method
