.class Landroidx/activity/result/ActivityResultRegistry$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/dr;


# instance fields
.field public final synthetic K:La/zo;

.field public final synthetic L:Landroidx/activity/result/w;

.field public final synthetic R:La/A8;

.field public final synthetic X:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroidx/activity/result/w;Ljava/lang/String;La/Gk;La/WN;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/result/ActivityResultRegistry$1;->L:Landroidx/activity/result/w;

    iput-object p2, p0, Landroidx/activity/result/ActivityResultRegistry$1;->X:Ljava/lang/String;

    iput-object p3, p0, Landroidx/activity/result/ActivityResultRegistry$1;->K:La/zo;

    iput-object p4, p0, Landroidx/activity/result/ActivityResultRegistry$1;->R:La/A8;

    return-void
.end method


# virtual methods
.method public final Q(La/RH;La/cw;)V
    .locals 4

    .line 1
    sget-object p1, La/cw;->ON_START:La/cw;

    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    iget-object v0, p0, Landroidx/activity/result/ActivityResultRegistry$1;->X:Ljava/lang/String;

    iget-object v1, p0, Landroidx/activity/result/ActivityResultRegistry$1;->L:Landroidx/activity/result/w;

    if-eqz p1, :cond_1

    iget-object p1, v1, Landroidx/activity/result/w;->i:Ljava/util/HashMap;

    new-instance p2, La/DK;

    iget-object v2, p0, Landroidx/activity/result/ActivityResultRegistry$1;->K:La/zo;

    iget-object v3, p0, Landroidx/activity/result/ActivityResultRegistry$1;->R:La/A8;

    invoke-direct {p2, v2, v3}, La/DK;-><init>(La/zo;La/A8;)V

    invoke-virtual {p1, v0, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, v1, Landroidx/activity/result/w;->Q:Ljava/util/HashMap;

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v2, p2}, La/zo;->h(Ljava/lang/Object;)V

    :cond_0
    iget-object p1, v1, Landroidx/activity/result/w;->X:Landroid/os/Bundle;

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p2

    check-cast p2, La/ic;

    if-eqz p2, :cond_3

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    iget-object p1, p2, La/ic;->K:Landroid/content/Intent;

    iget p2, p2, La/ic;->X:I

    invoke-virtual {v3, p1, p2}, La/A8;->FL(Landroid/content/Intent;I)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v2, p1}, La/zo;->h(Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    sget-object p1, La/cw;->ON_STOP:La/cw;

    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, v1, Landroidx/activity/result/w;->i:Ljava/util/HashMap;

    invoke-virtual {p1, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_2
    sget-object p1, La/cw;->ON_DESTROY:La/cw;

    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-virtual {v1, v0}, Landroidx/activity/result/w;->Q(Ljava/lang/String;)V

    :cond_3
    :goto_0
    return-void
.end method
