.class public final La/Cp;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final X:La/Wx;


# direct methods
.method public constructor <init>(La/Wx;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La/Cp;->X:La/Wx;

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 1

    .line 1
    iget-object p1, p0, La/Cp;->X:La/Wx;

    .line 2
    .line 3
    check-cast p1, La/lB;

    .line 4
    .line 5
    iget-object p1, p1, La/TE;->Z:La/Q9;

    .line 6
    .line 7
    check-cast p1, La/J8;

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    iget-object v0, p1, La/J8;->P:La/xX;

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 15
    .line 16
    .line 17
    iget-object p1, p1, La/J8;->F:La/Sz;

    .line 18
    .line 19
    iget v0, p1, La/Sz;->h:I

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    iput p2, p1, La/Sz;->h:I

    .line 24
    .line 25
    iget-object p1, p1, La/Sz;->p:La/J8;

    .line 26
    .line 27
    const/4 v0, 0x7

    .line 28
    invoke-virtual {p1, v0}, La/hb;->Q(I)V

    .line 29
    .line 30
    .line 31
    :cond_0
    return p2
.end method
