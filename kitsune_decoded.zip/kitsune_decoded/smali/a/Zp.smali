.class public interface abstract La/Zp;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/FH;
