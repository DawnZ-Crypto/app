.class public final La/J8;
.super La/hb;
.source "SourceFile"


# instance fields
.field public D:Z

.field public E:I

.field public final F:La/Sz;

.field public final H:La/so;

.field public final P:La/xX;

.field public S:Z

.field public W:Ljava/lang/String;

.field public final f:Landroid/content/SharedPreferences;

.field public l:Landroid/graphics/drawable/Drawable;

.field public q:Ljava/lang/String;

.field public final z:La/S6;


# direct methods
.method public constructor <init>(La/Zx;Landroid/content/SharedPreferences;)V
    .locals 3

    .line 1
    invoke-direct {p0}, La/hb;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, La/J8;->f:Landroid/content/SharedPreferences;

    .line 5
    .line 6
    new-instance p2, La/Sz;

    .line 7
    .line 8
    invoke-direct {p2, p0}, La/Sz;-><init>(La/J8;)V

    .line 9
    .line 10
    .line 11
    iput-object p2, p0, La/J8;->F:La/Sz;

    .line 12
    .line 13
    new-instance p2, La/so;

    .line 14
    .line 15
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object p2, p0, La/J8;->H:La/so;

    .line 19
    .line 20
    new-instance p2, La/S6;

    .line 21
    .line 22
    sget-object v0, La/uv;->w:Landroid/content/Context;

    .line 23
    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :goto_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-direct {p2, v0, p1}, La/S6;-><init>(Landroid/content/pm/PackageManager;La/Zx;)V

    .line 33
    .line 34
    .line 35
    iput-object p2, p0, La/J8;->z:La/S6;

    .line 36
    .line 37
    sget-object p1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 38
    .line 39
    sget-object p2, La/Dp;->w:La/Dp;

    .line 40
    .line 41
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    sget-object v0, La/Dp;->I:La/Hr;

    .line 45
    .line 46
    sget-object v1, La/Dp;->h:[La/KG;

    .line 47
    .line 48
    const/4 v2, 0x4

    .line 49
    aget-object v1, v1, v2

    .line 50
    .line 51
    invoke-virtual {v0, p2, v1}, La/Hr;->h(Ljava/lang/Object;La/KG;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p2

    .line 55
    check-cast p2, Ljava/lang/Number;

    .line 56
    .line 57
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result p2

    .line 61
    int-to-long v0, p2

    .line 62
    invoke-virtual {p1, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 63
    .line 64
    .line 65
    move-result-wide p1

    .line 66
    new-instance v0, La/xX;

    .line 67
    .line 68
    invoke-direct {v0, p0, p1, p2}, La/xX;-><init>(La/J8;J)V

    .line 69
    .line 70
    .line 71
    iput-object v0, p0, La/J8;->P:La/xX;

    .line 72
    .line 73
    return-void
.end method


# virtual methods
.method public final R(I)V
    .locals 4

    .line 1
    iget-boolean v0, p0, La/J8;->D:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, La/J8;->P:La/xX;

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/os/CountDownTimer;->cancel()V

    .line 9
    .line 10
    .line 11
    iget v0, p0, La/J8;->E:I

    .line 12
    .line 13
    iget-object v1, p0, La/J8;->f:Landroid/content/SharedPreferences;

    .line 14
    .line 15
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    iget-object v2, p0, La/J8;->q:Ljava/lang/String;

    .line 20
    .line 21
    const/4 v3, 0x0

    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_1
    move-object v2, v3

    .line 26
    :goto_0
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 31
    .line 32
    .line 33
    invoke-static {p0}, La/rE;->mh(La/AZ;)La/wE;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    new-instance v2, La/Rq;

    .line 38
    .line 39
    invoke-direct {v2, p0, p1, v0, v3}, La/Rq;-><init>(La/J8;IILa/hu;)V

    .line 40
    .line 41
    .line 42
    const/4 p1, 0x3

    .line 43
    invoke-static {v1, v3, v2, p1}, La/A8;->n(La/wE;La/Cg;La/Wb;I)La/ve;

    .line 44
    .line 45
    .line 46
    return-void
.end method
