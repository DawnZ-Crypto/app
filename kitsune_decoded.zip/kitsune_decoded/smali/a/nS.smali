.class public final La/nS;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/gr;


# static fields
.field public static final w:La/nS;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/nS;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/nS;->w:La/nS;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final w(La/b7;)La/vL;
    .locals 11

    .line 1
    iget-object v0, p1, La/b7;->w:La/WO;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-boolean v1, v0, La/WO;->P:Z

    .line 5
    .line 6
    if-eqz v1, :cond_3

    .line 7
    .line 8
    iget-boolean v1, v0, La/WO;->z:Z

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    xor-int/2addr v1, v2

    .line 12
    if-eqz v1, :cond_2

    .line 13
    .line 14
    iget-boolean v1, v0, La/WO;->H:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 15
    .line 16
    xor-int/2addr v1, v2

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    monitor-exit v0

    .line 20
    iget-object v1, v0, La/WO;->q:La/uV;

    .line 21
    .line 22
    iget-object v10, v0, La/WO;->X:La/qU;

    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    :try_start_1
    iget v4, p1, La/b7;->Q:I

    .line 28
    .line 29
    iget v5, p1, La/b7;->X:I

    .line 30
    .line 31
    iget v6, p1, La/b7;->O:I

    .line 32
    .line 33
    iget v7, v10, La/qU;->g:I

    .line 34
    .line 35
    iget-boolean v8, v10, La/qU;->f:Z

    .line 36
    .line 37
    iget-object v3, p1, La/b7;->i:La/EW;

    .line 38
    .line 39
    iget-object v3, v3, La/EW;->p:Ljava/io/Serializable;

    .line 40
    .line 41
    check-cast v3, Ljava/lang/String;

    .line 42
    .line 43
    const-string v9, "GET"

    .line 44
    .line 45
    invoke-static {v3, v9}, La/rE;->X(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    xor-int/lit8 v9, v3, 0x1

    .line 50
    .line 51
    move-object v3, v1

    .line 52
    invoke-virtual/range {v3 .. v9}, La/uV;->w(IIIIZZ)La/A6;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    invoke-virtual {v3, v10, p1}, La/A6;->M(La/qU;La/b7;)La/DP;

    .line 57
    .line 58
    .line 59
    move-result-object v3
    :try_end_1
    .catch La/IH; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 60
    new-instance v4, La/xw;

    .line 61
    .line 62
    iget-object v5, v0, La/WO;->d:La/Qr;

    .line 63
    .line 64
    invoke-direct {v4, v0, v5, v1, v3}, La/xw;-><init>(La/WO;La/Qr;La/uV;La/DP;)V

    .line 65
    .line 66
    .line 67
    iput-object v4, v0, La/WO;->S:La/xw;

    .line 68
    .line 69
    iput-object v4, v0, La/WO;->Y:La/xw;

    .line 70
    .line 71
    monitor-enter v0

    .line 72
    :try_start_2
    iput-boolean v2, v0, La/WO;->H:Z

    .line 73
    .line 74
    iput-boolean v2, v0, La/WO;->z:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 75
    .line 76
    monitor-exit v0

    .line 77
    iget-boolean v0, v0, La/WO;->D:Z

    .line 78
    .line 79
    if-nez v0, :cond_0

    .line 80
    .line 81
    const/4 v0, 0x0

    .line 82
    const/16 v1, 0x3d

    .line 83
    .line 84
    const/4 v2, 0x0

    .line 85
    invoke-static {p1, v2, v4, v0, v1}, La/b7;->w(La/b7;ILa/xw;La/EW;I)La/b7;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    iget-object p1, p1, La/b7;->i:La/EW;

    .line 90
    .line 91
    invoke-virtual {v0, p1}, La/b7;->h(La/EW;)La/vL;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    return-object p1

    .line 96
    :cond_0
    new-instance p1, Ljava/io/IOException;

    .line 97
    .line 98
    const-string v0, "Canceled"

    .line 99
    .line 100
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw p1

    .line 104
    :catchall_0
    move-exception p1

    .line 105
    monitor-exit v0

    .line 106
    throw p1

    .line 107
    :catch_0
    move-exception p1

    .line 108
    goto :goto_0

    .line 109
    :catch_1
    move-exception p1

    .line 110
    goto :goto_1

    .line 111
    :goto_0
    invoke-virtual {v1, p1}, La/uV;->h(Ljava/io/IOException;)V

    .line 112
    .line 113
    .line 114
    new-instance v0, La/IH;

    .line 115
    .line 116
    invoke-direct {v0, p1}, La/IH;-><init>(Ljava/io/IOException;)V

    .line 117
    .line 118
    .line 119
    throw v0

    .line 120
    :goto_1
    iget-object v0, p1, La/IH;->K:Ljava/io/IOException;

    .line 121
    .line 122
    invoke-virtual {v1, v0}, La/uV;->h(Ljava/io/IOException;)V

    .line 123
    .line 124
    .line 125
    throw p1

    .line 126
    :cond_1
    :try_start_3
    const-string p1, "Check failed."

    .line 127
    .line 128
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 129
    .line 130
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    throw v1

    .line 138
    :catchall_1
    move-exception p1

    .line 139
    goto :goto_2

    .line 140
    :cond_2
    const-string p1, "Check failed."

    .line 141
    .line 142
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 143
    .line 144
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    throw v1

    .line 152
    :cond_3
    const-string p1, "released"

    .line 153
    .line 154
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 155
    .line 156
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-direct {v1, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 164
    :goto_2
    monitor-exit v0

    .line 165
    throw p1
.end method
