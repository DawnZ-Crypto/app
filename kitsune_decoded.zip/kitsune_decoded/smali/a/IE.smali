.class public final La/IE;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# static fields
.field public static final Companion:La/Jt;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La/Jt;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La/IE;->Companion:La/Jt;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final registerIn(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget-object v0, La/IE;->Companion:La/Jt;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    new-instance v0, La/IE;

    .line 7
    .line 8
    invoke-direct {v0}, La/IE;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v0}, La/an;->T(Landroid/app/Activity;La/IE;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    sget p2, La/PS;->K:I

    sget-object p2, La/cw;->ON_CREATE:La/cw;

    invoke-static {p1, p2}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityPostResumed(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget v0, La/PS;->K:I

    sget-object v0, La/cw;->ON_RESUME:La/cw;

    invoke-static {p1, v0}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityPostStarted(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget v0, La/PS;->K:I

    sget-object v0, La/cw;->ON_START:La/cw;

    invoke-static {p1, v0}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityPreDestroyed(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget v0, La/PS;->K:I

    sget-object v0, La/cw;->ON_DESTROY:La/cw;

    invoke-static {p1, v0}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityPrePaused(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget v0, La/PS;->K:I

    sget-object v0, La/cw;->ON_PAUSE:La/cw;

    invoke-static {p1, v0}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityPreStopped(Landroid/app/Activity;)V
    .locals 1

    .line 1
    sget v0, La/PS;->K:I

    sget-object v0, La/cw;->ON_STOP:La/cw;

    invoke-static {p1, v0}, La/eI;->I(Landroid/app/Activity;La/cw;)V

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 0

    .line 1
    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 0

    .line 1
    return-void
.end method
