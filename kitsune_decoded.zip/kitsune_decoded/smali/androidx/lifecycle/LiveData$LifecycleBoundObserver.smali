.class Landroidx/lifecycle/LiveData$LifecycleBoundObserver;
.super La/nT;
.source "SourceFile"

# interfaces
.implements La/dr;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La/nT;",
        "La/dr;"
    }
.end annotation


# instance fields
.field public final d:La/RH;

.field public final synthetic f:Landroidx/lifecycle/h;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/h;La/RH;La/yb;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->f:Landroidx/lifecycle/h;

    invoke-direct {p0, p1, p3}, La/nT;-><init>(Landroidx/lifecycle/h;La/yb;)V

    iput-object p2, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->d:La/RH;

    return-void
.end method


# virtual methods
.method public final I(La/RH;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->d:La/RH;

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final M()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->d:La/RH;

    .line 2
    .line 3
    invoke-interface {v0}, La/RH;->I()Landroidx/lifecycle/w;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v0, v0, Landroidx/lifecycle/w;->e:La/m2;

    .line 8
    .line 9
    sget-object v1, La/m2;->L:La/m2;

    .line 10
    .line 11
    invoke-virtual {v0, v1}, La/m2;->w(La/m2;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0
.end method

.method public final Q(La/RH;La/cw;)V
    .locals 2

    .line 1
    iget-object p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->d:La/RH;

    .line 2
    .line 3
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    iget-object p2, p2, Landroidx/lifecycle/w;->e:La/m2;

    .line 8
    .line 9
    sget-object v0, La/m2;->X:La/m2;

    .line 10
    .line 11
    if-ne p2, v0, :cond_0

    .line 12
    .line 13
    iget-object p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->f:Landroidx/lifecycle/h;

    .line 14
    .line 15
    iget-object p2, p0, La/nT;->X:La/yb;

    .line 16
    .line 17
    invoke-virtual {p1, p2}, Landroidx/lifecycle/h;->V(La/yb;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    :goto_0
    if-eq v0, p2, :cond_1

    .line 23
    .line 24
    invoke-virtual {p0}, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->M()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-virtual {p0, v0}, La/nT;->O(Z)V

    .line 29
    .line 30
    .line 31
    invoke-interface {p1}, La/RH;->I()Landroidx/lifecycle/w;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-object v0, v0, Landroidx/lifecycle/w;->e:La/m2;

    .line 36
    .line 37
    move-object v1, v0

    .line 38
    move-object v0, p2

    .line 39
    move-object p2, v1

    .line 40
    goto :goto_0

    .line 41
    :cond_1
    return-void
.end method

.method public final V()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;->d:La/RH;

    invoke-interface {v0}, La/RH;->I()Landroidx/lifecycle/w;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroidx/lifecycle/w;->h(La/IQ;)V

    return-void
.end method
