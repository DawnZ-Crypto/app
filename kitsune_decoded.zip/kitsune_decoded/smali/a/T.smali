.class public interface abstract La/T;
.super Ljava/lang/Object;
.source "SourceFile"
