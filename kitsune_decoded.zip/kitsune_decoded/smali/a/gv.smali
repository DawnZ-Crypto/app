.class public abstract La/gv;
.super Landroidx/databinding/w;
.source "SourceFile"


# instance fields
.field public final C:Landroidx/constraintlayout/widget/Barrier;

.field public final n:Landroid/widget/TextView;

.field public final t:Landroid/widget/ImageView;

.field public x:La/Cu;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;Landroidx/constraintlayout/widget/Barrier;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    invoke-direct {p0, v0, p2, p1}, Landroidx/databinding/w;-><init>(ILandroid/view/View;Ljava/lang/Object;)V

    iput-object p3, p0, La/gv;->t:Landroid/widget/ImageView;

    iput-object p4, p0, La/gv;->n:Landroid/widget/TextView;

    iput-object p5, p0, La/gv;->C:Landroidx/constraintlayout/widget/Barrier;

    return-void
.end method


# virtual methods
.method public abstract W(La/Cu;)V
.end method
