.class public final La/PO;
.super La/hY;
.source "SourceFile"


# instance fields
.field public F:I

.field public L:Ljava/lang/Object;

.field public synthetic W:Ljava/lang/Object;

.field public d:La/pW;

.field public f:Ljava/io/File;

.field public l:La/Q;

.field public final synthetic q:La/Qr;


# direct methods
.method public constructor <init>(La/Qr;La/hu;)V
    .locals 0

    .line 1
    iput-object p1, p0, La/PO;->q:La/Qr;

    invoke-direct {p0, p2}, La/hY;-><init>(La/hu;)V

    return-void
.end method


# virtual methods
.method public final T(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La/PO;->W:Ljava/lang/Object;

    iget p1, p0, La/PO;->F:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La/PO;->F:I

    iget-object p1, p0, La/PO;->q:La/Qr;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, La/Qr;->Z(Landroid/app/Activity;La/hu;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
