.class public final La/tk;
.super La/k;
.source "SourceFile"


# instance fields
.field public R:[B


# virtual methods
.method public final E()Ljava/util/Enumeration;
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/tk;->R:[B
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    new-instance v1, La/KW;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance v2, La/l;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-direct {v2, v0, v3}, La/l;-><init>([BI)V

    .line 16
    .line 17
    .line 18
    iput-object v2, v1, La/KW;->w:La/l;

    .line 19
    .line 20
    invoke-virtual {v1}, La/KW;->w()La/Y;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object v0, v1, La/KW;->h:La/Y;

    .line 25
    .line 26
    return-object v1

    .line 27
    :cond_0
    invoke-super {p0}, La/k;->E()Ljava/util/Enumeration;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    :catchall_0
    move-exception v0

    .line 33
    monitor-exit p0

    .line 34
    throw v0
.end method

.method public final F(I)La/m;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La/k;->X:[La/m;

    .line 5
    .line 6
    aget-object p1, v0, p1

    .line 7
    .line 8
    return-object p1
.end method

.method public final H()La/z;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->f()La/Y;

    move-result-object v0

    check-cast v0, La/k;

    invoke-virtual {v0}, La/k;->H()La/z;

    move-result-object v0

    return-object v0
.end method

.method public final K(Z)I
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/tk;->R:[B
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    array-length v0, v0

    .line 8
    invoke-static {v0, p1}, La/sR;->X(IZ)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1

    .line 13
    :cond_0
    invoke-super {p0}, La/k;->f()La/Y;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0, p1}, La/Y;->K(Z)I

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    return p1

    .line 22
    :catchall_0
    move-exception p1

    .line 23
    monitor-exit p0

    .line 24
    throw p1
.end method

.method public final declared-synchronized P()V
    .locals 5

    .line 1
    const-string v0, "malformed ASN.1: "

    .line 2
    .line 3
    monitor-enter p0

    .line 4
    :try_start_0
    iget-object v1, p0, La/tk;->R:[B

    .line 5
    .line 6
    if-eqz v1, :cond_2

    .line 7
    .line 8
    new-instance v1, La/l;

    .line 9
    .line 10
    iget-object v2, p0, La/tk;->R:[B

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    invoke-direct {v1, v2, v3}, La/l;-><init>([BI)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    .line 16
    :try_start_1
    invoke-virtual {v1}, La/l;->U()La/Y;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    new-instance v2, La/y;

    .line 23
    .line 24
    invoke-direct {v2, v3}, La/y;-><init>(I)V

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    new-instance v4, La/y;

    .line 29
    .line 30
    invoke-direct {v4}, La/y;-><init>()V

    .line 31
    .line 32
    .line 33
    :cond_1
    invoke-virtual {v4, v2}, La/y;->w(La/m;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v1}, La/l;->U()La/Y;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    if-nez v2, :cond_1

    .line 41
    .line 42
    move-object v2, v4

    .line 43
    :goto_0
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v2}, La/y;->e()[La/m;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    iput-object v1, p0, La/k;->X:[La/m;

    .line 51
    .line 52
    const/4 v1, 0x0

    .line 53
    iput-object v1, p0, La/tk;->R:[B
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :catchall_0
    move-exception v0

    .line 57
    goto :goto_2

    .line 58
    :catch_0
    move-exception v1

    .line 59
    :try_start_2
    new-instance v2, La/D;

    .line 60
    .line 61
    new-instance v4, Ljava/lang/StringBuilder;

    .line 62
    .line 63
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-direct {v2, v3, v0, v1}, La/D;-><init>(ILjava/lang/String;Ljava/lang/Exception;)V

    .line 74
    .line 75
    .line 76
    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 77
    :cond_2
    :goto_1
    monitor-exit p0

    .line 78
    return-void

    .line 79
    :goto_2
    monitor-exit p0

    .line 80
    throw v0
.end method

.method public final S()La/V;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->f()La/Y;

    move-result-object v0

    check-cast v0, La/k;

    invoke-virtual {v0}, La/k;->S()La/V;

    move-result-object v0

    return-object v0
.end method

.method public final d()La/Y;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    invoke-super {p0}, La/k;->d()La/Y;

    move-result-object v0

    return-object v0
.end method

.method public final f()La/Y;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    invoke-super {p0}, La/k;->f()La/Y;

    move-result-object v0

    return-object v0
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    invoke-super {p0}, La/k;->hashCode()I

    move-result v0

    return v0
.end method

.method public final iterator()Ljava/util/Iterator;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    invoke-super {p0}, La/k;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method

.method public final m(La/sR;Z)V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, La/tk;->R:[B
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/16 v1, 0x30

    .line 8
    .line 9
    invoke-virtual {p1, v1, p2, v0}, La/sR;->y(IZ[B)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    invoke-super {p0}, La/k;->f()La/Y;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0, p1, p2}, La/Y;->m(La/sR;Z)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    monitor-exit p0

    .line 23
    throw p1
.end method

.method public final size()I
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->P()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La/k;->X:[La/m;

    .line 5
    .line 6
    array-length v0, v0

    .line 7
    return v0
.end method

.method public final z()La/v;
    .locals 1

    .line 1
    invoke-virtual {p0}, La/tk;->f()La/Y;

    move-result-object v0

    check-cast v0, La/k;

    invoke-virtual {v0}, La/k;->z()La/v;

    move-result-object v0

    return-object v0
.end method
