.class public Landroidx/recyclerview/widget/LinearLayoutManager;
.super La/XG;
.source "SourceFile"

# interfaces
.implements La/wx;


# instance fields
.field public final D:I

.field public E:I

.field public final F:Z

.field public H:La/fD;

.field public L:La/M2;

.field public final P:La/Lj;

.field public R:I

.field public S:I

.field public W:Z

.field public final Y:[I

.field public d:La/Tt;

.field public f:Z

.field public final l:Z

.field public q:Z

.field public final z:La/us;


# direct methods
.method public constructor <init>(I)V
    .locals 3

    invoke-direct {p0}, La/XG;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    const/high16 v0, -0x80000000

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    new-instance v2, La/us;

    invoke-direct {v2}, La/us;-><init>()V

    iput-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:La/us;

    new-instance v2, La/Lj;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->P:La/Lj;

    const/4 v2, 0x2

    iput v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->D:I

    new-array v2, v2, [I

    iput-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Y:[I

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Yo(I)V

    .line 1
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(Ljava/lang/String;)V

    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    invoke-virtual {p0}, La/XG;->lI()V

    :goto_0
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    invoke-direct {p0}, La/XG;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    const/high16 v0, -0x80000000

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    new-instance v1, La/us;

    invoke-direct {v1}, La/us;-><init>()V

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:La/us;

    new-instance v1, La/Lj;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->P:La/Lj;

    const/4 v1, 0x2

    iput v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->D:I

    new-array v1, v1, [I

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Y:[I

    invoke-static {p1, p2, p3, p4}, La/XG;->k(Landroid/content/Context;Landroid/util/AttributeSet;II)La/lS;

    move-result-object p1

    iget p2, p1, La/lS;->w:I

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->Yo(I)V

    iget-boolean p2, p1, La/lS;->p:Z

    .line 2
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(Ljava/lang/String;)V

    iget-boolean p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    if-ne p2, p3, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    invoke-virtual {p0}, La/XG;->lI()V

    .line 3
    :goto_0
    iget-boolean p1, p1, La/lS;->e:Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->XS(Z)V

    return-void
.end method


# virtual methods
.method public final AR(II)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {v1}, La/Tt;->i()I

    move-result v1

    sub-int/2addr v1, p2

    iput v1, v0, La/M2;->p:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    iput v1, v0, La/M2;->i:I

    iput p1, v0, La/M2;->e:I

    iput v2, v0, La/M2;->Q:I

    iput p2, v0, La/M2;->h:I

    const/high16 p1, -0x80000000

    iput p1, v0, La/M2;->X:I

    return-void
.end method

.method public final AW(La/R8;)I
    .locals 6

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->au(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->vz(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, La/rE;->q(La/R8;La/VO;Landroid/view/View;Landroid/view/View;La/XG;Z)I

    move-result p1

    return p1
.end method

.method public final B(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, La/XG;->B(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/XG;->q()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-lez v0, :cond_1

    .line 9
    .line 10
    invoke-virtual {p0}, La/XG;->q()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x1

    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-virtual {p0, v2, v0, v2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Pi(IIZZ)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    const/4 v0, -0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-static {v0}, La/XG;->U(Landroid/view/View;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->sH()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    .line 36
    .line 37
    .line 38
    :cond_1
    return-void
.end method

.method public final B2(La/fl;La/M2;La/R8;Z)I
    .locals 7

    .line 1
    iget v0, p2, La/M2;->p:I

    .line 2
    .line 3
    iget v1, p2, La/M2;->X:I

    .line 4
    .line 5
    const/high16 v2, -0x80000000

    .line 6
    .line 7
    if-eq v1, v2, :cond_1

    .line 8
    .line 9
    if-gez v0, :cond_0

    .line 10
    .line 11
    add-int/2addr v1, v0

    .line 12
    iput v1, p2, La/M2;->X:I

    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->cC(La/fl;La/M2;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    iget v1, p2, La/M2;->p:I

    .line 18
    .line 19
    iget v3, p2, La/M2;->O:I

    .line 20
    .line 21
    add-int/2addr v1, v3

    .line 22
    :cond_2
    iget-boolean v3, p2, La/M2;->T:Z

    .line 23
    .line 24
    if-nez v3, :cond_3

    .line 25
    .line 26
    if-lez v1, :cond_9

    .line 27
    .line 28
    :cond_3
    iget v3, p2, La/M2;->e:I

    .line 29
    .line 30
    if-ltz v3, :cond_9

    .line 31
    .line 32
    invoke-virtual {p3}, La/R8;->h()I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    if-ge v3, v4, :cond_9

    .line 37
    .line 38
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->P:La/Lj;

    .line 39
    .line 40
    const/4 v4, 0x0

    .line 41
    iput v4, v3, La/Lj;->w:I

    .line 42
    .line 43
    iput-boolean v4, v3, La/Lj;->h:Z

    .line 44
    .line 45
    iput-boolean v4, v3, La/Lj;->p:Z

    .line 46
    .line 47
    iput-boolean v4, v3, La/Lj;->e:Z

    .line 48
    .line 49
    invoke-virtual {p0, p1, p3, p2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ek(La/fl;La/R8;La/M2;La/Lj;)V

    .line 50
    .line 51
    .line 52
    iget-boolean v4, v3, La/Lj;->h:Z

    .line 53
    .line 54
    if-eqz v4, :cond_4

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_4
    iget v4, p2, La/M2;->h:I

    .line 58
    .line 59
    iget v5, v3, La/Lj;->w:I

    .line 60
    .line 61
    iget v6, p2, La/M2;->Q:I

    .line 62
    .line 63
    mul-int/2addr v6, v5

    .line 64
    add-int/2addr v6, v4

    .line 65
    iput v6, p2, La/M2;->h:I

    .line 66
    .line 67
    iget-boolean v4, v3, La/Lj;->p:Z

    .line 68
    .line 69
    if-eqz v4, :cond_5

    .line 70
    .line 71
    iget-object v4, p2, La/M2;->M:Ljava/util/List;

    .line 72
    .line 73
    if-nez v4, :cond_5

    .line 74
    .line 75
    iget-boolean v4, p3, La/R8;->X:Z

    .line 76
    .line 77
    if-nez v4, :cond_6

    .line 78
    .line 79
    :cond_5
    iget v4, p2, La/M2;->p:I

    .line 80
    .line 81
    sub-int/2addr v4, v5

    .line 82
    iput v4, p2, La/M2;->p:I

    .line 83
    .line 84
    sub-int/2addr v1, v5

    .line 85
    :cond_6
    iget v4, p2, La/M2;->X:I

    .line 86
    .line 87
    if-eq v4, v2, :cond_8

    .line 88
    .line 89
    add-int/2addr v4, v5

    .line 90
    iput v4, p2, La/M2;->X:I

    .line 91
    .line 92
    iget v5, p2, La/M2;->p:I

    .line 93
    .line 94
    if-gez v5, :cond_7

    .line 95
    .line 96
    add-int/2addr v4, v5

    .line 97
    iput v4, p2, La/M2;->X:I

    .line 98
    .line 99
    :cond_7
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->cC(La/fl;La/M2;)V

    .line 100
    .line 101
    .line 102
    :cond_8
    if-eqz p4, :cond_2

    .line 103
    .line 104
    iget-boolean v3, v3, La/Lj;->e:Z

    .line 105
    .line 106
    if-eqz v3, :cond_2

    .line 107
    .line 108
    :cond_9
    :goto_0
    iget p1, p2, La/M2;->p:I

    .line 109
    .line 110
    sub-int/2addr v0, p1

    .line 111
    return v0
.end method

.method public final C6()Z
    .locals 5

    .line 1
    iget v0, p0, La/XG;->m:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/high16 v2, 0x40000000    # 2.0f

    .line 5
    .line 6
    if-eq v0, v2, :cond_1

    .line 7
    .line 8
    iget v0, p0, La/XG;->T:I

    .line 9
    .line 10
    if-eq v0, v2, :cond_1

    .line 11
    .line 12
    invoke-virtual {p0}, La/XG;->q()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    move v2, v1

    .line 17
    :goto_0
    if-ge v2, v0, :cond_1

    .line 18
    .line 19
    invoke-virtual {p0, v2}, La/XG;->W(I)Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    iget v4, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 28
    .line 29
    if-gez v4, :cond_0

    .line 30
    .line 31
    iget v3, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 32
    .line 33
    if-gez v3, :cond_0

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    goto :goto_1

    .line 37
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    :goto_1
    return v1
.end method

.method public Ek(La/fl;La/R8;La/M2;La/Lj;)V
    .locals 11

    .line 1
    invoke-virtual {p3, p1}, La/M2;->h(La/fl;)Landroid/view/View;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p2, 0x1

    .line 6
    if-nez p1, :cond_0

    .line 7
    .line 8
    iput-boolean p2, p4, La/Lj;->h:Z

    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, La/Mk;

    .line 16
    .line 17
    iget-object v1, p3, La/M2;->M:Ljava/util/List;

    .line 18
    .line 19
    const/4 v2, 0x0

    .line 20
    const/4 v3, -0x1

    .line 21
    if-nez v1, :cond_3

    .line 22
    .line 23
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 24
    .line 25
    iget v4, p3, La/M2;->Q:I

    .line 26
    .line 27
    if-ne v4, v3, :cond_1

    .line 28
    .line 29
    move v4, p2

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    move v4, v2

    .line 32
    :goto_0
    if-ne v1, v4, :cond_2

    .line 33
    .line 34
    invoke-virtual {p0, p1, v3, v2}, La/XG;->h(Landroid/view/View;IZ)V

    .line 35
    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_2
    invoke-virtual {p0, p1, v2, v2}, La/XG;->h(Landroid/view/View;IZ)V

    .line 39
    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_3
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 43
    .line 44
    iget v4, p3, La/M2;->Q:I

    .line 45
    .line 46
    if-ne v4, v3, :cond_4

    .line 47
    .line 48
    move v4, p2

    .line 49
    goto :goto_1

    .line 50
    :cond_4
    move v4, v2

    .line 51
    :goto_1
    if-ne v1, v4, :cond_5

    .line 52
    .line 53
    invoke-virtual {p0, p1, v3, p2}, La/XG;->h(Landroid/view/View;IZ)V

    .line 54
    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_5
    invoke-virtual {p0, p1, v2, p2}, La/XG;->h(Landroid/view/View;IZ)V

    .line 58
    .line 59
    .line 60
    :goto_2
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    check-cast v1, La/Mk;

    .line 65
    .line 66
    iget-object v2, p0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 67
    .line 68
    invoke-virtual {v2, p1}, Landroidx/recyclerview/widget/RecyclerView;->t(Landroid/view/View;)Landroid/graphics/Rect;

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    iget v4, v2, Landroid/graphics/Rect;->left:I

    .line 73
    .line 74
    iget v5, v2, Landroid/graphics/Rect;->right:I

    .line 75
    .line 76
    add-int/2addr v4, v5

    .line 77
    iget v5, v2, Landroid/graphics/Rect;->top:I

    .line 78
    .line 79
    iget v2, v2, Landroid/graphics/Rect;->bottom:I

    .line 80
    .line 81
    add-int/2addr v5, v2

    .line 82
    iget v2, p0, La/XG;->y:I

    .line 83
    .line 84
    iget v6, p0, La/XG;->T:I

    .line 85
    .line 86
    invoke-virtual {p0}, La/XG;->D()I

    .line 87
    .line 88
    .line 89
    move-result v7

    .line 90
    invoke-virtual {p0}, La/XG;->Y()I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    add-int/2addr v8, v7

    .line 95
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 96
    .line 97
    add-int/2addr v8, v7

    .line 98
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 99
    .line 100
    add-int/2addr v8, v7

    .line 101
    add-int/2addr v8, v4

    .line 102
    iget v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 103
    .line 104
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->e()Z

    .line 105
    .line 106
    .line 107
    move-result v7

    .line 108
    invoke-static {v2, v6, v8, v4, v7}, La/XG;->F(IIIIZ)I

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    iget v4, p0, La/XG;->K:I

    .line 113
    .line 114
    iget v6, p0, La/XG;->m:I

    .line 115
    .line 116
    invoke-virtual {p0}, La/XG;->u()I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    invoke-virtual {p0}, La/XG;->P()I

    .line 121
    .line 122
    .line 123
    move-result v8

    .line 124
    add-int/2addr v8, v7

    .line 125
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 126
    .line 127
    add-int/2addr v8, v7

    .line 128
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 129
    .line 130
    add-int/2addr v8, v7

    .line 131
    add-int/2addr v8, v5

    .line 132
    iget v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 133
    .line 134
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->i()Z

    .line 135
    .line 136
    .line 137
    move-result v7

    .line 138
    invoke-static {v4, v6, v8, v5, v7}, La/XG;->F(IIIIZ)I

    .line 139
    .line 140
    .line 141
    move-result v4

    .line 142
    invoke-virtual {p0, p1, v2, v4, v1}, La/XG;->yd(Landroid/view/View;IILa/Mk;)Z

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    if-eqz v1, :cond_6

    .line 147
    .line 148
    invoke-virtual {p1, v2, v4}, Landroid/view/View;->measure(II)V

    .line 149
    .line 150
    .line 151
    :cond_6
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 152
    .line 153
    invoke-virtual {v1, p1}, La/Tt;->p(Landroid/view/View;)I

    .line 154
    .line 155
    .line 156
    move-result v1

    .line 157
    iput v1, p4, La/Lj;->w:I

    .line 158
    .line 159
    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 160
    .line 161
    if-ne v1, p2, :cond_9

    .line 162
    .line 163
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    if-eqz v1, :cond_7

    .line 168
    .line 169
    iget v1, p0, La/XG;->y:I

    .line 170
    .line 171
    invoke-virtual {p0}, La/XG;->Y()I

    .line 172
    .line 173
    .line 174
    move-result v2

    .line 175
    sub-int/2addr v1, v2

    .line 176
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 177
    .line 178
    invoke-virtual {v2, p1}, La/Tt;->T(Landroid/view/View;)I

    .line 179
    .line 180
    .line 181
    move-result v2

    .line 182
    sub-int v2, v1, v2

    .line 183
    .line 184
    goto :goto_3

    .line 185
    :cond_7
    invoke-virtual {p0}, La/XG;->D()I

    .line 186
    .line 187
    .line 188
    move-result v2

    .line 189
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 190
    .line 191
    invoke-virtual {v1, p1}, La/Tt;->T(Landroid/view/View;)I

    .line 192
    .line 193
    .line 194
    move-result v1

    .line 195
    add-int/2addr v1, v2

    .line 196
    :goto_3
    iget v4, p3, La/M2;->Q:I

    .line 197
    .line 198
    if-ne v4, v3, :cond_8

    .line 199
    .line 200
    iget p3, p3, La/M2;->h:I

    .line 201
    .line 202
    iget v3, p4, La/Lj;->w:I

    .line 203
    .line 204
    sub-int v3, p3, v3

    .line 205
    .line 206
    goto :goto_4

    .line 207
    :cond_8
    iget v3, p3, La/M2;->h:I

    .line 208
    .line 209
    iget p3, p4, La/Lj;->w:I

    .line 210
    .line 211
    add-int/2addr p3, v3

    .line 212
    goto :goto_4

    .line 213
    :cond_9
    invoke-virtual {p0}, La/XG;->u()I

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 218
    .line 219
    invoke-virtual {v2, p1}, La/Tt;->T(Landroid/view/View;)I

    .line 220
    .line 221
    .line 222
    move-result v2

    .line 223
    add-int/2addr v2, v1

    .line 224
    iget v4, p3, La/M2;->Q:I

    .line 225
    .line 226
    iget p3, p3, La/M2;->h:I

    .line 227
    .line 228
    if-ne v4, v3, :cond_a

    .line 229
    .line 230
    iget v3, p4, La/Lj;->w:I

    .line 231
    .line 232
    sub-int v3, p3, v3

    .line 233
    .line 234
    move v9, v1

    .line 235
    move v1, p3

    .line 236
    move p3, v2

    .line 237
    move v2, v3

    .line 238
    move v3, v9

    .line 239
    goto :goto_4

    .line 240
    :cond_a
    iget v3, p4, La/Lj;->w:I

    .line 241
    .line 242
    add-int/2addr v3, p3

    .line 243
    move v9, v2

    .line 244
    move v2, p3

    .line 245
    move p3, v9

    .line 246
    move v10, v3

    .line 247
    move v3, v1

    .line 248
    move v1, v10

    .line 249
    :goto_4
    invoke-static {p1, v2, v3, v1, p3}, La/XG;->n(Landroid/view/View;IIII)V

    .line 250
    .line 251
    .line 252
    iget-object p3, v0, La/Mk;->w:La/Ty;

    .line 253
    .line 254
    invoke-virtual {p3}, La/Ty;->I()Z

    .line 255
    .line 256
    .line 257
    move-result p3

    .line 258
    if-nez p3, :cond_b

    .line 259
    .line 260
    iget-object p3, v0, La/Mk;->w:La/Ty;

    .line 261
    .line 262
    invoke-virtual {p3}, La/Ty;->m()Z

    .line 263
    .line 264
    .line 265
    move-result p3

    .line 266
    if-eqz p3, :cond_c

    .line 267
    .line 268
    :cond_b
    iput-boolean p2, p4, La/Lj;->p:Z

    .line 269
    .line 270
    :cond_c
    invoke-virtual {p1}, Landroid/view/View;->hasFocusable()Z

    .line 271
    .line 272
    .line 273
    move-result p1

    .line 274
    iput-boolean p1, p4, La/Lj;->e:Z

    .line 275
    .line 276
    return-void
.end method

.method public final Ey()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, La/M2;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    iput-boolean v1, v0, La/M2;->w:Z

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    iput v1, v0, La/M2;->O:I

    .line 15
    .line 16
    iput v1, v0, La/M2;->V:I

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    iput-object v1, v0, La/M2;->M:Ljava/util/List;

    .line 20
    .line 21
    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final F9(Landroid/os/Parcelable;)V
    .locals 2

    .line 1
    instance-of v0, p1, La/fD;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    check-cast p1, La/fD;

    .line 6
    .line 7
    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 8
    .line 9
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 10
    .line 11
    const/4 v1, -0x1

    .line 12
    if-eq v0, v1, :cond_0

    .line 13
    .line 14
    iput v1, p1, La/fD;->X:I

    .line 15
    .line 16
    :cond_0
    invoke-virtual {p0}, La/XG;->lI()V

    .line 17
    .line 18
    .line 19
    :cond_1
    return-void
.end method

.method public final Fl()V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    xor-int/2addr v0, v1

    :goto_0
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    goto :goto_2

    :cond_1
    :goto_1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->l:Z

    goto :goto_0

    :goto_2
    return-void
.end method

.method public final GI(La/R8;)I
    .locals 7

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->au(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->vz(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v6}, La/rE;->F(La/R8;La/VO;Landroid/view/View;Landroid/view/View;La/XG;ZZ)I

    move-result p1

    return p1
.end method

.method public Gy(ILa/fl;La/R8;)I
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->fi(ILa/fl;La/R8;)I

    move-result p1

    return p1
.end method

.method public final HF(I)V
    .locals 1

    .line 1
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 2
    .line 3
    const/high16 p1, -0x80000000

    .line 4
    .line 5
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 6
    .line 7
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const/4 v0, -0x1

    .line 12
    iput v0, p1, La/fD;->X:I

    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0}, La/XG;->lI()V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final Hs(La/R8;)I
    .locals 6

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->au(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->vz(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->F:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, La/rE;->E(La/R8;La/VO;Landroid/view/View;Landroid/view/View;La/XG;Z)I

    move-result p1

    return p1
.end method

.method public final I(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->AW(La/R8;)I

    move-result p1

    return p1
.end method

.method public final ID()Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public final IL(I)I
    .locals 4

    .line 1
    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_b

    const/4 v2, 0x2

    if-eq p1, v2, :cond_8

    const/16 v2, 0x11

    const/high16 v3, -0x80000000

    if-eq p1, v2, :cond_6

    const/16 v2, 0x21

    if-eq p1, v2, :cond_4

    const/16 v0, 0x42

    if-eq p1, v0, :cond_2

    const/16 v0, 0x82

    if-eq p1, v0, :cond_0

    return v3

    :cond_0
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-ne p1, v1, :cond_1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    return v1

    :cond_2
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez p1, :cond_3

    goto :goto_1

    :cond_3
    move v1, v3

    :goto_1
    return v1

    :cond_4
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-ne p1, v1, :cond_5

    goto :goto_2

    :cond_5
    move v0, v3

    :goto_2
    return v0

    :cond_6
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez p1, :cond_7

    goto :goto_3

    :cond_7
    move v0, v3

    :goto_3
    return v0

    :cond_8
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-ne p1, v1, :cond_9

    return v1

    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    move-result p1

    if-eqz p1, :cond_a

    return v0

    :cond_a
    return v1

    :cond_b
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-ne p1, v1, :cond_c

    return v0

    :cond_c
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ck()Z

    move-result p1

    if-eqz p1, :cond_d

    return v1

    :cond_d
    return v0
.end method

.method public K(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hs(La/R8;)I

    move-result p1

    return p1
.end method

.method public final L(I)Landroid/view/View;
    .locals 2

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, La/XG;->W(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, La/XG;->U(Landroid/view/View;)I

    move-result v1

    sub-int v1, p1, v1

    if-ltz v1, :cond_1

    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, La/XG;->W(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, La/XG;->U(Landroid/view/View;)I

    move-result v1

    if-ne v1, p1, :cond_1

    return-object v0

    :cond_1
    invoke-super {p0, p1}, La/XG;->L(I)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public M(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->GI(La/R8;)I

    move-result p1

    return p1
.end method

.method public N3(La/R8;La/M2;La/Ge;)V
    .locals 1

    .line 1
    iget v0, p2, La/M2;->e:I

    if-ltz v0, :cond_0

    invoke-virtual {p1}, La/R8;->h()I

    move-result p1

    if-ge v0, p1, :cond_0

    const/4 p1, 0x0

    iget p2, p2, La/M2;->X:I

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-virtual {p3, v0, p1}, La/Ge;->h(II)V

    :cond_0
    return-void
.end method

.method public final O(IILa/R8;La/Ge;)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move p1, p2

    :goto_0
    invoke-virtual {p0}, La/XG;->q()I

    move-result p2

    if-eqz p2, :cond_3

    if-nez p1, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    const/4 p2, 0x1

    if-lez p1, :cond_2

    move v0, p2

    goto :goto_1

    :cond_2
    const/4 v0, -0x1

    :goto_1
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    invoke-virtual {p0, v0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->wU(IIZLa/R8;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    invoke-virtual {p0, p3, p1, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->N3(La/R8;La/M2;La/Ge;)V

    :cond_3
    :goto_2
    return-void
.end method

.method public final OS(La/fl;II)V
    .locals 0

    .line 1
    if-ne p2, p3, :cond_0

    return-void

    :cond_0
    if-le p3, p2, :cond_1

    add-int/lit8 p3, p3, -0x1

    :goto_0
    if-lt p3, p2, :cond_2

    invoke-virtual {p0, p3, p1}, La/XG;->y6(ILa/fl;)V

    add-int/lit8 p3, p3, -0x1

    goto :goto_0

    :cond_1
    :goto_1
    if-le p2, p3, :cond_2

    invoke-virtual {p0, p2, p1}, La/XG;->y6(ILa/fl;)V

    add-int/lit8 p2, p2, -0x1

    goto :goto_1

    :cond_2
    return-void
.end method

.method public final Pi(IIZZ)Landroid/view/View;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    const/16 v0, 0x140

    if-eqz p3, :cond_0

    const/16 p3, 0x6003

    goto :goto_0

    :cond_0
    move p3, v0

    :goto_0
    if-eqz p4, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    iget p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez p4, :cond_2

    iget-object p4, p0, La/XG;->p:La/v5;

    :goto_2
    invoke-virtual {p4, p1, p2, p3, v0}, La/v5;->X(IIII)Landroid/view/View;

    move-result-object p1

    goto :goto_3

    :cond_2
    iget-object p4, p0, La/XG;->e:La/v5;

    goto :goto_2

    :goto_3
    return-object p1
.end method

.method public final Qn(II)Landroid/view/View;
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    if-le p2, p1, :cond_0

    goto :goto_0

    :cond_0
    if-ge p2, p1, :cond_3

    :goto_0
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {p0, p1}, La/XG;->W(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, La/Tt;->e(Landroid/view/View;)I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {v1}, La/Tt;->Q()I

    move-result v1

    if-ge v0, v1, :cond_1

    const/16 v0, 0x4104

    const/16 v1, 0x4004

    goto :goto_1

    :cond_1
    const/16 v0, 0x1041

    const/16 v1, 0x1001

    :goto_1
    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez v2, :cond_2

    iget-object v2, p0, La/XG;->p:La/v5;

    :goto_2
    invoke-virtual {v2, p1, p2, v0, v1}, La/v5;->X(IIII)Landroid/view/View;

    move-result-object p1

    goto :goto_3

    :cond_2
    iget-object v2, p0, La/XG;->e:La/v5;

    goto :goto_2

    :goto_3
    return-object p1

    :cond_3
    invoke-virtual {p0, p1}, La/XG;->W(I)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public final RL(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {v1}, La/Tt;->Q()I

    move-result v1

    sub-int v1, p2, v1

    iput v1, v0, La/M2;->p:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iput p1, v0, La/M2;->e:I

    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    const/4 v1, -0x1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    move p1, v1

    :goto_0
    iput p1, v0, La/M2;->i:I

    iput v1, v0, La/M2;->Q:I

    iput p2, v0, La/M2;->h:I

    const/high16 p1, -0x80000000

    iput p1, v0, La/M2;->X:I

    return-void
.end method

.method public T(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Hs(La/R8;)I

    move-result p1

    return p1
.end method

.method public Te(La/fl;La/R8;La/us;I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final V(ILa/Ge;)V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget v3, v0, La/fD;->X:I

    .line 8
    .line 9
    if-ltz v3, :cond_0

    .line 10
    .line 11
    iget-boolean v0, v0, La/fD;->R:Z

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Fl()V

    .line 15
    .line 16
    .line 17
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 18
    .line 19
    iget v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 20
    .line 21
    if-ne v3, v1, :cond_2

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    add-int/lit8 v3, p1, -0x1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    move v3, v2

    .line 29
    :cond_2
    :goto_0
    if-eqz v0, :cond_3

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_3
    const/4 v1, 0x1

    .line 33
    :goto_1
    move v0, v2

    .line 34
    :goto_2
    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->D:I

    .line 35
    .line 36
    if-ge v0, v4, :cond_4

    .line 37
    .line 38
    if-ltz v3, :cond_4

    .line 39
    .line 40
    if-ge v3, p1, :cond_4

    .line 41
    .line 42
    invoke-virtual {p2, v3, v2}, La/Ge;->h(II)V

    .line 43
    .line 44
    .line 45
    add-int/2addr v3, v1

    .line 46
    add-int/lit8 v0, v0, 0x1

    .line 47
    .line 48
    goto :goto_2

    .line 49
    :cond_4
    return-void
.end method

.method public VQ(ILa/fl;La/R8;)I
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->fi(ILa/fl;La/R8;)I

    move-result p1

    return p1
.end method

.method public Vm(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 1

    .line 1
    new-instance v0, La/VS;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-direct {v0, p1}, La/VS;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    iput p2, v0, La/VS;->w:I

    .line 11
    .line 12
    invoke-virtual {p0, v0}, La/XG;->Vy(La/VS;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public XS(Z)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    invoke-virtual {p0}, La/XG;->lI()V

    return-void
.end method

.method public final Yo(I)V
    .locals 2

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne p1, v0, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 8
    .line 9
    const-string v1, "invalid orientation:"

    .line 10
    .line 11
    invoke-static {v1, p1}, La/zq;->i(Ljava/lang/String;I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw v0

    .line 19
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 20
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 24
    .line 25
    if-ne p1, v0, :cond_2

    .line 26
    .line 27
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 28
    .line 29
    if-nez v0, :cond_3

    .line 30
    .line 31
    :cond_2
    invoke-static {p0, p1}, La/VO;->w(La/XG;I)La/Tt;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 36
    .line 37
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:La/us;

    .line 38
    .line 39
    iput-object v0, v1, La/us;->w:La/Tt;

    .line 40
    .line 41
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    .line 42
    .line 43
    invoke-virtual {p0}, La/XG;->lI()V

    .line 44
    .line 45
    .line 46
    :cond_3
    return-void
.end method

.method public ZZ(La/fl;La/R8;ZZ)Landroid/view/View;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    .line 4
    .line 5
    .line 6
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x1

    .line 12
    if-eqz p4, :cond_0

    .line 13
    .line 14
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    sub-int/2addr v1, v3

    .line 19
    const/4 v4, -0x1

    .line 20
    move v5, v4

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move v4, v1

    .line 23
    move v1, v2

    .line 24
    move v5, v3

    .line 25
    :goto_0
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 30
    .line 31
    invoke-virtual {v7}, La/Tt;->Q()I

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 36
    .line 37
    invoke-virtual {v8}, La/Tt;->i()I

    .line 38
    .line 39
    .line 40
    move-result v8

    .line 41
    const/4 v9, 0x0

    .line 42
    move-object v10, v9

    .line 43
    move-object v11, v10

    .line 44
    :goto_1
    if-eq v1, v4, :cond_a

    .line 45
    .line 46
    invoke-virtual {v0, v1}, La/XG;->W(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v12

    .line 50
    invoke-static {v12}, La/XG;->U(Landroid/view/View;)I

    .line 51
    .line 52
    .line 53
    move-result v13

    .line 54
    iget-object v14, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 55
    .line 56
    invoke-virtual {v14, v12}, La/Tt;->e(Landroid/view/View;)I

    .line 57
    .line 58
    .line 59
    move-result v14

    .line 60
    iget-object v15, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 61
    .line 62
    invoke-virtual {v15, v12}, La/Tt;->h(Landroid/view/View;)I

    .line 63
    .line 64
    .line 65
    move-result v15

    .line 66
    if-ltz v13, :cond_9

    .line 67
    .line 68
    if-ge v13, v6, :cond_9

    .line 69
    .line 70
    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 71
    .line 72
    .line 73
    move-result-object v13

    .line 74
    check-cast v13, La/Mk;

    .line 75
    .line 76
    iget-object v13, v13, La/Mk;->w:La/Ty;

    .line 77
    .line 78
    invoke-virtual {v13}, La/Ty;->I()Z

    .line 79
    .line 80
    .line 81
    move-result v13

    .line 82
    if-eqz v13, :cond_1

    .line 83
    .line 84
    if-nez v11, :cond_9

    .line 85
    .line 86
    move-object v11, v12

    .line 87
    goto :goto_7

    .line 88
    :cond_1
    if-gt v15, v7, :cond_2

    .line 89
    .line 90
    if-ge v14, v7, :cond_2

    .line 91
    .line 92
    move v13, v3

    .line 93
    goto :goto_2

    .line 94
    :cond_2
    move v13, v2

    .line 95
    :goto_2
    if-lt v14, v8, :cond_3

    .line 96
    .line 97
    if-le v15, v8, :cond_3

    .line 98
    .line 99
    move v14, v3

    .line 100
    goto :goto_3

    .line 101
    :cond_3
    move v14, v2

    .line 102
    :goto_3
    if-nez v13, :cond_5

    .line 103
    .line 104
    if-eqz v14, :cond_4

    .line 105
    .line 106
    goto :goto_4

    .line 107
    :cond_4
    return-object v12

    .line 108
    :cond_5
    :goto_4
    if-eqz p3, :cond_7

    .line 109
    .line 110
    if-eqz v14, :cond_6

    .line 111
    .line 112
    goto :goto_5

    .line 113
    :cond_6
    if-nez v9, :cond_9

    .line 114
    .line 115
    goto :goto_6

    .line 116
    :cond_7
    if-eqz v13, :cond_8

    .line 117
    .line 118
    :goto_5
    move-object v10, v12

    .line 119
    goto :goto_7

    .line 120
    :cond_8
    if-nez v9, :cond_9

    .line 121
    .line 122
    :goto_6
    move-object v9, v12

    .line 123
    :cond_9
    :goto_7
    add-int/2addr v1, v5

    .line 124
    goto :goto_1

    .line 125
    :cond_a
    if-eqz v9, :cond_b

    .line 126
    .line 127
    goto :goto_8

    .line 128
    :cond_b
    if-eqz v10, :cond_c

    .line 129
    .line 130
    move-object v9, v10

    .line 131
    goto :goto_8

    .line 132
    :cond_c
    move-object v9, v11

    .line 133
    :goto_8
    return-object v9
.end method

.method public an()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->f:Z

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final au(Z)Landroid/view/View;
    .locals 3

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    :goto_0
    invoke-virtual {p0, v0, v2, p1, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Pi(IIZZ)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0}, La/XG;->q()I

    move-result v2

    goto :goto_0
.end method

.method public c(Landroid/view/View;ILa/fl;La/R8;)Landroid/view/View;
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Fl()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La/XG;->q()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    const/4 v0, 0x0

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->IL(I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    const/high16 p2, -0x80000000

    .line 17
    .line 18
    if-ne p1, p2, :cond_1

    .line 19
    .line 20
    return-object v0

    .line 21
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 25
    .line 26
    invoke-virtual {v1}, La/Tt;->X()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    int-to-float v1, v1

    .line 31
    const v2, 0x3eaaaaab

    .line 32
    .line 33
    .line 34
    mul-float/2addr v1, v2

    .line 35
    float-to-int v1, v1

    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-virtual {p0, p1, v1, v2, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->wU(IIZLa/R8;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 41
    .line 42
    iput p2, v1, La/M2;->X:I

    .line 43
    .line 44
    iput-boolean v2, v1, La/M2;->w:Z

    .line 45
    .line 46
    const/4 p2, 0x1

    .line 47
    invoke-virtual {p0, p3, v1, p4, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 48
    .line 49
    .line 50
    const/4 p3, -0x1

    .line 51
    if-ne p1, p3, :cond_3

    .line 52
    .line 53
    iget-boolean p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 54
    .line 55
    if-eqz p4, :cond_2

    .line 56
    .line 57
    invoke-virtual {p0}, La/XG;->q()I

    .line 58
    .line 59
    .line 60
    move-result p4

    .line 61
    sub-int/2addr p4, p2

    .line 62
    invoke-virtual {p0, p4, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Qn(II)Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    goto :goto_0

    .line 67
    :cond_2
    invoke-virtual {p0}, La/XG;->q()I

    .line 68
    .line 69
    .line 70
    move-result p2

    .line 71
    invoke-virtual {p0, v2, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->Qn(II)Landroid/view/View;

    .line 72
    .line 73
    .line 74
    move-result-object p2

    .line 75
    goto :goto_0

    .line 76
    :cond_3
    iget-boolean p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 77
    .line 78
    if-eqz p4, :cond_4

    .line 79
    .line 80
    invoke-virtual {p0}, La/XG;->q()I

    .line 81
    .line 82
    .line 83
    move-result p2

    .line 84
    invoke-virtual {p0, v2, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->Qn(II)Landroid/view/View;

    .line 85
    .line 86
    .line 87
    move-result-object p2

    .line 88
    goto :goto_0

    .line 89
    :cond_4
    invoke-virtual {p0}, La/XG;->q()I

    .line 90
    .line 91
    .line 92
    move-result p4

    .line 93
    sub-int/2addr p4, p2

    .line 94
    invoke-virtual {p0, p4, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Qn(II)Landroid/view/View;

    .line 95
    .line 96
    .line 97
    move-result-object p2

    .line 98
    :goto_0
    if-ne p1, p3, :cond_5

    .line 99
    .line 100
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ID()Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    goto :goto_1

    .line 105
    :cond_5
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->xK()Landroid/view/View;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    :goto_1
    invoke-virtual {p1}, Landroid/view/View;->hasFocusable()Z

    .line 110
    .line 111
    .line 112
    move-result p3

    .line 113
    if-eqz p3, :cond_7

    .line 114
    .line 115
    if-nez p2, :cond_6

    .line 116
    .line 117
    return-object v0

    .line 118
    :cond_6
    return-object p1

    .line 119
    :cond_7
    return-object p2
.end method

.method public final cC(La/fl;La/M2;)V
    .locals 5

    .line 1
    iget-boolean v0, p2, La/M2;->w:Z

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    iget-boolean v0, p2, La/M2;->T:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto/16 :goto_9

    .line 10
    .line 11
    :cond_0
    iget v0, p2, La/M2;->X:I

    .line 12
    .line 13
    iget v1, p2, La/M2;->V:I

    .line 14
    .line 15
    iget p2, p2, La/M2;->Q:I

    .line 16
    .line 17
    const/4 v2, -0x1

    .line 18
    const/4 v3, 0x0

    .line 19
    if-ne p2, v2, :cond_7

    .line 20
    .line 21
    invoke-virtual {p0}, La/XG;->q()I

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    if-gez v0, :cond_1

    .line 26
    .line 27
    goto/16 :goto_9

    .line 28
    .line 29
    :cond_1
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 30
    .line 31
    iget v4, v2, La/Tt;->e:I

    .line 32
    .line 33
    iget-object v2, v2, La/VO;->w:La/XG;

    .line 34
    .line 35
    packed-switch v4, :pswitch_data_0

    .line 36
    .line 37
    .line 38
    iget v2, v2, La/XG;->K:I

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :pswitch_0
    iget v2, v2, La/XG;->y:I

    .line 42
    .line 43
    :goto_0
    sub-int/2addr v2, v0

    .line 44
    add-int/2addr v2, v1

    .line 45
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 46
    .line 47
    if-eqz v0, :cond_4

    .line 48
    .line 49
    move v0, v3

    .line 50
    :goto_1
    if-ge v0, p2, :cond_e

    .line 51
    .line 52
    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 57
    .line 58
    invoke-virtual {v4, v1}, La/Tt;->e(Landroid/view/View;)I

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    if-lt v4, v2, :cond_3

    .line 63
    .line 64
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 65
    .line 66
    invoke-virtual {v4, v1}, La/Tt;->I(Landroid/view/View;)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    if-ge v1, v2, :cond_2

    .line 71
    .line 72
    goto :goto_2

    .line 73
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_3
    :goto_2
    invoke-virtual {p0, p1, v3, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->OS(La/fl;II)V

    .line 77
    .line 78
    .line 79
    goto/16 :goto_9

    .line 80
    .line 81
    :cond_4
    add-int/lit8 p2, p2, -0x1

    .line 82
    .line 83
    move v0, p2

    .line 84
    :goto_3
    if-ltz v0, :cond_e

    .line 85
    .line 86
    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 91
    .line 92
    invoke-virtual {v3, v1}, La/Tt;->e(Landroid/view/View;)I

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    if-lt v3, v2, :cond_6

    .line 97
    .line 98
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 99
    .line 100
    invoke-virtual {v3, v1}, La/Tt;->I(Landroid/view/View;)I

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-ge v1, v2, :cond_5

    .line 105
    .line 106
    goto :goto_4

    .line 107
    :cond_5
    add-int/lit8 v0, v0, -0x1

    .line 108
    .line 109
    goto :goto_3

    .line 110
    :cond_6
    :goto_4
    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->OS(La/fl;II)V

    .line 111
    .line 112
    .line 113
    goto :goto_9

    .line 114
    :cond_7
    if-gez v0, :cond_8

    .line 115
    .line 116
    goto :goto_9

    .line 117
    :cond_8
    sub-int/2addr v0, v1

    .line 118
    invoke-virtual {p0}, La/XG;->q()I

    .line 119
    .line 120
    .line 121
    move-result p2

    .line 122
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 123
    .line 124
    if-eqz v1, :cond_b

    .line 125
    .line 126
    add-int/lit8 p2, p2, -0x1

    .line 127
    .line 128
    move v1, p2

    .line 129
    :goto_5
    if-ltz v1, :cond_e

    .line 130
    .line 131
    invoke-virtual {p0, v1}, La/XG;->W(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 136
    .line 137
    invoke-virtual {v3, v2}, La/Tt;->h(Landroid/view/View;)I

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    if-gt v3, v0, :cond_a

    .line 142
    .line 143
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 144
    .line 145
    invoke-virtual {v3, v2}, La/Tt;->V(Landroid/view/View;)I

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    if-le v2, v0, :cond_9

    .line 150
    .line 151
    goto :goto_6

    .line 152
    :cond_9
    add-int/lit8 v1, v1, -0x1

    .line 153
    .line 154
    goto :goto_5

    .line 155
    :cond_a
    :goto_6
    invoke-virtual {p0, p1, p2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->OS(La/fl;II)V

    .line 156
    .line 157
    .line 158
    goto :goto_9

    .line 159
    :cond_b
    move v1, v3

    .line 160
    :goto_7
    if-ge v1, p2, :cond_e

    .line 161
    .line 162
    invoke-virtual {p0, v1}, La/XG;->W(I)Landroid/view/View;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 167
    .line 168
    invoke-virtual {v4, v2}, La/Tt;->h(Landroid/view/View;)I

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    if-gt v4, v0, :cond_d

    .line 173
    .line 174
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 175
    .line 176
    invoke-virtual {v4, v2}, La/Tt;->V(Landroid/view/View;)I

    .line 177
    .line 178
    .line 179
    move-result v2

    .line 180
    if-le v2, v0, :cond_c

    .line 181
    .line 182
    goto :goto_8

    .line 183
    :cond_c
    add-int/lit8 v1, v1, 0x1

    .line 184
    .line 185
    goto :goto_7

    .line 186
    :cond_d
    :goto_8
    invoke-virtual {p0, p1, v3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->OS(La/fl;II)V

    .line 187
    .line 188
    .line 189
    :cond_e
    :goto_9
    return-void

    .line 190
    nop

    .line 191
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public cM(La/R8;[I)V
    .locals 3

    .line 1
    iget p1, p1, La/R8;->w:I

    .line 2
    .line 3
    const/4 v0, -0x1

    .line 4
    const/4 v1, 0x0

    .line 5
    if-eq p1, v0, :cond_0

    .line 6
    .line 7
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 8
    .line 9
    invoke-virtual {p1}, La/Tt;->X()I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move p1, v1

    .line 15
    :goto_0
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 16
    .line 17
    iget v2, v2, La/M2;->Q:I

    .line 18
    .line 19
    if-ne v2, v0, :cond_1

    .line 20
    .line 21
    move v0, v1

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    move v0, p1

    .line 24
    move p1, v1

    .line 25
    :goto_1
    aput p1, p2, v1

    .line 26
    .line 27
    const/4 p1, 0x1

    .line 28
    aput v0, p2, p1

    .line 29
    .line 30
    return-void
.end method

.method public final ck()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, La/XG;->z()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public d()La/Mk;
    .locals 2

    .line 1
    new-instance v0, La/Mk;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, La/Mk;-><init>(II)V

    return-object v0
.end method

.method public final e()Z
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final eH()Landroid/os/Parcelable;
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, La/fD;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iget v2, v0, La/fD;->X:I

    .line 11
    .line 12
    iput v2, v1, La/fD;->X:I

    .line 13
    .line 14
    iget v2, v0, La/fD;->K:I

    .line 15
    .line 16
    iput v2, v1, La/fD;->K:I

    .line 17
    .line 18
    iget-boolean v0, v0, La/fD;->R:Z

    .line 19
    .line 20
    iput-boolean v0, v1, La/fD;->R:Z

    .line 21
    .line 22
    return-object v1

    .line 23
    :cond_0
    new-instance v0, La/fD;

    .line 24
    .line 25
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, La/XG;->q()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-lez v1, :cond_2

    .line 33
    .line 34
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    .line 35
    .line 36
    .line 37
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->f:Z

    .line 38
    .line 39
    iget-boolean v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 40
    .line 41
    xor-int/2addr v1, v2

    .line 42
    iput-boolean v1, v0, La/fD;->R:Z

    .line 43
    .line 44
    if-eqz v1, :cond_1

    .line 45
    .line 46
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->xK()Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 51
    .line 52
    invoke-virtual {v2}, La/Tt;->i()I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 57
    .line 58
    invoke-virtual {v3, v1}, La/Tt;->h(Landroid/view/View;)I

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    sub-int/2addr v2, v3

    .line 63
    iput v2, v0, La/fD;->K:I

    .line 64
    .line 65
    invoke-static {v1}, La/XG;->U(Landroid/view/View;)I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    iput v1, v0, La/fD;->X:I

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ID()Landroid/view/View;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-static {v1}, La/XG;->U(Landroid/view/View;)I

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    iput v2, v0, La/fD;->X:I

    .line 81
    .line 82
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 83
    .line 84
    invoke-virtual {v2, v1}, La/Tt;->e(Landroid/view/View;)I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 89
    .line 90
    invoke-virtual {v2}, La/Tt;->Q()I

    .line 91
    .line 92
    .line 93
    move-result v2

    .line 94
    sub-int/2addr v1, v2

    .line 95
    iput v1, v0, La/fD;->K:I

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_2
    const/4 v1, -0x1

    .line 99
    iput v1, v0, La/fD;->X:I

    .line 100
    .line 101
    :goto_0
    return-object v0
.end method

.method public final fi(ILa/fl;La/R8;)I
    .locals 5

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    const/4 v2, 0x1

    iput-boolean v2, v0, La/M2;->w:Z

    if-lez p1, :cond_1

    move v0, v2

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_0
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v3

    invoke-virtual {p0, v0, v3, v2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->wU(IIZLa/R8;)V

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iget v4, v2, La/M2;->X:I

    invoke-virtual {p0, p2, v2, p3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    move-result p2

    add-int/2addr p2, v4

    if-gez p2, :cond_2

    return v1

    :cond_2
    if-le v3, p2, :cond_3

    mul-int p1, v0, p2

    :cond_3
    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    neg-int p3, p1

    invoke-virtual {p2, p3}, La/Tt;->M(I)V

    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    iput p1, p2, La/M2;->I:I

    return p1

    :cond_4
    :goto_1
    return v1
.end method

.method public final i()Z
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final j()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public final m(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->AW(La/R8;)I

    move-result p1

    return p1
.end method

.method public final p(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    if-nez v0, :cond_0

    invoke-super {p0, p1}, La/XG;->p(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public p7(La/R8;)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:La/us;

    invoke-virtual {p1}, La/us;->e()V

    return-void
.end method

.method public final r(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    .line 1
    return-void
.end method

.method public rC(La/fl;La/R8;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 8
    .line 9
    const/4 v4, -0x1

    .line 10
    if-nez v3, :cond_0

    .line 11
    .line 12
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 13
    .line 14
    if-eq v3, v4, :cond_1

    .line 15
    .line 16
    :cond_0
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-nez v3, :cond_1

    .line 21
    .line 22
    invoke-virtual/range {p0 .. p1}, La/XG;->ZU(La/fl;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_1
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 27
    .line 28
    if-eqz v3, :cond_2

    .line 29
    .line 30
    iget v3, v3, La/fD;->X:I

    .line 31
    .line 32
    if-ltz v3, :cond_2

    .line 33
    .line 34
    iput v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 35
    .line 36
    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Ey()V

    .line 37
    .line 38
    .line 39
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 40
    .line 41
    const/4 v5, 0x0

    .line 42
    iput-boolean v5, v3, La/M2;->w:Z

    .line 43
    .line 44
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->Fl()V

    .line 45
    .line 46
    .line 47
    iget-object v3, v0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 48
    .line 49
    if-nez v3, :cond_4

    .line 50
    .line 51
    :cond_3
    :goto_0
    const/4 v3, 0x0

    .line 52
    goto :goto_1

    .line 53
    :cond_4
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    if-eqz v3, :cond_3

    .line 58
    .line 59
    iget-object v7, v0, La/XG;->w:La/D6;

    .line 60
    .line 61
    invoke-virtual {v7, v3}, La/D6;->I(Landroid/view/View;)Z

    .line 62
    .line 63
    .line 64
    move-result v7

    .line 65
    if-eqz v7, :cond_5

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_5
    :goto_1
    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:La/us;

    .line 69
    .line 70
    iget-boolean v8, v7, La/us;->i:Z

    .line 71
    .line 72
    const/4 v9, 0x1

    .line 73
    const/high16 v10, -0x80000000

    .line 74
    .line 75
    if-eqz v8, :cond_8

    .line 76
    .line 77
    iget v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 78
    .line 79
    if-ne v8, v4, :cond_8

    .line 80
    .line 81
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 82
    .line 83
    if-eqz v8, :cond_6

    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_6
    if-eqz v3, :cond_26

    .line 87
    .line 88
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 89
    .line 90
    invoke-virtual {v8, v3}, La/Tt;->e(Landroid/view/View;)I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 95
    .line 96
    invoke-virtual {v11}, La/Tt;->i()I

    .line 97
    .line 98
    .line 99
    move-result v11

    .line 100
    if-ge v8, v11, :cond_7

    .line 101
    .line 102
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 103
    .line 104
    invoke-virtual {v8, v3}, La/Tt;->h(Landroid/view/View;)I

    .line 105
    .line 106
    .line 107
    move-result v8

    .line 108
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 109
    .line 110
    invoke-virtual {v11}, La/Tt;->Q()I

    .line 111
    .line 112
    .line 113
    move-result v11

    .line 114
    if-gt v8, v11, :cond_26

    .line 115
    .line 116
    :cond_7
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 117
    .line 118
    .line 119
    move-result v8

    .line 120
    invoke-virtual {v7, v3, v8}, La/us;->p(Landroid/view/View;I)V

    .line 121
    .line 122
    .line 123
    goto/16 :goto_13

    .line 124
    .line 125
    :cond_8
    :goto_2
    invoke-virtual {v7}, La/us;->e()V

    .line 126
    .line 127
    .line 128
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 129
    .line 130
    iget-boolean v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    .line 131
    .line 132
    xor-int/2addr v3, v8

    .line 133
    iput-boolean v3, v7, La/us;->e:Z

    .line 134
    .line 135
    iget-boolean v3, v2, La/R8;->X:Z

    .line 136
    .line 137
    if-nez v3, :cond_18

    .line 138
    .line 139
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 140
    .line 141
    if-ne v3, v4, :cond_9

    .line 142
    .line 143
    goto/16 :goto_b

    .line 144
    .line 145
    :cond_9
    if-ltz v3, :cond_17

    .line 146
    .line 147
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 148
    .line 149
    .line 150
    move-result v8

    .line 151
    if-lt v3, v8, :cond_a

    .line 152
    .line 153
    goto/16 :goto_a

    .line 154
    .line 155
    :cond_a
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 156
    .line 157
    iput v3, v7, La/us;->h:I

    .line 158
    .line 159
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 160
    .line 161
    if-eqz v8, :cond_c

    .line 162
    .line 163
    iget v11, v8, La/fD;->X:I

    .line 164
    .line 165
    if-ltz v11, :cond_c

    .line 166
    .line 167
    iget-boolean v3, v8, La/fD;->R:Z

    .line 168
    .line 169
    iput-boolean v3, v7, La/us;->e:Z

    .line 170
    .line 171
    if-eqz v3, :cond_b

    .line 172
    .line 173
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 174
    .line 175
    invoke-virtual {v3}, La/Tt;->i()I

    .line 176
    .line 177
    .line 178
    move-result v3

    .line 179
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 180
    .line 181
    iget v8, v8, La/fD;->K:I

    .line 182
    .line 183
    :goto_3
    sub-int/2addr v3, v8

    .line 184
    :goto_4
    iput v3, v7, La/us;->p:I

    .line 185
    .line 186
    goto/16 :goto_12

    .line 187
    .line 188
    :cond_b
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 189
    .line 190
    invoke-virtual {v3}, La/Tt;->Q()I

    .line 191
    .line 192
    .line 193
    move-result v3

    .line 194
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->H:La/fD;

    .line 195
    .line 196
    iget v8, v8, La/fD;->K:I

    .line 197
    .line 198
    :goto_5
    add-int/2addr v3, v8

    .line 199
    goto :goto_4

    .line 200
    :cond_c
    iget v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 201
    .line 202
    if-ne v8, v10, :cond_15

    .line 203
    .line 204
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->L(I)Landroid/view/View;

    .line 205
    .line 206
    .line 207
    move-result-object v3

    .line 208
    if-eqz v3, :cond_11

    .line 209
    .line 210
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 211
    .line 212
    invoke-virtual {v8, v3}, La/Tt;->p(Landroid/view/View;)I

    .line 213
    .line 214
    .line 215
    move-result v8

    .line 216
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 217
    .line 218
    invoke-virtual {v11}, La/Tt;->X()I

    .line 219
    .line 220
    .line 221
    move-result v11

    .line 222
    if-le v8, v11, :cond_d

    .line 223
    .line 224
    goto/16 :goto_9

    .line 225
    .line 226
    :cond_d
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 227
    .line 228
    invoke-virtual {v8, v3}, La/Tt;->e(Landroid/view/View;)I

    .line 229
    .line 230
    .line 231
    move-result v8

    .line 232
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 233
    .line 234
    invoke-virtual {v11}, La/Tt;->Q()I

    .line 235
    .line 236
    .line 237
    move-result v11

    .line 238
    sub-int/2addr v8, v11

    .line 239
    if-gez v8, :cond_e

    .line 240
    .line 241
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 242
    .line 243
    invoke-virtual {v3}, La/Tt;->Q()I

    .line 244
    .line 245
    .line 246
    move-result v3

    .line 247
    iput v3, v7, La/us;->p:I

    .line 248
    .line 249
    iput-boolean v5, v7, La/us;->e:Z

    .line 250
    .line 251
    goto/16 :goto_12

    .line 252
    .line 253
    :cond_e
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 254
    .line 255
    invoke-virtual {v8}, La/Tt;->i()I

    .line 256
    .line 257
    .line 258
    move-result v8

    .line 259
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 260
    .line 261
    invoke-virtual {v11, v3}, La/Tt;->h(Landroid/view/View;)I

    .line 262
    .line 263
    .line 264
    move-result v11

    .line 265
    sub-int/2addr v8, v11

    .line 266
    if-gez v8, :cond_f

    .line 267
    .line 268
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 269
    .line 270
    invoke-virtual {v3}, La/Tt;->i()I

    .line 271
    .line 272
    .line 273
    move-result v3

    .line 274
    iput v3, v7, La/us;->p:I

    .line 275
    .line 276
    iput-boolean v9, v7, La/us;->e:Z

    .line 277
    .line 278
    goto/16 :goto_12

    .line 279
    .line 280
    :cond_f
    iget-boolean v8, v7, La/us;->e:Z

    .line 281
    .line 282
    if-eqz v8, :cond_10

    .line 283
    .line 284
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 285
    .line 286
    invoke-virtual {v8, v3}, La/Tt;->h(Landroid/view/View;)I

    .line 287
    .line 288
    .line 289
    move-result v3

    .line 290
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 291
    .line 292
    invoke-virtual {v8}, La/VO;->O()I

    .line 293
    .line 294
    .line 295
    move-result v8

    .line 296
    add-int/2addr v8, v3

    .line 297
    goto :goto_6

    .line 298
    :cond_10
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 299
    .line 300
    invoke-virtual {v8, v3}, La/Tt;->e(Landroid/view/View;)I

    .line 301
    .line 302
    .line 303
    move-result v8

    .line 304
    :goto_6
    iput v8, v7, La/us;->p:I

    .line 305
    .line 306
    goto/16 :goto_12

    .line 307
    .line 308
    :cond_11
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 309
    .line 310
    .line 311
    move-result v3

    .line 312
    if-lez v3, :cond_14

    .line 313
    .line 314
    invoke-virtual {v0, v5}, La/XG;->W(I)Landroid/view/View;

    .line 315
    .line 316
    .line 317
    move-result-object v3

    .line 318
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 319
    .line 320
    .line 321
    move-result v3

    .line 322
    iget v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 323
    .line 324
    if-ge v8, v3, :cond_12

    .line 325
    .line 326
    move v3, v9

    .line 327
    goto :goto_7

    .line 328
    :cond_12
    move v3, v5

    .line 329
    :goto_7
    iget-boolean v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 330
    .line 331
    if-ne v3, v8, :cond_13

    .line 332
    .line 333
    move v3, v9

    .line 334
    goto :goto_8

    .line 335
    :cond_13
    move v3, v5

    .line 336
    :goto_8
    iput-boolean v3, v7, La/us;->e:Z

    .line 337
    .line 338
    :cond_14
    :goto_9
    invoke-virtual {v7}, La/us;->w()V

    .line 339
    .line 340
    .line 341
    goto/16 :goto_12

    .line 342
    .line 343
    :cond_15
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 344
    .line 345
    iput-boolean v3, v7, La/us;->e:Z

    .line 346
    .line 347
    if-eqz v3, :cond_16

    .line 348
    .line 349
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 350
    .line 351
    invoke-virtual {v3}, La/Tt;->i()I

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    iget v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 356
    .line 357
    goto/16 :goto_3

    .line 358
    .line 359
    :cond_16
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 360
    .line 361
    invoke-virtual {v3}, La/Tt;->Q()I

    .line 362
    .line 363
    .line 364
    move-result v3

    .line 365
    iget v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 366
    .line 367
    goto/16 :goto_5

    .line 368
    .line 369
    :cond_17
    :goto_a
    iput v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 370
    .line 371
    iput v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 372
    .line 373
    :cond_18
    :goto_b
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 374
    .line 375
    .line 376
    move-result v3

    .line 377
    if-nez v3, :cond_19

    .line 378
    .line 379
    goto/16 :goto_10

    .line 380
    .line 381
    :cond_19
    iget-object v3, v0, La/XG;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 382
    .line 383
    if-nez v3, :cond_1b

    .line 384
    .line 385
    :cond_1a
    :goto_c
    const/4 v3, 0x0

    .line 386
    goto :goto_d

    .line 387
    :cond_1b
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 388
    .line 389
    .line 390
    move-result-object v3

    .line 391
    if-eqz v3, :cond_1a

    .line 392
    .line 393
    iget-object v8, v0, La/XG;->w:La/D6;

    .line 394
    .line 395
    invoke-virtual {v8, v3}, La/D6;->I(Landroid/view/View;)Z

    .line 396
    .line 397
    .line 398
    move-result v8

    .line 399
    if-eqz v8, :cond_1c

    .line 400
    .line 401
    goto :goto_c

    .line 402
    :cond_1c
    :goto_d
    if-eqz v3, :cond_1d

    .line 403
    .line 404
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 405
    .line 406
    .line 407
    move-result-object v8

    .line 408
    check-cast v8, La/Mk;

    .line 409
    .line 410
    iget-object v11, v8, La/Mk;->w:La/Ty;

    .line 411
    .line 412
    invoke-virtual {v11}, La/Ty;->I()Z

    .line 413
    .line 414
    .line 415
    move-result v11

    .line 416
    if-nez v11, :cond_1d

    .line 417
    .line 418
    iget-object v11, v8, La/Mk;->w:La/Ty;

    .line 419
    .line 420
    invoke-virtual {v11}, La/Ty;->p()I

    .line 421
    .line 422
    .line 423
    move-result v11

    .line 424
    if-ltz v11, :cond_1d

    .line 425
    .line 426
    iget-object v8, v8, La/Mk;->w:La/Ty;

    .line 427
    .line 428
    invoke-virtual {v8}, La/Ty;->p()I

    .line 429
    .line 430
    .line 431
    move-result v8

    .line 432
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 433
    .line 434
    .line 435
    move-result v11

    .line 436
    if-ge v8, v11, :cond_1d

    .line 437
    .line 438
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 439
    .line 440
    .line 441
    move-result v8

    .line 442
    invoke-virtual {v7, v3, v8}, La/us;->p(Landroid/view/View;I)V

    .line 443
    .line 444
    .line 445
    goto/16 :goto_12

    .line 446
    .line 447
    :cond_1d
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->f:Z

    .line 448
    .line 449
    iget-boolean v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    .line 450
    .line 451
    if-eq v3, v8, :cond_1e

    .line 452
    .line 453
    goto :goto_10

    .line 454
    :cond_1e
    iget-boolean v3, v7, La/us;->e:Z

    .line 455
    .line 456
    invoke-virtual {v0, v1, v2, v3, v8}, Landroidx/recyclerview/widget/LinearLayoutManager;->ZZ(La/fl;La/R8;ZZ)Landroid/view/View;

    .line 457
    .line 458
    .line 459
    move-result-object v3

    .line 460
    if-eqz v3, :cond_23

    .line 461
    .line 462
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 463
    .line 464
    .line 465
    move-result v8

    .line 466
    invoke-virtual {v7, v3, v8}, La/us;->h(Landroid/view/View;I)V

    .line 467
    .line 468
    .line 469
    iget-boolean v8, v2, La/R8;->X:Z

    .line 470
    .line 471
    if-nez v8, :cond_25

    .line 472
    .line 473
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->an()Z

    .line 474
    .line 475
    .line 476
    move-result v8

    .line 477
    if-eqz v8, :cond_25

    .line 478
    .line 479
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 480
    .line 481
    invoke-virtual {v8, v3}, La/Tt;->e(Landroid/view/View;)I

    .line 482
    .line 483
    .line 484
    move-result v8

    .line 485
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 486
    .line 487
    invoke-virtual {v11, v3}, La/Tt;->h(Landroid/view/View;)I

    .line 488
    .line 489
    .line 490
    move-result v3

    .line 491
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 492
    .line 493
    invoke-virtual {v11}, La/Tt;->Q()I

    .line 494
    .line 495
    .line 496
    move-result v11

    .line 497
    iget-object v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 498
    .line 499
    invoke-virtual {v12}, La/Tt;->i()I

    .line 500
    .line 501
    .line 502
    move-result v12

    .line 503
    if-gt v3, v11, :cond_1f

    .line 504
    .line 505
    if-ge v8, v11, :cond_1f

    .line 506
    .line 507
    move v13, v9

    .line 508
    goto :goto_e

    .line 509
    :cond_1f
    move v13, v5

    .line 510
    :goto_e
    if-lt v8, v12, :cond_20

    .line 511
    .line 512
    if-le v3, v12, :cond_20

    .line 513
    .line 514
    move v3, v9

    .line 515
    goto :goto_f

    .line 516
    :cond_20
    move v3, v5

    .line 517
    :goto_f
    if-nez v13, :cond_21

    .line 518
    .line 519
    if-eqz v3, :cond_25

    .line 520
    .line 521
    :cond_21
    iget-boolean v3, v7, La/us;->e:Z

    .line 522
    .line 523
    if-eqz v3, :cond_22

    .line 524
    .line 525
    move v11, v12

    .line 526
    :cond_22
    iput v11, v7, La/us;->p:I

    .line 527
    .line 528
    goto :goto_12

    .line 529
    :cond_23
    :goto_10
    invoke-virtual {v7}, La/us;->w()V

    .line 530
    .line 531
    .line 532
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    .line 533
    .line 534
    if-eqz v3, :cond_24

    .line 535
    .line 536
    invoke-virtual/range {p2 .. p2}, La/R8;->h()I

    .line 537
    .line 538
    .line 539
    move-result v3

    .line 540
    sub-int/2addr v3, v9

    .line 541
    goto :goto_11

    .line 542
    :cond_24
    move v3, v5

    .line 543
    :goto_11
    iput v3, v7, La/us;->h:I

    .line 544
    .line 545
    :cond_25
    :goto_12
    iput-boolean v9, v7, La/us;->i:Z

    .line 546
    .line 547
    :cond_26
    :goto_13
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 548
    .line 549
    iget v8, v3, La/M2;->I:I

    .line 550
    .line 551
    if-ltz v8, :cond_27

    .line 552
    .line 553
    move v8, v9

    .line 554
    goto :goto_14

    .line 555
    :cond_27
    move v8, v4

    .line 556
    :goto_14
    iput v8, v3, La/M2;->Q:I

    .line 557
    .line 558
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->Y:[I

    .line 559
    .line 560
    aput v5, v3, v5

    .line 561
    .line 562
    aput v5, v3, v9

    .line 563
    .line 564
    invoke-virtual {v0, v2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->cM(La/R8;[I)V

    .line 565
    .line 566
    .line 567
    aget v8, v3, v5

    .line 568
    .line 569
    invoke-static {v5, v8}, Ljava/lang/Math;->max(II)I

    .line 570
    .line 571
    .line 572
    move-result v8

    .line 573
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 574
    .line 575
    invoke-virtual {v11}, La/Tt;->Q()I

    .line 576
    .line 577
    .line 578
    move-result v11

    .line 579
    add-int/2addr v11, v8

    .line 580
    aget v3, v3, v9

    .line 581
    .line 582
    invoke-static {v5, v3}, Ljava/lang/Math;->max(II)I

    .line 583
    .line 584
    .line 585
    move-result v3

    .line 586
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 587
    .line 588
    iget v12, v8, La/Tt;->e:I

    .line 589
    .line 590
    iget-object v8, v8, La/VO;->w:La/XG;

    .line 591
    .line 592
    packed-switch v12, :pswitch_data_0

    .line 593
    .line 594
    .line 595
    invoke-virtual {v8}, La/XG;->P()I

    .line 596
    .line 597
    .line 598
    move-result v8

    .line 599
    goto :goto_15

    .line 600
    :pswitch_0
    invoke-virtual {v8}, La/XG;->Y()I

    .line 601
    .line 602
    .line 603
    move-result v8

    .line 604
    :goto_15
    add-int/2addr v8, v3

    .line 605
    iget-boolean v3, v2, La/R8;->X:Z

    .line 606
    .line 607
    if-eqz v3, :cond_2a

    .line 608
    .line 609
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->E:I

    .line 610
    .line 611
    if-eq v3, v4, :cond_2a

    .line 612
    .line 613
    iget v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 614
    .line 615
    if-eq v12, v10, :cond_2a

    .line 616
    .line 617
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->L(I)Landroid/view/View;

    .line 618
    .line 619
    .line 620
    move-result-object v3

    .line 621
    if-eqz v3, :cond_2a

    .line 622
    .line 623
    iget-boolean v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 624
    .line 625
    if-eqz v10, :cond_28

    .line 626
    .line 627
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 628
    .line 629
    invoke-virtual {v10}, La/Tt;->i()I

    .line 630
    .line 631
    .line 632
    move-result v10

    .line 633
    iget-object v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 634
    .line 635
    invoke-virtual {v12, v3}, La/Tt;->h(Landroid/view/View;)I

    .line 636
    .line 637
    .line 638
    move-result v3

    .line 639
    sub-int/2addr v10, v3

    .line 640
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 641
    .line 642
    :goto_16
    sub-int/2addr v10, v3

    .line 643
    goto :goto_17

    .line 644
    :cond_28
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 645
    .line 646
    invoke-virtual {v10, v3}, La/Tt;->e(Landroid/view/View;)I

    .line 647
    .line 648
    .line 649
    move-result v3

    .line 650
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 651
    .line 652
    invoke-virtual {v10}, La/Tt;->Q()I

    .line 653
    .line 654
    .line 655
    move-result v10

    .line 656
    sub-int/2addr v3, v10

    .line 657
    iget v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->S:I

    .line 658
    .line 659
    goto :goto_16

    .line 660
    :goto_17
    if-lez v10, :cond_29

    .line 661
    .line 662
    add-int/2addr v11, v10

    .line 663
    goto :goto_18

    .line 664
    :cond_29
    sub-int/2addr v8, v10

    .line 665
    :cond_2a
    :goto_18
    iget-boolean v3, v7, La/us;->e:Z

    .line 666
    .line 667
    if-eqz v3, :cond_2c

    .line 668
    .line 669
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 670
    .line 671
    if-eqz v3, :cond_2d

    .line 672
    .line 673
    :cond_2b
    move v4, v9

    .line 674
    goto :goto_19

    .line 675
    :cond_2c
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 676
    .line 677
    if-eqz v3, :cond_2b

    .line 678
    .line 679
    :cond_2d
    :goto_19
    invoke-virtual {v0, v1, v2, v7, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->Te(La/fl;La/R8;La/us;I)V

    .line 680
    .line 681
    .line 682
    invoke-virtual/range {p0 .. p1}, La/XG;->R(La/fl;)V

    .line 683
    .line 684
    .line 685
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 686
    .line 687
    iget-object v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 688
    .line 689
    iget v10, v4, La/Tt;->e:I

    .line 690
    .line 691
    iget-object v4, v4, La/VO;->w:La/XG;

    .line 692
    .line 693
    packed-switch v10, :pswitch_data_1

    .line 694
    .line 695
    .line 696
    iget v12, v4, La/XG;->m:I

    .line 697
    .line 698
    goto :goto_1a

    .line 699
    :pswitch_1
    iget v12, v4, La/XG;->T:I

    .line 700
    .line 701
    :goto_1a
    if-nez v12, :cond_2e

    .line 702
    .line 703
    packed-switch v10, :pswitch_data_2

    .line 704
    .line 705
    .line 706
    iget v4, v4, La/XG;->K:I

    .line 707
    .line 708
    goto :goto_1b

    .line 709
    :pswitch_2
    iget v4, v4, La/XG;->y:I

    .line 710
    .line 711
    :goto_1b
    if-nez v4, :cond_2e

    .line 712
    .line 713
    move v4, v9

    .line 714
    goto :goto_1c

    .line 715
    :cond_2e
    move v4, v5

    .line 716
    :goto_1c
    iput-boolean v4, v3, La/M2;->T:Z

    .line 717
    .line 718
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 719
    .line 720
    .line 721
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 722
    .line 723
    iput v5, v3, La/M2;->V:I

    .line 724
    .line 725
    iget-boolean v3, v7, La/us;->e:Z

    .line 726
    .line 727
    if-eqz v3, :cond_30

    .line 728
    .line 729
    iget v3, v7, La/us;->h:I

    .line 730
    .line 731
    iget v4, v7, La/us;->p:I

    .line 732
    .line 733
    invoke-virtual {v0, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->RL(II)V

    .line 734
    .line 735
    .line 736
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 737
    .line 738
    iput v11, v3, La/M2;->O:I

    .line 739
    .line 740
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 741
    .line 742
    .line 743
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 744
    .line 745
    iget v4, v3, La/M2;->h:I

    .line 746
    .line 747
    iget v10, v3, La/M2;->e:I

    .line 748
    .line 749
    iget v3, v3, La/M2;->p:I

    .line 750
    .line 751
    if-lez v3, :cond_2f

    .line 752
    .line 753
    add-int/2addr v8, v3

    .line 754
    :cond_2f
    iget v3, v7, La/us;->h:I

    .line 755
    .line 756
    iget v11, v7, La/us;->p:I

    .line 757
    .line 758
    invoke-virtual {v0, v3, v11}, Landroidx/recyclerview/widget/LinearLayoutManager;->AR(II)V

    .line 759
    .line 760
    .line 761
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 762
    .line 763
    iput v8, v3, La/M2;->O:I

    .line 764
    .line 765
    iget v8, v3, La/M2;->e:I

    .line 766
    .line 767
    iget v11, v3, La/M2;->i:I

    .line 768
    .line 769
    add-int/2addr v8, v11

    .line 770
    iput v8, v3, La/M2;->e:I

    .line 771
    .line 772
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 773
    .line 774
    .line 775
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 776
    .line 777
    iget v8, v3, La/M2;->h:I

    .line 778
    .line 779
    iget v3, v3, La/M2;->p:I

    .line 780
    .line 781
    if-lez v3, :cond_33

    .line 782
    .line 783
    invoke-virtual {v0, v10, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->RL(II)V

    .line 784
    .line 785
    .line 786
    iget-object v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 787
    .line 788
    iput v3, v4, La/M2;->O:I

    .line 789
    .line 790
    invoke-virtual {v0, v1, v4, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 791
    .line 792
    .line 793
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 794
    .line 795
    iget v4, v3, La/M2;->h:I

    .line 796
    .line 797
    goto :goto_1d

    .line 798
    :cond_30
    iget v3, v7, La/us;->h:I

    .line 799
    .line 800
    iget v4, v7, La/us;->p:I

    .line 801
    .line 802
    invoke-virtual {v0, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->AR(II)V

    .line 803
    .line 804
    .line 805
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 806
    .line 807
    iput v8, v3, La/M2;->O:I

    .line 808
    .line 809
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 810
    .line 811
    .line 812
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 813
    .line 814
    iget v8, v3, La/M2;->h:I

    .line 815
    .line 816
    iget v4, v3, La/M2;->e:I

    .line 817
    .line 818
    iget v3, v3, La/M2;->p:I

    .line 819
    .line 820
    if-lez v3, :cond_31

    .line 821
    .line 822
    add-int/2addr v11, v3

    .line 823
    :cond_31
    iget v3, v7, La/us;->h:I

    .line 824
    .line 825
    iget v10, v7, La/us;->p:I

    .line 826
    .line 827
    invoke-virtual {v0, v3, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;->RL(II)V

    .line 828
    .line 829
    .line 830
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 831
    .line 832
    iput v11, v3, La/M2;->O:I

    .line 833
    .line 834
    iget v10, v3, La/M2;->e:I

    .line 835
    .line 836
    iget v11, v3, La/M2;->i:I

    .line 837
    .line 838
    add-int/2addr v10, v11

    .line 839
    iput v10, v3, La/M2;->e:I

    .line 840
    .line 841
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 842
    .line 843
    .line 844
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 845
    .line 846
    iget v10, v3, La/M2;->h:I

    .line 847
    .line 848
    iget v3, v3, La/M2;->p:I

    .line 849
    .line 850
    if-lez v3, :cond_32

    .line 851
    .line 852
    invoke-virtual {v0, v4, v8}, Landroidx/recyclerview/widget/LinearLayoutManager;->AR(II)V

    .line 853
    .line 854
    .line 855
    iget-object v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 856
    .line 857
    iput v3, v4, La/M2;->O:I

    .line 858
    .line 859
    invoke-virtual {v0, v1, v4, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 860
    .line 861
    .line 862
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 863
    .line 864
    iget v8, v3, La/M2;->h:I

    .line 865
    .line 866
    :cond_32
    move v4, v10

    .line 867
    :cond_33
    :goto_1d
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 868
    .line 869
    .line 870
    move-result v3

    .line 871
    if-lez v3, :cond_35

    .line 872
    .line 873
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 874
    .line 875
    iget-boolean v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    .line 876
    .line 877
    xor-int/2addr v3, v10

    .line 878
    if-eqz v3, :cond_34

    .line 879
    .line 880
    invoke-virtual {v0, v8, v1, v2, v9}, Landroidx/recyclerview/widget/LinearLayoutManager;->rn(ILa/fl;La/R8;Z)I

    .line 881
    .line 882
    .line 883
    move-result v3

    .line 884
    add-int/2addr v4, v3

    .line 885
    add-int/2addr v8, v3

    .line 886
    invoke-virtual {v0, v4, v1, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->xY(ILa/fl;La/R8;Z)I

    .line 887
    .line 888
    .line 889
    move-result v3

    .line 890
    :goto_1e
    add-int/2addr v4, v3

    .line 891
    add-int/2addr v8, v3

    .line 892
    goto :goto_1f

    .line 893
    :cond_34
    invoke-virtual {v0, v4, v1, v2, v9}, Landroidx/recyclerview/widget/LinearLayoutManager;->xY(ILa/fl;La/R8;Z)I

    .line 894
    .line 895
    .line 896
    move-result v3

    .line 897
    add-int/2addr v4, v3

    .line 898
    add-int/2addr v8, v3

    .line 899
    invoke-virtual {v0, v8, v1, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->rn(ILa/fl;La/R8;Z)I

    .line 900
    .line 901
    .line 902
    move-result v3

    .line 903
    goto :goto_1e

    .line 904
    :cond_35
    :goto_1f
    iget-boolean v3, v2, La/R8;->M:Z

    .line 905
    .line 906
    if-eqz v3, :cond_3d

    .line 907
    .line 908
    invoke-virtual/range {p0 .. p0}, La/XG;->q()I

    .line 909
    .line 910
    .line 911
    move-result v3

    .line 912
    if-eqz v3, :cond_3d

    .line 913
    .line 914
    iget-boolean v3, v2, La/R8;->X:Z

    .line 915
    .line 916
    if-nez v3, :cond_3d

    .line 917
    .line 918
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->an()Z

    .line 919
    .line 920
    .line 921
    move-result v3

    .line 922
    if-nez v3, :cond_36

    .line 923
    .line 924
    goto/16 :goto_24

    .line 925
    .line 926
    :cond_36
    iget-object v3, v1, La/fl;->Q:Ljava/lang/Object;

    .line 927
    .line 928
    check-cast v3, Ljava/util/List;

    .line 929
    .line 930
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 931
    .line 932
    .line 933
    move-result v10

    .line 934
    invoke-virtual {v0, v5}, La/XG;->W(I)Landroid/view/View;

    .line 935
    .line 936
    .line 937
    move-result-object v11

    .line 938
    invoke-static {v11}, La/XG;->U(Landroid/view/View;)I

    .line 939
    .line 940
    .line 941
    move-result v11

    .line 942
    move v12, v5

    .line 943
    move v13, v12

    .line 944
    move v14, v13

    .line 945
    :goto_20
    if-ge v12, v10, :cond_3a

    .line 946
    .line 947
    invoke-interface {v3, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 948
    .line 949
    .line 950
    move-result-object v15

    .line 951
    check-cast v15, La/Ty;

    .line 952
    .line 953
    invoke-virtual {v15}, La/Ty;->I()Z

    .line 954
    .line 955
    .line 956
    move-result v16

    .line 957
    if-eqz v16, :cond_37

    .line 958
    .line 959
    goto :goto_22

    .line 960
    :cond_37
    invoke-virtual {v15}, La/Ty;->p()I

    .line 961
    .line 962
    .line 963
    move-result v9

    .line 964
    if-ge v9, v11, :cond_38

    .line 965
    .line 966
    const/4 v9, 0x1

    .line 967
    goto :goto_21

    .line 968
    :cond_38
    move v9, v5

    .line 969
    :goto_21
    iget-boolean v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 970
    .line 971
    iget-object v15, v15, La/Ty;->w:Landroid/view/View;

    .line 972
    .line 973
    if-eq v9, v6, :cond_39

    .line 974
    .line 975
    iget-object v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 976
    .line 977
    invoke-virtual {v6, v15}, La/Tt;->p(Landroid/view/View;)I

    .line 978
    .line 979
    .line 980
    move-result v6

    .line 981
    add-int/2addr v13, v6

    .line 982
    goto :goto_22

    .line 983
    :cond_39
    iget-object v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 984
    .line 985
    invoke-virtual {v6, v15}, La/Tt;->p(Landroid/view/View;)I

    .line 986
    .line 987
    .line 988
    move-result v6

    .line 989
    add-int/2addr v14, v6

    .line 990
    :goto_22
    add-int/lit8 v12, v12, 0x1

    .line 991
    .line 992
    const/4 v9, 0x1

    .line 993
    goto :goto_20

    .line 994
    :cond_3a
    iget-object v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 995
    .line 996
    iput-object v3, v6, La/M2;->M:Ljava/util/List;

    .line 997
    .line 998
    if-lez v13, :cond_3b

    .line 999
    .line 1000
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ID()Landroid/view/View;

    .line 1001
    .line 1002
    .line 1003
    move-result-object v3

    .line 1004
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 1005
    .line 1006
    .line 1007
    move-result v3

    .line 1008
    invoke-virtual {v0, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->RL(II)V

    .line 1009
    .line 1010
    .line 1011
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 1012
    .line 1013
    iput v13, v3, La/M2;->O:I

    .line 1014
    .line 1015
    iput v5, v3, La/M2;->p:I

    .line 1016
    .line 1017
    const/4 v4, 0x0

    .line 1018
    invoke-virtual {v3, v4}, La/M2;->w(Landroid/view/View;)V

    .line 1019
    .line 1020
    .line 1021
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 1022
    .line 1023
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 1024
    .line 1025
    .line 1026
    :cond_3b
    if-lez v14, :cond_3c

    .line 1027
    .line 1028
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->xK()Landroid/view/View;

    .line 1029
    .line 1030
    .line 1031
    move-result-object v3

    .line 1032
    invoke-static {v3}, La/XG;->U(Landroid/view/View;)I

    .line 1033
    .line 1034
    .line 1035
    move-result v3

    .line 1036
    invoke-virtual {v0, v3, v8}, Landroidx/recyclerview/widget/LinearLayoutManager;->AR(II)V

    .line 1037
    .line 1038
    .line 1039
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 1040
    .line 1041
    iput v14, v3, La/M2;->O:I

    .line 1042
    .line 1043
    iput v5, v3, La/M2;->p:I

    .line 1044
    .line 1045
    const/4 v4, 0x0

    .line 1046
    invoke-virtual {v3, v4}, La/M2;->w(Landroid/view/View;)V

    .line 1047
    .line 1048
    .line 1049
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 1050
    .line 1051
    invoke-virtual {v0, v1, v3, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->B2(La/fl;La/M2;La/R8;Z)I

    .line 1052
    .line 1053
    .line 1054
    goto :goto_23

    .line 1055
    :cond_3c
    const/4 v4, 0x0

    .line 1056
    :goto_23
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 1057
    .line 1058
    iput-object v4, v1, La/M2;->M:Ljava/util/List;

    .line 1059
    .line 1060
    :cond_3d
    :goto_24
    iget-boolean v1, v2, La/R8;->X:Z

    .line 1061
    .line 1062
    if-nez v1, :cond_3e

    .line 1063
    .line 1064
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 1065
    .line 1066
    invoke-virtual {v1}, La/Tt;->X()I

    .line 1067
    .line 1068
    .line 1069
    move-result v2

    .line 1070
    iput v2, v1, La/VO;->h:I

    .line 1071
    .line 1072
    goto :goto_25

    .line 1073
    :cond_3e
    invoke-virtual {v7}, La/us;->e()V

    .line 1074
    .line 1075
    .line 1076
    :goto_25
    iget-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Z

    .line 1077
    .line 1078
    iput-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->f:Z

    .line 1079
    .line 1080
    return-void

    .line 1081
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch
.end method

.method public final rn(ILa/fl;La/R8;Z)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {v0}, La/Tt;->i()I

    move-result v0

    sub-int/2addr v0, p1

    if-lez v0, :cond_1

    neg-int v0, v0

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->fi(ILa/fl;La/R8;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {p3}, La/Tt;->i()I

    move-result p3

    sub-int/2addr p3, p1

    if-lez p3, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {p1, p3}, La/Tt;->M(I)V

    add-int/2addr p3, p2

    return p3

    :cond_0
    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final sH()I
    .locals 4

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v2, v3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Pi(IIZZ)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {v0}, La/XG;->U(Landroid/view/View;)I

    move-result v2

    :goto_0
    return v2
.end method

.method public final vz(Z)Landroid/view/View;
    .locals 3

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0}, La/XG;->q()I

    move-result v2

    :goto_0
    invoke-virtual {p0, v0, v2, p1, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->Pi(IIZZ)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    sub-int/2addr v0, v1

    const/4 v2, -0x1

    goto :goto_0
.end method

.method public final w(I)Landroid/graphics/PointF;
    .locals 3

    .line 1
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, La/XG;->U(Landroid/view/View;)I

    move-result v1

    const/4 v2, 0x1

    if-ge p1, v1, :cond_1

    move v0, v2

    :cond_1
    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    if-eq v0, p1, :cond_2

    const/4 v2, -0x1

    :cond_2
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->R:I

    const/4 v0, 0x0

    if-nez p1, :cond_3

    new-instance p1, Landroid/graphics/PointF;

    int-to-float v1, v2

    invoke-direct {p1, v1, v0}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p1

    :cond_3
    new-instance p1, Landroid/graphics/PointF;

    int-to-float v1, v2

    invoke-direct {p1, v0, v1}, Landroid/graphics/PointF;-><init>(FF)V

    return-object p1
.end method

.method public final wU(IIZLa/R8;)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 4
    .line 5
    iget v2, v1, La/Tt;->e:I

    .line 6
    .line 7
    iget-object v1, v1, La/VO;->w:La/XG;

    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget v3, v1, La/XG;->m:I

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :pswitch_0
    iget v3, v1, La/XG;->T:I

    .line 16
    .line 17
    :goto_0
    const/4 v4, 0x0

    .line 18
    const/4 v5, 0x1

    .line 19
    if-nez v3, :cond_0

    .line 20
    .line 21
    packed-switch v2, :pswitch_data_1

    .line 22
    .line 23
    .line 24
    iget v1, v1, La/XG;->K:I

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :pswitch_1
    iget v1, v1, La/XG;->y:I

    .line 28
    .line 29
    :goto_1
    if-nez v1, :cond_0

    .line 30
    .line 31
    move v1, v5

    .line 32
    goto :goto_2

    .line 33
    :cond_0
    move v1, v4

    .line 34
    :goto_2
    iput-boolean v1, v0, La/M2;->T:Z

    .line 35
    .line 36
    iput p1, v0, La/M2;->Q:I

    .line 37
    .line 38
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->Y:[I

    .line 39
    .line 40
    aput v4, v0, v4

    .line 41
    .line 42
    aput v4, v0, v5

    .line 43
    .line 44
    invoke-virtual {p0, p4, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->cM(La/R8;[I)V

    .line 45
    .line 46
    .line 47
    aget p4, v0, v4

    .line 48
    .line 49
    invoke-static {v4, p4}, Ljava/lang/Math;->max(II)I

    .line 50
    .line 51
    .line 52
    move-result p4

    .line 53
    aget v0, v0, v5

    .line 54
    .line 55
    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-ne p1, v5, :cond_1

    .line 60
    .line 61
    move v4, v5

    .line 62
    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 63
    .line 64
    if-eqz v4, :cond_2

    .line 65
    .line 66
    move v1, v0

    .line 67
    goto :goto_3

    .line 68
    :cond_2
    move v1, p4

    .line 69
    :goto_3
    iput v1, p1, La/M2;->O:I

    .line 70
    .line 71
    if-eqz v4, :cond_3

    .line 72
    .line 73
    goto :goto_4

    .line 74
    :cond_3
    move p4, v0

    .line 75
    :goto_4
    iput p4, p1, La/M2;->V:I

    .line 76
    .line 77
    const/4 p4, -0x1

    .line 78
    if-eqz v4, :cond_5

    .line 79
    .line 80
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 81
    .line 82
    iget v2, v0, La/Tt;->e:I

    .line 83
    .line 84
    iget-object v0, v0, La/VO;->w:La/XG;

    .line 85
    .line 86
    packed-switch v2, :pswitch_data_2

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0}, La/XG;->P()I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    goto :goto_5

    .line 94
    :pswitch_2
    invoke-virtual {v0}, La/XG;->Y()I

    .line 95
    .line 96
    .line 97
    move-result v0

    .line 98
    :goto_5
    add-int/2addr v0, v1

    .line 99
    iput v0, p1, La/M2;->O:I

    .line 100
    .line 101
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->xK()Landroid/view/View;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 106
    .line 107
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 108
    .line 109
    if-eqz v1, :cond_4

    .line 110
    .line 111
    move v5, p4

    .line 112
    :cond_4
    iput v5, v0, La/M2;->i:I

    .line 113
    .line 114
    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    .line 115
    .line 116
    .line 117
    move-result p4

    .line 118
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 119
    .line 120
    iget v2, v1, La/M2;->i:I

    .line 121
    .line 122
    add-int/2addr p4, v2

    .line 123
    iput p4, v0, La/M2;->e:I

    .line 124
    .line 125
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 126
    .line 127
    invoke-virtual {p4, p1}, La/Tt;->h(Landroid/view/View;)I

    .line 128
    .line 129
    .line 130
    move-result p4

    .line 131
    iput p4, v1, La/M2;->h:I

    .line 132
    .line 133
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 134
    .line 135
    invoke-virtual {p4, p1}, La/Tt;->h(Landroid/view/View;)I

    .line 136
    .line 137
    .line 138
    move-result p1

    .line 139
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 140
    .line 141
    invoke-virtual {p4}, La/Tt;->i()I

    .line 142
    .line 143
    .line 144
    move-result p4

    .line 145
    sub-int/2addr p1, p4

    .line 146
    goto :goto_7

    .line 147
    :cond_5
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->ID()Landroid/view/View;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 152
    .line 153
    iget v1, v0, La/M2;->O:I

    .line 154
    .line 155
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 156
    .line 157
    invoke-virtual {v2}, La/Tt;->Q()I

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    add-int/2addr v2, v1

    .line 162
    iput v2, v0, La/M2;->O:I

    .line 163
    .line 164
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 165
    .line 166
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    .line 167
    .line 168
    if-eqz v1, :cond_6

    .line 169
    .line 170
    goto :goto_6

    .line 171
    :cond_6
    move v5, p4

    .line 172
    :goto_6
    iput v5, v0, La/M2;->i:I

    .line 173
    .line 174
    invoke-static {p1}, La/XG;->U(Landroid/view/View;)I

    .line 175
    .line 176
    .line 177
    move-result p4

    .line 178
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 179
    .line 180
    iget v2, v1, La/M2;->i:I

    .line 181
    .line 182
    add-int/2addr p4, v2

    .line 183
    iput p4, v0, La/M2;->e:I

    .line 184
    .line 185
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 186
    .line 187
    invoke-virtual {p4, p1}, La/Tt;->e(Landroid/view/View;)I

    .line 188
    .line 189
    .line 190
    move-result p4

    .line 191
    iput p4, v1, La/M2;->h:I

    .line 192
    .line 193
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 194
    .line 195
    invoke-virtual {p4, p1}, La/Tt;->e(Landroid/view/View;)I

    .line 196
    .line 197
    .line 198
    move-result p1

    .line 199
    neg-int p1, p1

    .line 200
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    .line 201
    .line 202
    invoke-virtual {p4}, La/Tt;->Q()I

    .line 203
    .line 204
    .line 205
    move-result p4

    .line 206
    add-int/2addr p1, p4

    .line 207
    :goto_7
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->L:La/M2;

    .line 208
    .line 209
    iput p2, p4, La/M2;->p:I

    .line 210
    .line 211
    if-eqz p3, :cond_7

    .line 212
    .line 213
    sub-int/2addr p2, p1

    .line 214
    iput p2, p4, La/M2;->p:I

    .line 215
    .line 216
    :cond_7
    iput p1, p4, La/M2;->X:I

    .line 217
    .line 218
    return-void

    .line 219
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch
.end method

.method public final xK()Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->W:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La/XG;->q()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    invoke-virtual {p0, v0}, La/XG;->W(I)Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public final xY(ILa/fl;La/R8;Z)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {v0}, La/Tt;->Q()I

    move-result v0

    sub-int v0, p1, v0

    if-lez v0, :cond_1

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->fi(ILa/fl;La/R8;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    invoke-virtual {p3}, La/Tt;->Q()I

    move-result p3

    sub-int/2addr p1, p3

    if-lez p1, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->d:La/Tt;

    neg-int p4, p1

    invoke-virtual {p3, p4}, La/Tt;->M(I)V

    sub-int/2addr p2, p1

    :cond_0
    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public y(La/R8;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->GI(La/R8;)I

    move-result p1

    return p1
.end method
